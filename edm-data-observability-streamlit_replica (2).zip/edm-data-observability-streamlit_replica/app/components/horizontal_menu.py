MENU_ITEMS = [
    "Overview",
    "Timeline",
    "Flow & Network",
    "Latency",
    "Status Table",
    "Freshness",
    "Data Elements",
    "Raw Data",
    "Database Query",
]

MENU_TO_PAGE_FILE = {
    "Overview": "overview.py",
    "Timeline": "timeline.py",
    "Flow & Network": "flow_network.py",
    "Latency": "latency.py",
    "Status Table": "status_table.py",
    "Freshness": "freshness.py",
    "Data Elements": "data_elements.py",
    "Raw Data": "raw_data.py",
    "Database Query": "db_query.py",
}
