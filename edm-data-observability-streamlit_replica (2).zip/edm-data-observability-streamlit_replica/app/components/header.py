import streamlit as st


def render_header():
    st.markdown(
        """
        <div style="
            display:flex; align-items:center; justify-content:space-between;
            padding:10px 4px 8px; border-bottom:2px solid #e2e6ec; margin-bottom:6px;
        ">
            <div style="font-size:20px;font-weight:700;color:#1a1a2e;letter-spacing:-0.3px;">
                Asset &amp; Diagnostic Data Observability
            </div>
            <div style="display:flex;align-items:center;gap:10px;font-size:14px;color:#6b7280;">
                <span style="font-weight:500;">End-to-end lineage:</span>
                <span style="background:#eff6ff;color:#2563eb;padding:4px 12px;border-radius:5px;font-weight:600;font-size:14px;">&#9881; Asset</span>
                <span style="color:#9ca3af;font-size:16px;">&rarr;</span>
                <span style="background:#ecfdf5;color:#059669;padding:4px 12px;border-radius:5px;font-weight:600;font-size:14px;">&#9992; Flight</span>
                <span style="color:#9ca3af;font-size:16px;">&rarr;</span>
                <span style="background:#f5f3ff;color:#7c3aed;padding:4px 12px;border-radius:5px;font-weight:600;font-size:14px;">&#9679; Customer</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
