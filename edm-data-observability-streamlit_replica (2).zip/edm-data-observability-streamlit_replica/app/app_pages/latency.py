import streamlit as st

from utils.charts import build_latency_chart


def render():
    df = st.session_state.df

    st.subheader(" Latency Analysis")
    latency_fig = build_latency_chart(df)
    st.plotly_chart(latency_fig, use_container_width=True)
    st.caption("Latency includes processing + transfer overhead. Delays/Errors inflate values.")
