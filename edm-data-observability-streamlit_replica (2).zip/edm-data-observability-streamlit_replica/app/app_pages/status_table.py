import streamlit as st


def render():
    df = st.session_state.df

    st.subheader(" System Status Table")
    display_df = df[["system", "status", "start_time", "end_time", "latency_sec", "records", "data_size_mb"]].copy()
    display_df["start_time"] = display_df["start_time"].dt.strftime("%H:%M:%S")
    display_df["end_time"] = display_df["end_time"].dt.strftime("%H:%M:%S")
    display_df.rename(columns={"latency_sec": "latency_s", "data_size_mb": "size_MB"}, inplace=True)
    st.dataframe(display_df, use_container_width=True)
