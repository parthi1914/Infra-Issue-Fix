# Docker

```bash
docker build -t edm-data-observability .
docker run --rm -p 8501:8501 edm-data-observability
```
