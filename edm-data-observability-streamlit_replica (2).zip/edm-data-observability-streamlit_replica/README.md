# edm-data-observability-streamlit

Run:

```bash
pip install -r requirements.txt
streamlit run app/main.py
```
