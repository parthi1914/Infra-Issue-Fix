import streamlit as st
import pandas as pd

from utils.charts import build_data_elements_heatmap_v2
from services.data_element_service import (
    get_data_elements_multi,
    filter_matrix_df_by_status,
)
from services.lookup_service import get_engine_serials

# ── Page-size constants ────────────────────────────────────────────────────────
_MATRIX_ESNS_PER_PAGE = 2   # ESNs displayed per matrix page
_FAILED_ROWS_PER_PAGE = 20  # Rows displayed per Failed-Elements page


# ── Shared pagination bar ──────────────────────────────────────────────────────
def _pagination_bar(current_page: int, total_pages: int, session_key: str) -> None:
    """
    Render a professional, enterprise-style pagination bar.

    Inspired by the css-pagination design (First / Prev / numbered pages
    with ellipsis / Next / Last) and styled with GE corporate colours.

    When the user clicks a different page the function writes the new page
    number to st.session_state[session_key] and calls st.rerun() so the
    caller re-renders with the new slice.  Does nothing when total_pages <= 1.
    """
    if total_pages <= 1:
        return

    def _page_range(cur: int, total: int, wing: int = 2) -> list:
        """Return page numbers interspersed with None (= ellipsis marker)."""
        visible: set = {1, total}
        for d in range(-wing, wing + 1):
            p = cur + d
            if 1 <= p <= total:
                visible.add(p)
        result, prev = [], None
        for p in sorted(visible):
            if prev is not None and p - prev > 1:
                result.append(None)       # ellipsis placeholder
            result.append(p)
            prev = p
        return result

    page_items = _page_range(current_page, total_pages)
    # Slots: « First | ‹ Prev | [page items] | Next › | Last »
    n_slots = 4 + len(page_items)

    # Active page = red (matching css-pagination reference); hover on nav = darker red.
    # type="primary" is used exclusively for the active page button, so this override
    # is safe and will not affect other UI elements on the page.
    st.markdown("""
    <style>
    button[data-testid="baseButton-primary"] {
        background-color: #e03030 !important;
        border-color:     #e03030 !important;
        color:            #ffffff !important;
    }
    button[data-testid="baseButton-primary"]:hover {
        background-color: #b52020 !important;
        border-color:     #b52020 !important;
    }
    </style>
    """, unsafe_allow_html=True)

    # Centre the bar with flanking spacers
    pad = max(1, (16 - n_slots) // 2)
    _, mid, _ = st.columns([pad, n_slots, pad])

    with mid:
        cols = st.columns(n_slots, gap="small")
        new_page = current_page
        idx = 0

        # « First
        if cols[idx].button(
            "« First", key=f"{session_key}_first", help="First page",
            use_container_width=True
        ):
            new_page = 1
        idx += 1

        # ‹ Prev
        if cols[idx].button(
            "<", key=f"{session_key}_prev", help="Previous page",
            use_container_width=True
        ):
            new_page = max(1, current_page - 1)
        idx += 1

        # Page numbers / ellipsis
        for item in page_items:
            if item is None:
                cols[idx].markdown(
                    "<div style='text-align:center;line-height:2.2;"
                    "color:#aaa;font-size:15px;'>…</div>",
                    unsafe_allow_html=True,
                )
            else:
                btn_type = "primary" if item == current_page else "secondary"
                if cols[idx].button(
                    str(item), key=f"{session_key}_p{item}",
                    type=btn_type, use_container_width=True
                ):
                    new_page = item
            idx += 1

        # Next >
        if cols[idx].button(
            ">", key=f"{session_key}_next", help="Next page",
            use_container_width=True
        ):
            new_page = min(total_pages, current_page + 1)
        idx += 1

        # Last »
        if cols[idx].button(
            "Last »", key=f"{session_key}_last", help="Last page",
            use_container_width=True
        ):
            new_page = total_pages

    st.markdown(
        f"<div style='text-align:center;color:#888;font-size:11px;"
        f"margin-top:4px;margin-bottom:8px;'>"
        f"Page <strong>{current_page}</strong> of <strong>{total_pages}</strong>"
        f"</div>",
        unsafe_allow_html=True,
    )

    if new_page != current_page:
        st.session_state[session_key] = new_page
        st.rerun()


# ── Main render ────────────────────────────────────────────────────────────────
def render():
    """Render the Data Elements tab with multi-ESN support."""

    st.subheader("Data Elements Tracking")

    # -----------------------------------------------------------------
    # ESN multi-select dropdown: load all ESNs from SP, default to
    # sidebar selection
    # -----------------------------------------------------------------
    esn_options = get_engine_serials()
    sidebar_esns = []
    use_custom_input = st.session_state.get("use_custom_input", False)
    custom_esn = st.session_state.get("custom_esn_input", "")
    dropdown_esn = st.session_state.get("esn_dropdown", "")
    if use_custom_input and custom_esn:
        sidebar_esns = [custom_esn]
    elif not use_custom_input and dropdown_esn:
        sidebar_esns = [dropdown_esn]

    selected_esns = st.multiselect(
        "Select ESN(s)",
        options=esn_options,
        default=sidebar_esns if sidebar_esns else [],
        placeholder="Choose one or more ESNs...",
        key="de_esn_multiselect",
    )

    # Show the sidebar filter-info banner only when a single ESN is active.
    # When multiple ESNs are selected the multiselect itself provides context,
    # so the banner is redundant and is intentionally suppressed.
    if len(selected_esns) == 1:
        from utils.utils import show_filter_info
        show_filter_info()

    # -----------------------------------------------------------------
    # Guard: no ESNs selected
    # -----------------------------------------------------------------
    if not selected_esns:
        st.info("Select one or more ESNs above to view data elements.")
        return

    # -----------------------------------------------------------------
    # Fetch data from v2 SPs
    # -----------------------------------------------------------------
    result = get_data_elements_multi(selected_esns)
    matrix_df = result["matrix_df"]
    failures_df = result["failures_df"]
    summary = result["summary"]

    # Debug: show which ESNs are present in the loaded DataFrame
    if not matrix_df.empty and "esn" in matrix_df.columns:
        present_esns = sorted(matrix_df["esn"].unique())
        st.info(f"Loaded data for ESNs: {', '.join(present_esns)}")

    if matrix_df.empty:
        st.warning("No data returned for the selected ESN(s). Try different filters.")
        return

    # -----------------------------------------------------------------
    # KPI row
    # -----------------------------------------------------------------
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("ESNs", summary["esn_count"])
    k2.metric("Properties", summary["properties"])
    k3.metric("Pass", summary["passed"], delta=f"{summary['pass_rate']:.1f}%")
    k4.metric(
        "Fail", summary["failed"],
        delta=f"-{100 - summary['pass_rate']:.1f}%",
        delta_color="inverse",
    )
    k5.metric("Pass Rate", f"{summary['pass_rate']:.1f}%")

    # -----------------------------------------------------------------
    # Status filter
    # -----------------------------------------------------------------
    st.markdown("---")

    matrix_filter = st.radio(
        "Filter by Status:",
        options=["All", "Pass", "Fail"],
        index=0,
        horizontal=True,
        key="de_status_filter",
        label_visibility="collapsed",
    )

    filtered_df = filter_matrix_df_by_status(matrix_df, matrix_filter)

    if matrix_filter != "All":
        st.caption(
            f"Showing {len(filtered_df)} of {len(matrix_df)} rows ({matrix_filter} only)"
        )

    # -----------------------------------------------------------------
    # Matrix grid with pagination (2 ESNs per page)
    # -----------------------------------------------------------------
    if filtered_df.empty:
        st.success("No rows match the selected filter.")
    else:
        # Unique ESNs preserving their DataFrame order
        unique_esns: list = list(dict.fromkeys(
            filtered_df["esn"].tolist() if "esn" in filtered_df.columns else []
        ))
        total_matrix_pages = max(
            1,
            (len(unique_esns) + _MATRIX_ESNS_PER_PAGE - 1) // _MATRIX_ESNS_PER_PAGE,
        )

        # Reset matrix page whenever the ESN selection or status filter changes
        filter_sig = f"{sorted(selected_esns)}-{matrix_filter}"
        if st.session_state.get("_matrix_filter_sig") != filter_sig:
            st.session_state["matrix_esn_page"] = 1
            st.session_state["_matrix_filter_sig"] = filter_sig

        matrix_page = max(
            1,
            min(st.session_state.get("matrix_esn_page", 1), total_matrix_pages),
        )

        # Slice to the current page's ESNs
        page_esns = unique_esns[
            (matrix_page - 1) * _MATRIX_ESNS_PER_PAGE:
            matrix_page * _MATRIX_ESNS_PER_PAGE
        ]
        page_df = filtered_df[filtered_df["esn"].isin(page_esns)]

        # Render the HTML heatmap for this page's ESNs
        heatmap_html = build_data_elements_heatmap_v2(page_df)
        st.markdown(heatmap_html, unsafe_allow_html=True)

        # Professional pagination bar below the matrix
        _pagination_bar(matrix_page, total_matrix_pages, "matrix_esn_page")

    # -----------------------------------------------------------------
    # Failed Elements Details
    # -----------------------------------------------------------------
    st.markdown("---")
    st.markdown("### Failed Elements Details")

    # Mirror the same ESN-change detection used for the Matrix grid:
    # whenever the ESN selection changes, reset the Failed Elements page
    # to 1 so the grid always opens on the first page of fresh data.
    _failed_esn_sig = str(sorted(selected_esns))
    if st.session_state.get("_failed_esn_sig") != _failed_esn_sig:
        st.session_state["failed_elements_page"] = 1
        st.session_state["_failed_esn_sig"] = _failed_esn_sig

    # Build display_df: failures for the currently-selected ESNs only.
    # Filtered explicitly by selected_esns so any ESN added or removed is
    # reflected immediately on the next Streamlit rerun (no extra state needed).
    display_df = pd.DataFrame()
    if failures_df is not None and not failures_df.empty:
        filtered_failures = failures_df[failures_df["esn"].isin(selected_esns)]
        if not filtered_failures.empty:
            display_df = filtered_failures.rename(columns={
                "esn": "ESN",
                "system_name": "System",
                "property_name": "Property",
                "expected": "Expected",
                "actual_value": "Actual",
                "status": "Status",
                "reason": "Reason",
            })
            for col in ["prop_order", "Tail", "tail"]:
                if col in display_df.columns:
                    display_df = display_df.drop(columns=[col])

    if not display_df.empty:
        total_failed = len(display_df)
        st.caption(f"{total_failed} failed element(s)")

        # Corporate header styling for the dataframe
        st.markdown("""
        <style>
        [data-testid="stDataFrame"] thead tr th {
            background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%) !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            font-size: 11px !important;
            letter-spacing: 0.5px !important;
            padding: 10px 12px !important;
        }
        [data-testid="stDataFrame"] thead tr th svg {
            fill: #ffffff !important;
            stroke: #ffffff !important;
        }
        [data-testid="stDataFrame"] thead tr th:hover {
            background: linear-gradient(135deg, #2d5a87 0%, #3d6a97 100%) !important;
        }
        </style>
        """, unsafe_allow_html=True)

        # Pagination state — page is already reset to 1 above when ESNs change.
        total_failed_pages = max(
            1,
            (total_failed + _FAILED_ROWS_PER_PAGE - 1) // _FAILED_ROWS_PER_PAGE,
        )
        failed_page = max(
            1,
            min(st.session_state.get("failed_elements_page", 1), total_failed_pages),
        )

        start_idx = (failed_page - 1) * _FAILED_ROWS_PER_PAGE
        end_idx = min(start_idx + _FAILED_ROWS_PER_PAGE, total_failed)
        page_failures = display_df.iloc[start_idx:end_idx]

        st.dataframe(
            page_failures,
            use_container_width=True,
            hide_index=True,
            height=min(400, 35 * len(page_failures) + 38),
            column_config={
                "ESN": st.column_config.TextColumn("ESN", width="small"),
                "System": st.column_config.TextColumn("System", width="small"),
                "Property": st.column_config.TextColumn("Property", width="medium"),
                "Expected": st.column_config.TextColumn("Expected", width="medium"),
                "Actual": st.column_config.TextColumn("Actual", width="medium"),
                "Reason": st.column_config.TextColumn("Reason", width="large"),
            },
        )

        # Professional pagination bar for failed elements
        _pagination_bar(failed_page, total_failed_pages, "failed_elements_page")
