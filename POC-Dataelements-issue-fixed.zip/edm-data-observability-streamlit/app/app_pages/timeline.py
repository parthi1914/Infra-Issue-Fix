import streamlit as st

from utils.charts import build_timeline, build_diagnostic_timeline
from utils.utils import show_filter_info, show_no_data_message


def render():
    """
    Render Timeline tab with diagnostic data.
    Shows "No Data" message until ESN and Tail Number are selected.
    """
    st.subheader("Timeline")
    
    # Display filter info and get values
    engine_serial, tail_number, operator_code = show_filter_info()
    
    # Check if ESN and Tail Number are selected
    if not engine_serial or not tail_number:
        show_no_data_message("Timeline")
        return
    
    # Render diagnostic timeline using DB data
    fig_timeline = build_diagnostic_timeline(engine_serial, tail_number)
    st.plotly_chart(fig_timeline, use_container_width=True)
