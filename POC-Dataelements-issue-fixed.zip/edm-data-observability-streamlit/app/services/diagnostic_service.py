"""
Diagnostic Service
==================
Provides diagnostic data from the stored procedure sp_get_overview_data.

BUG FIX: Previous code used SELECT DISTINCT data_source, last_update_date
which could return multiple rows per system and pick a non-latest timestamp.
The SP now uses ROW_NUMBER() to guarantee the LATEST row per system.

Validation Logic (cascading, all inside SP):
  1FA:  PASS if last_update_date IS NOT NULL
  1FDI: PASS if (time > 1FA) AND (gap <= 30 min); PENDING if 1FA failed
  PHM:  PASS if (time > 1FDI) AND (gap <= 30 min); PENDING if 1FDI failed/pending
  FMX:  PASS if (time > PHM) AND (gap <= 30 min); PENDING if PHM failed/pending

Caching: Enabled with 60s TTL to prevent repeated SP calls within same session.
"""

import logging
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional

from services.db import is_db_available, run_query
from utils.constants import SYSTEM_FLOW

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Caching Configuration
# ---------------------------------------------------------------------------
ENABLE_CACHE = True
CACHE_TTL_SECONDS = 60


def _apply_cache(func):
    """Apply Streamlit cache only if ENABLE_CACHE is True."""
    if ENABLE_CACHE:
        return st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)(func)
    return func


# ---------------------------------------------------------------------------
# Core SP Call (cached)
# ---------------------------------------------------------------------------
@_apply_cache
def _call_sp_overview(esn: str, tail: str, operator_code: str = None) -> pd.DataFrame:
    """
    Call sp_get_overview_data and return the result.
    Returns DataFrame with columns:
        system_name, last_update_time, status, message, time_str
    """
    sql = "SELECT * FROM sp_get_overview_data(:esn, :tail, :operator_code)"
    log.info("Calling sp_get_overview_data(ESN=%s, Tail=%s, Operator=%s)", esn, tail, operator_code)
    result = run_query(sql, {"esn": esn, "tail": tail, "operator_code": operator_code})
    log.info("SP returned %d rows", len(result) if result is not None else 0)
    return result


def _get_sp_statuses(esn: str, tail: str, operator_code: str = None) -> Dict[str, Dict]:
    """
    Get system statuses from SP, mapped into the same dict structure
    that the rest of the codebase expects.

    Returns:
        {
            "1FA":  {"status": "pass", "time": datetime, "message": "...", "time_str": "..."},
            "1FDI": {"status": "fail", "time": datetime, "message": "...", "time_str": "..."},
            ...
        }
    """
    if not is_db_available() or not esn or not tail:
        return {source: _empty_status(source) for source in SYSTEM_FLOW}

    try:
        rows = _call_sp_overview(esn, tail, operator_code)
        if rows is None or rows.empty:
            return {source: _empty_status(source) for source in SYSTEM_FLOW}

        statuses = {}
        for _, row in rows.iterrows():
            sys_name = row["system_name"]
            ts = pd.to_datetime(row["last_update_time"], errors="coerce")
            statuses[sys_name] = {
                "status": row["status"],
                "time": ts if pd.notna(ts) else None,
                "message": row["message"],
                "time_str": row["time_str"],
            }

        # Ensure all 4 systems are present
        for source in SYSTEM_FLOW:
            if source not in statuses:
                statuses[source] = _empty_status(source)

        return statuses

    except Exception as exc:
        log.warning("SP call failed: %s", exc)
        return {source: _empty_status(source) for source in SYSTEM_FLOW}


def _empty_status(source: str) -> dict:
    return {
        "status": "pending",
        "time": None,
        "message": "No data",
        "time_str": "—",
    }


# ---------------------------------------------------------------------------
# Single-load entry point for Overview tab
# ---------------------------------------------------------------------------
def get_overview_statuses(
    engine_serial: str,
    diagnostic_tail: str,
    operator_code: str = None,
) -> Dict[str, Dict]:
    """
    Load system statuses ONCE — pass the result to all Overview chart functions.

    Returns the same dict as _get_sp_statuses:
        {"1FA": {"status", "time", "message", "time_str"}, ...}
    """
    return _get_sp_statuses(engine_serial, diagnostic_tail, operator_code)


# ---------------------------------------------------------------------------
# Public API (same signatures as before — no changes needed in callers)
# ---------------------------------------------------------------------------
def get_diagnostic_records(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, Optional[datetime]]:
    """
    Get latest last_update_date per system.
    Returns dict: {"1FA": datetime, "1FDI": datetime, ...}
    """
    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)
    return {source: info["time"] for source, info in statuses.items()}


def calculate_system_statuses(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, Dict]:
    """
    Calculate Pass/Fail/Pending status for each system.
    All logic now runs inside the SP.
    """
    return _get_sp_statuses(engine_serial, diagnostic_tail)


def get_status_counts(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, int]:
    """Get counts of Pass, Fail, Pending systems."""
    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)
    counts = {"pass": 0, "fail": 0, "pending": 0}
    for info in statuses.values():
        counts[info["status"]] += 1
    return counts


def get_total_and_completed(
    engine_serial: str,
    diagnostic_tail: str,
) -> Tuple[int, int]:
    """Get total systems count and completed (non-null) count."""
    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)
    total = len(SYSTEM_FLOW)
    completed = sum(1 for info in statuses.values() if info["time"] is not None)
    return total, completed


def get_last_updated_times(
    engine_serial: str,
    diagnostic_tail: str,
) -> List[Dict]:
    """Get last updated times for display in table."""
    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)
    return [
        {"system": source, "last_updated": statuses[source]["time_str"]}
        for source in SYSTEM_FLOW
    ]


def get_data_population(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, Dict]:
    """
    Get data population metrics for each system.
    Uses SP statuses: present if time is not null.
    """
    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)
    result = {}
    for source in SYSTEM_FLOW:
        has_data = statuses[source]["time"] is not None
        result[source] = {
            "present": 1.0 if has_data else 0.0,
            "missing": 0.0 if has_data else 1.0,
        }
    return result


def get_sla_timeline_data(
    engine_serial: str,
    diagnostic_tail: str,
    now: datetime = None,
) -> Dict:
    """Get SLA timeline data for visualization."""
    if now is None:
        now = datetime.utcnow()

    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)

    # Calculate freshness from last valid timestamp
    valid_times = [info["time"] for info in statuses.values() if info["time"] is not None]
    if valid_times:
        last_time = max(valid_times)
        freshness_min = (now - last_time).total_seconds() / 60.0
    else:
        freshness_min = 999

    if freshness_min < 60:
        freshness_status = "ok"
    elif freshness_min < 120:
        freshness_status = "risk"
    else:
        freshness_status = "fail"

    return {
        "systems": statuses,
        "freshness_minutes": freshness_min,
        "freshness_status": freshness_status,
    }


def get_timeline_chart_data(
    engine_serial: str,
    diagnostic_tail: str,
) -> List[Dict]:
    """Get timeline data for Gantt-style chart."""
    statuses = _get_sp_statuses(engine_serial, diagnostic_tail)
    return [
        {
            "system": source,
            "last_update": statuses[source]["time"],
            "status": statuses[source]["status"],
            "message": statuses[source]["message"],
        }
        for source in SYSTEM_FLOW
    ]
