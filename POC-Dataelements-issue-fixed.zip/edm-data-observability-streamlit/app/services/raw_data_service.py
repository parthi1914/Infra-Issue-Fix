"""
Raw Data Service
================
Fetches raw data from asset_diagnostic_stg table for the Raw Data tab.

Displays one row per system (1FA, IFS, FDM, 1FDI, PHM, SOAR, RDF, FMX)
with columns: engine_serial, tail_number, system, start_time, end_time, status, latency_sec, records, data_size_mb
"""

import logging
import pandas as pd
import streamlit as st

from services.db import is_db_available, run_query

log = logging.getLogger(__name__)

# Systems in display order
SYSTEMS = ["1FA", "IFS", "FDM", "1FDI", "PHM", "SOAR", "RDF", "FMX"]

# ---------------------------------------------------------------------------
# Caching Configuration
# ---------------------------------------------------------------------------
CACHE_TTL_SECONDS = 60


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def _fetch_raw_cached(esn: str, tail: str) -> pd.DataFrame:
    """Cached wrapper around _fetch_raw_data_from_db."""
    return _fetch_raw_data_from_db(esn, tail)


def get_raw_data(esn: str, tail: str) -> pd.DataFrame:
    """
    Fetch raw data for the given ESN and tail number.
    
    Returns a DataFrame with columns:
    - engine_serial
    - tail_number
    - system
    - start_time
    - end_time
    - status
    - latency_sec
    - records
    - data_size_mb
    """
    if not esn or not tail:
        return _empty_dataframe()
    
    if not is_db_available():
        log.warning("Database not available, returning empty dataframe")
        return _empty_dataframe()
    
    try:
        df = _fetch_raw_cached(esn, tail)
        if df.empty:
            log.info(f"No raw data found for ESN={esn}, Tail={tail}")
            return _empty_dataframe()
        return df
    except Exception as e:
        log.error(f"Error fetching raw data: {e}")
        return _empty_dataframe()


def _fetch_raw_data_from_db(esn: str, tail: str) -> pd.DataFrame:
    """
    Query asset_diagnostic_stg for raw data.
    Gets latest row per system based on last_update_date.
    """
    sql = """
    WITH ranked AS (
        SELECT 
            esn,
            diagnostic_tail,
            data_source,
            last_update_date,
            ROW_NUMBER() OVER (
                PARTITION BY data_source 
                ORDER BY last_update_date DESC NULLS LAST
            ) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = :esn
          AND diagnostic_tail = :tail
    )
    SELECT 
        esn,
        diagnostic_tail,
        data_source,
        last_update_date
    FROM ranked
    WHERE rn = 1
    ORDER BY 
        CASE data_source
            WHEN '1FA' THEN 1
            WHEN 'IFS' THEN 2
            WHEN 'FDM' THEN 3
            WHEN '1FDI' THEN 4
            WHEN 'PHM' THEN 5
            WHEN 'SOAR' THEN 6
            WHEN 'RDF' THEN 7
            WHEN 'FMX' THEN 8
            ELSE 9
        END
    """
    
    df = run_query(sql, {"esn": esn, "tail": tail})
    
    if df.empty:
        return pd.DataFrame()
    
    # Format the data for display
    result = pd.DataFrame({
        "engine_serial": df["esn"],
        "tail_number": df["diagnostic_tail"],
        "system": df["data_source"],
        "start_time": df["last_update_date"],
        "end_time": df["last_update_date"],
        "status": "",  # Empty for now
        "latency_sec": "",  # Empty for now
        "records": "",  # Empty for now
        "data_size_mb": "",  # Empty for now
    })
    
    return result


def _empty_dataframe() -> pd.DataFrame:
    """Return an empty DataFrame with the correct columns."""
    return pd.DataFrame(columns=[
        "engine_serial",
        "tail_number", 
        "system",
        "start_time",
        "end_time",
        "status",
        "latency_sec",
        "records",
        "data_size_mb"
    ])
