DROP FUNCTION IF EXISTS sp_get_filter_options(TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_filter_options(
    mode TEXT,
    value TEXT DEFAULT NULL
)
RETURNS TABLE (
    option_value TEXT,
    option_type TEXT
)
AS $$
BEGIN
    -- All ESNs
    IF mode IS NULL OR mode = 'all_esns' THEN
        RETURN QUERY
        SELECT DISTINCT esn::TEXT AS option_value, 'esn'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn IS NOT NULL;
    END IF;

    -- All Tail Numbers
    IF mode = 'all_tails' THEN
        RETURN QUERY
        SELECT DISTINCT diagnostic_tail::TEXT AS option_value, 'tail'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE diagnostic_tail IS NOT NULL;
    END IF;

    -- Tails for ESN
    IF mode = 'tails_for_esn' THEN
        RETURN QUERY
        SELECT DISTINCT diagnostic_tail::TEXT AS option_value, 'tail'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = value AND diagnostic_tail IS NOT NULL;
    END IF;

    -- ESNs for Tail
    IF mode = 'esns_for_tail' THEN
        RETURN QUERY
        SELECT DISTINCT esn::TEXT AS option_value, 'esn'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE diagnostic_tail = value AND esn IS NOT NULL;
    END IF;

    -- Operator Codes for ESN
    IF mode = 'operators_for_esn' THEN
        RETURN QUERY
        SELECT DISTINCT operator::TEXT AS option_value, 'operator'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = value AND operator IS NOT NULL;
    END IF;

    -- Operator Codes for Tail
    IF mode = 'operators_for_tail' THEN
        RETURN QUERY
        SELECT DISTINCT operator_diagnostic_code::TEXT AS option_value, 'operator'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE diagnostic_tail = value AND operator_diagnostic_code IS NOT NULL;
    END IF;

END;
$$ LANGUAGE plpgsql STABLE;