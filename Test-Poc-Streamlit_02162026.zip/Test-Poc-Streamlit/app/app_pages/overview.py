import streamlit as st
from datetime import datetime

from utils.charts import (
    build_diagnostic_pass_fail_summary,
    build_diagnostic_sla_timeline_html,
    build_diagnostic_last_updated_table,
    build_diagnostic_root_cause_panel,
    build_diagnostic_dominos_style_tracker_html,
    build_diagnostic_error_notifications,
)
from utils.utils import show_filter_info, show_no_data_message
from services.diagnostic_service import calculate_system_statuses
from services.sns_service import send_error_alert


def render():
    """
    Render Overview tab with the original design.
    Shows "No Data" message until ESN and Tail Number are selected.
    """
    st.subheader("Overview Board")
    
    # Display filter info and get values
    engine_serial, tail_number, operator_code = show_filter_info()
    
    # Check if ESN and Tail Number are selected
    if not engine_serial or not tail_number:
        show_no_data_message("Overview Board")
        return
    
    # Current time for timeline calculations — rounded to the minute so that
    # chart cache keys stay stable across re-renders within the same minute.
    now = datetime.utcnow().replace(second=0, microsecond=0)

    # ===================================================================
    # 1. Status Summary Cards (Pass, Fail, Pending) - Enterprise Style
    # ===================================================================
    status_summary = build_diagnostic_pass_fail_summary(engine_serial, tail_number)
    
    # Build cards using st.columns for reliable rendering
    card_cols = st.columns(3)
    
    card_styles = {
        "Pass": {"bg": "linear-gradient(135deg,#059669 0%,#10b981 50%,#34d399 100%)", "border": "#047857", "icon": "✔"},
        "Fail": {"bg": "linear-gradient(135deg,#dc2626 0%,#ef4444 50%,#f87171 100%)", "border": "#b91c1c", "icon": "✖"},
        "Pending": {"bg": "linear-gradient(135deg,#d97706 0%,#f59e0b 50%,#fbbf24 100%)", "border": "#b45309", "icon": "⏳"},
    }
    
    for idx, (_, r) in enumerate(status_summary.iterrows()):
        cat = r["category"]
        style = card_styles.get(cat, card_styles["Pending"])
        
        card_html = f"""
        <div style="
            background:{style['bg']};
            border-left:5px solid {style['border']};
            border-radius:12px;
            padding:20px 24px;
            display:flex;
            align-items:center;
            gap:16px;
            box-shadow:0 4px 12px rgba(0,0,0,0.08);
        ">
            <div style="
                width:52px;height:52px;
                border-radius:12px;
                background:rgba(255,255,255,0.25);
                display:flex;align-items:center;justify-content:center;
                font-size:24px;color:#fff;
            ">{style['icon']}</div>
            <div>
                <h4 style="margin:0;font-size:13px;font-weight:600;color:rgba(255,255,255,0.85);text-transform:uppercase;letter-spacing:0.5px;">{cat}</h4>
                <p style="margin:4px 0 0;font-size:32px;font-weight:800;color:#fff;line-height:1;">{int(r['count'])}</p>
                <small style="font-size:11px;color:rgba(255,255,255,0.7);">System Status</small>
            </div>
        </div>
        """
        card_cols[idx].markdown(card_html, unsafe_allow_html=True)

    # ===================================================================
    # 2. SLA Timeline (Styled)
    # ===================================================================
    st.markdown("### SLA Timeline")
    sla_html = build_diagnostic_sla_timeline_html(engine_serial, tail_number, now)
    st.markdown(sla_html, unsafe_allow_html=True)

    # ===================================================================
    # 3. Domino Style Progress
    # ===================================================================
    st.markdown("### Domino Style Progress")
    dom_html = build_diagnostic_dominos_style_tracker_html(engine_serial, tail_number, now)
    st.markdown(dom_html, unsafe_allow_html=True)

    # ===================================================================
    # 4. Error Notifications & Response Team Alerts
    # ===================================================================
    error_notif_html = build_diagnostic_error_notifications(engine_serial, tail_number, now)
    if error_notif_html:
        st.markdown("### 🚨 Error Notifications & Response Team Alerts")
        st.markdown(error_notif_html, unsafe_allow_html=True)
    
    # ===================================================================
    # 4.1 Send Alert Action (Outside alert box - Enterprise pattern)
    # ===================================================================
    # Get failed systems for the alert
    statuses = calculate_system_statuses(engine_serial, tail_number)
    failed_systems = [
        {
            "system": source,
            "reason": info.get("message", "Unknown error"),
            "last_update": info.get("time_str", "N/A")
        }
        for source, info in statuses.items()
        if info.get("status") == "fail"
    ]
    
    # Show send alert button only if there are failures
    if failed_systems:
        st.markdown("""
        <style>
        /* Style the Send Alert button - medium size */
        div[data-testid="stButton"] > button[kind="primary"] {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 8px 24px;
            font-weight: 600;
            font-size: 13px;
            box-shadow: 0 2px 8px rgba(220, 53, 69, 0.25);
            transition: all 0.2s ease;
        }
        div[data-testid="stButton"] > button[kind="primary"]:hover {
            background: linear-gradient(135deg, #c82333 0%, #a71d2a 100%);
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.4);
        }
        </style>
        """, unsafe_allow_html=True)
        
        # Right-aligned button
        col1, col2 = st.columns([5, 1])
        with col2:
            send_clicked = st.button("📧 Send Alert", key="send_alert_btn", type="primary")
        
        # Full-width success/error message
        if send_clicked:
            with st.spinner("Sending..."):
                operator_code = st.session_state.get("operator_code", "")
                result = send_error_alert(
                    engine_serial=engine_serial,
                    tail_number=tail_number,
                    operator_code=operator_code,
                    failed_systems=failed_systems
                )
            
            if result["success"]:
                st.markdown(f"""
                <div style="background: linear-gradient(90deg, #d4edda 0%, #c3e6cb 50%, #d4edda 100%); 
                            border-top: 2px solid #28a745; 
                            border-bottom: 2px solid #28a745; 
                            padding: 10px 20px; 
                            margin: 12px -1rem;
                            display: flex; 
                            align-items: center; 
                            justify-content: center;
                            gap: 12px;">
                    <span style="color: #28a745; font-size: 18px;">✅</span>
                    <span style="color: #155724; font-size: 14px; font-weight: 600;">Alert sent successfully to response team</span>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style="background: linear-gradient(90deg, #f8d7da 0%, #f5c6cb 50%, #f8d7da 100%); 
                            border-top: 2px solid #dc3545; 
                            border-bottom: 2px solid #dc3545; 
                            padding: 10px 20px; 
                            margin: 12px -1rem;
                            display: flex; 
                            align-items: center; 
                            justify-content: center;
                            gap: 12px;">
                    <span style="color: #dc3545; font-size: 18px;">❌</span>
                    <span style="color: #721c24; font-size: 14px; font-weight: 600;">Failed to send alert</span>
                    <span style="color: #721c24; font-size: 12px; opacity: 0.8;">|</span>
                    <span style="color: #721c24; font-size: 12px;">{result['message'][:80]}</span>
                </div>
                """, unsafe_allow_html=True)

    # ===================================================================
    # 5. Last Updated Times
    # ===================================================================
    st.markdown("### Last Updated Times")
    last_updated_table = build_diagnostic_last_updated_table(engine_serial, tail_number)
    st.dataframe(last_updated_table, use_container_width=True)

    # ===================================================================
    # 6. Root Cause & Governance
    # ===================================================================
    st.markdown("### Root Cause & Governance")
    governance_df = build_diagnostic_root_cause_panel(engine_serial, tail_number)
    st.dataframe(governance_df, use_container_width=True)
    st.caption("⚠️ *Disclaimer: The root cause analysis and recommended actions displayed above are system-generated hypothetical suggestions for illustrative purposes only. Actual root causes may vary and should be verified through detailed investigation.*")
