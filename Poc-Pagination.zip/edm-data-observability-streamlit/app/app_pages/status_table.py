import streamlit as st

from utils.utils import show_no_data_message


def render():
    df = st.session_state.get("df", None)
    engine_serial = st.session_state.get("engine_serial", "")
    tail_number = st.session_state.get("tail_number", "")

    st.subheader(" System Status Table")
    
    # Check if filters are selected and data is available
    if not engine_serial or not tail_number or df is None or (hasattr(df, 'empty') and df.empty):
        show_no_data_message("Status Table")
        return
    
    display_df = df[["system", "status", "start_time", "end_time", "latency_sec", "records", "data_size_mb"]].copy()
    display_df["start_time"] = display_df["start_time"].dt.strftime("%H:%M:%S")
    display_df["end_time"] = display_df["end_time"].dt.strftime("%H:%M:%S")
    display_df.rename(columns={"latency_sec": "latency_s", "data_size_mb": "size_MB"}, inplace=True)
    st.dataframe(display_df, use_container_width=True)
