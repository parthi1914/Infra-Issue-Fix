import streamlit as st
import pandas as pd

from utils.charts import build_data_elements_heatmap_v2
from services.data_element_service import (
    get_data_elements_multi,
    filter_matrix_df_by_status,
)
from services.lookup_service import get_engine_serials


def render():
    """Render the Data Elements tab with multi-ESN support."""

    st.subheader("Data Elements Tracking")

    # Show selected ESN, Operator Code as in Overview (tail removed)
    from utils.utils import show_filter_info
    show_filter_info()

    # -----------------------------------------------------------------

    # ESN multi-select dropdown: load all ESNs from sp, default to sidebar selection
    esn_options = get_engine_serials()
    # Default: sidebar ESN(s) if present, else empty
    sidebar_esns = []
    use_custom_input = st.session_state.get("use_custom_input", False)
    custom_esn = st.session_state.get("custom_esn_input", "")
    dropdown_esn = st.session_state.get("esn_dropdown", "")
    # If custom input, use that as default; else use dropdown selection if present
    if use_custom_input and custom_esn:
        sidebar_esns = [custom_esn]
    elif not use_custom_input and dropdown_esn:
        sidebar_esns = [dropdown_esn]

    selected_esns = st.multiselect(
        "Select ESN(s)",
        options=esn_options,
        default=sidebar_esns if sidebar_esns else [],
        placeholder="Choose one or more ESNs...",
        key="de_esn_multiselect",
    )
    # Tail logic removed: always ESN-only

    # -----------------------------------------------------------------
    # Guard: no ESNs selected
    # -----------------------------------------------------------------
    if not selected_esns:
        st.info("Select one or more ESNs above to view data elements.")
        return

    # -----------------------------------------------------------------
    # Fetch data from v2 SPs
    # -----------------------------------------------------------------
    result = get_data_elements_multi(selected_esns)
    matrix_df = result["matrix_df"]
    failures_df = result["failures_df"]
    summary = result["summary"]

    # Debug: Show which ESNs are present in the loaded DataFrame
    if not matrix_df.empty and "esn" in matrix_df.columns:
        present_esns = sorted(matrix_df["esn"].unique())
        st.info(f"Loaded data for ESNs: {', '.join(present_esns)}")

    if matrix_df.empty:
        st.warning("No data returned for the selected ESN(s). Try different filters.")
        return

    # -----------------------------------------------------------------
    # KPI row
    # -----------------------------------------------------------------
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("ESNs", summary["esn_count"])
    k2.metric("Properties", summary["properties"])
    k3.metric("Pass", summary["passed"], delta=f"{summary['pass_rate']:.1f}%")
    k4.metric("Fail", summary["failed"],
              delta=f"-{100 - summary['pass_rate']:.1f}%",
              delta_color="inverse")
    k5.metric("Pass Rate", f"{summary['pass_rate']:.1f}%")

    # -----------------------------------------------------------------
    # Status filter
    # -----------------------------------------------------------------
    st.markdown("---")

    matrix_filter = st.radio(
        "Filter by Status:",
        options=["All", "Pass", "Fail"],
        index=0,
        horizontal=True,
        key="de_status_filter",
        label_visibility="collapsed",
    )

    filtered_df = filter_matrix_df_by_status(matrix_df, matrix_filter)

    if matrix_filter != "All":
        st.caption(
            f"Showing {len(filtered_df)} of {len(matrix_df)} rows ({matrix_filter} only)"
        )

    # -----------------------------------------------------------------
    # Matrix grid: show HTML heatmap (restored previous grid)
    # -----------------------------------------------------------------
    if filtered_df.empty:
        st.success("No rows match the selected filter.")
    else:
        heatmap_html = build_data_elements_heatmap_v2(filtered_df)
        st.markdown(heatmap_html, unsafe_allow_html=True)

    # -----------------------------------------------------------------
    # Failed Elements Details
    # -----------------------------------------------------------------
    st.markdown("---")
    st.markdown("### Failed Elements Details")

    if failures_df is not None and not failures_df.empty:
        # Filter failures_df to only selected ESNs (if multi-ESN selected)
        filtered_failures = failures_df[failures_df["esn"].isin(selected_esns)]
        display_df = filtered_failures.rename(columns={
            "esn": "ESN",
            "system_name": "System",
            "property_name": "Property",
            "expected": "Expected",
            "actual_value": "Actual",
            "status": "Status",
            "reason": "Reason",
        })

        # Drop prop_order and Tail from display if present
        for col in ["prop_order", "Tail", "tail"]:
            if col in display_df.columns:
                display_df = display_df.drop(columns=[col])

        st.caption(f"{len(display_df)} failed element(s)")

        # Corporate header styling
        st.markdown("""
        <style>
        [data-testid="stDataFrame"] thead tr th {
            background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%) !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            font-size: 11px !important;
            letter-spacing: 0.5px !important;
            padding: 10px 12px !important;
        }
        [data-testid="stDataFrame"] thead tr th svg {
            fill: #ffffff !important;
            stroke: #ffffff !important;
        }
        [data-testid="stDataFrame"] thead tr th:hover {
            background: linear-gradient(135deg, #2d5a87 0%, #3d6a97 100%) !important;
        }
        </style>
        """, unsafe_allow_html=True)

        # Custom Pagination Bar for Failed Elements
        page_size = 20
        total_rows = len(display_df)
        total_pages = (total_rows - 1) // page_size + 1
        failed_page = st.session_state.get("failed_elements_page", 1)
        if failed_page < 1:
            failed_page = 1
        if failed_page > total_pages:
            failed_page = total_pages
        start_idx = (failed_page - 1) * page_size
        end_idx = min(start_idx + page_size, total_rows)
        st.dataframe(
            display_df.iloc[start_idx:end_idx],
            use_container_width=True,
            hide_index=True,
            height=min(400, 35 * len(display_df.iloc[start_idx:end_idx]) + 38),
            column_config={
                "ESN": st.column_config.TextColumn("ESN", width="small"),
                "System": st.column_config.TextColumn("System", width="small"),
                "Property": st.column_config.TextColumn("Property", width="medium"),
                "Expected": st.column_config.TextColumn("Expected", width="medium"),
                "Actual": st.column_config.TextColumn("Actual", width="medium"),
                "Reason": st.column_config.TextColumn("Reason", width="large"),
            },
        )
        # Simple page navigation for Failed Elements grid
        if total_pages > 1:
            new_failed_page = st.number_input("Go to Failed Elements page:", min_value=1, max_value=total_pages, value=failed_page, step=1, key="failed_elements_page_jump", label_visibility="collapsed")
            if new_failed_page != failed_page:
                st.session_state["failed_elements_page"] = new_failed_page
    else:
        st.success("All data elements passed validation!")
