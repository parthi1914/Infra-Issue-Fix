import streamlit as st


def render():
    df = st.session_state.df

    st.subheader(" Raw Simulated Data")
    st.write(df)
