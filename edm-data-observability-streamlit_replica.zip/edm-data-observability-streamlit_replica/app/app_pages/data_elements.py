import streamlit as st
import pandas as pd

from utils.constants import DATA_ELEMENTS
from utils.data_simulation import simulate_data_elements_status, simulate_data_elements_with_values
from utils.charts import build_data_elements_heatmap


def render():
    df = st.session_state.df
    engine_serial = st.session_state.engine_serial
    tail_number = st.session_state.tail_number

    st.subheader(" Data Elements Tracking (19 per system)")
    st.caption("Matrix of expected elements across systems \u2014 Hover over cells to see actual values and failure reasons")

    # Summary KPIs
    mat = simulate_data_elements_status(df)
    total = mat.size
    passed = int((mat == "Pass").sum().sum())
    failed = total - passed
    pass_rate = (passed / total * 100) if total > 0 else 0

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Elements Tracked", len(DATA_ELEMENTS))
    col2.metric("Pass Count", passed, delta=f"{pass_rate:.1f}%")
    col3.metric("Fail Count", failed, delta=f"-{100 - pass_rate:.1f}%", delta_color="inverse")
    col4.metric("Pass Rate", f"{pass_rate:.1f}%")

    # Heatmap with values and tooltips
    elements_html = build_data_elements_heatmap(df, engine_serial, tail_number)
    st.markdown(elements_html, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Failed Elements Details")

    data = simulate_data_elements_with_values(df, engine_serial, tail_number)
    failures = []
    for system, elements in data.items():
        for element, details in elements.items():
            if details["status"] == "Fail":
                failures.append({
                    "System": system,
                    "Property": element,
                    "Expected": details["expected"],
                    "Actual": details["value"],
                    "Reason": details["reason"],
                })

    if failures:
        fail_df = pd.DataFrame(failures)
        st.dataframe(fail_df, use_container_width=True, hide_index=True)
    else:
        st.success(" All data elements passed validation!")
