import streamlit as st

from utils.sidebar import setup_sidebar
from components.header import render_header
from components.kpis import render_kpis
from components.horizontal_menu import MENU_ITEMS

from app_pages import overview, timeline, flow_network, latency, status_table, freshness, data_elements, raw_data

st.set_page_config(page_title="Engine Data Observability", layout="wide")

# ---- Shared header (separate component) ----
render_header()

# ---- Sidebar controls + data computation ----
setup_sidebar()

# ---- High-level KPIs (separate component) ----
render_kpis()

# ---- Horizontal tab navigation ----
tabs = st.tabs(MENU_ITEMS)

PAGE_RENDERERS = [
    overview.render,
    timeline.render,
    flow_network.render,
    latency.render,
    status_table.render,
    freshness.render,
    data_elements.render,
    raw_data.render,
]

for tab, renderer in zip(tabs, PAGE_RENDERERS):
    with tab:
        renderer()
