import streamlit as st

from utils.constants import SYSTEM_FLOW


def render_kpis():
    """Render the high-level KPI metrics visible on every page."""
    df = st.session_state.df
    col_a, col_b, col_c, col_d = st.columns(4)
    col_a.metric("Total Systems", len(SYSTEM_FLOW))
    col_b.metric("Completed Systems", int((df.status == "Complete").sum()))
    col_c.metric("Avg Latency (s)", f"{df.latency_sec.mean():.2f}")
    col_d.metric("Total Records (current hop)", f"{int(df.records.iloc[-1]):,}")
