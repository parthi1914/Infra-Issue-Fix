import streamlit as st

MENU_ITEMS = [
    "Overview",
    "Timeline",
    "Flow & Network",
    "Latency",
    "Status Table",
    "Freshness",
    "Data Elements",
    "Raw Data",
]

# Map menu labels to the module file names inside app_pages/
MENU_TO_PAGE_FILE = {
    "Overview": "overview.py",
    "Timeline": "timeline.py",
    "Flow & Network": "flow_network.py",
    "Latency": "latency.py",
    "Status Table": "status_table.py",
    "Freshness": "freshness.py",
    "Data Elements": "data_elements.py",
    "Raw Data": "raw_data.py",
}


def render_horizontal_menu() -> str:
    """Render a horizontal tab-style menu and return the selected page label."""
    # Use st.tabs for a native horizontal menu
    tabs = st.tabs(MENU_ITEMS)

    # Determine which tab is selected by storing the mapping
    # Since st.tabs doesn't return the selected index directly,
    # we use session_state to track via on-click-like patterns.
    # Instead, we return the tab objects so main.py can render
    # page content inside each tab.
    return tabs
