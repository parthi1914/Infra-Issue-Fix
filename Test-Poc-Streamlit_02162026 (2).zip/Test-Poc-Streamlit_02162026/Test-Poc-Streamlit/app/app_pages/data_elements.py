import streamlit as st
import pandas as pd

from utils.charts import build_data_elements_heatmap
from services.data_element_service import get_data_elements_matrix
from utils.utils import show_filter_info, show_no_data_message


def filter_matrix_by_status(matrix_data: dict, status_filter: str) -> dict:
    """
    Filter matrix data based on status filter.
    
    Args:
        matrix_data: Original matrix data with systems, properties, matrix
        status_filter: "All", "Pass", or "Fail"
    
    Returns:
        Filtered matrix_data with only matching properties
    
    Logic:
        - All: Return all properties
        - Pass: Return only properties where ALL systems have Pass status
        - Fail: Return only properties where ANY system has Fail status
    """
    if status_filter == "All":
        return matrix_data
    
    systems = matrix_data["systems"]
    properties = matrix_data["properties"]
    matrix = matrix_data["matrix"]
    
    filtered_properties = []
    filtered_matrix = {}
    
    for prop in properties:
        prop_data = matrix.get(prop, {})
        
        # Check status of all systems for this property
        all_pass = True
        any_fail = False
        
        for system in systems:
            cell = prop_data.get(system, {"status": "Fail"})
            if cell.get("status") == "Fail":
                any_fail = True
                all_pass = False
        
        # Apply filter logic
        include_row = False
        if status_filter == "Pass" and all_pass:
            include_row = True
        elif status_filter == "Fail" and any_fail:
            include_row = True
        
        if include_row:
            filtered_properties.append(prop)
            filtered_matrix[prop] = prop_data
    
    # Recalculate summary for filtered data
    passed = 0
    failed = 0
    for prop in filtered_properties:
        prop_data = filtered_matrix.get(prop, {})
        for system in systems:
            cell = prop_data.get(system, {"status": "Fail"})
            if cell.get("status") == "Pass":
                passed += 1
            else:
                failed += 1
    
    total = passed + failed
    pass_rate = (passed / total * 100) if total > 0 else 0
    
    return {
        "systems": systems,
        "properties": filtered_properties,
        "matrix": filtered_matrix,
        "summary": {
            "passed": passed,
            "failed": failed,
            "pass_rate": pass_rate
        },
        "failures": [f for f in matrix_data.get("failures", []) if f.get("property") in filtered_properties]
    }


def render():
    """Render the Data Elements tab with matrix grid and failure details."""
    df = st.session_state.get("df", pd.DataFrame())

    st.subheader(" Data Elements Tracking")
    
    # Display filter info and get values
    engine_serial, tail_number, operator_code = show_filter_info()
    
    # Validate inputs
    if not engine_serial or not tail_number:
        show_no_data_message("Data Elements")
        return
    
    st.caption("Matrix of data elements across systems — Hover over cells to see actual values and failure reasons")

    # Get matrix data from service
    matrix_data = get_data_elements_matrix(engine_serial, tail_number)
    summary = matrix_data["summary"]

    # Display KPIs
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Properties Tracked", len(matrix_data["properties"]))
    col2.metric("Pass Count", summary["passed"], delta=f"{summary['pass_rate']:.1f}%")
    col3.metric("Fail Count", summary["failed"], delta=f"-{100 - summary['pass_rate']:.1f}%", delta_color="inverse")
    col4.metric("Pass Rate", f"{summary['pass_rate']:.1f}%")

    # =========================================================================
    # Matrix Status Filter
    # =========================================================================
    st.markdown("---")
    
    # Filter styling
    st.markdown("""
    <style>
    .matrix-filter-label {
        font-weight: 600;
        color: #1e3a5f;
        font-size: 14px;
        margin-bottom: 8px;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown("<div class='matrix-filter-label'>📊 Filter Matrix by Status</div>", unsafe_allow_html=True)
    
    # Radio button filter
    matrix_filter = st.radio(
        "Show rows:",
        options=["All", "Pass", "Fail"],
        index=0,
        horizontal=True,
        key="matrix_status_filter",
        label_visibility="collapsed"
    )
    
    # Filter the matrix data based on selection
    filtered_matrix_data = filter_matrix_by_status(matrix_data, matrix_filter)
    
    # Show filtered count
    original_count = len(matrix_data["properties"])
    filtered_count = len(filtered_matrix_data["properties"])
    if matrix_filter != "All":
        st.caption(f"Showing {filtered_count} of {original_count} properties ({matrix_filter} only)")

    # Render the matrix heatmap with filtered data
    elements_html = build_data_elements_heatmap(
        df, engine_serial, tail_number, matrix_data=filtered_matrix_data
    )
    st.markdown(elements_html, unsafe_allow_html=True)

    # Failed Elements Details section
    st.markdown("---")
    st.markdown("### Failed Elements Details")

    failures = matrix_data["failures"]
    if failures:
        fail_df = pd.DataFrame(failures).rename(columns={
            "system": "System",
            "property": "Property",
            "expected": "Expected",
            "actual": "Actual",
            "reason": "Reason"
        })
        
        total_rows = len(fail_df)
        rows_per_page = 20
        
        # Initialize session state
        if "fail_current_page" not in st.session_state:
            st.session_state.fail_current_page = 1
        
        total_pages = max(1, (total_rows + rows_per_page - 1) // rows_per_page)
        
        # Ensure current page is within bounds
        current_page = min(max(1, st.session_state.fail_current_page), total_pages)
        if current_page != st.session_state.fail_current_page:
            st.session_state.fail_current_page = current_page
        
        # Calculate slice indices
        start_idx = (current_page - 1) * rows_per_page
        end_idx = min(start_idx + rows_per_page, total_rows)
        
        # Display record count
        st.caption(f"Showing {start_idx + 1}–{end_idx} of {total_rows} records")
        
        # Custom CSS for dataframe header styling
        # Corporate Navy header with white text, sort indicators remain visible
        st.markdown("""
        <style>
        /* Style the dataframe header row */
        [data-testid="stDataFrame"] thead tr th {
            background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%) !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            font-size: 11px !important;
            letter-spacing: 0.5px !important;
            padding: 10px 12px !important;
        }
        /* Ensure sort icons remain visible (white) */
        [data-testid="stDataFrame"] thead tr th svg {
            fill: #ffffff !important;
            stroke: #ffffff !important;
        }
        [data-testid="stDataFrame"] thead tr th button {
            color: #ffffff !important;
        }
        /* Hover effect on header */
        [data-testid="stDataFrame"] thead tr th:hover {
            background: linear-gradient(135deg, #2d5a87 0%, #3d6a97 100%) !important;
        }
        </style>
        """, unsafe_allow_html=True)
        
        # Data table
        page_df = fail_df.iloc[start_idx:end_idx]
        st.dataframe(
            page_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "System": st.column_config.TextColumn("System", width="small"),
                "Property": st.column_config.TextColumn("Property", width="medium"),
                "Expected": st.column_config.TextColumn("Expected", width="medium"),
                "Actual": st.column_config.TextColumn("Actual", width="medium"),
                "Reason": st.column_config.TextColumn("Reason", width="large"),
            }
        )
        
        # =====================================================================
        # Numbered Pagination Below Grid - Right Aligned
        # =====================================================================
        
        # Build page numbers to display (show max 7 pages with ellipsis)
        def get_page_range(current, total):
            if total <= 7:
                return list(range(1, total + 1))
            
            pages = []
            if current <= 4:
                pages = [1, 2, 3, 4, 5, '...', total]
            elif current >= total - 3:
                pages = [1, '...', total-4, total-3, total-2, total-1, total]
            else:
                pages = [1, '...', current-1, current, current+1, '...', total]
            return pages
        
        page_range = get_page_range(current_page, total_pages)
        
        # Create columns: spacer + PREV (wider) + page numbers + NEXT (wider)
        # col_widths: [spacer, PREV, page1, page2, ..., NEXT]
        col_widths = [4] + [1] + [0.5] * len(page_range) + [1]
        cols = st.columns(col_widths)
        
        # cols[0] = spacer (empty)
        # cols[1] = PREV button
        # cols[2:-1] = page number buttons
        # cols[-1] = NEXT button
        
        with cols[1]:
            if st.button("◀ PREV", key="pn_prev", disabled=(current_page <= 1)):
                st.session_state.fail_current_page = current_page - 1
                st.rerun()
        
        for i, p in enumerate(page_range):
            with cols[i + 2]:
                if p != '...':
                    if st.button(str(p), key=f"pn_{p}", type="primary" if p == current_page else "secondary"):
                        if p != current_page:
                            st.session_state.fail_current_page = p
                            st.rerun()
                else:
                    st.markdown("<div style='text-align:center; padding-top:6px;'>...</div>", unsafe_allow_html=True)
        
        with cols[-1]:
            if st.button("NEXT ▶", key="pn_next", disabled=(current_page >= total_pages)):
                st.session_state.fail_current_page = current_page + 1
                st.rerun()
        
    else:
        st.success(" All data elements passed validation!")
