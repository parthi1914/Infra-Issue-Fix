# Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022-2025)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import inspect
import textwrap

import streamlit as st


def show_no_data_message(tab_name: str = ""):
    """
    Display a styled 'No Data Available' message.
    Used when filters are not selected or data is empty.
    """
    st.markdown(f"""
    <div style="
        border: 2px dashed #e0e0e0;
        border-radius: 12px;
        padding: 60px 40px;
        text-align: center;
        background: linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%);
        margin: 20px 0;
    ">
        <div style="font-size: 60px; margin-bottom: 20px;">📊</div>
        <h3 style="color: #333; margin-bottom: 10px;">No Data Available</h3>
        <p style="color: #666;">
            Please select an <span style="color: #667eea; font-weight: 600;">Engine Serial (ESN)</span> 
            and <span style="color: #667eea; font-weight: 600;">Tail Number</span> 
            from the sidebar filters to view the {tab_name}.
        </p>
    </div>
    """, unsafe_allow_html=True)


def show_filter_info():
    """
    Display selected filter values (ESN, Tail, Operator Code) as a styled banner.
    Returns the filter values tuple (engine_serial, tail_number, operator_code).
    """
    engine_serial = st.session_state.get("engine_serial", "")
    tail_number = st.session_state.get("tail_number", "")
    operator_code = st.session_state.get("operator_code", "")
    
    if engine_serial and tail_number:
        st.markdown(f"""
        <div style="
            background: linear-gradient(135deg, #f0f4ff 0%, #e8f0fe 100%);
            border-left: 4px solid #667eea;
            border-radius: 8px;
            padding: 10px 16px;
            margin-bottom: 16px;
            display: flex;
            gap: 24px;
            align-items: center;
            flex-wrap: wrap;
        ">
            <span style="font-size: 13px; color: #475569;">
                <strong style="color: #667eea;">ESN:</strong> {engine_serial}
            </span>
            <span style="font-size: 13px; color: #475569;">
                <strong style="color: #667eea;">Tail:</strong> {tail_number}
            </span>
            <span style="font-size: 13px; color: #475569;">
                <strong style="color: #667eea;">Operator Code:</strong> {operator_code or '—'}
            </span>
        </div>
        """, unsafe_allow_html=True)
    
    return engine_serial, tail_number, operator_code


def show_code(demo):
    """Showing the code of the demo."""
    show_code_flag = st.sidebar.checkbox("Show code", True)
    if show_code_flag:
        # Showing the code of the demo.
        st.markdown("## Code")
        sourcelines, _ = inspect.getsourcelines(demo)
        st.code(textwrap.dedent("".join(sourcelines[1:])))