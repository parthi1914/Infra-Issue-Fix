-- ============================================================================
-- Stored Procedure: sp_get_data_elements_matrix
-- ============================================================================
-- Replaces Python-side matrix logic for Data Elements tab.
-- Handles all 19 properties, 4 systems, validation, and summary in one call.
--
-- Performance: Single table scan → LATERAL unpivot → window-based 1FA lookup
-- Scales to 100K+ records via ROW_NUMBER partition pruning.
--
-- Usage:
--   SELECT * FROM sp_get_data_elements_matrix('ESN123', 'HZ-FAB');
-- ============================================================================

DROP FUNCTION IF EXISTS sp_get_data_elements_matrix(TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_data_elements_matrix(
    p_esn  TEXT,
    p_tail TEXT
)
RETURNS TABLE (
    property_name TEXT,
    system_name   TEXT,
    actual_value  TEXT,
    expected      TEXT,
    status        TEXT,
    reason        TEXT
)
AS $$
BEGIN
    RETURN QUERY

    WITH
    -- Step 1: Get latest row per system (single scan with ROW_NUMBER)
    latest AS (
        SELECT
            data_source,
            esn,
            diagnostic_installation_date,
            diagnostic_tail,
            engine_position,
            installation_date,
            last_update_date,
            n1_modifier,
            operator,
            monitor,
            operator_diagnostic_code,
            tail_number_aircraft_id,
            engine_model,
            engine_type,
            engine_family_model_series,
            aircraft_delivery_date,
            aircraft_family,
            aircraft_model,
            aircraft_series,
            installation_history,
            ROW_NUMBER() OVER (
                PARTITION BY data_source
                ORDER BY last_update_date DESC NULLS LAST
            ) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn
          AND diagnostic_tail = p_tail
    ),

    -- Step 2: Only keep rn=1 (latest per system)
    systems AS (
        SELECT * FROM latest WHERE rn = 1
    ),

    -- Step 3: Unpivot all 19 columns into rows using LATERAL VALUES (single pass)
    unpivoted AS (
        SELECT
            s.data_source                    AS sys,
            props.prop_name                  AS prop,
            props.raw_val                    AS raw_val
        FROM systems s
        CROSS JOIN LATERAL (
            VALUES
                ('ESN',                          s.esn::TEXT),
                ('Diagnostic Installation Date', s.diagnostic_installation_date::TEXT),
                ('Diagnostic Tail',              s.diagnostic_tail::TEXT),
                ('Engine Position',              s.engine_position::TEXT),
                ('Installation Date',            s.installation_date::TEXT),
                ('Last Updated Date',            s.last_update_date::TEXT),
                ('N1 Modifier',                  s.n1_modifier::TEXT),
                ('Operator',                     s.operator::TEXT),
                ('Monitor',                      s.monitor::TEXT),
                ('Operator Diagnostic Code',     s.operator_diagnostic_code::TEXT),
                ('Tail Number Aircraft ID',      s.tail_number_aircraft_id::TEXT),
                ('Engine Model',                 s.engine_model::TEXT),
                ('Engine Type',                  s.engine_type::TEXT),
                ('Engine Family Model Series',   s.engine_family_model_series::TEXT),
                ('Aircraft Delivery Date',       s.aircraft_delivery_date::TEXT),
                ('Aircraft Family',              s.aircraft_family::TEXT),
                ('Aircraft Model',               s.aircraft_model::TEXT),
                ('Aircraft Series',              s.aircraft_series::TEXT),
                ('Installation History',         s.installation_history::TEXT)
        ) AS props(prop_name, raw_val)
    ),

    -- Step 4: Normalise values (NULL / empty / NaN / None → 'NULL', trim whitespace)
    normalised AS (
        SELECT
            sys,
            prop,
            CASE
                WHEN raw_val IS NULL THEN 'NULL'
                WHEN TRIM(raw_val) = '' THEN 'NULL'
                WHEN UPPER(TRIM(raw_val)) IN ('NONE', 'NAN', 'NAT') THEN 'NULL'
                ELSE TRIM(raw_val)
            END AS val
        FROM unpivoted
    ),

    -- Step 5: Flag invalid placeholder dates
    with_flags AS (
        SELECT
            sys,
            prop,
            val,
            CASE
                WHEN val <> 'NULL'
                 AND (   val LIKE '%9999-01-01%'
                      OR val LIKE '%9999-12-31%'
                      OR val LIKE '%1900-01-01%'
                      OR val LIKE '%0001-01-01%' )
                THEN TRUE
                ELSE FALSE
            END AS is_invalid_date
        FROM normalised
    ),

    -- Step 6: Determine expected value per property
    --   Priority: 1FA (if valid) → 1FDI → PHM → FMX → '—'
    expected_calc AS (
        SELECT
            prop,
            COALESCE(
                -- 1FA value if valid
                MAX(CASE WHEN sys = '1FA'  AND val <> 'NULL' AND NOT is_invalid_date THEN val END),
                -- Fallback: first valid from other systems in order
                MAX(CASE WHEN sys = '1FDI' AND val <> 'NULL' AND NOT is_invalid_date THEN val END),
                MAX(CASE WHEN sys = 'PHM'  AND val <> 'NULL' AND NOT is_invalid_date THEN val END),
                MAX(CASE WHEN sys = 'FMX'  AND val <> 'NULL' AND NOT is_invalid_date THEN val END),
                '—'
            ) AS expected_val
        FROM with_flags
        GROUP BY prop
    ),

    -- Step 7: Join back and compute status + reason
    validated AS (
        SELECT
            f.prop                          AS property_name,
            f.sys                           AS system_name,
            f.val                           AS actual_value,
            e.expected_val                  AS expected,
            -- Status logic (mirrors Python _validate_value)
            CASE
                -- NULL → Fail
                WHEN f.val = 'NULL'
                    THEN 'Fail'
                -- Invalid placeholder date → Fail
                WHEN f.is_invalid_date
                    THEN 'Fail'
                -- 1FA with valid value → always Pass
                WHEN f.sys = '1FA'
                    THEN 'Pass'
                -- No baseline → Pass
                WHEN e.expected_val = '—'
                    THEN 'Pass'
                -- Match → Pass
                WHEN f.val = e.expected_val
                    THEN 'Pass'
                -- Mismatch → Fail
                ELSE 'Fail'
            END                             AS status,
            -- Reason
            CASE
                WHEN f.val = 'NULL'
                    THEN 'Null value found'
                WHEN f.is_invalid_date
                    THEN 'Invalid placeholder date: ' || f.val
                WHEN f.sys = '1FA'
                    THEN ''
                WHEN e.expected_val = '—'
                    THEN ''
                WHEN f.val = e.expected_val
                    THEN ''
                ELSE 'Value mismatch: expected ''' || e.expected_val || ''' but got ''' || f.val || ''''
            END                             AS reason
        FROM with_flags f
        JOIN expected_calc e ON e.prop = f.prop
    )

    -- Final output ordered by property display order then system order
    SELECT
        v.property_name,
        v.system_name,
        v.actual_value,
        v.expected,
        v.status,
        v.reason
    FROM validated v
    ORDER BY
        CASE v.property_name
            WHEN 'ESN'                          THEN  1
            WHEN 'Diagnostic Installation Date' THEN  2
            WHEN 'Diagnostic Tail'              THEN  3
            WHEN 'Engine Position'              THEN  4
            WHEN 'Installation Date'            THEN  5
            WHEN 'Last Updated Date'            THEN  6
            WHEN 'N1 Modifier'                  THEN  7
            WHEN 'Operator'                     THEN  8
            WHEN 'Monitor'                      THEN  9
            WHEN 'Operator Diagnostic Code'     THEN 10
            WHEN 'Tail Number Aircraft ID'      THEN 11
            WHEN 'Engine Model'                 THEN 12
            WHEN 'Engine Type'                  THEN 13
            WHEN 'Engine Family Model Series'   THEN 14
            WHEN 'Aircraft Delivery Date'       THEN 15
            WHEN 'Aircraft Family'              THEN 16
            WHEN 'Aircraft Model'               THEN 17
            WHEN 'Aircraft Series'              THEN 18
            WHEN 'Installation History'         THEN 19
            ELSE 99
        END,
        CASE v.system_name
            WHEN '1FA'  THEN 1
            WHEN '1FDI' THEN 2
            WHEN 'PHM'  THEN 3
            WHEN 'FMX'  THEN 4
            ELSE 5
        END;

END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================================
-- RECOMMENDED INDEX for performance at 100K+ scale
-- ============================================================================
-- This covering index ensures the ROW_NUMBER query does an index-only scan:
--
-- CREATE INDEX IF NOT EXISTS idx_asset_diag_esn_tail_latest
--     ON edm_raw.asset_diagnostic_stg (esn, diagnostic_tail, data_source, last_update_date DESC NULLS LAST);
--
-- Run this on your database if it doesn't already exist.
-- ============================================================================
