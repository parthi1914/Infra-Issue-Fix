-- ============================================================================
-- Stored Procedure: sp_get_filter_options
-- ============================================================================
-- Returns filter dropdown data for sidebar (ESN, Tail, Operator).
-- One SP handles all lookup modes to minimize round-trips.
--
-- Modes:
--   'all_esns'           → all distinct ESNs
--   'all_tails'          → all distinct tails
--   'tails_for_esn'      → tails for a given ESN
--   'esns_for_tail'      → ESNs for a given tail
--   'operators_for_esn'  → operator codes for a given ESN
--   'operators_for_tail' → operator codes for a given tail
--
-- Usage:
--   SELECT * FROM sp_get_filter_options('all_esns', NULL);
--   SELECT * FROM sp_get_filter_options('tails_for_esn', '729497');
-- ============================================================================

DROP FUNCTION IF EXISTS sp_get_filter_options(TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_filter_options(
    p_mode  TEXT,
    p_value TEXT DEFAULT NULL
)
RETURNS TABLE (option_value TEXT)
AS $$
BEGIN
    IF p_mode = 'all_esns' THEN
        RETURN QUERY
        SELECT DISTINCT a.esn::TEXT
        FROM edm_raw.asset_diagnostic_stg a
        WHERE a.esn IS NOT NULL AND TRIM(a.esn) <> ''
        ORDER BY 1;

    ELSIF p_mode = 'all_tails' THEN
        RETURN QUERY
        SELECT DISTINCT a.diagnostic_tail::TEXT
        FROM edm_raw.asset_diagnostic_stg a
        WHERE a.diagnostic_tail IS NOT NULL AND TRIM(a.diagnostic_tail) <> ''
        ORDER BY 1;

    ELSIF p_mode = 'tails_for_esn' THEN
        RETURN QUERY
        SELECT DISTINCT a.diagnostic_tail::TEXT
        FROM edm_raw.asset_diagnostic_stg a
        WHERE a.esn = p_value
          AND a.diagnostic_tail IS NOT NULL AND TRIM(a.diagnostic_tail) <> ''
        ORDER BY 1;

    ELSIF p_mode = 'esns_for_tail' THEN
        RETURN QUERY
        SELECT DISTINCT a.esn::TEXT
        FROM edm_raw.asset_diagnostic_stg a
        WHERE a.diagnostic_tail = p_value
          AND a.esn IS NOT NULL AND TRIM(a.esn) <> ''
        ORDER BY 1;

    ELSIF p_mode = 'operators_for_esn' THEN
        RETURN QUERY
        SELECT DISTINCT a.operator_diagnostic_code::TEXT
        FROM edm_raw.asset_diagnostic_stg a
        WHERE a.esn = p_value
          AND a.operator_diagnostic_code IS NOT NULL
          AND TRIM(a.operator_diagnostic_code) <> ''
        ORDER BY 1;

    ELSIF p_mode = 'operators_for_tail' THEN
        RETURN QUERY
        SELECT DISTINCT a.operator_diagnostic_code::TEXT
        FROM edm_raw.asset_diagnostic_stg a
        WHERE a.diagnostic_tail = p_value
          AND a.operator_diagnostic_code IS NOT NULL
          AND TRIM(a.operator_diagnostic_code) <> ''
        ORDER BY 1;

    END IF;
END;
$$ LANGUAGE plpgsql STABLE;
