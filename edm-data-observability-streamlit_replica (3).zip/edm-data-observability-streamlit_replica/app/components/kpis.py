import streamlit as st

from utils.constants import SYSTEM_FLOW

_CARD_CSS = """
<style>
.kpi-row {
    display: flex;
    gap: 12px;
    margin: 4px 0 10px;
}
.kpi-card {
    flex: 1;
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 12px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}
.kpi-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    flex-shrink: 0;
}
.kpi-text .kpi-label {
    font-size: 11px;
    font-weight: 600;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin: 0;
}
.kpi-text .kpi-value {
    font-size: 22px;
    font-weight: 700;
    color: #111827;
    margin: 0;
    line-height: 1.2;
}
</style>
"""

_CARD_TEMPLATE = """
<div class="kpi-card">
    <div class="kpi-icon" style="background:{bg};color:{fg};">{icon}</div>
    <div class="kpi-text">
        <p class="kpi-label">{label}</p>
        <p class="kpi-value">{value}</p>
    </div>
</div>
"""


def render_kpis():
    df = st.session_state.df

    total_systems = len(SYSTEM_FLOW)
    completed = int((df.status == "Complete").sum())
    avg_latency = f"{df.latency_sec.mean():.2f}s"
    total_records = f"{int(df.records.iloc[-1]):,}"

    cards = [
        {"label": "Total Systems",   "value": total_systems, "icon": "&#9670;", "bg": "#eff6ff", "fg": "#2563eb"},
        {"label": "Completed",       "value": completed,     "icon": "&#10003;","bg": "#ecfdf5", "fg": "#059669"},
        {"label": "Avg Latency",     "value": avg_latency,   "icon": "&#9202;", "bg": "#fefce8", "fg": "#d97706"},
        {"label": "Total Records",   "value": total_records,  "icon": "&#9776;", "bg": "#f5f3ff", "fg": "#7c3aed"},
    ]

    html = _CARD_CSS + '<div class="kpi-row">'
    for c in cards:
        html += _CARD_TEMPLATE.format(**c)
    html += "</div>"

    st.markdown(html, unsafe_allow_html=True)
