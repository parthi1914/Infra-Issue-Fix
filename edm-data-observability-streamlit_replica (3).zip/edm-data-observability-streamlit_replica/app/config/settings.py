import logging
import streamlit as st

log = logging.getLogger(__name__)

_DEFAULT_SECRET_NAME = "av-edm-dev-rds-rpt-credentials"
_DEFAULT_REGION = "us-east-1"
_DEFAULT_PROFILE = None


def _has_aws_config() -> bool:
    try:
        aws_cfg = dict(st.secrets.get("aws", {}))
        return bool(aws_cfg)
    except Exception:
        return False


def _try_aws_secrets_manager() -> str | None:
    if not _has_aws_config():
        return None

    try:
        from config.secrets_manager import get_connection_string

        aws_cfg = dict(st.secrets["aws"])
        secret_name = aws_cfg.get("secret_name", _DEFAULT_SECRET_NAME)
        region = aws_cfg.get("region", _DEFAULT_REGION)
        profile = aws_cfg.get("profile", _DEFAULT_PROFILE)

        url = get_connection_string(secret_name, region, profile)
        log.info("DB credentials loaded from AWS Secrets Manager")
        return url
    except Exception as exc:
        log.debug("AWS Secrets Manager unavailable: %s", exc)
        return None


def _try_streamlit_secrets() -> str | None:
    try:
        cfg = st.secrets["postgres"]
        url = (
            f"postgresql+psycopg2://{cfg['user']}:{cfg['password']}"
            f"@{cfg['host']}:{cfg.get('port', 5432)}/{cfg['dbname']}"
        )
        log.info("DB credentials loaded from secrets.toml")
        return url
    except Exception:
        return None


def get_database_url() -> str | None:
    return _try_aws_secrets_manager() or _try_streamlit_secrets()


def get_connection_info() -> dict | None:
    if _has_aws_config():
        try:
            from config.secrets_manager import get_rds_credentials

            aws_cfg = dict(st.secrets["aws"])
            secret_name = aws_cfg.get("secret_name", _DEFAULT_SECRET_NAME)
            region = aws_cfg.get("region", _DEFAULT_REGION)
            profile = aws_cfg.get("profile", _DEFAULT_PROFILE)

            creds = get_rds_credentials(secret_name, region, profile)
            return {
                "host": creds["host"],
                "port": creds.get("port", 5432),
                "dbname": creds["db_name"],
                "user": creds["username"],
                "source": "AWS Secrets Manager",
            }
        except Exception:
            pass

    try:
        cfg = st.secrets["postgres"]
        return {
            "host": cfg["host"],
            "port": cfg.get("port", 5432),
            "dbname": cfg["dbname"],
            "user": cfg["user"],
            "source": "secrets.toml",
        }
    except Exception:
        pass

    return None
