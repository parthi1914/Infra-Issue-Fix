import streamlit as st

from utils.charts import build_timeline


def render():
    df = st.session_state.df

    st.subheader(" Timeline")
    fig_timeline = build_timeline(df)
    st.plotly_chart(fig_timeline, use_container_width=True)
