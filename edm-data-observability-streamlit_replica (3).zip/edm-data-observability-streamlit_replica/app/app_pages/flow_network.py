import streamlit as st

from utils.charts import build_sankey, build_network_graph


def render():
    df = st.session_state.df

    st.subheader(" Flow & Network")
    col1, col2 = st.columns([2, 1])
    with col1:
        sankey = build_sankey(df)
        st.plotly_chart(sankey, use_container_width=True)
    with col2:
        network_fig = build_network_graph(df)
        st.plotly_chart(network_fig, use_container_width=True)
