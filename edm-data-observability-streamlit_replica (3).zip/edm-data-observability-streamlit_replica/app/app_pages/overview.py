import streamlit as st
from datetime import datetime

from utils.charts import (
    build_status_summary,
    build_population_pies,
    build_sla_dominos_html,
    build_dominos_style_tracker_html,
    build_error_notifications,
    build_last_updated_table,
    fake_root_cause_panel,
)


def render():
    df = st.session_state.df
    now = st.session_state.now
    window_hours = st.session_state.window_hours

    st.subheader(" Overview Board")

    status_summary = build_status_summary(df)
    card_cols = st.columns(4)
    mapping_to_col = {"Fail": 0, "Pass": 1, "Pending": 2, "Processing": 3}
    for _, r in status_summary.iterrows():
        cat = r["category"]
        idx = mapping_to_col[cat]
        bg = {
            "Fail": "#ffe5e0",
            "Pass": "#e3f9e5",
            "Pending": "#e0efff",
            "Processing": "#e0efff",
        }[cat]
        card_cols[idx].markdown(
            f"<div style='padding:12px;border-radius:8px;background:{bg};'>"
            f"<h4 style='margin:0'>{cat}</h4>"
            f"<p style='font-size:28px;margin:0;font-weight:700'>{int(r['count'])}</p>"
            f"<small>System Status</small></div>",
            unsafe_allow_html=True,
        )

    st.markdown("### Data Population by System")
    population_pies = build_population_pies(df)
    pie_row = st.columns(len(population_pies))
    for i, fig in enumerate(population_pies):
        pie_row[i].plotly_chart(fig, use_container_width=True)

    st.markdown("### SLA Timeline (Styled)")
    sla_html_tracker = build_sla_dominos_html(df, now, hours=window_hours)
    st.markdown(sla_html_tracker, unsafe_allow_html=True)

    st.markdown("### Domino Style Progress")
    dom_html = build_dominos_style_tracker_html(df, datetime.utcnow())
    st.markdown(dom_html, unsafe_allow_html=True)

    error_notif_html = build_error_notifications(df, now)
    if error_notif_html:
        st.markdown("### Error Notifications & Response Team Alerts")
        st.components.v1.html(error_notif_html, height=380, scrolling=False)

    st.markdown("### Last Updated Times")
    last_updated_table = build_last_updated_table(df)
    st.dataframe(last_updated_table, use_container_width=True)

    st.markdown("### Root Cause & Governance")
    governance_df = fake_root_cause_panel()
    st.dataframe(governance_df, use_container_width=True)
