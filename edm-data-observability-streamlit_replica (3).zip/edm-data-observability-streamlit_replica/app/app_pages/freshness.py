import streamlit as st

from utils.charts import freshness_gauge, build_simple_freshness_card, build_freshness_timeline


def render():
    df = st.session_state.df
    now = st.session_state.now

    st.subheader(" Data Freshness")

    view_option = st.radio(
        "Choose View:", ["Simple Card", "Timeline", "Gauge (Original)"],
        horizontal=True, index=0,
    )

    if view_option == "Simple Card":
        freshness_card = build_simple_freshness_card(df, now)
        st.markdown(freshness_card, unsafe_allow_html=True)
    elif view_option == "Timeline":
        freshness_timeline_fig = build_freshness_timeline(df, now)
        st.plotly_chart(freshness_timeline_fig, use_container_width=True)
    else:
        freshness_fig = freshness_gauge(df, now)
        st.plotly_chart(freshness_fig, use_container_width=True)

    st.markdown("---")
    st.markdown("### Reading the Gauge")
    st.markdown("""
**Shows**: Minutes since last data completion (FMX system)

- **Green (0-60 min)**: Fresh \u2014 within SLA
- **Amber (60-120 min)**: Aging \u2014 check for delays
- **Red (120+ min)**: Stale \u2014 investigate immediately
""")
