import streamlit as st
import streamlit.components.v1 as components
import random
import numpy as np
from datetime import datetime

from services.lookup_service import (
    get_engine_serials,
    get_tail_numbers,
    get_tails_for_engine,
    get_engines_for_tail,
)
from services.event_service import get_events


def setup_sidebar():
    st.sidebar.header("Filters")
    st.sidebar.subheader("Identifiers")

    engine_serials = get_engine_serials()
    tail_numbers = get_tail_numbers()

    selection_method = st.sidebar.radio(
        "Select by:", ["Engine Serial (ESN)", "Tail Number"], horizontal=True,
    )

    if selection_method == "Engine Serial (ESN)":
        engine_choice = st.sidebar.selectbox("Sample Engine Serial", engine_serials, index=0)
        available_tails = get_tails_for_engine(engine_choice)
        tail_choice = st.sidebar.selectbox("Tail Number (for this ESN)", available_tails, index=0)
    else:
        tail_choice = st.sidebar.selectbox("Sample Tail Number", tail_numbers, index=0)
        available_esns = get_engines_for_tail(tail_choice)
        engine_choice = st.sidebar.selectbox("Engine Serial (on this aircraft)", available_esns, index=0)

    variation = "Normal"

    custom_values = st.sidebar.checkbox("Use custom input instead")
    if custom_values:
        engine_serial = st.sidebar.text_input("Engine Serial", value=engine_choice)
        tail_number = st.sidebar.text_input("Tail Number", value=tail_choice)
    else:
        engine_serial = engine_choice
        tail_number = tail_choice

    window_hours = st.sidebar.slider("Time Window (hours)", 1.0, 6.0, 3.0, 0.5)
    auto_refresh = st.sidebar.checkbox("Auto-refresh (every 30s)")
    seed = st.sidebar.number_input(
        "Simulation Seed", min_value=0, max_value=10_000, value=42, step=1,
        help="Change to vary synthetic data.",
    )

    random.seed(seed)
    np.random.seed(seed)

    now = datetime.utcnow()

    if auto_refresh:
        components.html(
            "<script>setTimeout(function(){window.parent.location.reload()}, 30000)</script>",
            height=0,
        )

    if st.sidebar.button(" Regenerate Simulation"):
        get_events.clear()

    df = get_events(engine_serial, tail_number, now, hours=window_hours, variation=variation)

    st.session_state.df = df
    st.session_state.engine_serial = engine_serial
    st.session_state.tail_number = tail_number
    st.session_state.now = now
    st.session_state.window_hours = window_hours
