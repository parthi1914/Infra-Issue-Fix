import logging
import pandas as pd

from services.db import is_db_available, run_query
from utils.data_simulation import (
    simulate_data_elements_status as _sim_status,
    simulate_data_elements_with_values as _sim_values,
)

log = logging.getLogger(__name__)


def get_data_elements_status(df: pd.DataFrame) -> pd.DataFrame:
    if not is_db_available():
        return _sim_status(df)

    try:
        systems = list(df["system"].values)
        ph = ", ".join(f":s{i}" for i in range(len(systems)))
        params = {f"s{i}": s for i, s in enumerate(systems)}

        sql = f"""
            SELECT system,
                   element_name,
                   validation_status
              FROM data_element_validations
             WHERE system IN ({ph})
             ORDER BY system, element_name
        """
        result = run_query(sql, params)

        if result.empty:
            return _sim_status(df)

        pivot = result.pivot(
            index="element_name", columns="system", values="validation_status"
        )
        return pivot.reindex(columns=systems).fillna("Fail")
    except Exception as exc:
        log.warning("DB query failed, falling back to simulation: %s", exc)
        return _sim_status(df)


def get_data_elements_with_values(
    df: pd.DataFrame, engine_serial: str, tail_number: str
) -> dict:
    if not is_db_available():
        return _sim_values(df, engine_serial, tail_number)

    try:
        systems = list(df["system"].values)
        ph = ", ".join(f":s{i}" for i in range(len(systems)))
        params = {f"s{i}": s for i, s in enumerate(systems)}
        params["esn"] = engine_serial
        params["tail"] = tail_number

        sql = f"""
            SELECT system,
                   element_name,
                   actual_value,
                   expected_value,
                   validation_status,
                   failure_reason
              FROM data_element_validations
             WHERE engine_serial = :esn
               AND tail_number   = :tail
               AND system IN ({ph})
             ORDER BY system, element_name
        """
        rows = run_query(sql, params)

        if rows.empty:
            return _sim_values(df, engine_serial, tail_number)

        result = {}
        for _, r in rows.iterrows():
            sys = r["system"]
            if sys not in result:
                result[sys] = {}
            result[sys][r["element_name"]] = {
                "value": r["actual_value"],
                "expected": r["expected_value"],
                "status": r["validation_status"],
                "reason": r["failure_reason"] or "",
            }
        return result
    except Exception as exc:
        log.warning("DB query failed, falling back to simulation: %s", exc)
        return _sim_values(df, engine_serial, tail_number)
