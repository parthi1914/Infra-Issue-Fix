-- ============================================================================
-- Stored Procedure: sp_replicate_diagnostic_data
-- ============================================================================
-- Replicates data from edm_raw.asset_diagnostic_stg to
-- edm_rpt.asset_diagnostic_data_observability.
--
-- Behavior:
--   First run  (no prior successful log entry) → FULL_LOAD: copies all rows.
--   Subsequent (prior successful log exists)   → INCREMENTAL: copies only rows
--       where last_update_date > last successful run's last_source_timestamp.
--
-- Deduplication:
--   Uses NOT EXISTS on (esn, diagnostic_tail, data_source, last_update_date)
--   to prevent duplicate rows on re-runs or overlapping incremental windows.
--
-- Execution Log:
--   Each invocation writes a row to edm_rpt.etl_replication_log with:
--     run_type, records_processed, records_inserted, records_skipped,
--     last_source_timestamp, status (SUCCESS / FAILED), duration.
--
-- Returns:
--   Single row with execution summary.
--
-- Usage:
--   SELECT * FROM sp_replicate_diagnostic_data();
--
-- Prerequisites:
--   Run ddl_asset_diagnostic_data_observability.sql first.
-- ============================================================================

DROP FUNCTION IF EXISTS sp_replicate_diagnostic_data();

CREATE OR REPLACE FUNCTION sp_replicate_diagnostic_data()
RETURNS TABLE (
    log_id              BIGINT,
    run_type            TEXT,
    status              TEXT,
    records_processed   BIGINT,
    records_inserted    BIGINT,
    records_skipped     BIGINT,
    duration_seconds    NUMERIC
)
AS $$
DECLARE
    v_log_id              BIGINT;
    v_run_type            TEXT;
    v_start               TIMESTAMPTZ := clock_timestamp();
    v_last_ts             TIMESTAMPTZ;
    v_source_max_ts       TIMESTAMPTZ;
    v_records_processed   BIGINT := 0;
    v_records_inserted    BIGINT := 0;
    v_records_skipped     BIGINT := 0;
    v_src_table           TEXT := 'edm_raw.asset_diagnostic_stg';
    v_tgt_table           TEXT := 'edm_rpt.asset_diagnostic_data_observability';
BEGIN
    -- -----------------------------------------------------------------
    -- 1. Insert log entry (RUNNING)
    -- -----------------------------------------------------------------
    INSERT INTO edm_rpt.etl_replication_log (
        execution_start, status, source_table, target_table
    )
    VALUES (v_start, 'RUNNING', v_src_table, v_tgt_table)
    RETURNING etl_replication_log.log_id INTO v_log_id;

    -- -----------------------------------------------------------------
    -- 2. Determine run type: check last successful run
    -- -----------------------------------------------------------------
    SELECT l.last_source_timestamp
      INTO v_last_ts
      FROM edm_rpt.etl_replication_log l
     WHERE l.status = 'SUCCESS'
       AND l.target_table = v_tgt_table
     ORDER BY l.execution_start DESC
     LIMIT 1;

    IF v_last_ts IS NULL THEN
        v_run_type := 'FULL_LOAD';
    ELSE
        v_run_type := 'INCREMENTAL';
    END IF;

    -- -----------------------------------------------------------------
    -- 3. Count source records to process
    -- -----------------------------------------------------------------
    IF v_run_type = 'FULL_LOAD' THEN
        SELECT COUNT(*) INTO v_records_processed
          FROM edm_raw.asset_diagnostic_stg;
    ELSE
        SELECT COUNT(*) INTO v_records_processed
          FROM edm_raw.asset_diagnostic_stg
         WHERE last_update_date > v_last_ts;
    END IF;

    -- -----------------------------------------------------------------
    -- 4. Insert records with deduplication
    -- -----------------------------------------------------------------
    IF v_run_type = 'FULL_LOAD' THEN

        WITH inserted AS (
            INSERT INTO edm_rpt.asset_diagnostic_data_observability (
                data_source,
                esn,
                diagnostic_installation_date,
                diagnostic_tail,
                engine_position,
                installation_date,
                last_update_date,
                n1_modifier,
                operator,
                monitor,
                operator_diagnostic_code,
                tail_number_aircraft_id,
                engine_model,
                engine_type,
                engine_family_model_series,
                aircraft_delivery_date,
                aircraft_family,
                aircraft_model,
                aircraft_series,
                installation_history,
                replicated_at
            )
            SELECT
                s.data_source,
                s.esn,
                s.diagnostic_installation_date,
                s.diagnostic_tail,
                s.engine_position,
                s.installation_date,
                s.last_update_date,
                s.n1_modifier,
                s.operator,
                s.monitor,
                s.operator_diagnostic_code,
                s.tail_number_aircraft_id,
                s.engine_model,
                s.engine_type,
                s.engine_family_model_series,
                s.aircraft_delivery_date,
                s.aircraft_family,
                s.aircraft_model,
                s.aircraft_series,
                s.installation_history,
                NOW()
            FROM edm_raw.asset_diagnostic_stg s
            WHERE NOT EXISTS (
                SELECT 1
                  FROM edm_rpt.asset_diagnostic_data_observability t
                 WHERE t.esn              = s.esn
                   AND t.diagnostic_tail  = s.diagnostic_tail
                   AND t.data_source      = s.data_source
                   AND t.last_update_date = s.last_update_date
            )
            RETURNING 1
        )
        SELECT COUNT(*) INTO v_records_inserted FROM inserted;

    ELSE
        -- INCREMENTAL: only rows newer than last successful run
        WITH inserted AS (
            INSERT INTO edm_rpt.asset_diagnostic_data_observability (
                data_source,
                esn,
                diagnostic_installation_date,
                diagnostic_tail,
                engine_position,
                installation_date,
                last_update_date,
                n1_modifier,
                operator,
                monitor,
                operator_diagnostic_code,
                tail_number_aircraft_id,
                engine_model,
                engine_type,
                engine_family_model_series,
                aircraft_delivery_date,
                aircraft_family,
                aircraft_model,
                aircraft_series,
                installation_history,
                replicated_at
            )
            SELECT
                s.data_source,
                s.esn,
                s.diagnostic_installation_date,
                s.diagnostic_tail,
                s.engine_position,
                s.installation_date,
                s.last_update_date,
                s.n1_modifier,
                s.operator,
                s.monitor,
                s.operator_diagnostic_code,
                s.tail_number_aircraft_id,
                s.engine_model,
                s.engine_type,
                s.engine_family_model_series,
                s.aircraft_delivery_date,
                s.aircraft_family,
                s.aircraft_model,
                s.aircraft_series,
                s.installation_history,
                NOW()
            FROM edm_raw.asset_diagnostic_stg s
            WHERE s.last_update_date > v_last_ts
              AND NOT EXISTS (
                SELECT 1
                  FROM edm_rpt.asset_diagnostic_data_observability t
                 WHERE t.esn              = s.esn
                   AND t.diagnostic_tail  = s.diagnostic_tail
                   AND t.data_source      = s.data_source
                   AND t.last_update_date = s.last_update_date
              )
            RETURNING 1
        )
        SELECT COUNT(*) INTO v_records_inserted FROM inserted;

    END IF;

    -- Calculate skipped
    v_records_skipped := v_records_processed - v_records_inserted;

    -- Get max timestamp from source (for next incremental baseline)
    SELECT MAX(last_update_date)
      INTO v_source_max_ts
      FROM edm_raw.asset_diagnostic_stg;

    -- -----------------------------------------------------------------
    -- 5. Update log entry → SUCCESS
    -- -----------------------------------------------------------------
    UPDATE edm_rpt.etl_replication_log
       SET execution_end       = clock_timestamp(),
           status              = 'SUCCESS',
           run_type            = v_run_type,
           records_processed   = v_records_processed,
           records_inserted    = v_records_inserted,
           records_skipped     = v_records_skipped,
           last_source_timestamp = v_source_max_ts
     WHERE etl_replication_log.log_id = v_log_id;

    -- -----------------------------------------------------------------
    -- 6. Return summary
    -- -----------------------------------------------------------------
    RETURN QUERY
    SELECT
        v_log_id,
        v_run_type,
        'SUCCESS'::TEXT,
        v_records_processed,
        v_records_inserted,
        v_records_skipped,
        ROUND(EXTRACT(EPOCH FROM (clock_timestamp() - v_start))::NUMERIC, 2);

EXCEPTION WHEN OTHERS THEN
    -- Update log entry → FAILED
    UPDATE edm_rpt.etl_replication_log
       SET execution_end   = clock_timestamp(),
           status          = 'FAILED',
           run_type        = COALESCE(v_run_type, 'UNKNOWN'),
           error_message   = SQLERRM
     WHERE etl_replication_log.log_id = v_log_id;

    -- Re-raise so caller sees the error
    RAISE;
END;
$$ LANGUAGE plpgsql;
