-- ============================================================================
-- DDL: edm_rpt.asset_diagnostic_data_observability
-- ============================================================================
-- Target table for replicating data from edm_raw.asset_diagnostic_stg.
-- Mirrors the source table structure with an additional replicated_at column.
--
-- Also creates the ETL execution log table for tracking replication runs.
--
-- Prerequisites:
--   CREATE SCHEMA IF NOT EXISTS edm_rpt;
--
-- Usage:
--   Run this script once to create the tables and indexes.
-- ============================================================================

-- Ensure schema exists
CREATE SCHEMA IF NOT EXISTS edm_rpt;

-- ============================================================================
-- 1. Target Table
-- ============================================================================
CREATE TABLE IF NOT EXISTS edm_rpt.asset_diagnostic_data_observability (
    id                          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    data_source                 VARCHAR(10),
    esn                         VARCHAR(20),
    diagnostic_installation_date VARCHAR(50),
    diagnostic_tail             VARCHAR(20),
    engine_position             VARCHAR(10),
    installation_date           VARCHAR(50),
    last_update_date            TIMESTAMPTZ,
    n1_modifier                 VARCHAR(50),
    operator                    VARCHAR(20),
    monitor                     VARCHAR(50),
    operator_diagnostic_code    VARCHAR(20),
    tail_number_aircraft_id     VARCHAR(20),
    engine_model                VARCHAR(50),
    engine_type                 VARCHAR(50),
    engine_family_model_series  VARCHAR(50),
    aircraft_delivery_date      VARCHAR(50),
    aircraft_family             VARCHAR(50),
    aircraft_model              VARCHAR(50),
    aircraft_series             VARCHAR(20),
    installation_history        TEXT,
    replicated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE edm_rpt.asset_diagnostic_data_observability
    IS 'Replicated copy of edm_raw.asset_diagnostic_stg for reporting and observability.';

COMMENT ON COLUMN edm_rpt.asset_diagnostic_data_observability.replicated_at
    IS 'Timestamp when this row was copied from the source table.';

-- Composite index for deduplication lookups during replication
CREATE INDEX IF NOT EXISTS idx_ado_dedup
    ON edm_rpt.asset_diagnostic_data_observability (esn, diagnostic_tail, data_source, last_update_date);

-- Index for common query patterns
CREATE INDEX IF NOT EXISTS idx_ado_esn
    ON edm_rpt.asset_diagnostic_data_observability (esn);

CREATE INDEX IF NOT EXISTS idx_ado_last_update
    ON edm_rpt.asset_diagnostic_data_observability (last_update_date DESC NULLS LAST);


-- ============================================================================
-- 2. ETL Replication Log Table
-- ============================================================================
CREATE TABLE IF NOT EXISTS edm_rpt.etl_replication_log (
    log_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    execution_start     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    execution_end       TIMESTAMPTZ,
    status              VARCHAR(20) NOT NULL DEFAULT 'RUNNING',
    run_type            VARCHAR(20),
    source_table        TEXT NOT NULL,
    target_table        TEXT NOT NULL,
    records_processed   BIGINT DEFAULT 0,
    records_inserted    BIGINT DEFAULT 0,
    records_skipped     BIGINT DEFAULT 0,
    last_source_timestamp TIMESTAMPTZ,
    error_message       TEXT,
    executed_by         TEXT DEFAULT CURRENT_USER
);

COMMENT ON TABLE edm_rpt.etl_replication_log
    IS 'Execution log for sp_replicate_diagnostic_data. Tracks each ETL run with counts and status.';

-- Index for quick lookup of last successful run
CREATE INDEX IF NOT EXISTS idx_etl_log_status
    ON edm_rpt.etl_replication_log (status, execution_start DESC);
