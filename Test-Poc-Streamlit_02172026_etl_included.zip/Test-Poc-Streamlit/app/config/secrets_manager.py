import boto3
import json
from botocore.exceptions import ClientError


def get_rds_credentials(secret_name, region_name='us-east-1', profile_name=None):
    if profile_name:
        session = boto3.Session(profile_name=profile_name)
    else:
        session = boto3.Session()
    client = session.client('secretsmanager', region_name=region_name)

    try:
        response = client.get_secret_value(SecretId=secret_name)

        if 'SecretString' in response:
            secret = json.loads(response['SecretString'])

            endpoint = (secret.get('db_endpoint') or
                       secret.get('host') or
                       secret.get('endpoint') or
                       secret.get('hostname'))

            if not endpoint:
                raise ValueError(f"Could not find database endpoint in secret. Available keys: {list(secret.keys())}")

            db_name = (secret.get('db_name') or
                      secret.get('database') or
                      secret.get('dbname') or
                      secret.get('engine', 'postgres'))

            return {
                'username': secret.get('username'),
                'password': secret.get('password'),
                'db_name': db_name,
                'db_endpoint': endpoint,
                'host': endpoint,
                'port': secret.get('port', 5432)
            }
        else:
            raise ValueError("Secret does not contain a string value")

    except ClientError as e:
        raise Exception(f"Error retrieving secret: {e}")


def get_connection_string(secret_name, region_name='us-east-1', profile_name=None):
    creds = get_rds_credentials(secret_name, region_name, profile_name)

    return (f"postgresql://{creds['username']}:{creds['password']}@"
            f"{creds['host']}:{creds['port']}/{creds['db_name']}")
