import streamlit as st
import pandas as pd

from utils.charts import build_data_elements_heatmap_v2
from services.data_element_service import (
    get_data_elements_multi,
    filter_matrix_df_by_status,
)
from services.lookup_service import get_engine_serials


def render():
    """Render the Data Elements tab with multi-ESN support."""

    st.subheader("Data Elements Tracking")

    # -----------------------------------------------------------------
    # In-tab filters: ESN multi-select + optional tail
    # -----------------------------------------------------------------
    esn_options = get_engine_serials()

    col_esn, col_tail = st.columns([3, 2])
    with col_esn:
        selected_esns = st.multiselect(
            "Select ESN(s)",
            options=esn_options,
            default=[],
            placeholder="Choose one or more ESNs...",
            key="de_esn_multiselect",
        )
    with col_tail:
        tail_input = st.text_input(
            "Tail Number (optional)",
            value="",
            placeholder="e.g. SU-GEI",
            key="de_tail_input",
        ).strip() or None

    # -----------------------------------------------------------------
    # Guard: no ESNs selected
    # -----------------------------------------------------------------
    if not selected_esns:
        st.info("Select one or more ESNs above to view data elements.")
        return

    # -----------------------------------------------------------------
    # Fetch data from v2 SPs
    # -----------------------------------------------------------------
    result = get_data_elements_multi(selected_esns, tail_input)
    matrix_df = result["matrix_df"]
    failures_df = result["failures_df"]
    summary = result["summary"]

    if matrix_df.empty:
        st.warning("No data returned for the selected ESN(s). Try different filters.")
        return

    # -----------------------------------------------------------------
    # KPI row
    # -----------------------------------------------------------------
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("ESNs", summary["esn_count"])
    k2.metric("Properties", summary["properties"])
    k3.metric("Pass", summary["passed"], delta=f"{summary['pass_rate']:.1f}%")
    k4.metric("Fail", summary["failed"],
              delta=f"-{100 - summary['pass_rate']:.1f}%",
              delta_color="inverse")
    k5.metric("Pass Rate", f"{summary['pass_rate']:.1f}%")

    # -----------------------------------------------------------------
    # Status filter
    # -----------------------------------------------------------------
    st.markdown("---")

    matrix_filter = st.radio(
        "Filter by Status:",
        options=["All", "Pass", "Fail"],
        index=0,
        horizontal=True,
        key="de_status_filter",
        label_visibility="collapsed",
    )

    filtered_df = filter_matrix_df_by_status(matrix_df, matrix_filter)

    if matrix_filter != "All":
        st.caption(
            f"Showing {len(filtered_df)} of {len(matrix_df)} rows ({matrix_filter} only)"
        )

    # -----------------------------------------------------------------
    # Matrix heatmap grid
    # -----------------------------------------------------------------
    if filtered_df.empty:
        st.success("No rows match the selected filter.")
    else:
        heatmap_html = build_data_elements_heatmap_v2(filtered_df)
        st.markdown(heatmap_html, unsafe_allow_html=True)

    # -----------------------------------------------------------------
    # Failed Elements Details
    # -----------------------------------------------------------------
    st.markdown("---")
    st.markdown("### Failed Elements Details")

    if failures_df is not None and not failures_df.empty:
        display_df = failures_df.rename(columns={
            "esn": "ESN",
            "tail": "Tail",
            "system_name": "System",
            "property_name": "Property",
            "expected": "Expected",
            "actual_value": "Actual",
            "status": "Status",
            "reason": "Reason",
        })

        # Drop prop_order from display if present
        if "prop_order" in display_df.columns:
            display_df = display_df.drop(columns=["prop_order"])

        st.caption(f"{len(display_df)} failed element(s)")

        # Corporate header styling
        st.markdown("""
        <style>
        [data-testid="stDataFrame"] thead tr th {
            background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%) !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            font-size: 11px !important;
            letter-spacing: 0.5px !important;
            padding: 10px 12px !important;
        }
        [data-testid="stDataFrame"] thead tr th svg {
            fill: #ffffff !important;
            stroke: #ffffff !important;
        }
        [data-testid="stDataFrame"] thead tr th:hover {
            background: linear-gradient(135deg, #2d5a87 0%, #3d6a97 100%) !important;
        }
        </style>
        """, unsafe_allow_html=True)

        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True,
            height=min(400, 35 * len(display_df) + 38),
            column_config={
                "ESN": st.column_config.TextColumn("ESN", width="small"),
                "Tail": st.column_config.TextColumn("Tail", width="small"),
                "System": st.column_config.TextColumn("System", width="small"),
                "Property": st.column_config.TextColumn("Property", width="medium"),
                "Expected": st.column_config.TextColumn("Expected", width="medium"),
                "Actual": st.column_config.TextColumn("Actual", width="medium"),
                "Reason": st.column_config.TextColumn("Reason", width="large"),
            },
        )
    else:
        st.success("All data elements passed validation!")
