import streamlit as st
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

from utils.constants import SYSTEM_FLOW, STATUSES, DATA_ELEMENTS


@st.cache_data(show_spinner=False)
def simulate_events(engine_serial: str, tail_number: str, now: datetime, hours: float = 3.0, variation: str = "Normal") -> pd.DataFrame:
    """Simulate data travel events with deterministic variation by ESN+Tail hash and scenario label."""
    is_demo = (engine_serial == "000000" and tail_number == "N-DEMO")

    base_seed = abs(hash(engine_serial + tail_number + variation)) % (2**32 - 1)
    rng = random.Random(base_seed)
    np_rng = np.random.default_rng(base_seed)

    start_window = now - timedelta(hours=hours)
    base_start = start_window + timedelta(minutes=rng.randint(0, 25))

    records = []
    cumulative_time = base_start
    total_records = rng.randint(55_000, 125_000)
    remaining = total_records

    if variation == "High Delay":
        weight_profile = [0.03, 0.12, 0.45, 0.30, 0.10]
    elif variation == "Error Spike":
        weight_profile = [0.05, 0.10, 0.55, 0.15, 0.15]
    elif variation == "Fast Path":
        weight_profile = [0.02, 0.18, 0.70, 0.06, 0.04]
    else:  # Normal
        weight_profile = [0.04, 0.16, 0.60, 0.14, 0.06]

    pipeline_blocked = False
    for i, system in enumerate(SYSTEM_FLOW):
        proc_minutes = rng.randint(5, 22)
        if variation == "Fast Path":
            proc_minutes = int(proc_minutes * 0.7)
        start_time = cumulative_time
        end_time = start_time + timedelta(minutes=proc_minutes)
        gap = rng.randint(1, 8)
        if variation == "Fast Path":
            gap = max(1, int(gap * 0.5))
        cumulative_time = end_time + timedelta(minutes=gap) if i < len(SYSTEM_FLOW) - 1 else end_time

        if is_demo:
            status = "Complete"
        elif pipeline_blocked:
            status = "NotStarted"
        else:
            sys_bias = (abs(hash(system + engine_serial)) % 100) / 100.0
            adjusted_weights = [w * (0.9 + sys_bias * 0.2) for w in weight_profile]
            total_w = sum(adjusted_weights)
            adjusted_weights = [w / total_w for w in adjusted_weights]
            status = rng.choices(STATUSES[:5], weights=adjusted_weights, k=1)[0]

        if status == "NotStarted":
            end_time = start_time + timedelta(minutes=1)
        elif status == "Delayed":
            end_time += timedelta(minutes=rng.randint(6, 16))
        elif status == "Error":
            end_time += timedelta(minutes=rng.randint(2, 6))

        latency = rng.uniform(0.5, 4.5) * (1.4 if status in {"Delayed", "Error"} else 1.0)

        hop_records = max(int(remaining * rng.uniform(0.91, 0.985)), 900)
        remaining = hop_records
        data_size_mb = hop_records * rng.uniform(0.00055, 0.0011)

        records.append({
            "engine_serial": engine_serial,
            "tail_number": tail_number,
            "system": system,
            "start_time": start_time,
            "end_time": end_time,
            "status": status,
            "latency_sec": latency,
            "records": hop_records,
            "data_size_mb": data_size_mb,
        })

        if not is_demo and status != "Complete" and status != "NotStarted":
            pipeline_blocked = True

    df = pd.DataFrame(records)
    return df


def simulate_data_elements_with_values(df: pd.DataFrame, engine_serial: str, tail_number: str) -> dict:
    """Simulate per-system data element values and validation status with failure reasons."""
    systems = list(df["system"].values)
    rng = random.Random(abs(hash(engine_serial + tail_number + "elem")) % (2**32 - 1))

    status_to_pass = {
        "Complete": 0.97,
        "Processing": 0.92,
        "Pending": 0.90,
        "Delayed": 0.85,
        "Error": 0.70,
        "NotStarted": 0.0,
    }

    # All 19 properties from edm_raw.asset_diagnostic_stg table
    expected_values = {
        "ESN": engine_serial or "000000",
        "Diagnostic Installation Date": "2026-01-29",
        "Diagnostic Tail": tail_number,
        "Engine Position": "1",
        "Installation Date": "2026-01-29",
        "Last Updated Date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "N1 Modifier": "1000000045",
        "Operator": "15456",
        "Monitor": "TBD",
        "Operator Diagnostic Code": "ODC-001",
        "Tail Number Aircraft ID": tail_number,
        "Engine Model": "CFM56-7B26",
        "Engine Type": "TURBOFAN",
        "Engine Family Model Series": "CFM56-7B",
        "Aircraft Delivery Date": "2020-05-15",
        "Aircraft Family": "A320",
        "Aircraft Model": "A320-214",
        "Aircraft Series": "200",
        "Installation History": "2024-10-23",
    }

    result = {}
    for system in systems:
        system_status = df.loc[df.system == system, "status"].iloc[0]
        base_rate = status_to_pass.get(system_status, 0.9)
        jitter = (abs(hash(system)) % 7) / 100.0
        pass_rate = min(0.99, max(0.0, base_rate - (0.02 if system_status in {"Delayed", "Error"} else 0.0) + jitter))

        system_data = {}
        for element in DATA_ELEMENTS:
            expected = expected_values[element]
            is_pass = rng.random() < pass_rate

            if is_pass:
                actual = expected
                status = "Pass"
                reason = ""
            else:
                failure_type = rng.choice(["missing", "mismatch", "format", "null", "invalid"])
                if failure_type == "missing":
                    actual = "NULL"
                    reason = "Field missing in source data"
                elif failure_type == "mismatch":
                    if element == "Diagnostic Tail":
                        actual = rng.choice(["HB-JME", "N-XXXX", "D-ABCD"])
                        reason = f"Value mismatch: expected '{expected}' but got '{actual}'"
                    elif element == "Engine Position":
                        actual = rng.choice(["1", "2", "4"])
                        reason = f"Value mismatch: expected '{expected}' but got '{actual}'"
                    elif element == "Monitor":
                        actual = rng.choice(["PHM", "FDM", "BLANK"])
                        reason = f"Value mismatch: expected '{expected}' but got '{actual}'"
                    elif element in ["Installation Date", "Last Updated Date", "Diagnostic Installation Date"]:
                        actual = rng.choice(["2024-11-19", "2025-11-19", "2024-10-01"])
                        reason = f"Date mismatch: expected '{expected}' but got '{actual}'"
                    else:
                        actual = f"{expected}-WRONG"
                        reason = f"Value mismatch: expected '{expected}'"
                elif failure_type == "format":
                    actual = str(expected).replace("-", "").replace(":", "")[:10]
                    reason = "Format error: expected format not met"
                elif failure_type == "null":
                    actual = "NULL"
                    reason = "Null value found"
                else:
                    actual = "INVALID"
                    reason = "Data validation failed"
                status = "Fail"

            system_data[element] = {
                "value": actual,
                "expected": expected,
                "status": status,
                "reason": reason,
            }

        result[system] = system_data

    return result


def simulate_data_elements_status(df: pd.DataFrame) -> pd.DataFrame:
    """Legacy function for simple Pass/Fail matrix."""
    systems = list(df["system"].values)
    rng = random.Random(abs(hash(tuple(systems))) % (2**32 - 1))
    status_to_pass = {
        "Complete": 0.97,
        "Processing": 0.92,
        "Pending": 0.90,
        "Delayed": 0.85,
        "Error": 0.70,
        "NotStarted": 0.0,
    }
    matrix = {}
    for system in systems:
        status = df.loc[df.system == system, "status"].iloc[0]
        base_rate = status_to_pass.get(status, 0.9)
        jitter = (abs(hash(system)) % 7) / 100.0
        pass_rate = min(0.99, max(0.0, base_rate - (0.02 if status in {"Delayed", "Error"} else 0.0) + jitter))
        vals = []
        for el in DATA_ELEMENTS:
            vals.append("Pass" if rng.random() < pass_rate else "Fail")
        matrix[system] = vals
    return pd.DataFrame(matrix, index=DATA_ELEMENTS)
