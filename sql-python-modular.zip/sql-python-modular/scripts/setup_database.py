"""
Setup database schema in AWS PostgreSQL.
Run this once to create all tables.
"""
from app.core.database import get_database_service, Base
from app.core import initialize_app
from app.core.logging import get_logger
from sqlalchemy import Column, Integer, String, DateTime, Float, Index

# Initialize infrastructure
initialize_app()
logger = get_logger(__name__)

print("=" * 60)
print("Database Setup")
print("=" * 60)

# Define database models
class Event(Base):
    """Event model - represents events table."""
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(100), unique=True, nullable=False)
    engine_serial = Column(String(50), nullable=False, index=True)
    tail_number = Column(String(50), nullable=False, index=True)
    system = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    latency_ms = Column(Integer)
    data_element = Column(String(100))
    data_quality_score = Column(Float)

    # Composite indexes for common queries
    __table_args__ = (
        Index('idx_events_engine_timestamp', 'engine_serial', 'timestamp'),
        Index('idx_events_tail_timestamp', 'tail_number', 'timestamp'),
    )

    def __repr__(self):
        return f"<Event(event_id={self.event_id}, system={self.system}, status={self.status})>"


# Get database service
db_service = get_database_service()

# Test connection first
print("\n1. Testing connection...")
if not db_service.health_check():
    print("   ❌ Connection failed!")
    print("   Check your DATABASE_URL in .env")
    exit(1)
print("   ✅ Connection successful!")

# Create tables
print("\n2. Creating database tables...")
try:
    db_service.create_tables()
    print("   ✅ Tables created successfully!")
except Exception as e:
    print(f"   ❌ Failed to create tables: {e}")
    exit(1)

# Verify tables exist
print("\n3. Verifying tables...")
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            ORDER BY table_name
        """)
        tables = [row[0] for row in result]

        if tables:
            print(f"   ✅ Found {len(tables)} table(s):")
            for table in tables:
                print(f"      - {table}")
        else:
            print("   ⚠️  No tables found")

except Exception as e:
    print(f"   ❌ Verification failed: {e}")
    exit(1)

# Show indexes
print("\n4. Checking indexes...")
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT indexname, tablename
            FROM pg_indexes
            WHERE schemaname = 'public'
            ORDER BY tablename, indexname
        """)
        indexes = list(result)

        if indexes:
            print(f"   ✅ Found {len(indexes)} index(es):")
            for idx_name, table_name in indexes:
                print(f"      - {table_name}.{idx_name}")
        else:
            print("   ⚠️  No indexes found")

except Exception as e:
    print(f"   ❌ Index check failed: {e}")

print("\n" + "=" * 60)
print("Database setup complete! ✅")
print("=" * 60)
print("\nNext step: Run scripts/load_sample_data.py to load data")
