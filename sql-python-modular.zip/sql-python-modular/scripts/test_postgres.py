"""
Test PostgreSQL connection.
Run this to verify your AWS RDS connection is working.
"""
from app.core.database import get_database_service
from app.core import initialize_app
from app.core.logging import get_logger

# Initialize infrastructure
initialize_app()
logger = get_logger(__name__)

# Get database service
db_service = get_database_service()

print("=" * 60)
print("Testing PostgreSQL Connection")
print("=" * 60)

# Test connection
print("\n1. Testing connection...")
if db_service.health_check():
    print("   ✅ Connection successful!")
else:
    print("   ❌ Connection failed!")
    print("   Check logs/app.log for details")
    exit(1)

# Show connection details (password masked)
print("\n2. Connection details:")
print(f"   Database URL: {db_service._mask_password(db_service.settings.DATABASE_URL)}")
print(f"   Pool size: {db_service.settings.DB_POOL_SIZE}")
print(f"   Max overflow: {db_service.settings.DB_MAX_OVERFLOW}")
print(f"   Environment: {db_service.settings.ENVIRONMENT}")

# Test query
print("\n3. Testing query execution...")
try:
    with db_service.get_session() as session:
        result = session.execute("SELECT version()")
        version = result.scalar()
        print(f"   ✅ PostgreSQL version: {version}")
except Exception as e:
    print(f"   ❌ Query failed: {e}")
    exit(1)

print("\n" + "=" * 60)
print("All tests passed! ✅")
print("=" * 60)
print("\nYou can now run: streamlit run Home.py")
