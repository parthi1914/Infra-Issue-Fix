"""
Test AWS CloudWatch and SNS integration.
Run this to verify your AWS services are configured correctly.
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.core.config import get_settings
from datetime import datetime

# Initialize
initialize_app()
logger = get_logger(__name__)
settings = get_settings()

print("=" * 70)
print(" AWS SERVICES TEST".center(70))
print("=" * 70)

# Show configuration
print("\n📋 Configuration:")
print(f"   AWS Region: {settings.AWS_REGION}")
print(f"   Environment: {settings.ENVIRONMENT}")
print(f"   CloudWatch Enabled: {settings.ENABLE_AWS_LOGGING}")
print(f"   Local Logging Enabled: {settings.ENABLE_LOCAL_LOGGING}")

# Test 1: CloudWatch Logging
print("\n" + "─" * 70)
print("1️⃣  Testing CloudWatch Logging")
print("─" * 70)

if settings.ENABLE_AWS_LOGGING:
    print(f"   Log Group: {settings.AWS_LOG_GROUP}")
    print(f"   Log Stream: {settings.AWS_LOG_STREAM}")
    print(f"   Region: {settings.AWS_REGION}")

    try:
        # Send test logs with different levels
        test_id = datetime.now().strftime("%Y%m%d_%H%M%S")

        logger.info("🧪 TEST: CloudWatch INFO level", extra={
            "test": True,
            "test_id": test_id,
            "test_type": "cloudwatch_info"
        })

        logger.warning("🧪 TEST: CloudWatch WARNING level", extra={
            "test": True,
            "test_id": test_id,
            "test_type": "cloudwatch_warning"
        })

        logger.error("🧪 TEST: CloudWatch ERROR level", extra={
            "test": True,
            "test_id": test_id,
            "test_type": "cloudwatch_error"
        })

        print("\n   ✅ Test logs sent successfully!")
        print(f"   Test ID: {test_id}")
        print("\n   📍 View in AWS Console:")
        print(f"      1. Go to: CloudWatch → Log Groups → {settings.AWS_LOG_GROUP}")
        print(f"      2. Click stream: {settings.AWS_LOG_STREAM}")
        print(f"      3. Search for: {test_id}")
        print("\n   🔍 Or search via CLI:")
        print(f'      aws logs filter-log-events \\')
        print(f'        --log-group-name "{settings.AWS_LOG_GROUP}" \\')
        print(f'        --filter-pattern \'{{ $.test_id = "{test_id}" }}\'')

    except Exception as e:
        print(f"\n   ❌ CloudWatch test failed: {e}")
        print("\n   💡 Common issues:")
        print("      - Check AWS credentials")
        print("      - Verify IAM permissions (logs:PutLogEvents)")
        print("      - Check network connectivity to AWS")

else:
    print("   ⚠️  CloudWatch logging is DISABLED")
    print("\n   To enable:")
    print("      1. Edit .env file")
    print("      2. Set: ENABLE_AWS_LOGGING=True")
    print("      3. Set: AWS_LOG_GROUP=/aws/streamlit/data-observability")
    print("      4. Set: AWS_LOG_STREAM=app-stream")
    print("      5. Restart application")

# Test 2: SNS Notifications
print("\n" + "─" * 70)
print("2️⃣  Testing SNS Notifications")
print("─" * 70)

if settings.AWS_SNS_TOPIC_ARN:
    print(f"   Topic ARN: {settings.AWS_SNS_TOPIC_ARN}")
    print(f"   Region: {settings.AWS_REGION}")

    try:
        sns_service = inject("sns_service")

        test_id = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Send test alert
        message_id = sns_service.publish_alert(
            alert_type="TEST",
            message=f"🧪 Test alert from Data Observability Framework\n\nTest ID: {test_id}\nTimestamp: {datetime.now()}",
            severity="INFO",
            test=True,
            test_id=test_id,
            timestamp=datetime.now().isoformat()
        )

        print(f"\n   ✅ Test alert sent successfully!")
        print(f"   Message ID: {message_id}")
        print(f"   Test ID: {test_id}")
        print("\n   📬 Check for notification:")
        print("      - Email (check inbox/spam)")
        print("      - SMS (if configured)")
        print("      - HTTP endpoint (check logs)")
        print("      - Lambda (check CloudWatch Logs)")
        print("\n   🔍 Verify in AWS Console:")
        print(f"      1. Go to: SNS → Topics → {settings.AWS_SNS_TOPIC_ARN.split(':')[-1]}")
        print("      2. Click 'Publish message' to manually test")
        print("      3. Check subscriptions are 'Confirmed'")

    except Exception as e:
        print(f"\n   ❌ SNS test failed: {e}")
        print("\n   💡 Common issues:")
        print("      - Check AWS credentials")
        print("      - Verify IAM permissions (sns:Publish)")
        print("      - Confirm SNS topic exists")
        print("      - Check topic ARN is correct")
        print("\n   🔧 Debug commands:")
        print(f'      # List topics')
        print(f'      aws sns list-topics')
        print(f'\n      # List subscriptions')
        print(f'      aws sns list-subscriptions-by-topic \\')
        print(f'        --topic-arn "{settings.AWS_SNS_TOPIC_ARN}"')

else:
    print("   ⚠️  SNS is NOT CONFIGURED")
    print("\n   To enable:")
    print("      1. Create SNS topic:")
    print("         aws sns create-topic --name data-observability-alerts")
    print("\n      2. Add subscribers:")
    print("         aws sns subscribe \\")
    print("           --topic-arn <your-topic-arn> \\")
    print("           --protocol email \\")
    print("           --notification-endpoint your@email.com")
    print("\n      3. Edit .env file:")
    print("         AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:data-observability-alerts")
    print("\n      4. Restart application")

# Test 3: Local Logging (Fallback)
print("\n" + "─" * 70)
print("3️⃣  Testing Local Logging (Fallback)")
print("─" * 70)

if settings.ENABLE_LOCAL_LOGGING:
    print(f"   Log File: {settings.LOG_FILE}")

    try:
        test_id = datetime.now().strftime("%Y%m%d_%H%M%S")

        logger.info("🧪 TEST: Local file logging", extra={
            "test": True,
            "test_id": test_id,
            "test_type": "local_file"
        })

        print(f"\n   ✅ Local logging working!")
        print(f"   Test ID: {test_id}")
        print(f"\n   📄 View logs:")
        print(f'      cat {settings.LOG_FILE} | grep "{test_id}"')

    except Exception as e:
        print(f"\n   ❌ Local logging test failed: {e}")

else:
    print("   ⚠️  Local logging is DISABLED")

# Summary
print("\n" + "=" * 70)
print(" TEST SUMMARY".center(70))
print("=" * 70)

print("\n✅ Active Logging Destinations:")
destinations = []
if settings.ENABLE_LOCAL_LOGGING:
    destinations.append(f"   • Local File: {settings.LOG_FILE}")
destinations.append("   • Console: stdout")
if settings.ENABLE_AWS_LOGGING:
    destinations.append(f"   • CloudWatch: {settings.AWS_LOG_GROUP}")
if settings.AWS_SNS_TOPIC_ARN:
    destinations.append(f"   • SNS: {settings.AWS_SNS_TOPIC_ARN.split(':')[-1]}")

for dest in destinations:
    print(dest)

print("\n📚 Documentation:")
print("   • AWS Services Guide: docs/AWS_SERVICES_GUIDE.md")
print("   • Quick Reference: docs/QUICK_REFERENCE.md")
print("   • Architecture: ARCHITECTURE.md")

print("\n🚀 Next Steps:")
if not settings.ENABLE_AWS_LOGGING and not settings.AWS_SNS_TOPIC_ARN:
    print("   1. Configure AWS services in .env")
    print("   2. Re-run this test script")
    print("   3. Check AWS Console for logs/notifications")
elif not settings.ENABLE_AWS_LOGGING:
    print("   1. Enable CloudWatch logging in .env")
    print("   2. Re-run this test script")
elif not settings.AWS_SNS_TOPIC_ARN:
    print("   1. Configure SNS topic in .env")
    print("   2. Re-run this test script")
else:
    print("   ✅ All AWS services configured!")
    print("   • Check CloudWatch for logs")
    print("   • Check email/SMS for SNS notification")
    print("   • Ready to use in your application")

print("\n" + "=" * 70)
