"""
Example database queries using DatabaseService.
Run this to see how to query PostgreSQL.
"""
from datetime import datetime, timedelta
from app.core.database import get_database_service
from app.core import initialize_app
from app.core.logging import get_logger

# Initialize
initialize_app()
logger = get_logger(__name__)

# Get database service
db_service = get_database_service()

print("=" * 60)
print("Database Query Examples")
print("=" * 60)

# Example 1: Get all events
print("\n📊 Example 1: Get recent events")
print("-" * 60)
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT event_id, system, status, timestamp
            FROM events
            ORDER BY timestamp DESC
            LIMIT 5
        """)

        print("Recent events:")
        for row in result:
            print(f"  {row.event_id} | {row.system} | {row.status} | {row.timestamp}")

except Exception as e:
    print(f"❌ Query failed: {e}")

# Example 2: Filter by status
print("\n📊 Example 2: Filter by status")
print("-" * 60)
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT event_id, system, status
            FROM events
            WHERE status = :status
            ORDER BY timestamp DESC
            LIMIT 5
        """, {"status": "Complete"})

        print("Events with status 'Complete':")
        for row in result:
            print(f"  {row.event_id} | {row.system}")

except Exception as e:
    print(f"❌ Query failed: {e}")

# Example 3: Aggregate statistics
print("\n📊 Example 3: Aggregate by system")
print("-" * 60)
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT
                system,
                COUNT(*) as total_events,
                AVG(latency_ms) as avg_latency,
                MAX(latency_ms) as max_latency,
                COUNT(CASE WHEN status = 'Error' THEN 1 END) as error_count
            FROM events
            GROUP BY system
            ORDER BY total_events DESC
        """)

        print("Statistics by system:")
        print(f"  {'System':<10} {'Count':<8} {'Avg Latency':<15} {'Max Latency':<15} {'Errors':<8}")
        print("  " + "-" * 70)
        for row in result:
            avg_lat = f"{row.avg_latency:.1f}ms" if row.avg_latency else "N/A"
            max_lat = f"{row.max_latency}ms" if row.max_latency else "N/A"
            print(f"  {row.system:<10} {row.total_events:<8} {avg_lat:<15} {max_lat:<15} {row.error_count:<8}")

except Exception as e:
    print(f"❌ Query failed: {e}")

# Example 4: Filter by engine serial
print("\n📊 Example 4: Filter by engine serial")
print("-" * 60)
engine_serial = "000000"
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT event_id, system, status, timestamp
            FROM events
            WHERE engine_serial = :engine_serial
            ORDER BY timestamp DESC
            LIMIT 5
        """, {"engine_serial": engine_serial})

        print(f"Events for engine {engine_serial}:")
        for row in result:
            print(f"  {row.event_id} | {row.system} | {row.status}")

except Exception as e:
    print(f"❌ Query failed: {e}")

# Example 5: Time-based query
print("\n📊 Example 5: Recent events (last 7 days)")
print("-" * 60)
try:
    with db_service.get_session() as session:
        cutoff_time = datetime.now() - timedelta(days=7)
        result = session.execute("""
            SELECT
                DATE(timestamp) as event_date,
                COUNT(*) as count
            FROM events
            WHERE timestamp >= :cutoff_time
            GROUP BY DATE(timestamp)
            ORDER BY event_date DESC
        """, {"cutoff_time": cutoff_time})

        print("Events by date:")
        for row in result:
            print(f"  {row.event_date}: {row.count} events")

except Exception as e:
    print(f"❌ Query failed: {e}")

# Example 6: Data quality analysis
print("\n📊 Example 6: Data quality analysis")
print("-" * 60)
try:
    with db_service.get_session() as session:
        result = session.execute("""
            SELECT
                CASE
                    WHEN data_quality_score >= 0.95 THEN 'Excellent (0.95+)'
                    WHEN data_quality_score >= 0.90 THEN 'Good (0.90-0.95)'
                    WHEN data_quality_score >= 0.85 THEN 'Fair (0.85-0.90)'
                    ELSE 'Poor (<0.85)'
                END as quality_category,
                COUNT(*) as count,
                AVG(data_quality_score) as avg_score
            FROM events
            WHERE data_quality_score IS NOT NULL
            GROUP BY quality_category
            ORDER BY avg_score DESC
        """)

        print("Data quality distribution:")
        for row in result:
            print(f"  {row.quality_category}: {row.count} events (avg: {row.avg_score:.3f})")

except Exception as e:
    print(f"❌ Query failed: {e}")

print("\n" + "=" * 60)
print("Examples complete! ✅")
print("=" * 60)
print("\nSee docs/DATABASE_GUIDE.md for more examples")
