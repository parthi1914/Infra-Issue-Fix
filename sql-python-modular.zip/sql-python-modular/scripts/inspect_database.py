"""
Inspect existing database schema.
Run this to understand your table structure before creating models.
"""
from app.core import initialize_app, get_logger
from app.core.database import get_database_service
from app.core.config import get_settings

initialize_app()
logger = get_logger(__name__)
db_service = get_database_service()
settings = get_settings()

print("=" * 80)
print(" INSPECTING EXISTING DATABASE".center(80))
print("=" * 80)

# Show configuration
print("\n📋 Configuration:")
print(f"   DATABASE_URL: {db_service._mask_password(settings.DATABASE_URL)}")
print(f"   ENABLE_DUMMY_DATA: {settings.ENABLE_DUMMY_DATA}")

if settings.ENABLE_DUMMY_DATA:
    print("\n   ⚠️  WARNING: ENABLE_DUMMY_DATA is True")
    print("   Set ENABLE_DUMMY_DATA=False in .env to use PostgreSQL")

# Test connection
print("\n1. Testing connection...")
if not db_service.health_check():
    print("   ❌ Connection failed!")
    print("   Check your DATABASE_URL in .env")
    print("\n   Troubleshooting:")
    print("      1. Verify endpoint is correct")
    print("      2. Check username/password")
    print("      3. Verify security group allows your IP")
    print("      4. Test with psql:")
    print(f"         psql '{settings.DATABASE_URL}'")
    exit(1)

print("   ✅ Connected successfully!")

# Get PostgreSQL version
with db_service.get_session() as session:
    result = session.execute("SELECT version()")
    version = result.scalar()
    print(f"   PostgreSQL: {version.split(',')[0]}")

# List all schemas
print("\n2. Schemas in database:")
print("-" * 80)

with db_service.get_session() as session:
    result = session.execute("""
        SELECT schema_name
        FROM information_schema.schemata
        WHERE schema_name NOT IN ('pg_catalog', 'information_schema', 'pg_toast')
        ORDER BY schema_name
    """)

    schemas = [row[0] for row in result]
    print(f"   Found {len(schemas)} schema(s): {', '.join(schemas)}")

# List all tables
print("\n3. Tables in database:")
print("-" * 80)

with db_service.get_session() as session:
    result = session.execute("""
        SELECT
            schemaname,
            tablename,
            tableowner
        FROM pg_tables
        WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
        ORDER BY schemaname, tablename
    """)

    tables = list(result)

    if not tables:
        print("   ⚠️  No tables found!")
        print("\n   This might mean:")
        print("      - Database is empty")
        print("      - You're connected to wrong database")
        print("      - Tables are in a different schema")
        exit(1)

    print(f"   Found {len(tables)} table(s):\n")

    table_dict = {}
    for schema, table, owner in tables:
        print(f"   📋 {schema}.{table} (owner: {owner})")
        table_dict[(schema, table)] = True

# Get detailed information for each table
print("\n4. Table details:")
print("=" * 80)

with db_service.get_session() as session:
    for schema, table, _ in tables:
        print(f"\n┌─ Table: {schema}.{table}")
        print("│")

        # Get columns
        result = session.execute(f"""
            SELECT
                column_name,
                data_type,
                character_maximum_length,
                is_nullable,
                column_default
            FROM information_schema.columns
            WHERE table_schema = '{schema}'
            AND table_name = '{table}'
            ORDER BY ordinal_position
        """)

        columns = list(result)
        print(f"├─ Columns ({len(columns)}):")

        for col_name, data_type, max_len, nullable, default in columns:
            null_str = "NULL" if nullable == "YES" else "NOT NULL"
            len_str = f"({max_len})" if max_len else ""
            default_str = f" DEFAULT {default}" if default else ""
            print(f"│  • {col_name:<30} {data_type}{len_str:<20} {null_str}{default_str}")

        # Get primary key
        result = session.execute(f"""
            SELECT a.attname
            FROM pg_index i
            JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
            WHERE i.indrelid = '{schema}.{table}'::regclass
            AND i.indisprimary
        """)

        pkeys = [row[0] for row in result]
        if pkeys:
            print(f"│")
            print(f"├─ Primary Key: {', '.join(pkeys)}")

        # Get indexes
        result = session.execute(f"""
            SELECT
                indexname,
                indexdef
            FROM pg_indexes
            WHERE schemaname = '{schema}'
            AND tablename = '{table}'
            ORDER BY indexname
        """)

        indexes = list(result)
        if indexes:
            print(f"│")
            print(f"├─ Indexes ({len(indexes)}):")
            for idx_name, idx_def in indexes:
                # Simplify index definition
                if 'USING btree' in idx_def:
                    cols = idx_def.split('(')[1].split(')')[0]
                    print(f"│  • {idx_name}: {cols}")
                else:
                    print(f"│  • {idx_name}")

        # Get row count
        try:
            result = session.execute(f'SELECT COUNT(*) FROM "{schema}"."{table}"')
            count = result.scalar()
            print(f"│")
            print(f"├─ Row count: {count:,}")
        except Exception as e:
            print(f"│")
            print(f"├─ Row count: Unable to count ({e})")

        # Get sample data (first 3 rows)
        try:
            result = session.execute(f'SELECT * FROM "{schema}"."{table}" LIMIT 3')
            sample_rows = list(result)

            if sample_rows:
                print(f"│")
                print(f"└─ Sample data (first 3 rows):")
                for i, row in enumerate(sample_rows, 1):
                    row_dict = dict(row)
                    # Truncate long values
                    row_dict = {k: (str(v)[:50] + '...' if len(str(v)) > 50 else v)
                               for k, v in row_dict.items()}
                    print(f"   Row {i}: {row_dict}")
            else:
                print(f"│")
                print(f"└─ No data in table")

        except Exception as e:
            print(f"│")
            print(f"└─ Unable to fetch sample data: {e}")

        print()  # Blank line between tables

# Generate SQLAlchemy model template
print("\n5. SQLAlchemy Model Template:")
print("=" * 80)

print("\nCopy this to app/models/existing_tables.py:\n")
print("```python")
print('"""SQLAlchemy models for existing tables."""')
print("from sqlalchemy import Column, Integer, String, DateTime, Float, Boolean, Text")
print("from app.core.database import Base\n")

for schema, table, _ in tables:
    class_name = ''.join(word.capitalize() for word in table.split('_'))

    print(f"\nclass {class_name}(Base):")
    print(f'    """{schema}.{table} table."""')
    print(f'    __tablename__ = "{table}"')
    if schema != 'public':
        print(f'    __table_args__ = {{"schema": "{schema}", "extend_existing": True}}')
    else:
        print(f'    __table_args__ = {{"extend_existing": True}}')
    print()

    # Get columns for this table
    with db_service.get_session() as session:
        result = session.execute(f"""
            SELECT column_name, data_type, is_nullable, column_default
            FROM information_schema.columns
            WHERE table_schema = '{schema}' AND table_name = '{table}'
            ORDER BY ordinal_position
        """)

        columns = list(result)

        for col_name, data_type, nullable, default in columns:
            # Map PostgreSQL types to SQLAlchemy types
            type_map = {
                'integer': 'Integer',
                'bigint': 'Integer',
                'smallint': 'Integer',
                'character varying': 'String(255)',
                'varchar': 'String(255)',
                'text': 'Text',
                'timestamp without time zone': 'DateTime',
                'timestamp with time zone': 'DateTime',
                'date': 'DateTime',
                'boolean': 'Boolean',
                'double precision': 'Float',
                'real': 'Float',
                'numeric': 'Float'
            }

            sa_type = type_map.get(data_type, 'String')
            nullable_str = '' if nullable == 'YES' else ', nullable=False'

            # Check if primary key
            with db_service.get_session() as session:
                result = session.execute(f"""
                    SELECT a.attname
                    FROM pg_index i
                    JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
                    WHERE i.indrelid = '{schema}.{table}'::regclass
                    AND i.indisprimary
                    AND a.attname = '{col_name}'
                """)
                is_pkey = result.scalar() is not None

            pkey_str = ', primary_key=True' if is_pkey else ''

            print(f"    {col_name} = Column({sa_type}{pkey_str}{nullable_str})")

print("\n```")

print("\n" + "=" * 80)
print(" INSPECTION COMPLETE".center(80))
print("=" * 80)

print("\n📝 Next steps:")
print("   1. Copy the model template above to app/models/existing_tables.py")
print("   2. Review and adjust data types if needed")
print("   3. Update app/services/data_service.py to query these tables")
print("   4. Run: python scripts/test_real_database.py")
print("   5. Run: streamlit run Home.py")

print("\n💡 Tips:")
print("   - Use __table_args__ = {'extend_existing': True} to prevent creating new tables")
print("   - Match column names exactly to your database")
print("   - Add indexes for frequently queried columns")
print("   - Use aliases in queries if column names need to be different")
