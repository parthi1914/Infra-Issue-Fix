"""
Load sample data into PostgreSQL from JSON file.
"""
import json
from datetime import datetime
from pathlib import Path
from app.core.database import get_database_service
from app.core import initialize_app
from app.core.logging import get_logger

# Initialize
initialize_app()
logger = get_logger(__name__)

print("=" * 60)
print("Load Sample Data")
print("=" * 60)

# Get database service
db_service = get_database_service()

# Test connection
print("\n1. Testing connection...")
if not db_service.health_check():
    print("   ❌ Connection failed!")
    exit(1)
print("   ✅ Connection successful!")

# Load JSON data
json_file = Path("data/dummy_events.json")

if not json_file.exists():
    print(f"\n❌ JSON file not found: {json_file}")
    print("   Please create data/dummy_events.json first")
    exit(1)

print(f"\n2. Loading data from {json_file}...")
with open(json_file, "r") as f:
    events = json.load(f)

print(f"   Found {len(events)} events")

# Insert into database
print("\n3. Inserting events into PostgreSQL...")
inserted_count = 0
skipped_count = 0

try:
    with db_service.get_session() as session:
        for i, event in enumerate(events, 1):
            # Convert timestamp string to datetime
            timestamp_str = event['timestamp']
            if 'Z' in timestamp_str:
                timestamp_str = timestamp_str.replace('Z', '+00:00')
            event['timestamp'] = datetime.fromisoformat(timestamp_str)

            # Execute insert
            result = session.execute("""
                INSERT INTO events (
                    event_id, engine_serial, tail_number, system, status,
                    timestamp, latency_ms, data_element, data_quality_score
                ) VALUES (
                    :event_id, :engine_serial, :tail_number, :system, :status,
                    :timestamp, :latency_ms, :data_element, :data_quality_score
                )
                ON CONFLICT (event_id) DO NOTHING
            """, event)

            if result.rowcount > 0:
                inserted_count += 1
                print(f"   [{i}/{len(events)}] Inserted: {event['event_id']}")
            else:
                skipped_count += 1
                print(f"   [{i}/{len(events)}] Skipped (exists): {event['event_id']}")

        session.commit()

except Exception as e:
    print(f"\n❌ Insert failed: {e}")
    exit(1)

print(f"\n   ✅ Inserted: {inserted_count}")
print(f"   ⚠️  Skipped: {skipped_count}")

# Verify data
print("\n4. Verifying data...")
try:
    with db_service.get_session() as session:
        # Total count
        result = session.execute("SELECT COUNT(*) FROM events")
        total_count = result.scalar()
        print(f"   Total events in database: {total_count}")

        # Count by status
        result = session.execute("""
            SELECT status, COUNT(*) as count
            FROM events
            GROUP BY status
            ORDER BY count DESC
        """)
        print("\n   Events by status:")
        for status, count in result:
            print(f"      {status}: {count}")

        # Count by system
        result = session.execute("""
            SELECT system, COUNT(*) as count
            FROM events
            GROUP BY system
            ORDER BY count DESC
        """)
        print("\n   Events by system:")
        for system, count in result:
            print(f"      {system}: {count}")

except Exception as e:
    print(f"\n❌ Verification failed: {e}")
    exit(1)

print("\n" + "=" * 60)
print("Data loaded successfully! ✅")
print("=" * 60)
print("\nNext step: Update .env to set ENABLE_DUMMY_DATA=False")
print("Then run: streamlit run Home.py")
