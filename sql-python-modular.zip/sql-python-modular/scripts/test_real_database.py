"""
Test integration with existing AWS PostgreSQL database.
Run this after configuring DATABASE_URL to verify real data integration.
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.core.config import get_settings
import pandas as pd

initialize_app()
logger = get_logger(__name__)
settings = get_settings()

print("=" * 80)
print(" TESTING REAL DATABASE INTEGRATION".center(80))
print("=" * 80)

# Step 1: Check configuration
print("\n1️⃣  Configuration Check")
print("-" * 80)

print(f"   Environment: {settings.ENVIRONMENT}")
print(f"   ENABLE_DUMMY_DATA: {settings.ENABLE_DUMMY_DATA}")

db_service = inject("database_service")
print(f"   DATABASE_URL: {db_service._mask_password(settings.DATABASE_URL)}")

if settings.ENABLE_DUMMY_DATA:
    print("\n   ❌ ERROR: ENABLE_DUMMY_DATA is True!")
    print("\n   To use real PostgreSQL database:")
    print("      1. Edit .env file")
    print("      2. Set: ENABLE_DUMMY_DATA=False")
    print("      3. Re-run this script")
    exit(1)

print("\n   ✅ Configuration correct (ENABLE_DUMMY_DATA=False)")

# Step 2: Test database connection
print("\n2️⃣  Database Connection")
print("-" * 80)

print("   Testing connection...")

if not db_service.health_check():
    print("   ❌ Database connection failed!")
    print("\n   Troubleshooting steps:")
    print("      1. Check DATABASE_URL in .env")
    print("      2. Verify RDS security group allows your IP")
    print("      3. Test with psql:")
    print(f"         psql '{settings.DATABASE_URL}'")
    print("      4. Check RDS instance is running")
    print("      5. Verify username/password are correct")
    exit(1)

print("   ✅ Database connected successfully!")

# Get database info
with db_service.get_session() as session:
    result = session.execute("SELECT current_database(), current_user")
    db_name, db_user = result.fetchone()
    print(f"   Database: {db_name}")
    print(f"   User: {db_user}")

# Step 3: Check tables exist
print("\n3️⃣  Table Verification")
print("-" * 80)

print("   Checking for required tables...")

with db_service.get_session() as session:
    result = session.execute("""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
        ORDER BY table_name
    """)

    tables = [row[0] for row in result]

    if not tables:
        print("   ❌ No tables found in database!")
        print("\n   Make sure you're connected to the correct database")
        print("   Run: python scripts/inspect_database.py")
        exit(1)

    print(f"   ✅ Found {len(tables)} table(s):")
    for table in tables:
        print(f"      • {table}")

# Step 4: Test data service
print("\n4️⃣  Data Service Integration")
print("-" * 80)

try:
    data_service = inject("data_service")

    print("   Querying data (last 24 hours)...")

    df = data_service.get_events_data(hours=24)

    if len(df) == 0:
        print("   ⚠️  No data returned!")
        print("\n   Possible reasons:")
        print("      1. No data in last 24 hours")
        print("      2. Query needs adjustment for your schema")
        print("      3. Column names don't match")
        print("\n   Try:")
        print("      - Increase time window: hours=168 (7 days)")
        print("      - Run: python scripts/inspect_database.py")
        print("      - Check app/services/data_service.py query")
    else:
        print(f"   ✅ Retrieved {len(df)} records!")

        # Show data summary
        print(f"\n   📊 Data Summary:")
        print(f"      Columns: {len(df.columns)}")
        print(f"      Column names: {list(df.columns)}")

        if 'timestamp' in df.columns:
            print(f"      Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")

        if 'engine_serial' in df.columns:
            unique_engines = df['engine_serial'].nunique()
            print(f"      Unique engines: {unique_engines}")
            print(f"      Engines: {df['engine_serial'].unique().tolist()[:5]}" +
                  (" ..." if unique_engines > 5 else ""))

        if 'system' in df.columns:
            systems = df['system'].value_counts().to_dict()
            print(f"      Systems: {systems}")

        if 'status' in df.columns:
            statuses = df['status'].value_counts().to_dict()
            print(f"      Statuses: {statuses}")

        # Show sample records
        print(f"\n   📋 Sample Records (first 5):")
        print(f"   {'-' * 76}")

        display_cols = []
        for col in ['event_id', 'engine_serial', 'system', 'status', 'timestamp']:
            if col in df.columns:
                display_cols.append(col)

        if display_cols:
            for i, row in df.head(5).iterrows():
                values = [str(row[col])[:20] for col in display_cols]
                print(f"   {' | '.join(values)}")
        else:
            print(f"   {df.head(5).to_string()}")

except Exception as e:
    print(f"   ❌ Data query failed: {e}")
    logger.error("Data service test failed", exc_info=True)
    print("\n   Troubleshooting:")
    print("      1. Check app/services/data_service.py")
    print("      2. Verify column names match your table")
    print("      3. Run: python scripts/inspect_database.py")
    print("      4. Check logs/app.log for details")
    exit(1)

# Step 5: Test filtering
if len(df) > 0:
    print("\n5️⃣  Filter Testing")
    print("-" * 80)

    # Test engine filter
    if 'engine_serial' in df.columns and len(df) > 0:
        first_engine = df['engine_serial'].iloc[0]
        print(f"   Testing filter: engine_serial={first_engine}...")

        try:
            df_filtered = data_service.get_events_data(
                engine_serial=first_engine,
                hours=24
            )
            print(f"   ✅ Filtered to {len(df_filtered)} records for engine {first_engine}")

            # Verify all records are for the correct engine
            if len(df_filtered) > 0 and 'engine_serial' in df_filtered.columns:
                unique_engines = df_filtered['engine_serial'].unique()
                if len(unique_engines) == 1 and unique_engines[0] == first_engine:
                    print(f"   ✅ Filter working correctly")
                else:
                    print(f"   ⚠️  Filter returned unexpected engines: {unique_engines}")

        except Exception as e:
            print(f"   ❌ Filter test failed: {e}")

    # Test tail number filter
    if 'tail_number' in df.columns and df['tail_number'].notna().any():
        first_tail = df[df['tail_number'].notna()]['tail_number'].iloc[0]
        print(f"   Testing filter: tail_number={first_tail}...")

        try:
            df_filtered = data_service.get_events_data(
                tail_number=first_tail,
                hours=24
            )
            print(f"   ✅ Filtered to {len(df_filtered)} records for tail {first_tail}")

        except Exception as e:
            print(f"   ❌ Tail number filter test failed: {e}")

# Step 6: Performance check
if len(df) > 0:
    print("\n6️⃣  Performance Check")
    print("-" * 80)

    import time

    start_time = time.time()
    df_perf = data_service.get_events_data(hours=24)
    elapsed = time.time() - start_time

    print(f"   Query time: {elapsed:.3f} seconds for {len(df_perf)} records")

    if elapsed > 5:
        print(f"   ⚠️  Query is slow (>{elapsed:.1f}s)")
        print("   Consider:")
        print("      - Adding database indexes")
        print("      - Reducing time window")
        print("      - Adding LIMIT to query")
    else:
        print(f"   ✅ Query performance good")

# Final summary
print("\n" + "=" * 80)
print(" TEST SUMMARY".center(80))
print("=" * 80)

summary = []
summary.append("✅ Configuration: Correct (ENABLE_DUMMY_DATA=False)")
summary.append("✅ Database: Connected")
summary.append(f"✅ Tables: {len(tables)} found")
summary.append(f"✅ Data Query: {len(df)} records retrieved" if len(df) > 0 else "⚠️  Data Query: No records found")

if len(df) > 0:
    summary.append("✅ Filters: Working")
    summary.append("✅ Ready to use!")
else:
    summary.append("⚠️  No data - check query/schema")

for item in summary:
    print(f"   {item}")

if len(df) > 0:
    print("\n🚀 Next Steps:")
    print("   1. Run Streamlit app:")
    print("      streamlit run Home.py")
    print("\n   2. In the app:")
    print("      • Select engine from sidebar")
    print("      • View real data in Overview tab")
    print("      • Check all tabs for real data")
    print("\n   3. Configure AWS services (optional):")
    print("      python scripts/test_aws_services.py")

    print("\n✅ Integration test PASSED - Ready to use real data!")
else:
    print("\n⚠️  Integration test completed with warnings")
    print("   Data query returned no results - may need adjustment")

print("\n" + "=" * 80)
