# Database Scripts

Utility scripts for setting up and managing your PostgreSQL database.

## Scripts Overview

| Script | Purpose | When to Use |
|--------|---------|-------------|
| [test_postgres.py](test_postgres.py) | Test database connection | Before setup, to verify connectivity |
| [setup_database.py](setup_database.py) | Create database schema | Once, after creating RDS instance |
| [load_sample_data.py](load_sample_data.py) | Load JSON data into PostgreSQL | Once, after schema creation |
| [query_examples.py](query_examples.py) | Example database queries | Anytime, to see query examples |

## Quick Start

### 1. Test Connection

After creating your AWS RDS PostgreSQL instance and updating `.env`:

```bash
python scripts/test_postgres.py
```

**Expected output:**
```
============================================================
Testing PostgreSQL Connection
============================================================

1. Testing connection...
   ✅ Connection successful!

2. Connection details:
   Database URL: postgresql://admin:****@your-rds.amazonaws.com:5432/db
   Pool size: 10
   Max overflow: 20
   Environment: aws

3. Testing query execution...
   ✅ PostgreSQL version: PostgreSQL 14.7 on x86_64-pc-linux-gnu...

============================================================
All tests passed! ✅
============================================================
```

### 2. Create Database Schema

Creates the `events` table with proper indexes:

```bash
python scripts/setup_database.py
```

**What it does:**
- Creates `events` table
- Creates indexes on common query columns
- Verifies table creation
- Shows all indexes

**Expected output:**
```
============================================================
Database Setup
============================================================

1. Testing connection...
   ✅ Connection successful!

2. Creating database tables...
   ✅ Tables created successfully!

3. Verifying tables...
   ✅ Found 1 table(s):
      - events

4. Checking indexes...
   ✅ Found 5 index(es):
      - events.events_pkey
      - events.events_event_id_key
      - events.idx_events_engine_serial
      - events.idx_events_tail_number
      - events.idx_events_timestamp
```

### 3. Load Sample Data

Loads data from `data/dummy_events.json` into PostgreSQL:

```bash
python scripts/load_sample_data.py
```

**What it does:**
- Reads `data/dummy_events.json`
- Inserts events into PostgreSQL
- Skips duplicates (based on `event_id`)
- Shows statistics

**Expected output:**
```
============================================================
Load Sample Data
============================================================

1. Testing connection...
   ✅ Connection successful!

2. Loading data from data/dummy_events.json...
   Found 15 events

3. Inserting events into PostgreSQL...
   [1/15] Inserted: evt_001
   [2/15] Inserted: evt_002
   ...

   ✅ Inserted: 15
   ⚠️  Skipped: 0

4. Verifying data...
   Total events in database: 15

   Events by status:
      Complete: 10
      Processing: 2
      ...
```

### 4. Run Query Examples

See example database queries:

```bash
python scripts/query_examples.py
```

**What it shows:**
- Recent events
- Filter by status
- Aggregate statistics
- Filter by engine serial
- Time-based queries
- Data quality analysis

## Typical Workflow

### First Time Setup

```bash
# 1. Update .env with your PostgreSQL connection
nano .env
# Set DATABASE_URL=postgresql://...

# 2. Test connection
python scripts/test_postgres.py

# 3. Create schema
python scripts/setup_database.py

# 4. Load data
python scripts/load_sample_data.py

# 5. Update .env to use PostgreSQL
nano .env
# Set ENABLE_DUMMY_DATA=False

# 6. Run application
streamlit run Home.py
```

### After Schema Changes

```bash
# Drop and recreate tables (WARNING: deletes all data!)
python -c "from app.core.database import get_database_service; from app.core import initialize_app; initialize_app(); get_database_service().drop_tables()"

# Recreate schema
python scripts/setup_database.py

# Reload data
python scripts/load_sample_data.py
```

### Testing Queries

```bash
# See example queries
python scripts/query_examples.py

# Or open Python shell
python
>>> from app.core.database import get_database_service
>>> from app.core import initialize_app
>>> initialize_app()
>>> db = get_database_service()
>>> with db.get_session() as session:
...     result = session.execute("SELECT * FROM events LIMIT 5")
...     for row in result:
...         print(row)
```

## Troubleshooting

### Connection Failed

**Error:** Connection timeout or authentication failed

**Solutions:**
1. Check `.env` DATABASE_URL is correct
2. Verify RDS security group allows your IP
3. Ensure RDS is publicly accessible (for testing)
4. Test with `psql`:
   ```bash
   psql postgresql://admin:password@your-rds.amazonaws.com:5432/database
   ```

### Table Already Exists

**Error:** Table "events" already exists

**Solution:**
Table already created, skip to loading data:
```bash
python scripts/load_sample_data.py
```

Or drop and recreate (deletes data!):
```bash
python -c "from app.core.database import get_database_service; from app.core import initialize_app; initialize_app(); get_database_service().drop_tables(); get_database_service().create_tables()"
```

### JSON File Not Found

**Error:** JSON file not found: data/dummy_events.json

**Solution:**
File exists at `data/dummy_events.json`. Run from project root:
```bash
cd /path/to/sql-python-modular
python scripts/load_sample_data.py
```

## Advanced Usage

### Custom Queries

Create your own query script:

```python
# my_query.py
from app.core.database import get_database_service
from app.core import initialize_app

initialize_app()
db_service = get_database_service()

with db_service.get_session() as session:
    result = session.execute("""
        -- Your SQL query here
        SELECT * FROM events WHERE status = 'Error'
    """)

    for row in result:
        print(row)
```

### Backup Data

Export data to JSON:

```python
# backup.py
import json
from app.core.database import get_database_service
from app.core import initialize_app

initialize_app()
db = get_database_service()

with db.get_session() as session:
    result = session.execute("SELECT * FROM events")

    events = []
    for row in result:
        events.append(dict(row))

    with open("backup.json", "w") as f:
        json.dump(events, f, indent=2, default=str)

print(f"Backed up {len(events)} events")
```

## Related Documentation

- **[DATABASE_GUIDE.md](../docs/DATABASE_GUIDE.md)**: Complete database guide
- **[QUICKSTART.md](../QUICKSTART.md)**: Quick start guide
- **[README.md](../README.md)**: Main documentation

## Need Help?

Check the logs:
```bash
cat logs/app.log | grep -i error
```

All database operations are logged with correlation IDs for debugging.
