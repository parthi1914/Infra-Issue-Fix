# Real Data Integration - Simple Checklist

## 🎯 Goal
Connect your Streamlit app to **existing AWS PostgreSQL database** and display **real data** in Overview and all tabs.

## ✅ Step-by-Step Checklist

### Step 1: Get Database Connection Info

- [ ] Have AWS RDS endpoint (e.g., `mydb.abc123.us-east-1.rds.amazonaws.com`)
- [ ] Have database name
- [ ] Have username
- [ ] Have password
- [ ] Know which port (usually `5432`)

**How to get:**
```bash
aws rds describe-db-instances --query 'DBInstances[*].[DBInstanceIdentifier,Endpoint.Address]' --output table
```

---

### Step 2: Update Configuration

- [ ] Edit `.env` file
- [ ] Set `ENABLE_DUMMY_DATA=False`
- [ ] Set `DATABASE_URL=postgresql://user:pass@host:5432/dbname`

**Example .env:**
```bash
# Switch to PostgreSQL
ENABLE_DUMMY_DATA=False

# Your database connection
DATABASE_URL=postgresql://admin:MyPassword123@mydb.abc123.us-east-1.rds.amazonaws.com:5432/production_db

# Connection pool
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
```

---

### Step 3: Inspect Your Database

- [ ] Run inspection script:
  ```bash
  python scripts/inspect_database.py
  ```

- [ ] Note down:
  - [ ] Table name (e.g., `events`, `flight_data`, `engine_events`)
  - [ ] Column names
  - [ ] Data types
  - [ ] Primary key

**You should see:**
- List of all tables
- Columns in each table
- Sample data
- SQLAlchemy model template (copy this!)

---

### Step 4: Create SQLAlchemy Models

- [ ] Create file: `app/models/existing_tables.py`
- [ ] Copy model template from inspection output
- [ ] Adjust to match your table structure

**Template:**
```python
from sqlalchemy import Column, Integer, String, DateTime, Float
from app.core.database import Base

class Event(Base):
    """Your existing events table."""
    __tablename__ = "events"  # YOUR table name
    __table_args__ = {'extend_existing': True}  # Don't create new table!

    # Match YOUR actual columns
    id = Column(Integer, primary_key=True)
    event_id = Column(String(100))
    engine_serial = Column(String(50))
    # ... add all your columns
```

---

### Step 5: Update Data Service Query

- [ ] Edit `app/services/data_service.py`
- [ ] Find `_get_postgres_data()` method (line ~95)
- [ ] Update SQL query to match YOUR table

**Example:**
```python
def _get_postgres_data(self, engine_serial=None, tail_number=None, hours=24):
    query = """
        SELECT
            event_id,
            engine_serial,
            tail_number,
            system_name as system,      -- Map to expected column
            status,
            timestamp,
            latency_ms,
            data_element,
            quality_score as data_quality_score  -- Map to expected column
        FROM YOUR_TABLE_NAME              -- ← Change this!
        WHERE timestamp >= NOW() - INTERVAL '%s hours'
    """ % hours

    # ... rest of the code
```

**Key changes:**
- [ ] Change table name to YOUR table
- [ ] Change column names to YOUR columns
- [ ] Use `as` to map to expected names (system, data_quality_score)

---

### Step 6: Test the Integration

- [ ] Run test script:
  ```bash
  python scripts/test_real_database.py
  ```

**Expected output:**
```
✅ Configuration: Correct
✅ Database: Connected
✅ Tables: 3 found
✅ Data Query: 1,234 records retrieved
✅ Filters: Working
✅ Ready to use!
```

**If errors:**
- Check logs: `cat logs/app.log | tail -50`
- Verify column names match
- Check table name is correct

---

### Step 7: Run the Application

- [ ] Start Streamlit:
  ```bash
  streamlit run Home.py
  ```

- [ ] Open browser: http://localhost:8501

- [ ] Verify:
  - [ ] Sidebar shows engine serials from YOUR data
  - [ ] Overview tab shows YOUR real events
  - [ ] Timeline shows YOUR data
  - [ ] All tabs display YOUR real data
  - [ ] Filters work correctly

---

### Step 8: Enable AWS Services (Optional)

- [ ] Enable CloudWatch logging:
  ```bash
  ENABLE_AWS_LOGGING=True
  AWS_LOG_GROUP=/aws/streamlit/data-observability
  ```

- [ ] Configure SNS alerts:
  ```bash
  AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:alerts
  ```

- [ ] Test AWS services:
  ```bash
  python scripts/test_aws_services.py
  ```

---

## 🚨 Common Issues & Solutions

### Issue 1: Connection Failed

**Error:** `Connection timeout` or `Authentication failed`

**Solutions:**
- [ ] Check RDS security group allows your IP
- [ ] Verify username/password
- [ ] Test with psql: `psql "postgresql://..."`

### Issue 2: No Data Returned

**Error:** Query returns 0 records

**Solutions:**
- [ ] Increase time window: `hours=168` (7 days)
- [ ] Check table has data: `SELECT COUNT(*) FROM your_table`
- [ ] Verify timestamp column name
- [ ] Check WHERE clause

### Issue 3: Column Not Found

**Error:** `column "data_quality_score" does not exist`

**Solutions:**
- [ ] Check actual column name in your table
- [ ] Use alias in query: `quality_score as data_quality_score`
- [ ] Update query to use correct column names

### Issue 4: Wrong Data Displayed

**Error:** Data looks wrong or empty

**Solutions:**
- [ ] Check you're querying the right table
- [ ] Verify column mappings (use `as` to rename)
- [ ] Check filters are working
- [ ] Look at logs: `cat logs/app.log`

---

## 📊 Quick Commands Reference

```bash
# Step 1: Inspect your database
python scripts/inspect_database.py

# Step 2: Test integration
python scripts/test_real_database.py

# Step 3: Run application
streamlit run Home.py

# Troubleshooting: Check logs
cat logs/app.log | tail -50

# Troubleshooting: Test direct connection
psql "postgresql://user:pass@host:5432/db"

# Troubleshooting: Test AWS services
python scripts/test_aws_services.py
```

---

## 📁 Files to Modify

| File | What to Change |
|------|----------------|
| `.env` | `ENABLE_DUMMY_DATA=False`, `DATABASE_URL=...` |
| `app/models/existing_tables.py` | Create models for YOUR tables |
| `app/services/data_service.py` | Update query to use YOUR table/columns |

---

## 🎯 Success Criteria

✅ **You're done when:**
1. `python scripts/test_real_database.py` passes
2. Streamlit shows YOUR real data
3. All tabs display YOUR data
4. Filters work correctly
5. No errors in logs

---

## 📚 Documentation

- **Complete guide:** [docs/EXISTING_DATABASE_GUIDE.md](docs/EXISTING_DATABASE_GUIDE.md)
- **Database guide:** [docs/DATABASE_GUIDE.md](docs/DATABASE_GUIDE.md)
- **AWS services:** [docs/AWS_SERVICES_GUIDE.md](docs/AWS_SERVICES_GUIDE.md)
- **Quick reference:** [docs/QUICK_REFERENCE.md](docs/QUICK_REFERENCE.md)

---

## 💡 Pro Tips

1. **Start with inspection:** Always run `inspect_database.py` first
2. **Test incrementally:** Test after each step
3. **Check logs:** Logs show exact SQL queries and errors
4. **Use correlation IDs:** Search logs by correlation_id for debugging
5. **Limit data:** Add `LIMIT` to queries during testing
6. **Add indexes:** Create indexes on frequently queried columns

---

## Need Help?

1. **Check logs:** `cat logs/app.log | grep ERROR`
2. **Find correlation ID:** Look for `[01HQXXX...]` in error message
3. **Search logs:** `cat logs/app.log | grep "01HQXXX..."`
4. **Run inspection:** `python scripts/inspect_database.py`
5. **Test connection:** `psql "YOUR_DATABASE_URL"`

**All errors include correlation IDs for easy debugging!**
