# Connect to Existing AWS PostgreSQL Database

## Overview

This guide shows how to connect your application to an **existing AWS PostgreSQL database** with **real tables and data** (without creating new tables).

## 🎯 Goal

Connect the framework to your existing database and display real data in the Overview tab and other components.

---

## Step 1: Get Your Database Connection Details

### Find Your RDS Endpoint

**Option 1: AWS Console**
1. Go to AWS Console → RDS → Databases
2. Click on your database instance
3. Copy the "Endpoint" (e.g., `mydb.abc123.us-east-1.rds.amazonaws.com`)

**Option 2: AWS CLI**
```bash
# List all RDS instances
aws rds describe-db-instances \
  --query 'DBInstances[*].[DBInstanceIdentifier,Endpoint.Address,Endpoint.Port]' \
  --output table

# Get specific instance
aws rds describe-db-instances \
  --db-instance-identifier your-db-name \
  --query 'DBInstances[0].Endpoint.Address' \
  --output text
```

### Get Connection Information

You need:
- ✅ **Endpoint**: `your-db.abc123.us-east-1.rds.amazonaws.com`
- ✅ **Port**: `5432` (default PostgreSQL)
- ✅ **Database Name**: `your_database_name`
- ✅ **Username**: `your_username`
- ✅ **Password**: `your_password`

---

## Step 2: Test Direct Connection

### Test with psql (Optional but Recommended)

```bash
# Install psql if needed
# Windows: Download from https://www.postgresql.org/download/windows/
# Mac: brew install postgresql
# Linux: sudo apt-get install postgresql-client

# Test connection
psql -h your-db.abc123.us-east-1.rds.amazonaws.com \
     -p 5432 \
     -U your_username \
     -d your_database_name

# Enter password when prompted
```

**If successful, you'll see:**
```
your_database_name=>
```

**List all tables:**
```sql
\dt
```

**Describe a table:**
```sql
\d table_name
```

---

## Step 3: Update Configuration

### Update .env File

```bash
# Edit .env
nano .env
```

Add/update these lines:

```bash
# ==================== Database Configuration ====================

# Switch from JSON to PostgreSQL
ENABLE_DUMMY_DATA=False

# Your existing AWS PostgreSQL database
DATABASE_URL=postgresql://your_username:your_password@your-db.abc123.us-east-1.rds.amazonaws.com:5432/your_database_name

# Connection pool settings
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
DB_ECHO=False  # Set to True to see SQL queries (for debugging)
```

**Important:** Replace with your actual values!

### Verify Configuration

```bash
# Check .env
cat .env | grep DATABASE_URL

# Should show your connection string (password visible)
```

---

## Step 4: Inspect Your Existing Tables

Create a script to inspect your database schema:

### Create `scripts/inspect_database.py`

```python
"""
Inspect existing database schema.
Run this to see your table structure.
"""
from app.core import initialize_app, get_logger
from app.core.database import get_database_service

initialize_app()
logger = get_logger(__name__)
db_service = get_database_service()

print("=" * 80)
print(" INSPECTING EXISTING DATABASE".center(80))
print("=" * 80)

# Test connection
print("\n1. Testing connection...")
if not db_service.health_check():
    print("   ❌ Connection failed!")
    print("   Check your DATABASE_URL in .env")
    exit(1)
print("   ✅ Connected successfully!")

# List all tables
print("\n2. Tables in database:")
print("-" * 80)

with db_service.get_session() as session:
    result = session.execute("""
        SELECT
            schemaname,
            tablename,
            tableowner
        FROM pg_tables
        WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
        ORDER BY tablename
    """)

    tables = list(result)

    if not tables:
        print("   ⚠️  No tables found!")
        exit(1)

    print(f"   Found {len(tables)} table(s):\n")
    for schema, table, owner in tables:
        print(f"   📋 {schema}.{table} (owner: {owner})")

# Get detailed information for each table
print("\n3. Table details:")
print("-" * 80)

with db_service.get_session() as session:
    for schema, table, _ in tables:
        print(f"\n   📋 Table: {schema}.{table}")

        # Get columns
        result = session.execute(f"""
            SELECT
                column_name,
                data_type,
                is_nullable,
                column_default
            FROM information_schema.columns
            WHERE table_schema = '{schema}'
            AND table_name = '{table}'
            ORDER BY ordinal_position
        """)

        columns = list(result)
        print(f"      Columns ({len(columns)}):")

        for col_name, data_type, nullable, default in columns:
            null_str = "NULL" if nullable == "YES" else "NOT NULL"
            default_str = f" DEFAULT {default}" if default else ""
            print(f"         • {col_name:<30} {data_type:<20} {null_str}{default_str}")

        # Get row count
        result = session.execute(f'SELECT COUNT(*) FROM "{schema}"."{table}"')
        count = result.scalar()
        print(f"      Row count: {count:,}")

        # Get sample data (first 2 rows)
        result = session.execute(f'SELECT * FROM "{schema}"."{table}" LIMIT 2')
        sample_rows = list(result)

        if sample_rows:
            print(f"      Sample data (first 2 rows):")
            for i, row in enumerate(sample_rows, 1):
                print(f"         Row {i}: {dict(row)}")

print("\n" + "=" * 80)
print(" INSPECTION COMPLETE".center(80))
print("=" * 80)

print("\n📝 Next steps:")
print("   1. Identify the table(s) you want to query")
print("   2. Note the column names")
print("   3. Create SQLAlchemy models (see Step 5)")
print("   4. Update DataService to query your tables (see Step 6)")
```

### Run the Inspection

```bash
python scripts/inspect_database.py
```

**Output example:**
```
================================================================================
                         INSPECTING EXISTING DATABASE
================================================================================

1. Testing connection...
   ✅ Connected successfully!

2. Tables in database:
--------------------------------------------------------------------------------
   Found 3 table(s):

   📋 public.events
   📋 public.engines
   📋 public.flights

3. Table details:
--------------------------------------------------------------------------------

   📋 Table: public.events
      Columns (10):
         • id                            integer              NOT NULL
         • event_id                      character varying    NOT NULL
         • engine_serial                 character varying    NOT NULL
         • tail_number                   character varying    NULL
         • system_name                   character varying    NOT NULL
         • status                        character varying    NOT NULL
         • timestamp                     timestamp            NOT NULL
         • latency_ms                    integer              NULL
         • data_element                  character varying    NULL
         • quality_score                 double precision     NULL
      Row count: 15,432
      Sample data (first 2 rows):
         Row 1: {'id': 1, 'event_id': 'evt_001', 'engine_serial': '000000', ...}
         Row 2: {'id': 2, 'event_id': 'evt_002', 'engine_serial': '038429', ...}
```

---

## Step 5: Create SQLAlchemy Models for Existing Tables

### Understanding Your Table Structure

From the inspection, note:
- **Table name** (e.g., `events`, `engines`, `flights`)
- **Column names** and types
- **Primary keys**
- **Relationships**

### Create Models File

Create `app/models/existing_tables.py`:

```python
"""
SQLAlchemy models for existing database tables.
These models map to your existing database schema (DO NOT create new tables).
"""
from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey
from sqlalchemy.orm import relationship
from app.core.database import Base


# ============================================================================
# IMPORTANT: Set __table_args__ to prevent table creation
# ============================================================================

class Event(Base):
    """
    Maps to existing 'events' table.
    Adjust column names to match YOUR actual table.
    """
    __tablename__ = "events"
    __table_args__ = {'extend_existing': True}  # Don't try to create

    # Primary key
    id = Column(Integer, primary_key=True)

    # Columns (adjust to match your table)
    event_id = Column(String(100), unique=True, nullable=False)
    engine_serial = Column(String(50), nullable=False, index=True)
    tail_number = Column(String(50), nullable=True)
    system_name = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    latency_ms = Column(Integer, nullable=True)
    data_element = Column(String(100), nullable=True)
    quality_score = Column(Float, nullable=True)

    def __repr__(self):
        return f"<Event(event_id={self.event_id}, system={self.system_name}, status={self.status})>"


class Engine(Base):
    """
    Maps to existing 'engines' table (if you have one).
    """
    __tablename__ = "engines"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    serial_number = Column(String(50), unique=True, nullable=False)
    model = Column(String(100))
    manufacture_date = Column(DateTime)

    def __repr__(self):
        return f"<Engine(serial={self.serial_number}, model={self.model})>"


class Flight(Base):
    """
    Maps to existing 'flights' table (if you have one).
    """
    __tablename__ = "flights"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True)
    flight_number = Column(String(20))
    tail_number = Column(String(50))
    departure_time = Column(DateTime)
    arrival_time = Column(DateTime)

    def __repr__(self):
        return f"<Flight(flight_number={self.flight_number}, tail={self.tail_number})>"


# ============================================================================
# Add more models as needed for your other tables
# ============================================================================
```

**IMPORTANT:**
- ✅ Use `__table_args__ = {'extend_existing': True}` to prevent creating new tables
- ✅ Match column names **exactly** to your existing table
- ✅ Match data types to your table's data types
- ✅ **DO NOT** run `db_service.create_tables()` - tables already exist!

### Adjust Column Names

**Example: If your table uses different column names:**

Your actual table:
```sql
CREATE TABLE events (
    event_identifier VARCHAR(100),  -- Different name!
    eng_serial VARCHAR(50),         -- Different name!
    ...
);
```

Update your model:
```python
class Event(Base):
    __tablename__ = "events"
    __table_args__ = {'extend_existing': True}

    # Map to actual column names
    event_id = Column('event_identifier', String(100))  # Use 'event_identifier'
    engine_serial = Column('eng_serial', String(50))    # Use 'eng_serial'
```

---

## Step 6: Update DataService to Query Real Tables

### Update `app/services/data_service.py`

Edit the `_get_postgres_data` method to query your actual table:

```python
def _get_postgres_data(
    self,
    engine_serial: Optional[str] = None,
    tail_number: Optional[str] = None,
    hours: int = 24
) -> pd.DataFrame:
    """Load data from existing PostgreSQL tables."""
    from app.core.database import get_database_service
    from app.models.existing_tables import Event  # Import your model

    db_service = get_database_service()

    activity_logger.log_activity(
        activity="query_postgres",
        status="started",
        engine_serial=engine_serial,
        tail_number=tail_number,
        hours=hours
    )

    try:
        with db_service.get_session() as session:
            # Build query using your actual table structure
            query = """
                SELECT
                    event_id,
                    engine_serial,
                    tail_number,
                    system_name as system,  -- Map to expected column
                    status,
                    timestamp,
                    latency_ms,
                    data_element,
                    quality_score as data_quality_score  -- Map to expected column
                FROM events
                WHERE timestamp >= NOW() - INTERVAL '%s hours'
            """ % hours

            # Add filters
            filters = []
            params = {}

            if engine_serial:
                filters.append("engine_serial = :engine_serial")
                params["engine_serial"] = engine_serial

            if tail_number:
                filters.append("tail_number = :tail_number")
                params["tail_number"] = tail_number

            if filters:
                query += " AND " + " AND ".join(filters)

            query += " ORDER BY timestamp DESC LIMIT 10000"  # Limit for safety

            # Execute and convert to DataFrame
            df = pd.read_sql(query, session.bind, params=params)

            activity_logger.log_activity(
                activity="query_postgres",
                status="completed",
                rows_returned=len(df)
            )

            logger.info(f"Loaded {len(df)} records from existing database")
            return df

    except Exception as e:
        activity_logger.log_activity(
            activity="query_postgres",
            status="failed",
            error=str(e)
        )
        log_exception(e, context={"activity": "query_postgres"})
        raise DataNotFoundException(
            f"Failed to query existing database: {e}",
            details={
                "engine_serial": engine_serial,
                "tail_number": tail_number,
                "hours": hours
            }
        )
```

**Key points:**
- ✅ Query your actual table name (`events`, not a new table)
- ✅ Map column names (e.g., `system_name as system`)
- ✅ Add `LIMIT` to prevent loading too much data
- ✅ Use filters (engine_serial, tail_number)

---

## Step 7: Create Mapping Helper (Optional)

If your table columns are very different, create a mapping function:

### Create `app/services/data_mapper.py`

```python
"""
Map database columns to application expected format.
"""
import pandas as pd
from typing import Dict, Any


def map_database_to_app_format(df: pd.DataFrame) -> pd.DataFrame:
    """
    Map database columns to format expected by the application.

    Args:
        df: DataFrame from database with actual column names

    Returns:
        DataFrame with standardized column names
    """
    # Column mapping: database_column -> app_column
    column_mapping = {
        # Database column name -> Expected app column name
        'event_identifier': 'event_id',
        'eng_serial': 'engine_serial',
        'tail_num': 'tail_number',
        'sys_name': 'system',
        'event_status': 'status',
        'event_timestamp': 'timestamp',
        'latency': 'latency_ms',
        'data_elem': 'data_element',
        'quality': 'data_quality_score'
    }

    # Rename columns
    df = df.rename(columns=column_mapping)

    # Ensure required columns exist
    required_columns = [
        'event_id', 'engine_serial', 'system',
        'status', 'timestamp'
    ]

    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Required column missing: {col}")

    # Add default values for optional columns
    optional_defaults = {
        'tail_number': None,
        'latency_ms': None,
        'data_element': None,
        'data_quality_score': 1.0
    }

    for col, default in optional_defaults.items():
        if col not in df.columns:
            df[col] = default

    return df


# Usage in DataService:
# df = pd.read_sql(query, ...)
# df = map_database_to_app_format(df)
```

---

## Step 8: Test the Integration

### Create Test Script

Create `scripts/test_real_database.py`:

```python
"""
Test integration with existing AWS PostgreSQL database.
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.core.config import get_settings

initialize_app()
logger = get_logger(__name__)
settings = get_settings()

print("=" * 80)
print(" TESTING REAL DATABASE INTEGRATION".center(80))
print("=" * 80)

# Check configuration
print("\n1. Configuration:")
print(f"   ENABLE_DUMMY_DATA: {settings.ENABLE_DUMMY_DATA}")
print(f"   DATABASE_URL: {settings.DATABASE_URL[:50]}...")

if settings.ENABLE_DUMMY_DATA:
    print("\n   ❌ ENABLE_DUMMY_DATA is True!")
    print("   Set ENABLE_DUMMY_DATA=False in .env to use PostgreSQL")
    exit(1)

# Test database connection
print("\n2. Testing database connection...")
db_service = inject("database_service")

if not db_service.health_check():
    print("   ❌ Database connection failed!")
    exit(1)

print("   ✅ Database connected successfully!")

# Test data query
print("\n3. Testing data query...")

try:
    data_service = inject("data_service")

    # Query without filters
    print("\n   Querying all data (last 24 hours)...")
    df = data_service.get_events_data(hours=24)

    print(f"   ✅ Retrieved {len(df)} records")

    if len(df) > 0:
        print(f"\n   📊 Data summary:")
        print(f"      Columns: {list(df.columns)}")
        print(f"      Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
        print(f"      Engines: {df['engine_serial'].nunique()} unique")
        print(f"      Systems: {df['system'].nunique()} unique")
        print(f"      Statuses: {df['status'].value_counts().to_dict()}")

        print(f"\n   📋 Sample records (first 3):")
        for i, row in df.head(3).iterrows():
            print(f"      {row['event_id']} | {row['engine_serial']} | {row['system']} | {row['status']}")

    # Test with filter
    if len(df) > 0:
        first_engine = df['engine_serial'].iloc[0]
        print(f"\n   Querying for specific engine: {first_engine}...")
        df_filtered = data_service.get_events_data(
            engine_serial=first_engine,
            hours=24
        )
        print(f"   ✅ Retrieved {len(df_filtered)} records for engine {first_engine}")

except Exception as e:
    print(f"   ❌ Query failed: {e}")
    logger.error("Data query failed", exc_info=True)
    exit(1)

print("\n" + "=" * 80)
print(" INTEGRATION TEST PASSED ✅".center(80))
print("=" * 80)

print("\n📋 Next steps:")
print("   1. Run Streamlit app: streamlit run Home.py")
print("   2. Select engine from sidebar")
print("   3. View real data in Overview tab")
print("   4. Check all tabs for real data")
```

### Run the Test

```bash
python scripts/test_real_database.py
```

**Expected output:**
```
================================================================================
                    TESTING REAL DATABASE INTEGRATION
================================================================================

1. Configuration:
   ENABLE_DUMMY_DATA: False
   DATABASE_URL: postgresql://user@host.rds.amazonaws.com...

2. Testing database connection...
   ✅ Database connected successfully!

3. Testing data query...
   Querying all data (last 24 hours)...
   ✅ Retrieved 1,532 records

   📊 Data summary:
      Columns: ['event_id', 'engine_serial', 'tail_number', 'system', ...]
      Date range: 2026-02-04 10:00:00 to 2026-02-05 10:00:00
      Engines: 8 unique
      Systems: 8 unique
      Statuses: {'Complete': 1200, 'Processing': 200, 'Error': 132}

   📋 Sample records (first 3):
      evt_real_001 | 000000 | 1FA | Complete
      evt_real_002 | 000000 | IFS | Complete
      evt_real_003 | 038429 | FDM | Processing

================================================================================
                       INTEGRATION TEST PASSED ✅
================================================================================
```

---

## Step 9: Run the Application

### Start Streamlit with Real Data

```bash
streamlit run Home.py
```

**What happens:**
1. ✅ App connects to your AWS PostgreSQL database
2. ✅ Queries your existing `events` table
3. ✅ Displays real data in Overview tab
4. ✅ All tabs show real data
5. ✅ Filters by engine_serial and tail_number work
6. ✅ All logs go to CloudWatch (if enabled)

### Verify Real Data

1. **Open application** in browser (http://localhost:8501)
2. **Sidebar:** Select an engine serial from your real data
3. **Overview tab:** Should show real events from your database
4. **Timeline tab:** Should show real event timeline
5. **All other tabs:** Should display your real data

---

## Step 10: Troubleshooting

### Issue 1: Column Names Don't Match

**Error:**
```
sqlalchemy.exc.OperationalError: column "data_quality_score" does not exist
```

**Solution:**

Update query to use correct column names:
```python
# Check actual column name in your table
SELECT column_name FROM information_schema.columns
WHERE table_name = 'events';

# Update query to use actual name or alias
SELECT quality_score as data_quality_score FROM events
```

### Issue 2: Too Much Data

**Error:**
```
MemoryError: Unable to allocate array
```

**Solution:**

Add LIMIT to query:
```python
query += " ORDER BY timestamp DESC LIMIT 10000"  # Limit rows
```

Or add pagination:
```python
query += " OFFSET :offset LIMIT :limit"
params["offset"] = 0
params["limit"] = 1000
```

### Issue 3: Slow Queries

**Solution:**

Check indexes exist:
```sql
-- In psql
\d events

-- Should show indexes on:
-- - engine_serial
-- - timestamp
-- - tail_number
```

If missing, create indexes:
```sql
CREATE INDEX idx_events_engine_serial ON events(engine_serial);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_events_tail_number ON events(tail_number);
```

### Issue 4: Date/Time Format Issues

**Error:**
```
TypeError: Object of type Timestamp is not JSON serializable
```

**Solution:**

Convert timestamps in DataService:
```python
# After reading from database
if 'timestamp' in df.columns:
    df['timestamp'] = pd.to_datetime(df['timestamp'])
```

---

## Summary Checklist

### ✅ Pre-Flight Checklist

- [ ] Have AWS RDS endpoint and credentials
- [ ] Can connect with `psql` (optional but recommended)
- [ ] Know your table names and structure
- [ ] Updated `.env` with `DATABASE_URL`
- [ ] Set `ENABLE_DUMMY_DATA=False`

### ✅ Implementation Checklist

- [ ] Ran `scripts/inspect_database.py` to see table structure
- [ ] Created models in `app/models/existing_tables.py`
- [ ] Updated `app/services/data_service.py` with real query
- [ ] Created column mapping (if needed)
- [ ] Ran `scripts/test_real_database.py` successfully
- [ ] Started Streamlit and verified real data displays

### ✅ Production Checklist

- [ ] Enabled AWS CloudWatch logging
- [ ] Configured SNS alerts
- [ ] Added database indexes for performance
- [ ] Set appropriate connection pool size
- [ ] Tested with multiple users
- [ ] Set up monitoring and alerts

---

## Quick Reference

### Key Files to Modify

| File | What to Change |
|------|----------------|
| `.env` | `DATABASE_URL`, `ENABLE_DUMMY_DATA=False` |
| `app/models/existing_tables.py` | Create models matching your tables |
| `app/services/data_service.py` | Update `_get_postgres_data()` method |
| `app/services/data_mapper.py` | Create if column names differ (optional) |

### Key Commands

```bash
# Inspect database
python scripts/inspect_database.py

# Test integration
python scripts/test_real_database.py

# Run application
streamlit run Home.py

# Check logs
cat logs/app.log | tail -50
```

---

## Next Steps

1. **Follow Steps 1-9** in order
2. **Test each step** before moving to next
3. **Check logs** if issues arise
4. **Adjust queries** to match your schema
5. **Optimize** with indexes if slow
6. **Deploy** to production

**Need help?** Check logs with correlation_id for detailed debugging!
