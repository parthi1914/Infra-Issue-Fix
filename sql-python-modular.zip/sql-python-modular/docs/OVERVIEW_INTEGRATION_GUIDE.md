# Overview Screen Integration with Real Database

## Understanding the Overview Screen

The Overview screen displays:

1. **Status Summary Cards** (Fail/Pass/Pending/Processing counts)
2. **Data Population Pies** (completeness by system)
3. **SLA Timeline** (visual progress tracker)
4. **Domino Style Progress** (stage-by-stage tracker)
5. **Error Notifications** (team alerts)
6. **Last Updated Times** (freshness)
7. **Root Cause & Governance** (issues and actions)

---

## Sample Database Schema (Realistic Example)

### Realistic Multi-Table Schema for Engine Data Pipeline

```sql
-- ============================================================================
-- Table 1: EVENTS (Main pipeline events)
-- ============================================================================
CREATE TABLE events (
    event_id VARCHAR(100) PRIMARY KEY,
    engine_serial VARCHAR(50) NOT NULL,
    tail_number VARCHAR(50),
    system_name VARCHAR(50) NOT NULL,      -- 1FA, IFS, FDM, etc.
    status VARCHAR(50) NOT NULL,            -- Complete, Error, Processing, Pending
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    latency_ms INTEGER,
    records_processed INTEGER,
    data_size_mb FLOAT,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_events_engine ON events(engine_serial);
CREATE INDEX idx_events_system ON events(system_name);
CREATE INDEX idx_events_status ON events(status);
CREATE INDEX idx_events_time ON events(start_time, end_time);

-- ============================================================================
-- Table 2: DATA_ELEMENTS (Data quality tracking)
-- ============================================================================
CREATE TABLE data_elements (
    element_id SERIAL PRIMARY KEY,
    event_id VARCHAR(100) REFERENCES events(event_id),
    element_name VARCHAR(100) NOT NULL,    -- engine_config, flight_data, etc.
    is_present BOOLEAN DEFAULT FALSE,       -- TRUE if data populated
    completeness_score FLOAT,               -- 0.0 to 1.0
    quality_score FLOAT,                    -- 0.0 to 1.0
    validation_errors INTEGER DEFAULT 0,
    last_updated TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_data_elements_event ON data_elements(event_id);
CREATE INDEX idx_data_elements_name ON data_elements(element_name);

-- ============================================================================
-- Table 3: SLA_TARGETS (Expected completion times)
-- ============================================================================
CREATE TABLE sla_targets (
    sla_id SERIAL PRIMARY KEY,
    system_name VARCHAR(50) NOT NULL,
    expected_duration_minutes INTEGER,      -- Expected processing time
    sla_threshold_minutes INTEGER,          -- SLA violation threshold
    priority_level VARCHAR(20),             -- HIGH, MEDIUM, LOW
    UNIQUE(system_name)
);

-- ============================================================================
-- Table 4: ERROR_LOGS (Detailed error tracking)
-- ============================================================================
CREATE TABLE error_logs (
    error_id SERIAL PRIMARY KEY,
    event_id VARCHAR(100) REFERENCES events(event_id),
    error_code VARCHAR(50),
    error_severity VARCHAR(20),             -- CRITICAL, HIGH, MEDIUM, LOW
    error_message TEXT,
    stack_trace TEXT,
    notified_team VARCHAR(100),
    notification_sent_at TIMESTAMP,
    resolved_at TIMESTAMP,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_error_logs_event ON error_logs(event_id);
CREATE INDEX idx_error_logs_severity ON error_logs(error_severity);

-- ============================================================================
-- Table 5: ENGINES (Engine master data)
-- ============================================================================
CREATE TABLE engines (
    engine_id SERIAL PRIMARY KEY,
    serial_number VARCHAR(50) UNIQUE NOT NULL,
    model VARCHAR(100),
    manufacture_date DATE,
    status VARCHAR(50),                     -- ACTIVE, MAINTENANCE, RETIRED
    current_tail_number VARCHAR(50)
);

CREATE INDEX idx_engines_serial ON engines(serial_number);

-- ============================================================================
-- Table 6: FLIGHTS (Flight information)
-- ============================================================================
CREATE TABLE flights (
    flight_id SERIAL PRIMARY KEY,
    flight_number VARCHAR(20),
    tail_number VARCHAR(50),
    departure_time TIMESTAMP,
    arrival_time TIMESTAMP,
    engine_serial_1 VARCHAR(50),            -- Left engine
    engine_serial_2 VARCHAR(50),            -- Right engine
    flight_status VARCHAR(50)
);

CREATE INDEX idx_flights_tail ON flights(tail_number);
CREATE INDEX idx_flights_engines ON flights(engine_serial_1, engine_serial_2);
CREATE INDEX idx_flights_time ON flights(departure_time);

-- ============================================================================
-- Table 7: SYSTEM_HEALTH (System uptime and performance)
-- ============================================================================
CREATE TABLE system_health (
    health_id SERIAL PRIMARY KEY,
    system_name VARCHAR(50) NOT NULL,
    check_time TIMESTAMP DEFAULT NOW(),
    is_healthy BOOLEAN DEFAULT TRUE,
    response_time_ms INTEGER,
    error_rate FLOAT,                       -- Percentage
    throughput_records_per_hour INTEGER,
    notes TEXT
);

CREATE INDEX idx_system_health_system ON system_health(system_name);
CREATE INDEX idx_system_health_time ON system_health(check_time);
```

---

## Inserting Sample Data

```sql
-- Sample events
INSERT INTO events (event_id, engine_serial, tail_number, system_name, status, start_time, end_time, latency_ms, records_processed, data_size_mb) VALUES
('evt_001', '000000', 'N-DEMO', '1FA', 'Complete', NOW() - INTERVAL '2 hours', NOW() - INTERVAL '1 hour 58 minutes', 120, 1500, 25.5),
('evt_002', '000000', 'N-DEMO', 'IFS', 'Complete', NOW() - INTERVAL '1 hour 58 minutes', NOW() - INTERVAL '1 hour 55 minutes', 180, 1500, 18.2),
('evt_003', '000000', 'N-DEMO', 'FDM', 'Processing', NOW() - INTERVAL '1 hour 55 minutes', NOW() - INTERVAL '1 hour 50 minutes', 300, 1200, 45.8),
('evt_004', '000000', 'N-DEMO', '1FDI', 'Pending', NOW() - INTERVAL '1 hour 50 minutes', NOW() - INTERVAL '1 hour 45 minutes', NULL, NULL, NULL),
('evt_005', '000000', 'N-DEMO', 'PHM', 'Error', NOW() - INTERVAL '1 hour 45 minutes', NOW() - INTERVAL '1 hour 40 minutes', 500, 800, 12.3, 'Database timeout'),
('evt_006', '038429', 'N-DEMO', 'SOAR', 'Complete', NOW() - INTERVAL '1 hour 40 minutes', NOW() - INTERVAL '1 hour 35 minutes', 220, 950, 22.1),
('evt_007', '038429', 'N-DEMO', 'RDF', 'Complete', NOW() - INTERVAL '1 hour 35 minutes', NOW() - INTERVAL '1 hour 30 minutes', 190, 950, 15.7),
('evt_008', '038429', 'N-DEMO', 'FMX', 'Complete', NOW() - INTERVAL '1 hour 30 minutes', NOW() - INTERVAL '1 hour 28 minutes', 110, 950, 8.3);

-- Sample data elements
INSERT INTO data_elements (event_id, element_name, is_present, completeness_score, quality_score, validation_errors) VALUES
('evt_001', 'engine_config', TRUE, 0.98, 0.97, 2),
('evt_001', 'maintenance_history', TRUE, 0.95, 0.96, 0),
('evt_002', 'asset_reference', TRUE, 0.99, 0.98, 1),
('evt_003', 'flight_data', TRUE, 0.92, 0.88, 5),
('evt_005', 'health_metrics', FALSE, 0.65, 0.70, 12);

-- Sample SLA targets
INSERT INTO sla_targets (system_name, expected_duration_minutes, sla_threshold_minutes, priority_level) VALUES
('1FA', 2, 5, 'HIGH'),
('IFS', 3, 6, 'HIGH'),
('FDM', 5, 10, 'MEDIUM'),
('1FDI', 5, 10, 'HIGH'),
('PHM', 5, 8, 'HIGH'),
('SOAR', 3, 6, 'MEDIUM'),
('RDF', 2, 5, 'MEDIUM'),
('FMX', 2, 4, 'HIGH');

-- Sample error logs
INSERT INTO error_logs (event_id, error_code, error_severity, error_message, notified_team, notification_sent_at) VALUES
('evt_005', 'DB_TIMEOUT', 'CRITICAL', 'Database connection timeout after 30 seconds', 'PHM Analytics Team', NOW() - INTERVAL '1 hour 43 minutes');

-- Sample engines
INSERT INTO engines (serial_number, model, manufacture_date, status, current_tail_number) VALUES
('000000', 'GE90-115B', '2020-01-15', 'ACTIVE', 'N-DEMO'),
('038429', 'GE90-115B', '2019-08-22', 'ACTIVE', 'N-DEMO'),
('041223', 'GEnx-1B', '2021-03-10', 'ACTIVE', 'B-1316');

-- Sample flights
INSERT INTO flights (flight_number, tail_number, departure_time, arrival_time, engine_serial_1, engine_serial_2, flight_status) VALUES
('GE1234', 'N-DEMO', NOW() - INTERVAL '3 hours', NOW() - INTERVAL '45 minutes', '000000', '038429', 'COMPLETED'),
('GE5678', 'B-1316', NOW() - INTERVAL '2 hours', NOW() - INTERVAL '30 minutes', '041223', '052781', 'IN_PROGRESS');

-- Sample system health
INSERT INTO system_health (system_name, check_time, is_healthy, response_time_ms, error_rate, throughput_records_per_hour) VALUES
('1FA', NOW() - INTERVAL '5 minutes', TRUE, 45, 0.2, 15000),
('IFS', NOW() - INTERVAL '5 minutes', TRUE, 38, 0.1, 12000),
('FDM', NOW() - INTERVAL '5 minutes', TRUE, 92, 0.5, 18000),
('PHM', NOW() - INTERVAL '5 minutes', FALSE, 850, 5.2, 5000);
```

---

## Implementing Overview Metrics with Real Database Queries

### 1. Status Summary (Fail/Pass/Pending/Processing Counts)

**What it shows:** Count of events by status category

**Query with JOIN (including engine info):**

```sql
-- Query: Get status summary with engine context
SELECT
    CASE
        WHEN e.status = 'Complete' THEN 'Pass'
        WHEN e.status = 'Error' THEN 'Fail'
        WHEN e.status IN ('Pending', 'Delayed', 'NotStarted') THEN 'Pending'
        ELSE 'Processing'
    END as category,
    COUNT(*) as count,
    COUNT(DISTINCT e.engine_serial) as engines_affected,
    AVG(e.latency_ms) as avg_latency_ms
FROM events e
INNER JOIN engines eng ON e.engine_serial = eng.serial_number
WHERE e.start_time >= NOW() - INTERVAL '24 hours'
  AND eng.status = 'ACTIVE'
  AND e.engine_serial = :engine_serial  -- Filter parameter
GROUP BY category
ORDER BY
    CASE category
        WHEN 'Fail' THEN 1
        WHEN 'Pass' THEN 2
        WHEN 'Pending' THEN 3
        ELSE 4
    END;
```

**Implementation in `data_service.py`:**

```python
def get_status_summary(self, engine_serial: str, hours: int = 24) -> pd.DataFrame:
    """Get status summary with counts."""
    db_service = get_database_service()

    with db_service.get_session() as session:
        query = """
            SELECT
                CASE
                    WHEN e.status = 'Complete' THEN 'Pass'
                    WHEN e.status = 'Error' THEN 'Fail'
                    WHEN e.status IN ('Pending', 'Delayed', 'NotStarted') THEN 'Pending'
                    ELSE 'Processing'
                END as category,
                COUNT(*) as count
            FROM events e
            WHERE e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            GROUP BY category
        """ % hours

        df = pd.read_sql(query, session.bind, params={"engine_serial": engine_serial})

        # Ensure all categories present
        all_categories = pd.DataFrame({
            'category': ['Fail', 'Pass', 'Pending', 'Processing'],
            'count': [0, 0, 0, 0]
        })

        df = all_categories.merge(df, on='category', how='left', suffixes=('', '_new'))
        df['count'] = df['count_new'].fillna(df['count']).astype(int)
        df = df[['category', 'count']]

        return df
```

---

### 2. Data Population (Completeness by System)

**What it shows:** Data completeness percentage for each system

**Query with JOIN (data elements):**

```sql
-- Query: Get data population/completeness by system
SELECT
    e.system_name,
    COUNT(DISTINCT de.element_name) as total_elements,
    SUM(CASE WHEN de.is_present THEN 1 ELSE 0 END) as present_elements,
    AVG(de.completeness_score) as avg_completeness,
    AVG(de.quality_score) as avg_quality,
    SUM(de.validation_errors) as total_errors
FROM events e
LEFT JOIN data_elements de ON e.event_id = de.event_id
WHERE e.start_time >= NOW() - INTERVAL '24 hours'
  AND e.engine_serial = :engine_serial
GROUP BY e.system_name
ORDER BY e.system_name;
```

**Calculation:**
```
Completeness % = (present_elements / total_elements) * 100
OR
Completeness % = avg_completeness * 100
```

**Implementation:**

```python
def get_data_population(self, engine_serial: str, hours: int = 24) -> pd.DataFrame:
    """Get data population/completeness by system."""
    db_service = get_database_service()

    with db_service.get_session() as session:
        query = """
            SELECT
                e.system_name as system,
                COUNT(DISTINCT de.element_name) as total_elements,
                SUM(CASE WHEN de.is_present THEN 1 ELSE 0 END) as present_elements,
                COALESCE(AVG(de.completeness_score), 0.85) as completeness,
                COALESCE(AVG(de.quality_score), 0.90) as quality
            FROM events e
            LEFT JOIN data_elements de ON e.event_id = de.event_id
            WHERE e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            GROUP BY e.system_name
        """ % hours

        df = pd.read_sql(query, session.bind, params={"engine_serial": engine_serial})

        # Calculate percentages
        df['completeness_pct'] = (df['completeness'] * 100).round(1)
        df['missing_pct'] = (100 - df['completeness_pct']).round(1)

        return df
```

---

### 3. SLA Timeline (Time-based Progress)

**What it shows:** Timeline showing when each system started/completed and if SLA was met

**Query with JOIN (events + SLA targets):**

```sql
-- Query: Get SLA timeline with target comparison
SELECT
    e.event_id,
    e.engine_serial,
    e.system_name,
    e.status,
    e.start_time,
    e.end_time,
    e.latency_ms,
    EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 as duration_minutes,
    sla.expected_duration_minutes,
    sla.sla_threshold_minutes,
    sla.priority_level,
    CASE
        WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.expected_duration_minutes THEN 'ON_TIME'
        WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.sla_threshold_minutes THEN 'AT_RISK'
        ELSE 'SLA_BREACH'
    END as sla_status,
    eng.model as engine_model
FROM events e
INNER JOIN sla_targets sla ON e.system_name = sla.system_name
INNER JOIN engines eng ON e.engine_serial = eng.serial_number
WHERE e.start_time >= NOW() - INTERVAL '24 hours'
  AND e.engine_serial = :engine_serial
ORDER BY e.start_time;
```

**Implementation:**

```python
def get_sla_timeline(self, engine_serial: str, hours: int = 24) -> pd.DataFrame:
    """Get SLA timeline with breach detection."""
    db_service = get_database_service()

    with db_service.get_session() as session:
        query = """
            SELECT
                e.event_id,
                e.system_name as system,
                e.status,
                e.start_time,
                e.end_time,
                EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 as duration_minutes,
                sla.expected_duration_minutes,
                sla.sla_threshold_minutes,
                CASE
                    WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.expected_duration_minutes THEN 'ON_TIME'
                    WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.sla_threshold_minutes THEN 'AT_RISK'
                    ELSE 'SLA_BREACH'
                END as sla_status
            FROM events e
            LEFT JOIN sla_targets sla ON e.system_name = sla.system_name
            WHERE e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            ORDER BY e.start_time
        """ % hours

        df = pd.read_sql(query, session.bind, params={"engine_serial": engine_serial})

        # Convert timestamps
        df['start_time'] = pd.to_datetime(df['start_time'])
        df['end_time'] = pd.to_datetime(df['end_time'])

        return df
```

---

### 4. Error Notifications (with Team Mapping)

**What it shows:** Error events with team notifications and details

**Query with MULTIPLE JOINS:**

```sql
-- Query: Get error notifications with full context
SELECT
    e.event_id,
    e.engine_serial,
    e.system_name,
    e.status,
    e.start_time,
    e.error_message,
    e.records_processed,
    e.data_size_mb,
    e.latency_ms,
    el.error_code,
    el.error_severity,
    el.notified_team,
    el.notification_sent_at,
    el.resolved_at,
    el.resolution_notes,
    eng.model as engine_model,
    eng.status as engine_status,
    sh.is_healthy as system_healthy,
    sh.error_rate as system_error_rate
FROM events e
INNER JOIN error_logs el ON e.event_id = el.event_id
INNER JOIN engines eng ON e.engine_serial = eng.serial_number
LEFT JOIN LATERAL (
    SELECT is_healthy, error_rate
    FROM system_health
    WHERE system_name = e.system_name
    ORDER BY check_time DESC
    LIMIT 1
) sh ON true
WHERE e.status = 'Error'
  AND e.start_time >= NOW() - INTERVAL '24 hours'
  AND e.engine_serial = :engine_serial
ORDER BY el.notification_sent_at DESC;
```

**Implementation:**

```python
def get_error_notifications(self, engine_serial: str, hours: int = 24) -> pd.DataFrame:
    """Get error notifications with team and context."""
    db_service = get_database_service()

    with db_service.get_session() as session:
        query = """
            SELECT
                e.event_id,
                e.system_name as system,
                e.error_message,
                e.records_processed as records,
                e.data_size_mb,
                e.latency_ms / 1000.0 as latency_sec,
                el.error_severity,
                el.notified_team,
                el.notification_sent_at,
                e.start_time
            FROM events e
            INNER JOIN error_logs el ON e.event_id = el.event_id
            WHERE e.status = 'Error'
              AND e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            ORDER BY el.notification_sent_at DESC
        """ % hours

        df = pd.read_sql(query, session.bind, params={"engine_serial": engine_serial})

        # Convert timestamps
        if not df.empty:
            df['start_time'] = pd.to_datetime(df['start_time'])
            df['notification_sent_at'] = pd.to_datetime(df['notification_sent_at'])

        return df
```

---

### 5. Last Updated Times (Freshness)

**What it shows:** When each system last processed data

**Query:**

```sql
-- Query: Get last updated time per system
SELECT
    e.system_name,
    MAX(e.end_time) as last_updated,
    EXTRACT(EPOCH FROM (NOW() - MAX(e.end_time))) / 60.0 as minutes_since_update,
    COUNT(*) as events_today,
    SUM(CASE WHEN e.status = 'Complete' THEN 1 ELSE 0 END) as successful_events
FROM events e
WHERE e.start_time >= NOW() - INTERVAL '24 hours'
  AND e.engine_serial = :engine_serial
GROUP BY e.system_name
ORDER BY e.system_name;
```

**Implementation:**

```python
def get_last_updated(self, engine_serial: str) -> pd.DataFrame:
    """Get last updated times per system."""
    db_service = get_database_service()

    with db_service.get_session() as session:
        query = """
            SELECT
                e.system_name as system,
                MAX(e.end_time) as last_updated,
                EXTRACT(EPOCH FROM (NOW() - MAX(e.end_time))) / 60.0 as minutes_ago
            FROM events e
            WHERE e.engine_serial = :engine_serial
            GROUP BY e.system_name
            ORDER BY e.system_name
        """

        df = pd.read_sql(query, session.bind, params={"engine_serial": engine_serial})

        if not df.empty:
            df['last_updated'] = pd.to_datetime(df['last_updated'])

        return df
```

---

### 6. Complex JOIN Example: Flight Context

**Query joining multiple tables for full context:**

```sql
-- Query: Get comprehensive event context with flight info
SELECT
    e.event_id,
    e.engine_serial,
    e.system_name,
    e.status,
    e.start_time,
    e.end_time,
    -- Engine info
    eng.model as engine_model,
    eng.manufacture_date,
    -- Flight info
    f.flight_number,
    f.departure_time,
    f.arrival_time,
    f.flight_status,
    -- Data quality
    AVG(de.completeness_score) as avg_completeness,
    AVG(de.quality_score) as avg_quality,
    SUM(de.validation_errors) as total_errors,
    -- SLA info
    sla.expected_duration_minutes,
    sla.sla_threshold_minutes,
    -- System health
    sh.is_healthy as system_healthy,
    sh.error_rate as system_error_rate
FROM events e
INNER JOIN engines eng
    ON e.engine_serial = eng.serial_number
LEFT JOIN flights f
    ON eng.serial_number IN (f.engine_serial_1, f.engine_serial_2)
    AND f.departure_time <= e.start_time
    AND (f.arrival_time IS NULL OR f.arrival_time >= e.start_time)
LEFT JOIN data_elements de
    ON e.event_id = de.event_id
LEFT JOIN sla_targets sla
    ON e.system_name = sla.system_name
LEFT JOIN LATERAL (
    SELECT is_healthy, error_rate
    FROM system_health
    WHERE system_name = e.system_name
    ORDER BY check_time DESC
    LIMIT 1
) sh ON true
WHERE e.start_time >= NOW() - INTERVAL '24 hours'
  AND e.engine_serial = :engine_serial
GROUP BY
    e.event_id, e.engine_serial, e.system_name, e.status,
    e.start_time, e.end_time, eng.model, eng.manufacture_date,
    f.flight_number, f.departure_time, f.arrival_time, f.flight_status,
    sla.expected_duration_minutes, sla.sla_threshold_minutes,
    sh.is_healthy, sh.error_rate
ORDER BY e.start_time;
```

---

## Complete Updated DataService

Here's how to integrate all these queries into your `DataService`:

```python
# app/services/data_service.py

def get_overview_data(
    self,
    engine_serial: str,
    tail_number: Optional[str] = None,
    hours: int = 24
) -> Dict[str, pd.DataFrame]:
    """
    Get all data needed for Overview screen.
    Returns dictionary of DataFrames.
    """
    db_service = get_database_service()

    result = {}

    with db_service.get_session() as session:
        # 1. Status Summary
        result['status_summary'] = pd.read_sql("""
            SELECT
                CASE
                    WHEN e.status = 'Complete' THEN 'Pass'
                    WHEN e.status = 'Error' THEN 'Fail'
                    WHEN e.status IN ('Pending', 'Delayed', 'NotStarted') THEN 'Pending'
                    ELSE 'Processing'
                END as category,
                COUNT(*) as count
            FROM events e
            WHERE e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            GROUP BY category
        """ % hours, session.bind, params={"engine_serial": engine_serial})

        # 2. Data Population
        result['data_population'] = pd.read_sql("""
            SELECT
                e.system_name as system,
                COALESCE(AVG(de.completeness_score), 0.85) as completeness,
                COALESCE(AVG(de.quality_score), 0.90) as quality
            FROM events e
            LEFT JOIN data_elements de ON e.event_id = de.event_id
            WHERE e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            GROUP BY e.system_name
        """ % hours, session.bind, params={"engine_serial": engine_serial})

        # 3. SLA Timeline
        result['sla_timeline'] = pd.read_sql("""
            SELECT
                e.event_id,
                e.system_name as system,
                e.status,
                e.start_time,
                e.end_time,
                e.latency_ms,
                e.records_processed as records,
                e.data_size_mb,
                EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 as duration_minutes
            FROM events e
            WHERE e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            ORDER BY e.start_time
        """ % hours, session.bind, params={"engine_serial": engine_serial})

        # Convert timestamps
        if not result['sla_timeline'].empty:
            result['sla_timeline']['start_time'] = pd.to_datetime(result['sla_timeline']['start_time'])
            result['sla_timeline']['end_time'] = pd.to_datetime(result['sla_timeline']['end_time'])

        # 4. Error Notifications
        result['error_notifications'] = pd.read_sql("""
            SELECT
                e.event_id,
                e.system_name as system,
                e.error_message,
                e.records_processed as records,
                e.data_size_mb,
                e.latency_ms / 1000.0 as latency_sec,
                el.notified_team,
                el.notification_sent_at,
                e.start_time
            FROM events e
            INNER JOIN error_logs el ON e.event_id = el.event_id
            WHERE e.status = 'Error'
              AND e.start_time >= NOW() - INTERVAL '%s hours'
              AND e.engine_serial = :engine_serial
            ORDER BY el.notification_sent_at DESC
        """ % hours, session.bind, params={"engine_serial": engine_serial})

        if not result['error_notifications'].empty:
            result['error_notifications']['start_time'] = pd.to_datetime(result['error_notifications']['start_time'])
            result['error_notifications']['notification_sent_at'] = pd.to_datetime(result['error_notifications']['notification_sent_at'])

        # 5. Last Updated
        result['last_updated'] = pd.read_sql("""
            SELECT
                e.system_name as system,
                MAX(e.end_time) as end_time
            FROM events e
            WHERE e.engine_serial = :engine_serial
            GROUP BY e.system_name
        """, session.bind, params={"engine_serial": engine_serial})

        if not result['last_updated'].empty:
            result['last_updated']['end_time'] = pd.to_datetime(result['last_updated']['end_time'])

    return result
```

---

## Update Overview Component

Update `app/components/tabs/overview.py` to use the new data:

```python
from app.core.di import inject

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader("📊 Overview Board")

    # Get data service
    data_service = inject("data_service")

    # Get all overview data
    overview_data = data_service.get_overview_data(
        engine_serial=engine_serial,
        hours=window_hours
    )

    # 1. Status Summary Cards
    status_summary = overview_data['status_summary']
    if not status_summary.empty:
        card_cols = st.columns(4)
        mapping_to_col = {"Fail": 0, "Pass": 1, "Pending": 2, "Processing": 3}

        for _, r in status_summary.iterrows():
            cat = r["category"]
            idx = mapping_to_col.get(cat, 3)
            bg = {
                "Fail": "#ffe5e0",
                "Pass": "#e3f9e5",
                "Pending": "#e0efff",
                "Processing": "#e0efff"
            }.get(cat, "#f0f0f0")

            card_cols[idx].markdown(
                f"<div style='padding:12px;border-radius:8px;background:{bg};'>"
                f"<h4 style='margin:0'>{cat}</h4>"
                f"<p style='font-size:28px;margin:0;font-weight:700'>{int(r['count'])}</p>"
                f"<small>System Status</small></div>",
                unsafe_allow_html=True
            )

    # 2. Data Population
    data_pop = overview_data['data_population']
    if not data_pop.empty:
        st.markdown("### 📈 Data Population by System")

        import plotly.graph_objects as go

        pie_cols = st.columns(len(data_pop))
        for i, (_, row) in enumerate(data_pop.iterrows()):
            completeness = row['completeness']
            missing = 1 - completeness

            fig = go.Figure(data=[go.Pie(
                labels=["Present", "Missing"],
                values=[completeness, missing],
                hole=0.55
            )])
            fig.update_layout(
                title=f"{row['system']}<br>{completeness*100:.1f}% Complete",
                margin=dict(l=0, r=0, t=45, b=0),
                showlegend=False
            )
            pie_cols[i].plotly_chart(fig, use_container_width=True)

    # 3. SLA Timeline (use existing builder with new data)
    sla_df = overview_data['sla_timeline']
    if not sla_df.empty:
        st.markdown("### ⏱️ SLA Timeline")
        sla_html = build_sla_dominos_html(sla_df, now, hours=window_hours)
        st.markdown(sla_html, unsafe_allow_html=True)

    # 4. Error Notifications
    error_df = overview_data['error_notifications']
    if not error_df.empty:
        st.markdown("### 🚨 Error Notifications")
        error_html = build_error_notifications(error_df, now)
        st.components.v1.html(error_html, height=380, scrolling=False)

    # 5. Last Updated
    last_updated_df = overview_data['last_updated']
    if not last_updated_df.empty:
        st.markdown("### 🕐 Last Updated Times")
        st.dataframe(last_updated_df, use_container_width=True)
```

---

## Summary

### Key Points:

1. **Multiple Tables** - Use realistic schema with events, data_elements, sla_targets, error_logs, engines, flights
2. **JOINs** - Combine data from multiple tables for rich context
3. **Aggregations** - Use COUNT, AVG, SUM for metrics
4. **Window Functions** - Use EXTRACT, INTERVAL for time-based queries
5. **Lateral Joins** - Get latest system health per system
6. **All data logged** - Every query is logged with correlation_id

### Benefits of This Approach:

✅ **Realistic** - Uses actual database patterns
✅ **Performant** - Single queries with JOINs instead of multiple round-trips
✅ **Maintainable** - Clear separation of concerns
✅ **Scalable** - Indexes on key columns
✅ **Traceable** - All queries logged with correlation IDs

**Next:** Run `python scripts/inspect_database.py` to see your actual schema, then adapt these queries!
