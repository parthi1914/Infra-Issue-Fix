# Quick Reference Guide

## Your Questions Answered

### 1. What is DatabaseService?

**DatabaseService** is a wrapper around SQLAlchemy that provides:

```python
from app.core.database import get_database_service

db_service = get_database_service()

# Get a session (auto-commit, auto-rollback, auto-close)
with db_service.get_session() as session:
    result = session.execute("SELECT * FROM events")
    for row in result:
        print(row)
# Session automatically closed, connection returned to pool
```

**Key Features:**

| Feature | What It Does |
|---------|-------------|
| **Session Management** | Automatic commit/rollback/close |
| **Connection Pooling** | Reuses connections (PostgreSQL) |
| **Activity Logging** | Every query is logged with correlation ID |
| **Multi-Database** | Works with SQLite and PostgreSQL |
| **Health Checks** | Test database connectivity |
| **Error Handling** | Catches errors, logs with context |

### 2. What is SQLAlchemy?

**SQLAlchemy** is a Python library that lets you work with databases using Python code instead of raw SQL.

**Simple Comparison:**

```python
# ❌ Without SQLAlchemy (raw SQL, database-specific)
import psycopg2
conn = psycopg2.connect("postgresql://...")
cursor = conn.cursor()
cursor.execute("SELECT * FROM events WHERE status = %s", ("Complete",))
results = cursor.fetchall()
cursor.close()
conn.close()

# ✅ With SQLAlchemy (clean, works with any database)
with db_service.get_session() as session:
    results = session.execute(
        "SELECT * FROM events WHERE status = :status",
        {"status": "Complete"}
    )
```

**Key Components:**

```
┌─────────────────────────────────────────┐
│         Your Python Code                 │
│  with db_service.get_session():         │
└────────────────┬────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────┐
│         SQLAlchemy                       │
│  ┌──────────────┐   ┌───────────────┐  │
│  │   Engine     │   │   Session     │  │
│  │ (Connection) │   │ (Transaction) │  │
│  └──────────────┘   └───────────────┘  │
└────────────────┬────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────┐
│   Database (SQLite or PostgreSQL)       │
└─────────────────────────────────────────┘
```

### 3. How to Implement AWS PostgreSQL?

**3-Step Process:**

#### Step 1: Create RDS Instance

```bash
# Via AWS Console: RDS → Create Database → PostgreSQL
# Or via CLI:
aws rds create-db-instance \
  --db-instance-identifier data-observability-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --master-username admin \
  --master-user-password YourPassword123! \
  --allocated-storage 20
```

#### Step 2: Update Configuration

```bash
# Edit .env file
ENABLE_DUMMY_DATA=False
DATABASE_URL=postgresql://admin:YourPassword123!@your-rds-endpoint.rds.amazonaws.com:5432/data_observability
```

#### Step 3: Setup and Load Data

```bash
# Test connection
python scripts/test_postgres.py

# Create schema
python scripts/setup_database.py

# Load data
python scripts/load_sample_data.py

# Run application
streamlit run Home.py
```

**That's it!** No code changes needed.

---

## Quick Commands

### Test Connection
```bash
python scripts/test_postgres.py
```

### Create Tables
```bash
python scripts/setup_database.py
```

### Load Sample Data
```bash
python scripts/load_sample_data.py
```

### Query Examples
```bash
python scripts/query_examples.py
```

---

## Common Database Operations

### 1. Query Data

```python
from app.core.database import get_database_service
from app.core import initialize_app

initialize_app()
db = get_database_service()

with db.get_session() as session:
    result = session.execute("""
        SELECT * FROM events
        WHERE engine_serial = :serial
        ORDER BY timestamp DESC
        LIMIT 10
    """, {"serial": "000000"})

    for row in result:
        print(f"{row.event_id} | {row.system} | {row.status}")
```

### 2. Insert Data

```python
with db.get_session() as session:
    session.execute("""
        INSERT INTO events (event_id, engine_serial, system, status, timestamp)
        VALUES (:event_id, :serial, :system, :status, NOW())
    """, {
        "event_id": "evt_new_001",
        "serial": "000000",
        "system": "1FA",
        "status": "Complete"
    })
    # Auto-commit on exit
```

### 3. Update Data

```python
with db.get_session() as session:
    session.execute("""
        UPDATE events
        SET status = :new_status
        WHERE event_id = :event_id
    """, {
        "new_status": "Error",
        "event_id": "evt_001"
    })
```

### 4. Aggregate Query

```python
with db.get_session() as session:
    result = session.execute("""
        SELECT
            system,
            COUNT(*) as total,
            AVG(latency_ms) as avg_latency
        FROM events
        GROUP BY system
        ORDER BY total DESC
    """)

    for row in result:
        print(f"{row.system}: {row.total} events, {row.avg_latency:.1f}ms avg")
```

---

## Architecture Overview

### How DatabaseService Works

```
Your Code
    │
    ├─► with db_service.get_session() as session:
    │
    ▼
DatabaseService (app/core/database.py)
    │
    ├─► Create session from pool
    ├─► Log: "database_session started"
    │
    ▼
SQLAlchemy Session
    │
    ├─► Execute your query
    ├─► Log: "database_query started"
    │
    ▼
PostgreSQL Database
    │
    ├─► Return results
    │
    ▼
SQLAlchemy Session
    │
    ├─► Commit (if no errors)
    ├─► Log: "database_session completed"
    │
    ▼
DatabaseService
    │
    ├─► Close session
    └─► Return connection to pool

All steps logged with correlation_id
```

### Connection Pooling

```
┌────────────────────────────────────────┐
│      Application Requests              │
│  [Req1] [Req2] [Req3] ... [Req15]     │
└────────────────┬───────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│      Connection Pool                   │
│                                        │
│  Permanent (10 connections):          │
│  [●●●●●●●●●●]                          │
│                                        │
│  Overflow (up to 20 more):            │
│  [○○○○○○○○○○] (created when needed)    │
└────────────────┬───────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────┐
│      PostgreSQL Database               │
└────────────────────────────────────────┘

Benefits:
✅ Faster (reuses connections)
✅ Scalable (handles many requests)
✅ Efficient (doesn't overwhelm database)
```

---

## Configuration

### SQLite (Local Development)

```bash
# .env
ENABLE_DUMMY_DATA=True
DATABASE_URL=sqlite:///./data_observability.db
```

**Characteristics:**
- Single file database
- No connection pooling
- Perfect for development
- No server needed

### PostgreSQL (Production)

```bash
# .env
ENABLE_DUMMY_DATA=False
DATABASE_URL=postgresql://user:pass@host:5432/database
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
```

**Characteristics:**
- Client-server database
- Connection pooling
- Production-ready
- Concurrent access
- Better performance at scale

---

## Key Files

| File | Purpose |
|------|---------|
| [app/core/database.py](../app/core/database.py) | DatabaseService implementation |
| [app/services/data_service.py](../app/services/data_service.py) | Data abstraction (JSON/PostgreSQL) |
| [scripts/test_postgres.py](../scripts/test_postgres.py) | Test connection |
| [scripts/setup_database.py](../scripts/setup_database.py) | Create schema |
| [scripts/load_sample_data.py](../scripts/load_sample_data.py) | Load data |
| [docs/DATABASE_GUIDE.md](DATABASE_GUIDE.md) | Complete database guide |

---

## Cheat Sheet

```bash
# 1. Test PostgreSQL connection
python scripts/test_postgres.py

# 2. Create database tables
python scripts/setup_database.py

# 3. Load sample data
python scripts/load_sample_data.py

# 4. See query examples
python scripts/query_examples.py

# 5. Update .env
# ENABLE_DUMMY_DATA=False

# 6. Run application
streamlit run Home.py
```

---

## Need More Details?

📖 **[DATABASE_GUIDE.md](DATABASE_GUIDE.md)** - Complete guide with:
- Detailed SQLAlchemy explanation
- Step-by-step AWS RDS setup
- Troubleshooting guide
- Advanced examples

📖 **[ARCHITECTURE.md](../ARCHITECTURE.md)** - System architecture

📖 **[QUICKSTART.md](../QUICKSTART.md)** - 5-minute quick start

---

## Summary

### DatabaseService in 3 Points:

1. **Wrapper around SQLAlchemy** - Makes database access easy
2. **Automatic Management** - Handles connections, transactions, logging
3. **Multi-Database** - Works with SQLite (local) and PostgreSQL (production)

### SQLAlchemy in 3 Points:

1. **Python ↔ Database Translator** - Write Python, not SQL
2. **Works with Any Database** - SQLite, PostgreSQL, MySQL, Oracle, etc.
3. **Enterprise Features** - Connection pooling, transactions, ORM

### AWS PostgreSQL in 3 Steps:

1. **Create RDS Instance** - Via AWS Console or CLI
2. **Update .env File** - Set DATABASE_URL
3. **Run Scripts** - test → setup → load → run

**Everything is already implemented and ready to use!** 🎉
