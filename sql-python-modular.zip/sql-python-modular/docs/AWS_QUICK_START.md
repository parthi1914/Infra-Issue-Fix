# AWS Services - Quick Start

## 🎯 In 60 Seconds

### What You Have

**Two AWS services already integrated:**

1. **CloudWatch Logging** - Sends logs to AWS
2. **SNS Notifications** - Sends alerts via Email/SMS

### How to Use

**CloudWatch:**
```python
# Just use regular logging - it automatically goes to CloudWatch!
from app.core.logging import get_logger

logger = get_logger(__name__)
logger.info("Event occurred", extra={"key": "value"})
# ✅ Goes to Console + File + CloudWatch (if enabled)
```

**SNS:**
```python
# Send alerts
from app.core.di import inject

sns = inject("sns_service")
sns.publish_alert(
    alert_type="ERROR",
    message="Something went wrong!",
    severity="CRITICAL"
)
# ✅ Sends Email/SMS to subscribers
```

---

## 🚀 5-Minute Setup

### CloudWatch Logging

**1. Update .env:**
```bash
ENABLE_AWS_LOGGING=True
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=app-stream
```

**2. Set AWS credentials** (one of these):
- IAM Role (EC2) - automatic
- Environment variables - `aws configure`
- .env file - `AWS_ACCESS_KEY_ID=xxx`

**3. Run app:**
```bash
streamlit run Home.py
```

**4. View logs:**
- AWS Console → CloudWatch → Log Groups
- Search by correlation_id

### SNS Notifications

**1. Create SNS topic:**
```bash
aws sns create-topic --name data-observability-alerts
```

**2. Add email subscriber:**
```bash
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:xxx:data-observability-alerts \
  --protocol email \
  --notification-endpoint your@email.com
```

**3. Confirm subscription** (check email)

**4. Update .env:**
```bash
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:xxx:data-observability-alerts
```

**5. Test:**
```bash
python scripts/test_aws_services.py
```

---

## 📊 Visual Flow

### CloudWatch Logging Flow

```
Your Code                         Console (immediate)
    │                                  ↑
    ├─► logger.info("Message")        │
    │                              ┌───┴────┐
    ▼                              │        │
Logging System                 ────┤Handlers├────
    │                              │        │
    │ Adds correlation_id          └───┬────┘
    │ Formats as JSON                  │
    │                                  ├────→ logs/app.log (local)
    │                                  │
    │                                  └────→ CloudWatch (AWS)
    │                                         • Searchable
    │                                         • Persistent
    │                                         • Centralized
    ▼
All logs include correlation_id for tracing
```

### SNS Notification Flow

```
Your Code
    │
    ├─► sns.publish_alert("ERROR", "Failed!")
    │
    ▼
SNS Service
    │
    ├─► Formats message
    ├─► Adds metadata
    ├─► Logs activity
    │
    ▼
AWS SNS Topic
    │
    ├───────┬──────────┬───────────┬────────────
    │       │          │           │
    ▼       ▼          ▼           ▼
  Email    SMS     HTTP/HTTPS   Lambda
    │       │          │           │
    ▼       ▼          ▼           ▼
  Team    Ops      Webhook    Automation
```

---

## 💡 Common Use Cases

### Use Case 1: Log Everything

```python
from app.core.logging import get_logger

logger = get_logger(__name__)

# All these go to CloudWatch automatically
logger.info("User logged in", extra={"user_id": "123"})
logger.warning("Rate limit approaching", extra={"current": 90})
logger.error("Failed to connect", extra={"retry": 3})
```

### Use Case 2: Send Alert on Error

```python
from app.core.di import inject
from app.core.logging import get_logger

logger = get_logger(__name__)
sns = inject("sns_service")

try:
    result = process_data()
except Exception as e:
    # Log error
    logger.error(f"Processing failed: {e}", exc_info=True)

    # Send alert
    sns.publish_alert(
        alert_type="ERROR",
        message=f"Data processing failed: {e}",
        severity="CRITICAL"
    )
```

### Use Case 3: Monitor Data Quality

```python
from app.core.di import inject
from app.core.logging import get_logger

logger = get_logger(__name__)
sns = inject("sns_service")

# Get data
data_service = inject("data_service")
df = data_service.get_events_data(hours=1)

# Check quality
quality = df['data_quality_score'].mean()

logger.info(f"Data quality: {quality:.3f}", extra={
    "quality_score": quality,
    "record_count": len(df)
})

if quality < 0.85:
    # Send warning
    sns.publish_alert(
        alert_type="DATA_QUALITY",
        message=f"Quality below threshold: {quality:.3f}",
        severity="WARNING",
        current_score=quality,
        threshold=0.85
    )
```

---

## 🔧 Configuration Cheat Sheet

### Minimal (Local Only)

```bash
# .env
ENABLE_AWS_LOGGING=False
ENABLE_LOCAL_LOGGING=True
# No AWS needed!
```

### Development (AWS CloudWatch Only)

```bash
# .env
ENABLE_AWS_LOGGING=True
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=dev-stream
AWS_REGION=us-east-1
```

### Production (CloudWatch + SNS)

```bash
# .env
ENABLE_AWS_LOGGING=True
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=prod-stream
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:alerts
AWS_REGION=us-east-1
```

---

## 🧪 Test Commands

```bash
# Test AWS services
python scripts/test_aws_services.py

# See practical examples
python examples/aws_examples.py

# Check logs
cat logs/app.log | tail -20

# Search CloudWatch (CLI)
aws logs filter-log-events \
  --log-group-name "/aws/streamlit/data-observability" \
  --filter-pattern "ERROR"
```

---

## 🎓 IAM Permissions Needed

### CloudWatch Logging

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ],
    "Resource": "arn:aws:logs:*:*:*"
  }]
}
```

### SNS Publishing

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": ["sns:Publish"],
    "Resource": "arn:aws:sns:*:*:*"
  }]
}
```

---

## ❓ FAQ

### Q: Do logs go to CloudWatch automatically?

**A:** Yes! Just use `logger.info()` - if `ENABLE_AWS_LOGGING=True`, logs automatically go to CloudWatch.

### Q: How do I search logs in CloudWatch?

**A:** Use correlation_id or any field:
```
{ $.correlation_id = "01HQXXX..." }
{ $.level = "ERROR" }
{ $.engine_serial = "000000" }
```

### Q: Can I send SNS without CloudWatch?

**A:** Yes! They're independent. Configure only what you need.

### Q: How much does it cost?

**A:**
- CloudWatch: $0.50 per GB ingested (first 5GB free)
- SNS: $0.50 per million requests, $0.75 per 100k SMS
- Very affordable for typical usage!

### Q: Can I use local logs AND CloudWatch?

**A:** Yes! Enable both:
```bash
ENABLE_LOCAL_LOGGING=True
ENABLE_AWS_LOGGING=True
```

### Q: What if AWS credentials are wrong?

**A:** App continues working, logs warning:
```
Failed to setup AWS CloudWatch logging: NoCredentialsError
```
Local logging still works!

---

## 📚 Next Steps

1. **Test basic setup:**
   ```bash
   python scripts/test_aws_services.py
   ```

2. **Read full guide:**
   [docs/AWS_SERVICES_GUIDE.md](AWS_SERVICES_GUIDE.md)

3. **See examples:**
   ```bash
   python examples/aws_examples.py
   ```

4. **Configure for your environment:**
   Edit `.env` file

5. **Deploy and monitor:**
   Check CloudWatch console

---

## 🎯 Key Takeaways

✅ **No code changes needed** - Just configure .env

✅ **Automatically integrated** - Use regular logging

✅ **Correlation IDs included** - Track requests end-to-end

✅ **Production ready** - Batched, efficient, robust

✅ **Fail-safe** - Falls back to local logging if AWS unavailable

✅ **Activity logging** - Every operation is logged

✅ **Easy to test** - Run test script anytime

**Start simple, add features as needed!** 🚀
