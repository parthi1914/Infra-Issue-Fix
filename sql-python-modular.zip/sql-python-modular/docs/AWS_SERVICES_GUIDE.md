# AWS Services Guide - CloudWatch Logging & SNS

## Overview

This framework has **built-in AWS integration** for:
1. **CloudWatch Logging** - Send logs to AWS CloudWatch
2. **SNS** - Send notifications and alerts

Both are **already implemented** and just need configuration!

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [AWS CloudWatch Logging](#aws-cloudwatch-logging)
3. [AWS SNS Notifications](#aws-sns-notifications)
4. [Configuration](#configuration)
5. [Practical Examples](#practical-examples)
6. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

### How AWS Services are Integrated

```
┌─────────────────────────────────────────────────────────┐
│              Your Application Code                       │
│  logger.info("Event occurred")                          │
│  sns_service.publish_alert("Alert!")                    │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ Uses
                     ▼
┌─────────────────────────────────────────────────────────┐
│          Core AWS Infrastructure                         │
│  ┌──────────────────┐      ┌──────────────────┐        │
│  │  Boto3 Factory   │      │   SNS Service    │        │
│  │  (app/core/aws)  │      │  (app/core/aws)  │        │
│  └──────────────────┘      └──────────────────┘        │
│  ┌──────────────────┐                                   │
│  │  Logging System  │                                   │
│  │ (app/core/logging)│                                  │
│  └──────────────────┘                                   │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ Calls via boto3
                     ▼
┌─────────────────────────────────────────────────────────┐
│                    AWS Services                          │
│  ┌──────────────────┐      ┌──────────────────┐        │
│  │  CloudWatch Logs │      │       SNS        │        │
│  │  (Log Groups)    │      │    (Topics)      │        │
│  └──────────────────┘      └──────────────────┘        │
└─────────────────────────────────────────────────────────┘
```

### Key Components

| Component | File | Purpose |
|-----------|------|---------|
| **Boto3Factory** | [app/core/aws.py](../app/core/aws.py) | Creates and caches AWS clients |
| **SNSService** | [app/core/aws.py](../app/core/aws.py) | Wrapper for SNS operations |
| **Logging** | [app/core/logging.py](../app/core/logging.py) | Handles CloudWatch logging |

---

## AWS CloudWatch Logging

### What is CloudWatch Logging?

**CloudWatch** is AWS's logging service that:
- ✅ Stores logs centrally
- ✅ Searchable across all servers
- ✅ Persistent (doesn't disappear when server restarts)
- ✅ Integrated with AWS monitoring

### How It Works in the Framework

```
Your Code
    │
    ├─► logger.info("Event occurred", extra={"key": "value"})
    │
    ▼
Logging System (app/core/logging.py)
    │
    ├─► Formats log as JSON
    ├─► Adds correlation_id
    ├─► Adds timestamp, level, module, etc.
    │
    ▼
Multiple Handlers
    │
    ├─► Console Handler ──────► Terminal (immediate visibility)
    ├─► File Handler ──────────► logs/app.log (local backup)
    └─► CloudWatch Handler ────► AWS CloudWatch (searchable, persistent)
```

### Configuration

#### Step 1: Enable CloudWatch in .env

```bash
# .env

# Enable AWS CloudWatch logging
ENABLE_AWS_LOGGING=True

# CloudWatch configuration
AWS_REGION=us-east-1
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=app-stream

# AWS credentials (optional - use IAM role if on EC2)
# AWS_ACCESS_KEY_ID=your_access_key
# AWS_SECRET_ACCESS_KEY=your_secret_key
```

#### Step 2: Set Up AWS Credentials

**Option 1: IAM Role (Recommended for EC2/ECS)**
```bash
# No configuration needed - instance uses IAM role
# Just attach a role with CloudWatchLogsFullAccess policy
```

**Option 2: Environment Variables**
```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_REGION=us-east-1
```

**Option 3: AWS CLI Profile**
```bash
aws configure
# Enter credentials when prompted
```

#### Step 3: Create Log Group (Optional)

```bash
# Create log group manually (or let the app create it)
aws logs create-log-group --log-group-name /aws/streamlit/data-observability

# Set retention period (optional)
aws logs put-retention-policy \
  --log-group-name /aws/streamlit/data-observability \
  --retention-in-days 30
```

### How Logging Works

**Code Location:** [app/core/logging.py](../app/core/logging.py:65-88)

```python
# In app/core/logging.py

# AWS CloudWatch handler
if settings.ENABLE_AWS_LOGGING:
    import watchtower
    from app.core.aws import get_boto3_client

    cloudwatch_client = get_boto3_client("logs")

    cloudwatch_handler = watchtower.CloudWatchLogHandler(
        log_group=settings.AWS_LOG_GROUP,
        stream_name=settings.AWS_LOG_STREAM,
        boto3_client=cloudwatch_client,
        send_interval=5,  # Send logs every 5 seconds (batched)
        create_log_group=True  # Automatically create log group
    )
    cloudwatch_handler.setLevel(logging.INFO)
    cloudwatch_handler.setFormatter(json_formatter)
    logger.addHandler(cloudwatch_handler)
```

**Key Features:**
- ✅ Batches logs every 5 seconds (efficient)
- ✅ Auto-creates log group if missing
- ✅ JSON format (easy to search)
- ✅ Includes correlation_id

### Using CloudWatch Logging

**No code changes needed!** Just use regular logging:

```python
from app.core.logging import get_logger

logger = get_logger(__name__)

# This goes to Console + File + CloudWatch (if enabled)
logger.info("Processing started", extra={
    "engine_serial": "000000",
    "record_count": 100
})

logger.error("Processing failed", extra={
    "error_code": "DB_TIMEOUT",
    "retry_count": 3
})
```

**Log appears in 3 places:**

1. **Console:**
   ```
   2026-02-05 10:00:00 | INFO | mymodule | [01HQXXX...] | Processing started
   ```

2. **Local File (logs/app.log):**
   ```json
   {
     "timestamp": "2026-02-05T10:00:00",
     "level": "INFO",
     "message": "Processing started",
     "correlation_id": "01HQXXX...",
     "engine_serial": "000000",
     "record_count": 100
   }
   ```

3. **CloudWatch (if enabled):**
   Same JSON format, searchable in AWS Console

### Searching CloudWatch Logs

#### Via AWS Console:

1. Go to AWS Console → CloudWatch → Log Groups
2. Click `/aws/streamlit/data-observability`
3. Click `app-stream`
4. Use filter:
   ```
   { $.correlation_id = "01HQXXX..." }
   { $.level = "ERROR" }
   { $.engine_serial = "000000" }
   ```

#### Via AWS CLI:

```bash
# Search by correlation ID
aws logs filter-log-events \
  --log-group-name /aws/streamlit/data-observability \
  --filter-pattern '{ $.correlation_id = "01HQXXX..." }'

# Search for errors
aws logs filter-log-events \
  --log-group-name /aws/streamlit/data-observability \
  --filter-pattern '{ $.level = "ERROR" }'

# Search by custom field
aws logs filter-log-events \
  --log-group-name /aws/streamlit/data-observability \
  --filter-pattern '{ $.engine_serial = "000000" }'
```

---

## AWS SNS Notifications

### What is SNS?

**SNS (Simple Notification Service)** sends notifications via:
- 📧 Email
- 📱 SMS
- 🔗 HTTP/HTTPS endpoints
- 📲 Mobile push notifications
- ☁️ AWS Lambda triggers

### How It Works in the Framework

```
Your Code
    │
    ├─► sns_service.publish_alert("Data quality low", severity="WARNING")
    │
    ▼
SNS Service (app/core/aws.py)
    │
    ├─► Formats message
    ├─► Adds attributes (severity, alert_type)
    ├─► Logs activity (started/completed/failed)
    │
    ▼
boto3 SNS Client
    │
    ├─► Publishes to SNS Topic
    │
    ▼
AWS SNS Topic
    │
    ├─► Routes to all subscribers:
    │   ├─► Email (team@company.com)
    │   ├─► SMS (555-1234)
    │   └─► Lambda (trigger automation)
```

### Configuration

#### Step 1: Create SNS Topic

**Via AWS Console:**
1. Go to AWS Console → SNS → Topics
2. Click "Create topic"
3. Type: Standard
4. Name: `data-observability-alerts`
5. Click "Create topic"
6. Copy the ARN: `arn:aws:sns:us-east-1:123456789012:data-observability-alerts`

**Via AWS CLI:**
```bash
# Create topic
aws sns create-topic --name data-observability-alerts

# Output:
# {
#   "TopicArn": "arn:aws:sns:us-east-1:123456789012:data-observability-alerts"
# }
```

#### Step 2: Add Subscribers

**Email Subscription:**
```bash
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:123456789012:data-observability-alerts \
  --protocol email \
  --notification-endpoint team@company.com

# Check email and confirm subscription
```

**SMS Subscription:**
```bash
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:123456789012:data-observability-alerts \
  --protocol sms \
  --notification-endpoint +15551234567
```

**Lambda Subscription (for automation):**
```bash
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:123456789012:data-observability-alerts \
  --protocol lambda \
  --notification-endpoint arn:aws:lambda:us-east-1:123456789012:function:my-handler
```

#### Step 3: Update .env

```bash
# .env

# SNS Configuration
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:data-observability-alerts
```

### SNS Service Code

**Code Location:** [app/core/aws.py](../app/core/aws.py:139-275)

```python
class SNSService:
    """AWS SNS service wrapper."""

    def publish_message(
        self,
        message: str,
        subject: Optional[str] = None,
        topic_arn: Optional[str] = None,
        attributes: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Publish a message to SNS topic."""

        # Get topic ARN from config or parameter
        topic_arn = topic_arn or self.settings.AWS_SNS_TOPIC_ARN

        # Log activity
        activity_logger.log_activity(
            activity="sns_publish",
            status="started",
            topic_arn=topic_arn
        )

        # Publish to SNS
        response = self.client.publish(
            TopicArn=topic_arn,
            Message=message,
            Subject=subject,
            MessageAttributes=attributes
        )

        # Log completion
        activity_logger.log_activity(
            activity="sns_publish",
            status="completed",
            message_id=response["MessageId"]
        )

        return response["MessageId"]
```

### Using SNS Service

#### Example 1: Simple Message

```python
from app.core.di import inject

# Get SNS service from DI container
sns_service = inject("sns_service")

# Send simple message
message_id = sns_service.publish_message(
    message="Data processing completed successfully",
    subject="Success Notification"
)

print(f"Message sent: {message_id}")
```

#### Example 2: Structured Alert

```python
from app.core.di import inject

sns_service = inject("sns_service")

# Send alert with severity and metadata
message_id = sns_service.publish_alert(
    alert_type="DATA_QUALITY",
    message="Data quality score dropped below threshold",
    severity="WARNING",
    engine_serial="000000",
    quality_score=0.82,
    threshold=0.85
)
```

#### Example 3: Error Notification

```python
from app.core.di import inject
from app.core.context import get_correlation_id

sns_service = inject("sns_service")

try:
    # Some operation
    result = process_data()
except Exception as e:
    # Send error alert
    sns_service.publish_alert(
        alert_type="ERROR",
        message=f"Data processing failed: {e}",
        severity="CRITICAL",
        correlation_id=get_correlation_id(),
        error_type=type(e).__name__
    )
    raise
```

#### Example 4: Custom Attributes

```python
sns_service = inject("sns_service")

# Publish with custom attributes (for filtering/routing)
sns_service.publish_message(
    message="Engine maintenance required",
    subject="Maintenance Alert",
    attributes={
        "alert_type": "MAINTENANCE",
        "priority": "HIGH",
        "engine_serial": "000000",
        "maintenance_type": "SCHEDULED"
    }
)
```

### SNS Message Format

**What subscribers receive:**

**Email Example:**
```
Subject: [WARNING] DATA_QUALITY

Body:
Data quality score dropped below threshold

Attributes:
- alert_type: DATA_QUALITY
- severity: WARNING
- engine_serial: 000000
- quality_score: 0.82
```

**SMS Example:**
```
[WARNING] DATA_QUALITY: Data quality score dropped below threshold
```

---

## Configuration

### Complete AWS Configuration

```bash
# .env file

# ==================== AWS Configuration ====================

# AWS Region
AWS_REGION=us-east-1

# AWS Credentials (optional - use IAM role if on EC2/ECS)
# AWS_ACCESS_KEY_ID=your_access_key
# AWS_SECRET_ACCESS_KEY=your_secret_key

# ==================== CloudWatch Logging ====================

# Enable CloudWatch logging
ENABLE_AWS_LOGGING=True

# CloudWatch log group and stream
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=app-stream

# ==================== SNS Configuration ====================

# SNS Topic ARN for alerts
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:data-observability-alerts
```

### IAM Permissions Required

**For CloudWatch Logs:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogStreams"
      ],
      "Resource": "arn:aws:logs:*:*:log-group:/aws/streamlit/*"
    }
  ]
}
```

**For SNS:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "sns:Publish"
      ],
      "Resource": "arn:aws:sns:*:*:data-observability-alerts"
    }
  ]
}
```

**Combined Policy (Recommended):**
```bash
# Create policy file
cat > aws-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogStreams"
      ],
      "Resource": "arn:aws:logs:*:*:log-group:/aws/streamlit/*"
    },
    {
      "Effect": "Allow",
      "Action": ["sns:Publish"],
      "Resource": "arn:aws:sns:*:*:data-observability-alerts"
    }
  ]
}
EOF

# Create IAM policy
aws iam create-policy \
  --policy-name DataObservabilityAppPolicy \
  --policy-document file://aws-policy.json

# Attach to role (for EC2)
aws iam attach-role-policy \
  --role-name your-ec2-role \
  --policy-arn arn:aws:iam::123456789012:policy/DataObservabilityAppPolicy
```

---

## Practical Examples

### Example 1: Complete Workflow with AWS Logging and SNS

```python
"""
Example: Process data with AWS logging and SNS alerts.
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.core.context import get_correlation_id

# Initialize infrastructure
initialize_app()
logger = get_logger(__name__)

# Get services
sns_service = inject("sns_service")
data_service = inject("data_service")

# Get correlation ID for this request
correlation_id = get_correlation_id()

logger.info("Starting data processing", extra={
    "correlation_id": correlation_id
})

try:
    # Get data
    df = data_service.get_events_data(engine_serial="000000", hours=24)

    logger.info(f"Retrieved {len(df)} events", extra={
        "record_count": len(df),
        "engine_serial": "000000"
    })

    # Check data quality
    avg_quality = df['data_quality_score'].mean()

    if avg_quality < 0.85:
        # Send SNS alert
        logger.warning("Low data quality detected", extra={
            "avg_quality": avg_quality,
            "threshold": 0.85
        })

        sns_service.publish_alert(
            alert_type="DATA_QUALITY",
            message=f"Data quality below threshold: {avg_quality:.2f}",
            severity="WARNING",
            engine_serial="000000",
            avg_quality=avg_quality,
            threshold=0.85,
            correlation_id=correlation_id
        )

    logger.info("Data processing completed successfully")

except Exception as e:
    logger.error("Data processing failed", exc_info=True, extra={
        "error_type": type(e).__name__,
        "error_message": str(e)
    })

    # Send critical alert
    sns_service.publish_alert(
        alert_type="ERROR",
        message=f"Data processing failed: {e}",
        severity="CRITICAL",
        correlation_id=correlation_id,
        error_type=type(e).__name__
    )

    raise

# Logs go to:
# ✅ Console (immediate visibility)
# ✅ logs/app.log (local backup)
# ✅ CloudWatch (searchable by correlation_id)
#
# SNS alert goes to:
# ✅ Email subscribers
# ✅ SMS subscribers
# ✅ Lambda functions (for automation)
```

### Example 2: Integration in Streamlit App

```python
# In your Streamlit app (Home.py or any component)

from app.core.logging import get_logger
from app.core.di import inject

logger = get_logger(__name__)
sns_service = inject("sns_service")

# Log user interaction (goes to CloudWatch)
logger.info("User selected engine", extra={
    "engine_serial": engine_serial,
    "tail_number": tail_number,
    "user_action": "filter_data"
})

# Process data
df = get_data(engine_serial)

# Check for anomalies
error_count = len(df[df['status'] == 'Error'])
if error_count > 10:
    # Log warning
    logger.warning(f"High error count: {error_count}", extra={
        "error_count": error_count,
        "engine_serial": engine_serial
    })

    # Send SNS alert
    sns_service.publish_alert(
        alert_type="HIGH_ERROR_RATE",
        message=f"Engine {engine_serial} has {error_count} errors",
        severity="WARNING",
        engine_serial=engine_serial,
        error_count=error_count
    )

    # Show warning in UI
    st.warning(f"⚠️ High error count detected: {error_count}")
```

### Example 3: Scheduled Job with AWS Integration

```python
"""
Example: Scheduled job that checks data quality and sends alerts.
Run with cron: 0 * * * * python scripts/check_data_quality.py
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from datetime import datetime

initialize_app()
logger = get_logger(__name__)

sns_service = inject("sns_service")
data_service = inject("data_service")

logger.info("Starting scheduled data quality check")

# Get recent data
df = data_service.get_events_data(hours=1)

# Analyze
total_events = len(df)
error_events = len(df[df['status'] == 'Error'])
error_rate = error_events / total_events if total_events > 0 else 0

logger.info("Data quality check completed", extra={
    "total_events": total_events,
    "error_events": error_events,
    "error_rate": error_rate
})

# Alert if error rate too high
if error_rate > 0.05:  # 5% threshold
    sns_service.publish_alert(
        alert_type="DATA_QUALITY_CHECK",
        message=f"Error rate: {error_rate:.1%} ({error_events}/{total_events})",
        severity="ERROR" if error_rate > 0.10 else "WARNING",
        total_events=total_events,
        error_events=error_events,
        error_rate=error_rate,
        check_time=datetime.now().isoformat()
    )

logger.info("Scheduled check completed")

# All logs automatically go to CloudWatch
# Can be viewed in AWS Console or searched by time/correlation_id
```

---

## Troubleshooting

### CloudWatch Logging Issues

#### Issue 1: Logs Not Appearing in CloudWatch

**Error in logs:**
```
Failed to setup AWS CloudWatch logging: NoCredentialsError
```

**Solutions:**

1. **Check credentials:**
   ```bash
   # Test AWS credentials
   aws sts get-caller-identity

   # Should return your AWS account info
   ```

2. **Set credentials in .env:**
   ```bash
   AWS_ACCESS_KEY_ID=your_access_key
   AWS_SECRET_ACCESS_KEY=your_secret_key
   AWS_REGION=us-east-1
   ```

3. **Check IAM permissions:**
   ```bash
   # Test CloudWatch access
   aws logs describe-log-groups

   # Should list log groups (or succeed with empty list)
   ```

#### Issue 2: Permission Denied

**Error:**
```
AccessDeniedException: User is not authorized to perform: logs:CreateLogGroup
```

**Solution:**

Add CloudWatch permissions to IAM user/role:
```bash
aws iam attach-user-policy \
  --user-name your-user \
  --policy-arn arn:aws:iam::aws:policy/CloudWatchLogsFullAccess
```

#### Issue 3: Logs Delayed

**Behavior:** Logs appear in CloudWatch after 5-10 seconds

**Explanation:** This is normal! Logs are batched every 5 seconds for efficiency.

**To see immediate logs:** Check console output or `logs/app.log`

### SNS Issues

#### Issue 1: Messages Not Received

**Check 1: Verify topic ARN:**
```bash
# List topics
aws sns list-topics

# Verify it matches .env AWS_SNS_TOPIC_ARN
```

**Check 2: Verify subscriptions:**
```bash
# List subscriptions
aws sns list-subscriptions-by-topic \
  --topic-arn arn:aws:sns:us-east-1:123456789012:data-observability-alerts

# Ensure subscriptions are "Confirmed"
```

**Check 3: Check email spam folder**

Email notifications might be in spam initially.

#### Issue 2: Permission Denied

**Error:**
```
AuthorizationError: User is not authorized to perform: SNS:Publish
```

**Solution:**

Add SNS publish permission:
```bash
aws iam attach-user-policy \
  --user-name your-user \
  --policy-arn arn:aws:iam::aws:policy/AmazonSNSFullAccess
```

#### Issue 3: Message Not Sent (No Error)

**Check logs:**
```bash
cat logs/app.log | grep sns_publish
```

**Common causes:**

1. **SNS topic ARN not configured:**
   ```bash
   # Check .env
   cat .env | grep AWS_SNS_TOPIC_ARN

   # Should have value, not empty
   ```

2. **Warning logged instead of error:**
   ```
   SNS topic ARN not configured - message not sent
   ```

   Set `AWS_SNS_TOPIC_ARN` in `.env`

---

## Testing AWS Services

### Test Script: AWS Integration

Create `scripts/test_aws_services.py`:

```python
"""
Test AWS CloudWatch and SNS integration.
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.core.config import get_settings

# Initialize
initialize_app()
logger = get_logger(__name__)
settings = get_settings()

print("=" * 60)
print("Testing AWS Services")
print("=" * 60)

# Test 1: CloudWatch Logging
print("\n1. Testing CloudWatch Logging...")
print(f"   Enabled: {settings.ENABLE_AWS_LOGGING}")

if settings.ENABLE_AWS_LOGGING:
    print(f"   Log Group: {settings.AWS_LOG_GROUP}")
    print(f"   Log Stream: {settings.AWS_LOG_STREAM}")

    # Send test log
    logger.info("TEST: CloudWatch logging test message", extra={
        "test": True,
        "test_id": "cloudwatch_test_001"
    })

    print("   ✅ Test log sent")
    print(f"   Check CloudWatch console: {settings.AWS_LOG_GROUP}")
else:
    print("   ⚠️  CloudWatch logging is disabled")
    print("   Set ENABLE_AWS_LOGGING=True in .env to enable")

# Test 2: SNS
print("\n2. Testing SNS...")
print(f"   Topic ARN: {settings.AWS_SNS_TOPIC_ARN or '(not configured)'}")

if settings.AWS_SNS_TOPIC_ARN:
    try:
        sns_service = inject("sns_service")

        # Send test alert
        message_id = sns_service.publish_alert(
            alert_type="TEST",
            message="This is a test alert from the framework",
            severity="INFO",
            test=True,
            test_id="sns_test_001"
        )

        print(f"   ✅ Test alert sent")
        print(f"   Message ID: {message_id}")
        print("   Check email/SMS for notification")

    except Exception as e:
        print(f"   ❌ SNS test failed: {e}")
else:
    print("   ⚠️  SNS is not configured")
    print("   Set AWS_SNS_TOPIC_ARN in .env to enable")

print("\n" + "=" * 60)
print("Test Complete")
print("=" * 60)
```

Run the test:
```bash
python scripts/test_aws_services.py
```

---

## Summary

### CloudWatch Logging

**What it does:** Sends logs to AWS CloudWatch for centralized logging

**Configuration:**
```bash
ENABLE_AWS_LOGGING=True
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=app-stream
```

**Usage:**
```python
logger.info("Message", extra={"key": "value"})
# Automatically goes to CloudWatch (if enabled)
```

**View logs:**
- AWS Console → CloudWatch → Log Groups
- Search by correlation_id, level, or custom fields

### SNS Notifications

**What it does:** Sends alerts via Email, SMS, HTTP, or Lambda

**Configuration:**
```bash
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:topic-name
```

**Usage:**
```python
sns_service = inject("sns_service")
sns_service.publish_alert(
    alert_type="ERROR",
    message="Something went wrong",
    severity="CRITICAL"
)
```

**Subscribers receive:**
- Email with subject and message
- SMS with brief message
- HTTP POST to webhook
- Lambda function trigger

### Key Points

1. ✅ **Already Implemented** - Just needs configuration
2. ✅ **No Code Changes** - Use regular logging
3. ✅ **Activity Logging** - Every operation logged
4. ✅ **Correlation IDs** - Track requests end-to-end
5. ✅ **Production Ready** - Batched, efficient, robust

---

## Next Steps

1. **Setup AWS credentials** (IAM role or access keys)
2. **Create SNS topic** and add subscribers
3. **Update .env** with AWS configuration
4. **Run test script** to verify everything works
5. **Check CloudWatch** console for logs
6. **Check email/SMS** for SNS notifications

**All the code is already there - just configure and use!** 🎉
