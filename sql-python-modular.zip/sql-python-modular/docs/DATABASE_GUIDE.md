# Database Implementation Guide

## Table of Contents
1. [What is SQLAlchemy?](#what-is-sqlalchemy)
2. [DatabaseService Explained](#databaseservice-explained)
3. [How to Implement AWS PostgreSQL](#how-to-implement-aws-postgresql)
4. [Practical Examples](#practical-examples)
5. [Troubleshooting](#troubleshooting)

---

## What is SQLAlchemy?

### Overview

**SQLAlchemy** is a Python library that provides:
1. **SQL Toolkit**: Tools to work with databases
2. **ORM (Object-Relational Mapping)**: Map Python objects to database tables

Think of it as a **translator between Python and databases**.

### Why Use SQLAlchemy?

#### Without SQLAlchemy (Raw SQL)
```python
import psycopg2

# Manual connection
conn = psycopg2.connect("postgresql://user:pass@host/db")
cursor = conn.cursor()

# Raw SQL strings
cursor.execute("SELECT * FROM events WHERE engine_serial = %s", (serial,))
results = cursor.fetchall()

# Manual cleanup
cursor.close()
conn.close()

# Problems:
# - Database-specific code (psycopg2 for PostgreSQL, sqlite3 for SQLite)
# - Manual connection management
# - SQL injection risks
# - No type safety
# - Lots of boilerplate
```

#### With SQLAlchemy
```python
from app.core.database import get_database_service

db_service = get_database_service()

# Python-friendly API
with db_service.get_session() as session:
    results = session.query(Event).filter_by(engine_serial=serial).all()

# Benefits:
# - Works with any database (SQLite, PostgreSQL, MySQL, etc.)
# - Automatic connection management
# - Type-safe queries
# - Automatic cleanup
# - Connection pooling
```

### SQLAlchemy Components

```
┌─────────────────────────────────────────────────────┐
│                  SQLAlchemy                          │
├─────────────────────────────────────────────────────┤
│                                                      │
│  ┌──────────────┐         ┌──────────────┐         │
│  │   Engine     │         │     ORM      │         │
│  │              │         │              │         │
│  │ - Connection │         │ - Models     │         │
│  │ - Pooling    │         │ - Sessions   │         │
│  │ - Dialect    │         │ - Queries    │         │
│  └──────────────┘         └──────────────┘         │
│                                                      │
└───────────────────┬──────────────────────────────────┘
                    │
                    │ Communicates with
                    ▼
┌─────────────────────────────────────────────────────┐
│              Database (SQLite/PostgreSQL)            │
└─────────────────────────────────────────────────────┘
```

**Key Terms:**

| Term | Description |
|------|-------------|
| **Engine** | Manages database connections and dialects |
| **Session** | Handles transactions and queries |
| **Model** | Python class representing a database table |
| **Query** | Python method to retrieve data |
| **Connection Pool** | Reuses connections for performance |

---

## DatabaseService Explained

### Architecture

The `DatabaseService` class wraps SQLAlchemy to provide:
- ✅ Automatic connection management
- ✅ Support for SQLite (local) and PostgreSQL (AWS)
- ✅ Connection pooling
- ✅ Activity logging
- ✅ Error handling with correlation IDs
- ✅ Health checks

### Core Components

#### 1. Engine (Connection Manager)

```python
# Located at: app/core/database.py:59-125

def _create_engine(self) -> Engine:
    """Creates the database engine with appropriate configuration."""

    # SQLite configuration (local development)
    if self.settings.DATABASE_URL.startswith("sqlite"):
        engine_kwargs["connect_args"] = {"check_same_thread": False}
        engine_kwargs["poolclass"] = StaticPool

    # PostgreSQL configuration (production)
    else:
        engine_kwargs["pool_size"] = 10          # 10 connections in pool
        engine_kwargs["max_overflow"] = 20       # +20 temporary connections
        engine_kwargs["pool_pre_ping"] = True    # Test connections before use
        engine_kwargs["pool_recycle"] = 3600     # Recycle after 1 hour
```

**What this means:**

| Setting | SQLite | PostgreSQL | Purpose |
|---------|--------|------------|---------|
| `pool_size` | N/A | 10 | Number of permanent connections |
| `max_overflow` | N/A | 20 | Additional connections when busy |
| `pool_pre_ping` | N/A | True | Verify connection before use |
| `pool_recycle` | N/A | 3600s | Refresh stale connections |

**Connection Pooling Diagram:**

```
┌──────────────────────────────────────────────────┐
│          Connection Pool (PostgreSQL)            │
│                                                   │
│  Permanent (pool_size=10):                      │
│  [Conn1] [Conn2] [Conn3] ... [Conn10]          │
│                                                   │
│  Overflow (max_overflow=20):                    │
│  [Conn11] [Conn12] ... [Conn30]                │
│  (Created when needed, closed when done)        │
└──────────────────────────────────────────────────┘
```

#### 2. Session (Transaction Manager)

```python
# Located at: app/core/database.py:147-190

@contextmanager
def get_session(self) -> Generator[Session, None, None]:
    """Context manager for database sessions."""
    session = self.session_factory()

    try:
        yield session
        session.commit()  # Auto-commit on success
    except SQLAlchemyError as e:
        session.rollback()  # Auto-rollback on error
        raise
    finally:
        session.close()  # Always close
```

**What this means:**

```python
# When you use it:
with db_service.get_session() as session:
    # 1. Session is created
    result = session.query(Event).all()
    # 2. Auto-commit if no errors
# 3. Auto-close (returns connection to pool)

# If error occurs:
try:
    with db_service.get_session() as session:
        result = session.query(Event).all()
        raise Exception("Something failed")
except Exception:
    # Session automatically rolled back
    # Connection returned to pool
    pass
```

#### 3. Activity Logging

Every database operation is logged:

```python
# Located at: app/core/database.py:91-97

@event.listens_for(engine, "before_cursor_execute")
def receive_before_cursor_execute(conn, cursor, statement, params, context, executemany):
    activity_logger.log_activity(
        activity="database_query",
        status="started",
        statement=statement[:200]  # First 200 chars of SQL
    )
```

**Example log output:**

```json
{
  "timestamp": "2026-02-05T10:00:00",
  "activity": "database_query",
  "status": "started",
  "statement": "SELECT * FROM events WHERE engine_serial = ?",
  "correlation_id": "01HQXXX..."
}
```

#### 4. Password Masking

Passwords are never logged:

```python
# Located at: app/core/database.py:127-145

def _mask_password(url: str) -> str:
    """Mask password in database URL for logging."""
    # Input:  postgresql://user:mypassword@host:5432/db
    # Output: postgresql://user:****@host:5432/db
```

---

## How to Implement AWS PostgreSQL

### Step-by-Step Guide

#### Step 1: Create RDS PostgreSQL Database

**Option A: Using AWS Console**

1. Go to AWS Console → RDS
2. Click "Create database"
3. Choose:
   - Engine: PostgreSQL
   - Version: 14+ (recommended)
   - Template: Production (or Dev/Test for testing)
4. Configure:
   - DB instance identifier: `data-observability-db`
   - Master username: `admin`
   - Master password: (choose strong password)
   - Instance class: `db.t3.micro` (for testing) or `db.t3.small` (production)
   - Storage: 20 GB (adjust as needed)
5. Connectivity:
   - VPC: (your VPC)
   - Public access: Yes (for testing) or No (production with VPN)
   - VPC security group: (create new or select existing)
6. Additional configuration:
   - Initial database name: `data_observability`
7. Click "Create database"

**Option B: Using AWS CLI**

```bash
aws rds create-db-instance \
  --db-instance-identifier data-observability-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 14.7 \
  --master-username admin \
  --master-user-password YourStrongPassword123! \
  --allocated-storage 20 \
  --db-name data_observability \
  --vpc-security-group-ids sg-xxxxxxxxx \
  --backup-retention-period 7 \
  --publicly-accessible
```

**Wait for creation** (5-10 minutes):

```bash
# Check status
aws rds describe-db-instances \
  --db-instance-identifier data-observability-db \
  --query 'DBInstances[0].DBInstanceStatus'
```

#### Step 2: Configure Security Group

**Allow your application to connect:**

1. Go to EC2 → Security Groups
2. Find your RDS security group
3. Add inbound rule:
   - Type: PostgreSQL
   - Protocol: TCP
   - Port: 5432
   - Source:
     - Your IP (for testing): `your.ip.address/32`
     - Your VPC CIDR (production): `10.0.0.0/16`
     - Application security group (production): `sg-xxxxxxxxx`

**Using AWS CLI:**

```bash
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxxxxxx \
  --protocol tcp \
  --port 5432 \
  --cidr your.ip.address/32
```

#### Step 3: Get Connection Details

```bash
# Get RDS endpoint
aws rds describe-db-instances \
  --db-instance-identifier data-observability-db \
  --query 'DBInstances[0].Endpoint.Address' \
  --output text

# Output example:
# data-observability-db.c9aktf8db3kj.us-east-1.rds.amazonaws.com
```

#### Step 4: Configure Application

**Update `.env` file:**

```bash
# Database Configuration
ENABLE_DUMMY_DATA=False
USE_AWS_POSTGRES=True

# PostgreSQL Connection
DATABASE_URL=postgresql://admin:YourStrongPassword123!@data-observability-db.c9aktf8db3kj.us-east-1.rds.amazonaws.com:5432/data_observability

# Connection pool settings
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
DB_ECHO=False
```

**Connection URL Format:**

```
postgresql://[username]:[password]@[endpoint]:[port]/[database_name]

Example:
postgresql://admin:YourStrongPassword123!@data-observability-db.c9aktf8db3kj.us-east-1.rds.amazonaws.com:5432/data_observability
```

#### Step 5: Test Connection

Create a test script `test_postgres.py`:

```python
from app.core.database import get_database_service
from app.core import initialize_app

# Initialize infrastructure
initialize_app()

# Get database service
db_service = get_database_service()

# Test connection
print("Testing PostgreSQL connection...")

if db_service.health_check():
    print("✅ Connection successful!")

    # Show connection details
    print(f"Database URL: {db_service.settings.DATABASE_URL}")
    print(f"Pool size: {db_service.settings.DB_POOL_SIZE}")
    print(f"Max overflow: {db_service.settings.DB_MAX_OVERFLOW}")
else:
    print("❌ Connection failed!")
```

Run the test:

```bash
python test_postgres.py
```

#### Step 6: Create Database Schema

Create `setup_database.py`:

```python
"""
Setup database schema in AWS PostgreSQL.
Run this once to create all tables.
"""
from app.core.database import get_database_service, Base
from app.core import initialize_app
from sqlalchemy import Column, Integer, String, DateTime, Float

# Initialize infrastructure
initialize_app()

# Define your database models
class Event(Base):
    """Event model - represents events table."""
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(100), unique=True, nullable=False)
    engine_serial = Column(String(50), nullable=False, index=True)
    tail_number = Column(String(50), nullable=False, index=True)
    system = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    latency_ms = Column(Integer)
    data_element = Column(String(100))
    data_quality_score = Column(Float)

    def __repr__(self):
        return f"<Event(event_id={self.event_id}, system={self.system}, status={self.status})>"


# Create tables
db_service = get_database_service()

print("Creating database tables...")
db_service.create_tables()
print("✅ Tables created successfully!")

# Verify tables exist
with db_service.get_session() as session:
    result = session.execute("""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
    """)
    tables = [row[0] for row in result]
    print(f"\nTables in database: {tables}")
```

Run the setup:

```bash
python setup_database.py
```

#### Step 7: Load Sample Data

Create `load_sample_data.py`:

```python
"""
Load sample data into PostgreSQL from JSON file.
"""
import json
from datetime import datetime
from app.core.database import get_database_service
from app.core import initialize_app

# Initialize
initialize_app()
db_service = get_database_service()

# Load JSON data
with open("data/dummy_events.json", "r") as f:
    events = json.load(f)

print(f"Loading {len(events)} events into PostgreSQL...")

# Insert into database
with db_service.get_session() as session:
    for event in events:
        # Convert timestamp string to datetime
        event['timestamp'] = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))

        # Execute insert
        session.execute("""
            INSERT INTO events (
                event_id, engine_serial, tail_number, system, status,
                timestamp, latency_ms, data_element, data_quality_score
            ) VALUES (
                :event_id, :engine_serial, :tail_number, :system, :status,
                :timestamp, :latency_ms, :data_element, :data_quality_score
            )
            ON CONFLICT (event_id) DO NOTHING
        """, event)

    session.commit()

print("✅ Data loaded successfully!")

# Verify
with db_service.get_session() as session:
    count = session.execute("SELECT COUNT(*) FROM events").scalar()
    print(f"Total events in database: {count}")
```

Run the data loader:

```bash
python load_sample_data.py
```

#### Step 8: Update Data Service Query

Edit [app/services/data_service.py](app/services/data_service.py:95):

```python
def _get_postgres_data(
    self,
    engine_serial: Optional[str] = None,
    tail_number: Optional[str] = None,
    hours: int = 24
) -> pd.DataFrame:
    """Load data from PostgreSQL database."""
    from app.core.database import get_database_service

    db_service = get_database_service()

    activity_logger.log_activity(
        activity="query_postgres",
        status="started"
    )

    try:
        with db_service.get_session() as session:
            # Build query
            query = """
                SELECT
                    event_id,
                    engine_serial,
                    tail_number,
                    system,
                    status,
                    timestamp,
                    latency_ms,
                    data_element,
                    data_quality_score
                FROM events
                WHERE timestamp >= NOW() - INTERVAL '%s hours'
            """ % hours

            filters = []
            params = {}

            if engine_serial:
                filters.append("engine_serial = :engine_serial")
                params["engine_serial"] = engine_serial

            if tail_number:
                filters.append("tail_number = :tail_number")
                params["tail_number"] = tail_number

            if filters:
                query += " AND " + " AND ".join(filters)

            query += " ORDER BY timestamp DESC"

            # Execute query and convert to DataFrame
            df = pd.read_sql(query, session.bind, params=params)

            activity_logger.log_activity(
                activity="query_postgres",
                status="completed",
                rows_returned=len(df)
            )

            logger.info(f"Loaded {len(df)} records from PostgreSQL")
            return df

    except Exception as e:
        activity_logger.log_activity(
            activity="query_postgres",
            status="failed",
            error=str(e)
        )
        raise DataNotFoundException(
            f"Failed to query PostgreSQL: {e}",
            details={
                "engine_serial": engine_serial,
                "tail_number": tail_number
            }
        )
```

#### Step 9: Test End-to-End

```bash
# Run Streamlit app
streamlit run Home.py

# Application will now:
# ✅ Connect to AWS PostgreSQL
# ✅ Query data from RDS
# ✅ Log all activities
# ✅ Display data in UI
```

---

## Practical Examples

### Example 1: Query Events

```python
from app.core.database import get_database_service
from datetime import datetime, timedelta

db_service = get_database_service()

# Query recent events
with db_service.get_session() as session:
    # SQL query
    query = """
        SELECT * FROM events
        WHERE timestamp >= :cutoff_time
        AND status = :status
        ORDER BY timestamp DESC
        LIMIT 100
    """

    result = session.execute(query, {
        "cutoff_time": datetime.now() - timedelta(hours=24),
        "status": "Complete"
    })

    for row in result:
        print(f"Event: {row.event_id}, System: {row.system}")
```

### Example 2: Insert New Event

```python
from app.core.database import get_database_service
from datetime import datetime

db_service = get_database_service()

# Insert event
with db_service.get_session() as session:
    session.execute("""
        INSERT INTO events (
            event_id, engine_serial, tail_number, system, status, timestamp
        ) VALUES (
            :event_id, :engine_serial, :tail_number, :system, :status, :timestamp
        )
    """, {
        "event_id": "evt_new_001",
        "engine_serial": "000000",
        "tail_number": "N-DEMO",
        "system": "1FA",
        "status": "Complete",
        "timestamp": datetime.now()
    })
    # Auto-commit on exit

print("✅ Event inserted")
```

### Example 3: Update Event Status

```python
from app.core.database import get_database_service

db_service = get_database_service()

# Update status
with db_service.get_session() as session:
    result = session.execute("""
        UPDATE events
        SET status = :new_status
        WHERE event_id = :event_id
    """, {
        "new_status": "Error",
        "event_id": "evt_001"
    })

    print(f"Updated {result.rowcount} rows")
```

### Example 4: Aggregate Query

```python
from app.core.database import get_database_service

db_service = get_database_service()

# Get statistics by system
with db_service.get_session() as session:
    result = session.execute("""
        SELECT
            system,
            COUNT(*) as total_events,
            AVG(latency_ms) as avg_latency,
            COUNT(CASE WHEN status = 'Error' THEN 1 END) as error_count
        FROM events
        WHERE timestamp >= NOW() - INTERVAL '24 hours'
        GROUP BY system
        ORDER BY total_events DESC
    """)

    for row in result:
        print(f"System: {row.system}")
        print(f"  Total: {row.total_events}")
        print(f"  Avg Latency: {row.avg_latency:.2f}ms")
        print(f"  Errors: {row.error_count}")
```

---

## Troubleshooting

### Issue 1: Connection Timeout

**Error:**
```
OperationalError: could not connect to server: Connection timed out
```

**Solutions:**

1. **Check Security Group:**
   ```bash
   aws ec2 describe-security-groups --group-ids sg-xxxxxxxxx
   ```
   Ensure port 5432 is open from your IP.

2. **Check RDS Public Access:**
   ```bash
   aws rds describe-db-instances \
     --db-instance-identifier data-observability-db \
     --query 'DBInstances[0].PubliclyAccessible'
   ```

3. **Test with psql:**
   ```bash
   psql -h data-observability-db.xxx.rds.amazonaws.com -U admin -d data_observability
   ```

### Issue 2: Authentication Failed

**Error:**
```
OperationalError: FATAL: password authentication failed
```

**Solutions:**

1. **Verify credentials:**
   ```bash
   # Check DATABASE_URL in .env
   cat .env | grep DATABASE_URL
   ```

2. **Reset master password:**
   ```bash
   aws rds modify-db-instance \
     --db-instance-identifier data-observability-db \
     --master-user-password NewPassword123!
   ```

### Issue 3: Too Many Connections

**Error:**
```
OperationalError: FATAL: too many connections for role "admin"
```

**Solutions:**

1. **Reduce pool size in `.env`:**
   ```bash
   DB_POOL_SIZE=5
   DB_MAX_OVERFLOW=10
   ```

2. **Increase max_connections in RDS:**
   ```bash
   # Create parameter group with higher max_connections
   aws rds modify-db-parameter-group \
     --db-parameter-group-name your-param-group \
     --parameters "ParameterName=max_connections,ParameterValue=200,ApplyMethod=immediate"
   ```

### Issue 4: Slow Queries

**Solutions:**

1. **Enable query logging:**
   ```bash
   # In .env
   DB_ECHO=True
   LOG_LEVEL=DEBUG
   ```

2. **Check indexes:**
   ```sql
   -- Connect to database
   SELECT * FROM pg_indexes WHERE tablename = 'events';
   ```

3. **Create indexes for common queries:**
   ```sql
   CREATE INDEX idx_events_timestamp ON events(timestamp);
   CREATE INDEX idx_events_engine_serial ON events(engine_serial);
   CREATE INDEX idx_events_tail_number ON events(tail_number);
   ```

### Issue 5: Connection Pool Exhausted

**Error:**
```
TimeoutError: QueuePool limit of size 10 overflow 20 reached
```

**Solutions:**

1. **Increase pool size:**
   ```bash
   # In .env
   DB_POOL_SIZE=20
   DB_MAX_OVERFLOW=40
   ```

2. **Check for connection leaks:**
   ```python
   # Always use context manager
   with db_service.get_session() as session:
       # Query here
       pass
   # Session automatically closed
   ```

---

## Summary

### DatabaseService Provides:

| Feature | Benefit |
|---------|---------|
| **SQLAlchemy Wrapper** | Works with SQLite and PostgreSQL |
| **Connection Pooling** | Reuses connections for performance |
| **Session Management** | Auto-commit/rollback |
| **Activity Logging** | Every query is logged |
| **Health Checks** | Test database connectivity |
| **Error Handling** | Correlation IDs for debugging |

### AWS PostgreSQL Setup:

1. ✅ Create RDS instance
2. ✅ Configure security group
3. ✅ Update `.env` with connection string
4. ✅ Create database schema
5. ✅ Load sample data
6. ✅ Update data service query
7. ✅ Test connection

### Key Files:

| File | Purpose |
|------|---------|
| [app/core/database.py](app/core/database.py) | DatabaseService implementation |
| [app/services/data_service.py](app/services/data_service.py) | Data abstraction layer |
| [.env](.env) | Database configuration |

**Need help?** Check logs with correlation ID for detailed error information!
