# Enable Real Database Data - Quick Checklist

## ✅ Current Status

- ✅ **Models Created:** 7 SQLAlchemy models in [app/models/existing_tables.py](app/models/existing_tables.py)
- ✅ **Queries Written:** 6 data service methods in [app/services/data_service.py](app/services/data_service.py)
- ✅ **Overview Updated:** Integration code added to [app/components/tabs/overview.py](app/components/tabs/overview.py)
- ⚠️ **Currently DISABLED:** Real data code is commented out
- ✅ **Dummy Data Works:** Application runs normally with dummy data

---

## 📋 Steps to Enable Real Data

### Step 1: Configure Database Connection

**File:** `.env`

```bash
# Set these environment variables
DATABASE_URL=postgresql://username:password@your-rds-endpoint:5432/your_database
ENABLE_DUMMY_DATA=false  # IMPORTANT: Must be false for real data
```

**Verify:**
```bash
python scripts/test_postgres.py
```

---

### Step 2: Verify Database Schema

**Run inspection script:**
```bash
python scripts/inspect_database.py
```

**Check for these tables:**
- [ ] `events` table exists
- [ ] `data_elements` table exists
- [ ] `sla_targets` table exists
- [ ] `error_logs` table exists
- [ ] `engines` table exists
- [ ] `flights` table exists (optional)
- [ ] `system_health` table exists (optional)

**If table names or columns differ:**
- Edit [app/models/existing_tables.py](app/models/existing_tables.py)
- Update table names and column names to match your database

---

### Step 3: Test Data Service Methods

**Run in Python:**
```python
from app.core import initialize_app
from app.core.di import inject

# Initialize application
initialize_app()

# Get data service
data_service = inject("data_service")

# Test with your actual engine serial
ENGINE_SERIAL = "YOUR_ACTUAL_ENGINE_SERIAL"  # Replace this!

# Test 1: Status summary
print("Testing status summary...")
status = data_service.get_status_summary(ENGINE_SERIAL, hours=24)
print(status)

# Test 2: Data population
print("\nTesting data population...")
population = data_service.get_data_population(ENGINE_SERIAL, hours=24)
print(population)

# Test 3: SLA timeline
print("\nTesting SLA timeline...")
sla = data_service.get_sla_timeline(ENGINE_SERIAL, hours=24)
print(sla)

# Test 4: Error notifications
print("\nTesting error notifications...")
errors = data_service.get_error_notifications(ENGINE_SERIAL, hours=24)
print(errors)

# Test 5: Last updated
print("\nTesting last updated...")
updated = data_service.get_last_updated(ENGINE_SERIAL, hours=24)
print(updated)

# Test 6: Complete overview data
print("\nTesting complete overview...")
overview = data_service.get_overview_data(ENGINE_SERIAL, hours=24)
print(f"Overview keys: {overview.keys()}")
for key, df in overview.items():
    print(f"\n{key}: {len(df)} rows")
    print(df.head())
```

**Expected Output:**
- All queries should return DataFrames
- No errors or exceptions
- Data should match your database content

---

### Step 4: Enable Real Data in Overview Component

**File:** [app/components/tabs/overview.py](app/components/tabs/overview.py)

#### 4.1 Uncomment Import (Line ~8)

**Change FROM:**
```python
# from ...core.di import inject  # Uncomment when enabling real data
```

**Change TO:**
```python
from ...core.di import inject
```

#### 4.2 Uncomment Real Data Section (Lines ~15-30)

**Uncomment this entire block:**
```python
# Get data service from DI container
data_service = inject("data_service")

# Fetch all Overview metrics from real database using JOIN queries
overview_data = data_service.get_overview_data(
    engine_serial=engine_serial,
    hours=int(window_hours)
)

# Extract individual metrics from overview_data
status_summary = overview_data['status_summary']
data_population_df = overview_data['data_population']
sla_timeline_df = overview_data['sla_timeline']
error_notifications_df = overview_data['error_notifications']
last_updated_df = overview_data['last_updated']
```

#### 4.3 Comment Out Dummy Data (Lines ~40-44)

**Comment out these lines:**
```python
# status_summary = build_status_summary(df)
# population_pies = build_population_pies(df)
# last_updated_table = build_last_updated_table(df)
# governance_df = fake_root_cause_panel()
# sla_html_tracker = build_sla_dominos_html(df, now, hours=window_hours)
```

#### 4.4 Update Data Population Visualization

**Replace dummy pie charts with real data:**

**Find this line (~35-37):**
```python
pie_row = st.columns(len(population_pies))
for i, fig in enumerate(population_pies):
    pie_row[i].plotly_chart(fig, use_container_width=True)
```

**Replace with:**
```python
# Build pie charts from real data
import plotly.graph_objects as go

population_pies = []
for _, row in data_population_df.iterrows():
    completeness = row['completeness_pct'] / 100.0
    missing = 1 - completeness
    fig = go.Figure(data=[go.Pie(
        labels=["Present", "Missing"],
        values=[completeness, missing],
        hole=0.55
    )])
    fig.update_layout(
        title=f"{row['system_name']} ({completeness*100:.1f}%)",
        margin=dict(l=0, r=0, t=35, b=0),
        showlegend=False
    )
    population_pies.append(fig)

# Display pie charts
pie_row = st.columns(len(population_pies))
for i, fig in enumerate(population_pies):
    pie_row[i].plotly_chart(fig, use_container_width=True)
```

#### 4.5 Update Last Updated Table

**Replace this line (~53-54):**
```python
st.dataframe(last_updated_table, use_container_width=True)
```

**With:**
```python
st.dataframe(last_updated_df, use_container_width=True)
```

#### 4.6 Update SLA Timeline (Optional - requires custom implementation)

The SLA timeline currently uses `build_sla_dominos_html()` which expects the simulated DataFrame format. You have two options:

**Option A:** Keep using the builder with real data
```python
# Keep this as-is, passing the sla_timeline_df
sla_html_tracker = build_sla_dominos_html(sla_timeline_df, now, hours=window_hours)
```

**Option B:** Create custom SLA visualization from real data (recommended later)

#### 4.7 Update Error Notifications

**Find this line (~48-51):**
```python
error_notif_html = build_error_notifications(df, now)
```

**Replace with:**
```python
# Build error notifications from real data
if len(error_notifications_df) > 0:
    # Custom HTML builder for real error data
    from ...builders.helpers import build_error_notifications_from_df
    error_notif_html = build_error_notifications_from_df(error_notifications_df, now)
else:
    error_notif_html = ""
```

**Note:** You may need to create a new helper function `build_error_notifications_from_df()` or adapt the existing one.

---

### Step 5: Run and Test

**Start Streamlit:**
```bash
streamlit run Home.py
```

**Verify in Overview Tab:**
- [ ] Status cards show correct counts (Fail/Pass/Pending/Processing)
- [ ] Data population pie charts show real percentages
- [ ] SLA timeline displays correctly
- [ ] Error notifications appear (if errors exist in database)
- [ ] Last updated table shows correct timestamps
- [ ] No errors in console or logs

**Check Logs:**
```bash
# Local logs
tail -f logs/app.log

# Look for these activity logs:
# - get_overview_data started/completed
# - get_status_summary started/completed
# - get_data_population started/completed
# etc.
```

---

### Step 6: Monitor and Optimize

**Add Database Indexes (if queries are slow):**
```sql
-- Run these in your PostgreSQL database
CREATE INDEX IF NOT EXISTS idx_events_engine ON events(engine_serial);
CREATE INDEX IF NOT EXISTS idx_events_time ON events(start_time);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_system ON events(system_name);
CREATE INDEX IF NOT EXISTS idx_data_elements_event ON data_elements(event_id);
CREATE INDEX IF NOT EXISTS idx_error_logs_event ON error_logs(event_id);
```

**Monitor Query Performance:**
- Check CloudWatch logs for query execution times
- Look for slow queries in activity logs
- Adjust time windows if needed (reduce hours parameter)

---

## 🚨 Common Issues and Solutions

### Issue: "relation 'events' does not exist"

**Cause:** Table name doesn't match model definition

**Solution:**
1. Run `python scripts/inspect_database.py` to see actual table names
2. Update `__tablename__` in [app/models/existing_tables.py](app/models/existing_tables.py)

### Issue: "column 'system_name' does not exist"

**Cause:** Column name doesn't match model definition

**Solution:**
1. Check actual column names with `inspect_database.py`
2. Update Column definitions in models:
   ```python
   # If your column is named 'SystemName':
   system_name = Column('SystemName', String(50), nullable=False)
   ```

### Issue: "No data returned" (empty DataFrames)

**Causes:**
- Wrong `engine_serial` value
- Time window too small
- No data in database for specified filters

**Solutions:**
1. Check what engine serials exist in your database:
   ```sql
   SELECT DISTINCT engine_serial FROM events LIMIT 10;
   ```
2. Increase time window: `hours=168` (7 days) or `hours=720` (30 days)
3. Remove filters temporarily to see all data

### Issue: "Application crashes" or "Streamlit error"

**Solutions:**
1. Check error logs: `tail -f logs/app.log`
2. Verify all imports are correct
3. Ensure `ENABLE_DUMMY_DATA=false` in `.env`
4. Restart Streamlit application

---

## 📊 Example Valid Configuration

**File:** `.env`
```bash
# Database connection
DATABASE_URL=postgresql://myuser:mypassword@my-rds.us-east-1.rds.amazonaws.com:5432/aviation_db
ENABLE_DUMMY_DATA=false

# AWS (optional, for CloudWatch logging)
ENABLE_AWS_LOGGING=true
AWS_LOG_GROUP=/aws/streamlit/aviation
AWS_LOG_STREAM=production
AWS_REGION=us-east-1
```

---

## 📚 Documentation References

- **[OVERVIEW_REAL_DATA_IMPLEMENTATION.md](docs/OVERVIEW_REAL_DATA_IMPLEMENTATION.md)** - Complete implementation guide
- **[OVERVIEW_INTEGRATION_GUIDE.md](docs/OVERVIEW_INTEGRATION_GUIDE.md)** - Database schema details
- **[DATABASE_GUIDE.md](docs/DATABASE_GUIDE.md)** - SQLAlchemy and PostgreSQL guide
- **[EXISTING_DATABASE_GUIDE.md](docs/EXISTING_DATABASE_GUIDE.md)** - Connecting to existing databases

---

## ✅ Final Checklist

Before going live with real data:

- [ ] Database connection configured and tested
- [ ] All required tables exist in database
- [ ] Data service methods tested and return data
- [ ] Overview component updated (imports uncommented)
- [ ] Real data section uncommented
- [ ] Dummy data section commented out
- [ ] Visualizations updated for real data
- [ ] Application runs without errors
- [ ] Overview tab displays correctly
- [ ] Logs show successful queries
- [ ] Performance is acceptable
- [ ] Database indexes created (if needed)

---

## 🎯 You're Ready!

Once all steps are complete, your Overview screen will display live data from your AWS PostgreSQL database with:
- ✅ Real-time status counts
- ✅ Actual data completeness metrics
- ✅ Live SLA monitoring
- ✅ Real error notifications
- ✅ Current update timestamps

All queries are logged with correlation IDs for tracking and debugging!
