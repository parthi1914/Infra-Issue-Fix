# Overview Screen - Quick Reference

## 🎯 What Overview Shows

```
┌─────────────────────────────────────────────────────────────┐
│                  OVERVIEW SCREEN                             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐                   │
│  │ FAIL │  │ PASS │  │ PEND │  │ PROC │  ◄── Status Cards  │
│  │  12  │  │  45  │  │   3  │  │   5  │                    │
│  └──────┘  └──────┘  └──────┘  └──────┘                    │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  DATA POPULATION (Pie Charts)                       │   │
│  │  [1FA: 98%] [IFS: 95%] [FDM: 92%] ...             │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  SLA TIMELINE                                        │   │
│  │  [====1FA====][====IFS====][====FDM====]...        │   │
│  │   Complete    Complete      Processing             │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  ERROR NOTIFICATIONS                                 │   │
│  │  🚨 PHM: Database timeout - Analytics Team notified │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  LAST UPDATED TIMES                                  │   │
│  │  1FA: 10:35:22 | IFS: 10:38:15 | FDM: 10:42:01     │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 📊 7 Key Metrics

| # | Metric | What It Shows | Database Table(s) |
|---|--------|---------------|-------------------|
| 1 | **Fail Count** | Events with status='Error' | `events` |
| 2 | **Pass Count** | Events with status='Complete' | `events` |
| 3 | **Pending Count** | Events waiting to start | `events` |
| 4 | **Processing Count** | Events currently running | `events` |
| 5 | **Data Population** | % of data fields populated | `events` + `data_elements` |
| 6 | **SLA Timeline** | Timeline showing progress | `events` + `sla_targets` |
| 7 | **Error Notifications** | Error details + team alerts | `events` + `error_logs` |

---

## 🗄️ Database Schema (Simplified)

### Core Tables

```sql
events                    data_elements               error_logs
├─ event_id (PK)         ├─ element_id (PK)          ├─ error_id (PK)
├─ engine_serial         ├─ event_id (FK)            ├─ event_id (FK)
├─ system_name           ├─ element_name             ├─ error_severity
├─ status                ├─ is_present               ├─ notified_team
├─ start_time            ├─ completeness_score       └─ notification_sent_at
└─ end_time              └─ quality_score

sla_targets              engines                     flights
├─ system_name (PK)      ├─ serial_number (PK)       ├─ flight_id (PK)
├─ expected_duration     ├─ model                    ├─ tail_number
└─ sla_threshold         └─ status                   ├─ engine_serial_1
                                                      └─ engine_serial_2
```

---

## 🔗 Table Relationships

```
engines ──────┐
             │
             ├──► events ────┬──► data_elements
             │               │
flights ─────┘               ├──► error_logs
                             │
         sla_targets ────────┘
```

---

## 📝 SQL Query Examples

### 1. Fail Count (Simple)

```sql
SELECT COUNT(*)
FROM events
WHERE status = 'Error'
  AND engine_serial = '000000'
  AND start_time >= NOW() - INTERVAL '24 hours';
```

### 2. Status Summary (with CASE)

```sql
SELECT
    CASE
        WHEN status = 'Complete' THEN 'Pass'
        WHEN status = 'Error' THEN 'Fail'
        WHEN status IN ('Pending', 'Delayed') THEN 'Pending'
        ELSE 'Processing'
    END as category,
    COUNT(*) as count
FROM events
WHERE engine_serial = '000000'
  AND start_time >= NOW() - INTERVAL '24 hours'
GROUP BY category;
```

**Result:**
```
category     | count
-------------|------
Pass         |   45
Fail         |   12
Pending      |    3
Processing   |    5
```

### 3. Data Population (with JOIN)

```sql
SELECT
    e.system_name,
    AVG(de.completeness_score) * 100 as completeness_pct
FROM events e
LEFT JOIN data_elements de ON e.event_id = de.event_id
WHERE e.engine_serial = '000000'
  AND e.start_time >= NOW() - INTERVAL '24 hours'
GROUP BY e.system_name;
```

**Result:**
```
system_name | completeness_pct
------------|------------------
1FA         |            98.2
IFS         |            95.7
FDM         |            92.3
```

### 4. SLA Timeline (with JOIN and time calc)

```sql
SELECT
    e.system_name,
    e.status,
    e.start_time,
    e.end_time,
    EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 as duration_minutes,
    sla.expected_duration_minutes,
    CASE
        WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.expected_duration_minutes
        THEN 'ON_TIME'
        ELSE 'SLA_BREACH'
    END as sla_status
FROM events e
LEFT JOIN sla_targets sla ON e.system_name = sla.system_name
WHERE e.engine_serial = '000000'
ORDER BY e.start_time;
```

**Result:**
```
system | status   | duration_min | expected | sla_status
-------|----------|--------------|----------|------------
1FA    | Complete |          2.1 |        2 | ON_TIME
IFS    | Complete |          3.2 |        3 | SLA_BREACH
FDM    | Processing|         5.0 |        5 | ON_TIME
```

### 5. Error Notifications (with MULTIPLE JOINS)

```sql
SELECT
    e.system_name,
    e.error_message,
    el.error_severity,
    el.notified_team,
    el.notification_sent_at,
    eng.model as engine_model
FROM events e
INNER JOIN error_logs el ON e.event_id = el.event_id
INNER JOIN engines eng ON e.engine_serial = eng.serial_number
WHERE e.status = 'Error'
  AND e.engine_serial = '000000'
ORDER BY el.notification_sent_at DESC;
```

**Result:**
```
system | error_message      | severity | notified_team         | sent_at
-------|--------------------|----------|-----------------------|-------------------
PHM    | Database timeout   | CRITICAL | PHM Analytics Team    | 2026-02-05 10:15:00
FMX    | API rate limit     | HIGH     | Customer Exp Team     | 2026-02-05 09:42:00
```

---

## 🔄 How Data Flows

```
1. Query Database (with JOINs)
   ↓
   SELECT events + data_elements + error_logs + sla_targets
   ↓
2. Return DataFrame
   ↓
   engine_serial | system | status | completeness | ...
   000000        | 1FA    | Complete| 0.98        | ...
   000000        | IFS    | Complete| 0.95        | ...
   ↓
3. Process in Python
   ↓
   df.groupby('status').count()
   df['completeness'].mean()
   ↓
4. Display in Streamlit
   ↓
   st.metric("Fail Count", fail_count)
   st.plotly_chart(pie_chart)
```

---

## 💡 JOIN Types Used

### 1. INNER JOIN (Only matching records)

```sql
FROM events e
INNER JOIN error_logs el ON e.event_id = el.event_id
-- Only events that have errors
```

### 2. LEFT JOIN (All left records + matching right)

```sql
FROM events e
LEFT JOIN data_elements de ON e.event_id = de.event_id
-- All events, with data elements if they exist
```

### 3. LATERAL JOIN (Correlated subquery)

```sql
FROM events e
LEFT JOIN LATERAL (
    SELECT is_healthy
    FROM system_health
    WHERE system_name = e.system_name
    ORDER BY check_time DESC
    LIMIT 1
) sh ON true
-- Latest health check for each system
```

---

## 🎯 Implementation Steps

### Step 1: Create Tables

```sql
-- Run in your PostgreSQL database
CREATE TABLE events (...);
CREATE TABLE data_elements (...);
CREATE TABLE error_logs (...);
CREATE TABLE sla_targets (...);
-- See OVERVIEW_INTEGRATION_GUIDE.md for full schema
```

### Step 2: Insert Sample Data

```sql
-- Test with sample data
INSERT INTO events VALUES (...);
INSERT INTO data_elements VALUES (...);
-- See guide for sample inserts
```

### Step 3: Add Method to DataService

```python
# app/services/data_service.py

def get_overview_data(self, engine_serial: str, hours: int = 24):
    """Get all overview metrics."""
    with db_service.get_session() as session:
        # Query 1: Status summary
        status_df = pd.read_sql("""
            SELECT ... FROM events ...
        """, session.bind, params={"engine_serial": engine_serial})

        # Query 2: Data population
        pop_df = pd.read_sql("""
            SELECT ... FROM events e
            LEFT JOIN data_elements de ...
        """, session.bind, params={"engine_serial": engine_serial})

        return {
            'status': status_df,
            'population': pop_df,
            ...
        }
```

### Step 4: Update Overview Component

```python
# app/components/tabs/overview.py

def render(df, now, window_hours, engine_serial, tail_number):
    data_service = inject("data_service")

    # Get all data
    overview = data_service.get_overview_data(engine_serial, window_hours)

    # Display metrics
    st.metric("Fail Count", overview['status']['Fail'].count())
    st.plotly_chart(create_pie(overview['population']))
    ...
```

---

## 📚 Complete Documentation

| Document | Purpose |
|----------|---------|
| **[OVERVIEW_INTEGRATION_GUIDE.md](docs/OVERVIEW_INTEGRATION_GUIDE.md)** | **Complete detailed guide** |
| **[EXISTING_DATABASE_GUIDE.md](docs/EXISTING_DATABASE_GUIDE.md)** | Connect to existing database |
| **[DATABASE_GUIDE.md](docs/DATABASE_GUIDE.md)** | SQLAlchemy & PostgreSQL guide |
| **[REAL_DATA_CHECKLIST.md](REAL_DATA_CHECKLIST.md)** | Step-by-step checklist |

---

## 🚀 Quick Commands

```bash
# 1. Inspect your database schema
python scripts/inspect_database.py

# 2. See example queries
cat docs/OVERVIEW_INTEGRATION_GUIDE.md

# 3. Test queries directly
psql "postgresql://user:pass@host:5432/db"
# Then run queries from guide

# 4. Test integration
python scripts/test_real_database.py

# 5. Run application
streamlit run Home.py
```

---

## 📊 Sample Data Result

When working correctly, you'll see:

```python
# overview_data['status']
   category  count
0      Fail     12
1      Pass     45
2   Pending      3
3 Processing      5

# overview_data['population']
  system  completeness  quality
0    1FA          0.98     0.97
1    IFS          0.95     0.96
2    FDM          0.92     0.88

# overview_data['sla_timeline']
  event_id system     status         start_time           end_time
0  evt_001    1FA  Complete  2026-02-05 08:00:00  2026-02-05 08:02:00
1  evt_002    IFS  Complete  2026-02-05 08:02:00  2026-02-05 08:05:00
2  evt_003    FDM  Processing 2026-02-05 08:05:00  2026-02-05 08:10:00
```

---

## ⚡ Performance Tips

1. **Add Indexes:**
   ```sql
   CREATE INDEX idx_events_engine ON events(engine_serial);
   CREATE INDEX idx_events_time ON events(start_time);
   CREATE INDEX idx_events_status ON events(status);
   ```

2. **Limit Time Window:**
   ```sql
   WHERE start_time >= NOW() - INTERVAL '24 hours'  -- Not all time!
   ```

3. **Use JOINs, not separate queries:**
   ```sql
   -- ✅ Good: Single query with JOIN
   SELECT e.*, de.completeness FROM events e LEFT JOIN data_elements de ...

   -- ❌ Bad: Two queries
   events = query("SELECT * FROM events")
   for event in events:
       elements = query("SELECT * FROM data_elements WHERE event_id = ?")
   ```

4. **Add LIMIT for safety:**
   ```sql
   ORDER BY start_time DESC LIMIT 1000
   ```

---

## 🎯 Key Takeaways

1. **Overview = 7 metrics** from database tables
2. **Use JOINs** to combine data from multiple tables
3. **One method** returns all data: `get_overview_data()`
4. **All queries logged** with correlation_id
5. **Easy to switch** between JSON and PostgreSQL

**Start with:** `python scripts/inspect_database.py` to see YOUR schema!
