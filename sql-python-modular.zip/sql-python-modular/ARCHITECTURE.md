# Architecture Documentation

## Overview

This application is built with a production-ready, modular architecture that supports:
- Simple JSON-like logging with AWS CloudWatch integration
- Global exception handling with correlation IDs
- Lightweight dependency injection
- AWS service integrations (SNS, boto3)
- Database abstraction (SQLite/PostgreSQL)
- Easy switching between dummy JSON data and PostgreSQL

## Architecture Principles

1. **Simplicity**: No complex abstractions, easy to understand and maintain
2. **Modularity**: Clear separation of concerns with service layers
3. **Production-Ready**: Comprehensive logging, error handling, and monitoring
4. **Flexibility**: Easy to switch between local and AWS environments
5. **Maintainability**: Minimal code changes required for configuration updates

## Directory Structure

```
sql-python-modular/
├── app/
│   ├── core/                    # Core infrastructure
│   │   ├── __init__.py         # App initialization
│   │   ├── config.py           # Configuration management
│   │   ├── context.py          # Correlation ID management
│   │   ├── logging.py          # Centralized logging
│   │   ├── exceptions.py       # Global exception handling
│   │   ├── di.py               # Dependency injection
│   │   ├── aws.py              # AWS service layer
│   │   └── database.py         # Database service layer
│   ├── services/               # Business logic services
│   │   ├── __init__.py
│   │   └── data_service.py    # Data abstraction layer
│   ├── components/             # UI components
│   ├── builders/               # Chart/UI builders
│   ├── config.py               # App constants
│   └── data_simulation.py      # Data simulation
├── data/
│   └── dummy_events.json       # Dummy data for development
├── logs/                       # Local log files (created at runtime)
├── Home.py                     # Streamlit entry point
├── requirements.txt            # Python dependencies
├── .env.example               # Configuration template
└── README.md                  # Getting started guide
```

## Core Components

### 1. Logging System ([app/core/logging.py](app/core/logging.py))

**Features:**
- JSON-like format for easy parsing
- Console output (human-readable)
- Local file logging (JSON format)
- AWS CloudWatch integration
- Correlation ID in every log entry
- Activity logging helper

**Usage:**
```python
from app.core.logging import get_logger, ActivityLogger

logger = get_logger(__name__)
activity_logger = ActivityLogger(logger)

# Simple logging
logger.info("Operation started", extra={"user_id": "123"})

# Activity logging
activity_logger.log_activity(
    activity="database_query",
    status="completed",
    rows_returned=100
)
```

**Log Format:**
```json
{
  "timestamp": "2026-02-05T10:00:00",
  "level": "INFO",
  "message": "Operation started",
  "correlation_id": "01HQXXX...",
  "environment": "local",
  "app_name": "Engine Data Observability",
  "module": "data_service",
  "function": "get_events_data"
}
```

### 2. Exception Handling ([app/core/exceptions.py](app/core/exceptions.py))

**Features:**
- Base `AppException` with correlation ID
- Specialized exceptions (DatabaseException, AWSServiceException, etc.)
- Global uncaught exception handler
- Automatic exception logging

**Usage:**
```python
from app.core.exceptions import DatabaseException, log_exception

try:
    # Database operation
    result = query_database()
except Exception as e:
    # Log and optionally re-raise
    log_exception(e, context={"query": "SELECT ..."}, reraise=True)

# Custom exceptions
raise DatabaseException(
    "Query failed",
    details={"table": "events", "error_code": "TIMEOUT"}
)
```

### 3. Correlation IDs ([app/core/context.py](app/core/context.py))

**Features:**
- Thread-safe context management
- ULID-based unique IDs (sortable)
- Automatic generation and propagation

**Usage:**
```python
from app.core.context import set_correlation_id, get_correlation_id

# Set correlation ID (e.g., at request start)
correlation_id = set_correlation_id()

# Get current correlation ID (anywhere in the call stack)
current_id = get_correlation_id()
```

### 4. Dependency Injection ([app/core/di.py](app/core/di.py))

**Features:**
- Lightweight container
- Singleton and factory patterns
- Lazy initialization
- Decorator support

**Usage:**
```python
from app.core.di import register_singleton, inject, autowired

# Register services
register_singleton("database_service", lambda: DatabaseService())

# Inject manually
db_service = inject("database_service")

# Inject via decorator
@autowired(db="database_service", sns="sns_service")
def my_function(db, sns):
    # db and sns are automatically injected
    pass
```

### 5. AWS Services ([app/core/aws.py](app/core/aws.py))

**Features:**
- Boto3 client/resource factory
- Connection pooling
- SNS service wrapper
- Activity logging for all operations

**Usage:**
```python
from app.core.aws import get_boto3_client, SNSService

# Get boto3 client
s3_client = get_boto3_client("s3")

# Use SNS service
sns_service = SNSService()
sns_service.publish_alert(
    alert_type="DATA_QUALITY",
    message="Low data quality detected",
    severity="WARNING",
    engine_serial="000000"
)
```

### 6. Database Service ([app/core/database.py](app/core/database.py))

**Features:**
- SQLAlchemy abstraction
- Support for SQLite and PostgreSQL
- Connection pooling (PostgreSQL)
- Session management
- Health checks

**Usage:**
```python
from app.core.database import get_database_service

db_service = get_database_service()

# Use session context manager
with db_service.get_session() as session:
    results = session.query(Event).filter_by(status="Complete").all()

# Health check
is_healthy = db_service.health_check()
```

### 7. Data Service ([app/services/data_service.py](app/services/data_service.py))

**Features:**
- Abstraction over data sources (JSON/PostgreSQL)
- Easy switching via configuration
- Consistent interface

**Usage:**
```python
from app.services.data_service import DataService

data_service = DataService()

# Get events (automatically uses JSON or PostgreSQL based on config)
df = data_service.get_events_data(
    engine_serial="000000",
    tail_number="N-DEMO",
    hours=24
)

# Get system status
status = data_service.get_system_status()
```

## Configuration Management

### Environment Variables (.env file)

All configuration is controlled via environment variables. See [.env.example](.env.example) for all options.

**Key Configuration Flags:**

1. **Data Source:**
   - `ENABLE_DUMMY_DATA=True` → Use JSON dummy data
   - `ENABLE_DUMMY_DATA=False` → Use PostgreSQL

2. **Logging:**
   - `ENABLE_LOCAL_LOGGING=True` → Write to local file
   - `ENABLE_AWS_LOGGING=True` → Send to CloudWatch

3. **Database:**
   - Local: `DATABASE_URL=sqlite:///./data_observability.db`
   - AWS: `DATABASE_URL=postgresql://user:pass@host:5432/db`

### Feature Flags

- `ENABLE_AUTH`: Enable/disable authentication (currently disabled)
- `ENABLE_DUMMY_DATA`: Use JSON data (True) or PostgreSQL (False)
- `USE_AWS_POSTGRES`: Flag for AWS PostgreSQL usage

## Switching from JSON to PostgreSQL

**Step 1:** Update [.env](.env):
```bash
ENABLE_DUMMY_DATA=False
USE_AWS_POSTGRES=True
DATABASE_URL=postgresql://username:password@your-rds-endpoint.rds.amazonaws.com:5432/dbname
```

**Step 2:** Create database schema (one-time):
```python
from app.core.database import get_database_service

db_service = get_database_service()
db_service.create_tables()
```

**Step 3:** Update query in [app/services/data_service.py](app/services/data_service.py#L95) to match your schema:
```python
def _get_postgres_data(self, ...):
    query = """
        SELECT * FROM your_events_table
        WHERE timestamp >= NOW() - INTERVAL '%s hours'
    """ % hours
    # Adjust to your actual table structure
```

That's it! No other code changes needed.

## Activity Logging

Every significant operation is logged with:
- Activity name (e.g., "database_query", "sns_publish")
- Status (started, completed, failed)
- Context data (parameters, results, errors)
- Correlation ID

**Benefits:**
- End-to-end request tracing
- Performance monitoring
- Debugging support
- Audit trail

**Example Log Entries:**
```json
{"activity": "database_query", "status": "started", "statement": "SELECT * FROM events..."}
{"activity": "database_query", "status": "completed", "rows_returned": 150}
{"activity": "sns_publish", "status": "completed", "message_id": "abc123"}
```

## AWS Integration

### CloudWatch Logs

**Setup:**
1. Set `ENABLE_AWS_LOGGING=True` in [.env](.env)
2. Configure `AWS_LOG_GROUP` and `AWS_LOG_STREAM`
3. Ensure AWS credentials are configured (IAM role or environment variables)

**Result:**
All logs are automatically sent to CloudWatch with structured JSON format.

### SNS Notifications

**Setup:**
1. Create SNS topic in AWS
2. Set `AWS_SNS_TOPIC_ARN` in [.env](.env)

**Usage:**
```python
from app.core.di import inject

sns_service = inject("sns_service")
sns_service.publish_alert(
    alert_type="ERROR",
    message="Critical system error",
    severity="CRITICAL"
)
```

## Best Practices

### 1. Logging
- Use `get_logger(__name__)` in each module
- Add correlation ID context to all logs
- Use ActivityLogger for operation tracking
- Log at appropriate levels (DEBUG, INFO, WARNING, ERROR)

### 2. Exception Handling
- Use custom exceptions for domain errors
- Always log exceptions with context
- Don't swallow exceptions silently
- Include correlation ID for tracing

### 3. Dependency Injection
- Register services at startup
- Use `inject()` to get services
- Don't create service instances directly
- Keep container usage simple

### 4. Database Access
- Always use session context manager
- Don't keep sessions open longer than needed
- Use connection pooling for PostgreSQL
- Log all database operations

### 5. Configuration
- Never hardcode configuration
- Use environment variables
- Provide sensible defaults
- Document all configuration options

## Testing

### Unit Testing
```python
from app.core.di import get_container

def test_service():
    container = get_container()
    container.clear()  # Clear for isolated test

    # Register test dependencies
    container.register_instance("database_service", MockDatabaseService())

    # Test your code
    ...
```

### Integration Testing
```bash
# Set test environment
export APP_ENV=test
export DATABASE_URL=sqlite:///:memory:

# Run tests
pytest
```

## Deployment

### Local Development
```bash
cp .env.example .env
# Edit .env for local configuration
streamlit run Home.py
```

### AWS Deployment
1. Update [.env](.env) with AWS configuration
2. Ensure AWS credentials are configured
3. Deploy to EC2/ECS/Lambda
4. Monitor logs in CloudWatch

## Performance Considerations

- **Logging:** Asynchronous CloudWatch handler (batched every 5 seconds)
- **Database:** Connection pooling for PostgreSQL
- **AWS:** Client caching in Boto3Factory
- **DI Container:** Lazy singleton initialization

## Security

- Passwords masked in database URLs
- AWS credentials via IAM roles (preferred) or environment variables
- No secrets in code or logs
- Authentication disabled by default (feature flag)

## Maintenance

### Adding New Services
1. Create service class in [app/services/](app/services/)
2. Register in [app/core/__init__.py](app/core/__init__.py)
3. Inject where needed using `inject()`

### Adding New AWS Services
1. Add client/resource creation in [app/core/aws.py](app/core/aws.py)
2. Create service wrapper class
3. Add activity logging
4. Register in DI container

### Updating Configuration
1. Add environment variable in [app/core/config.py](app/core/config.py)
2. Document in [.env.example](.env.example)
3. Update [README.md](README.md) if needed

## Troubleshooting

### Logs not appearing in CloudWatch
- Check AWS credentials
- Verify IAM permissions (logs:CreateLogGroup, logs:CreateLogStream, logs:PutLogEvents)
- Check `AWS_LOG_GROUP` and `AWS_LOG_STREAM` configuration

### Database connection errors
- Verify `DATABASE_URL` format
- Check network connectivity to PostgreSQL
- Ensure database exists and credentials are correct

### SNS publish failures
- Verify `AWS_SNS_TOPIC_ARN` is correct
- Check IAM permissions (sns:Publish)
- Review logs for detailed error messages

## Support

For issues or questions:
1. Check logs for correlation ID
2. Search logs in CloudWatch using correlation ID
3. Review exception details and stack traces
4. Check configuration in [.env](.env)
