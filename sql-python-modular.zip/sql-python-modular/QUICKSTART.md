# Quick Start Guide

## 5-Minute Setup

### 1. Install and Run (Local Development)

```bash
# Install dependencies
pip install -r requirements.txt

# Copy environment file
cp .env.example .env

# Run the application
streamlit run Home.py
```

That's it! The application will:
- ✅ Use dummy JSON data (no database required)
- ✅ Log to console and `logs/app.log`
- ✅ Generate correlation IDs for tracking
- ✅ Work completely offline

### 2. View the Logs

**Console Output:**
```
2026-02-05 10:00:00 | INFO | app.core | [01HQXXX...] | Application initialized
2026-02-05 10:00:01 | INFO | __main__ | [01HQXXX...] | Streamlit session started
```

**Log File:** Check `logs/app.log` for JSON-formatted logs

### 3. Test the Infrastructure

Open a Python shell and test the services:

```python
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.services.data_service import DataService

# Initialize infrastructure
initialize_app()

# Get logger
logger = get_logger(__name__)
logger.info("Testing logging system")

# Get data service
data_service = inject("data_service")
df = data_service.get_events_data(hours=24)

print(f"Retrieved {len(df)} events from JSON file")
```

## Switching to Production (AWS)

### 1. Update [.env](.env) File

```bash
# AWS Configuration
APP_ENV=aws
ENABLE_AWS_LOGGING=True
ENABLE_DUMMY_DATA=False

# AWS CloudWatch
AWS_REGION=us-east-1
AWS_LOG_GROUP=/aws/streamlit/data-observability
AWS_LOG_STREAM=app-stream

# AWS PostgreSQL
DATABASE_URL=postgresql://username:password@your-rds.amazonaws.com:5432/dbname

# SNS Notifications
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:alerts
```

### 2. Set Up AWS Credentials

Option 1: IAM Role (Recommended for EC2/ECS)
```bash
# No configuration needed - uses instance IAM role
```

Option 2: Environment Variables
```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_REGION=us-east-1
```

Option 3: AWS CLI Profile
```bash
aws configure
# Follow prompts to enter credentials
```

### 3. Test AWS Integration

```python
from app.core import initialize_app
from app.core.di import inject

initialize_app()

# Test SNS
sns_service = inject("sns_service")
sns_service.publish_alert(
    alert_type="TEST",
    message="Testing SNS integration",
    severity="INFO"
)

# Test Database
db_service = inject("database_service")
is_healthy = db_service.health_check()
print(f"Database healthy: {is_healthy}")
```

### 4. Check CloudWatch Logs

1. Go to AWS Console → CloudWatch → Log Groups
2. Find your log group: `/aws/streamlit/data-observability`
3. Search logs by correlation ID

## Common Use Cases

### Use Case 1: Add Custom Logging

```python
from app.core.logging import get_logger

logger = get_logger(__name__)

logger.info("Processing data", extra={
    "engine_serial": "000000",
    "record_count": 100
})
```

### Use Case 2: Send SNS Alert

```python
from app.core.di import inject

sns_service = inject("sns_service")

sns_service.publish_alert(
    alert_type="DATA_QUALITY",
    message=f"Low quality score: {score}",
    severity="WARNING",
    engine_serial=engine_serial,
    quality_score=score
)
```

### Use Case 3: Query Database

```python
from app.core.database import get_database_service

db_service = get_database_service()

with db_service.get_session() as session:
    results = session.execute("SELECT * FROM events LIMIT 10")
    for row in results:
        print(row)
```

### Use Case 4: Switch Data Source

```bash
# Edit .env
ENABLE_DUMMY_DATA=False  # Change from True to False

# Restart application
streamlit run Home.py
```

No code changes needed!

## Troubleshooting

### Problem: ModuleNotFoundError

**Solution:**
```bash
pip install -r requirements.txt
```

### Problem: No logs appearing

**Solution:**
Check that logs directory exists and is writable:
```bash
mkdir -p logs
ls -la logs/
```

### Problem: AWS CloudWatch not working

**Solution:**
1. Check AWS credentials: `aws sts get-caller-identity`
2. Verify IAM permissions:
   - `logs:CreateLogGroup`
   - `logs:CreateLogStream`
   - `logs:PutLogEvents`
3. Check `.env` configuration:
   ```bash
   ENABLE_AWS_LOGGING=True
   AWS_LOG_GROUP=/aws/streamlit/data-observability
   ```

### Problem: Database connection error

**Solution:**
1. Test DATABASE_URL format:
   - SQLite: `sqlite:///./data_observability.db`
   - PostgreSQL: `postgresql://user:pass@host:5432/db`
2. For PostgreSQL, test connectivity:
   ```bash
   psql postgresql://user:pass@host:5432/db
   ```

### Problem: Correlation ID not appearing

**Solution:**
Ensure infrastructure is initialized:
```python
from app.core import initialize_app
initialize_app()
```

## Next Steps

1. **Read Architecture:** See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed documentation
2. **Customize Configuration:** Edit [.env](.env) for your environment
3. **Add Your Services:** Create new services in [app/services/](app/services/)
4. **Deploy to AWS:** Follow production configuration above

## Support

- **Documentation:** [README.md](README.md) and [ARCHITECTURE.md](ARCHITECTURE.md)
- **Logs:** Check `logs/app.log` for JSON-formatted logs
- **Correlation IDs:** Use to trace requests end-to-end

## Key Files

| File | Purpose |
|------|---------|
| [Home.py](Home.py) | Application entry point |
| [.env](.env) | Configuration (create from .env.example) |
| [app/core/__init__.py](app/core/__init__.py) | Infrastructure initialization |
| [app/services/data_service.py](app/services/data_service.py) | Data abstraction layer |
| [data/dummy_events.json](data/dummy_events.json) | Sample data |

## Configuration Cheat Sheet

```bash
# Local Development (Default)
ENABLE_DUMMY_DATA=True
ENABLE_AWS_LOGGING=False
DATABASE_URL=sqlite:///./data_observability.db

# AWS Production
ENABLE_DUMMY_DATA=False
ENABLE_AWS_LOGGING=True
DATABASE_URL=postgresql://user:pass@rds-host:5432/db
AWS_SNS_TOPIC_ARN=arn:aws:sns:region:account:topic
```

Start with local development, then gradually enable AWS features as needed!
