# Engine Data Observability - Production-Ready Application

A modular, production-ready Streamlit application for engine data monitoring with comprehensive logging, AWS integration, and database support.

## Features

✅ **Production-Ready Infrastructure:**
- Simple, debug-friendly JSON-like logging
- AWS CloudWatch logging integration
- Local text-based logs
- Global exception handling with correlation IDs
- Activity logging for every operation

✅ **Lightweight Dependency Injection:**
- Easy to implement
- Minimal changes to existing code
- Singleton and factory patterns

✅ **AWS Integrations:**
- SNS notifications with structured alerts
- Boto3 factory for service management
- Generic, reusable AWS code
- Full activity logging

✅ **Database Abstraction:**
- SQLAlchemy service layer
- Support for SQLite (local) and PostgreSQL (AWS)
- Easy switching between data sources
- Connection pooling and health checks

✅ **Flexible Data Source:**
- Start with JSON dummy data
- Switch to PostgreSQL with one config change
- No code changes required

✅ **Authentication Scaffolding:**
- Feature flag controlled (disabled by default)
- Easy to enable when needed

## Quick Start

### 1. Installation

```bash
# Clone repository
cd sql-python-modular

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your configuration
# For local development, defaults work fine
```

### 3. Run Application

```bash
streamlit run Home.py
```

The application will:
- Initialize logging and exception handling
- Generate a correlation ID for tracking
- Start with dummy JSON data (default)
- Log to console and `logs/app.log`

## Configuration

### Local Development (Default)

```bash
# .env
APP_ENV=local
DEBUG=False
ENABLE_LOCAL_LOGGING=True
ENABLE_AWS_LOGGING=False
ENABLE_DUMMY_DATA=True
DATABASE_URL=sqlite:///./data_observability.db
```

### AWS Production

```bash
# .env
APP_ENV=aws
DEBUG=False
ENABLE_LOCAL_LOGGING=True
ENABLE_AWS_LOGGING=True
ENABLE_DUMMY_DATA=False
USE_AWS_POSTGRES=True
DATABASE_URL=postgresql://user:pass@your-rds.amazonaws.com:5432/dbname
AWS_SNS_TOPIC_ARN=arn:aws:sns:us-east-1:123456789012:alerts
AWS_LOG_GROUP=/aws/streamlit/data-observability
```

## Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed architecture documentation.

### Key Components

- **[app/core/logging.py](app/core/logging.py)**: Centralized logging with CloudWatch support
- **[app/core/exceptions.py](app/core/exceptions.py)**: Global exception handling
- **[app/core/context.py](app/core/context.py)**: Correlation ID management
- **[app/core/di.py](app/core/di.py)**: Lightweight dependency injection
- **[app/core/aws.py](app/core/aws.py)**: AWS service layer (SNS, boto3)
- **[app/core/database.py](app/core/database.py)**: Database service layer
- **[app/services/data_service.py](app/services/data_service.py)**: Data abstraction layer

### Project Structure

```
sql-python-modular/
├── app/
│   ├── core/              # Core infrastructure
│   ├── services/          # Business logic services
│   ├── components/        # UI components
│   └── builders/          # Chart builders
├── data/
│   └── dummy_events.json  # Sample data
├── logs/                  # Log files (auto-created)
├── Home.py               # Application entry point
├── .env.example          # Configuration template
└── ARCHITECTURE.md       # Detailed documentation
```

## Switching from JSON to PostgreSQL

### Step 1: Update Configuration

```bash
# .env
ENABLE_DUMMY_DATA=False
DATABASE_URL=postgresql://username:password@host:5432/database
```

### Step 2: Create Database Schema (One-time)

```python
from app.core.database import get_database_service

db_service = get_database_service()
db_service.create_tables()
```

### Step 3: Update Data Query (Optional)

Edit [app/services/data_service.py](app/services/data_service.py) line 95 to match your database schema:

```python
def _get_postgres_data(self, ...):
    query = """
        SELECT * FROM your_table_name
        WHERE timestamp >= NOW() - INTERVAL '%s hours'
    """ % hours
    # Adjust columns to match your schema
```

That's it! No other changes needed.

## Logging

### View Logs

**Console:** Logs appear in terminal with human-readable format
```
2026-02-05 10:00:00 | INFO     | app.core | [01HQXXX...] | Application initialized
```

**Local File:** JSON format in `logs/app.log`
```json
{
  "timestamp": "2026-02-05T10:00:00",
  "level": "INFO",
  "message": "Application initialized",
  "correlation_id": "01HQXXX...",
  "environment": "local"
}
```

**AWS CloudWatch:** Same JSON format in configured log group (when enabled)

### Activity Logging

Every significant operation is logged:
- Database queries
- SNS publishes
- Service initialization
- Data retrievals

Example:
```json
{"activity": "database_query", "status": "started", "statement": "SELECT..."}
{"activity": "database_query", "status": "completed", "rows_returned": 150}
```

## AWS Integration

### CloudWatch Logging

1. Set up AWS credentials (IAM role or environment variables)
2. Enable in [.env](.env):
   ```bash
   ENABLE_AWS_LOGGING=True
   AWS_LOG_GROUP=/aws/streamlit/data-observability
   ```
3. Logs automatically sent to CloudWatch with correlation IDs

### SNS Notifications

```python
from app.core.di import inject

sns_service = inject("sns_service")
sns_service.publish_alert(
    alert_type="DATA_QUALITY",
    message="Low data quality detected",
    severity="WARNING",
    engine_serial="000000"
)
```

## Usage Examples

### Get Data with Logging

```python
from app.core.logging import get_logger
from app.services.data_service import DataService

logger = get_logger(__name__)
data_service = DataService()

# Automatically logs the operation
df = data_service.get_events_data(
    engine_serial="000000",
    hours=24
)

logger.info(f"Retrieved {len(df)} events")
```

### Exception Handling

```python
from app.core.exceptions import DatabaseException, log_exception

try:
    result = perform_operation()
except Exception as e:
    log_exception(e, context={"operation": "data_load"})
    # Exception automatically includes correlation ID
```

### Dependency Injection

```python
from app.core.di import inject

# Get service from container
db_service = inject("database_service")
sns_service = inject("sns_service")
data_service = inject("data_service")
```

## Development

### Adding New Services

1. Create service in [app/services/](app/services/)
2. Register in [app/core/__init__.py](app/core/__init__.py)
3. Use dependency injection to access

### Testing

```bash
# Set test environment
export APP_ENV=test
export DATABASE_URL=sqlite:///:memory:

# Run tests
pytest
```

## Monitoring

### Correlation IDs

Every request/session gets a unique correlation ID:
- Appears in all logs
- Tracks requests end-to-end
- Enables debugging across services

### Health Checks

```python
from app.services.data_service import DataService

data_service = DataService()
status = data_service.get_system_status()
# Returns: {"data_source": "json", "environment": "local", ...}
```

## Troubleshooting

### No logs appearing in CloudWatch
- Check AWS credentials
- Verify IAM permissions (logs:CreateLogGroup, logs:PutLogEvents)
- Check `AWS_LOG_GROUP` configuration

### Database connection errors
- Verify `DATABASE_URL` format
- Test connection to PostgreSQL
- Check logs for detailed error with correlation ID

### Import errors
- Ensure virtual environment is activated
- Run `pip install -r requirements.txt`

## Documentation

- **[ARCHITECTURE.md](ARCHITECTURE.md)**: Detailed architecture and design decisions
- **[.env.example](.env.example)**: All configuration options with examples
- **Code Comments**: Comprehensive docstrings in all modules

## Requirements

- Python 3.8+
- Streamlit 1.28+
- SQLAlchemy 2.0+
- boto3 (for AWS integration)
- See [requirements.txt](requirements.txt) for full list

## License

Proprietary - GE Aviation

## Support

For issues:
1. Check logs with correlation ID
2. Review [ARCHITECTURE.md](ARCHITECTURE.md)
3. Search CloudWatch logs (if AWS enabled)
4. Contact development team with correlation ID
