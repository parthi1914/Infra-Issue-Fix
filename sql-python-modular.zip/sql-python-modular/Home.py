from __future__ import annotations

import random
from datetime import datetime

import numpy as np
import streamlit as st

from app.core import initialize_app, get_logger
from app.core.context import set_correlation_id
from app.data_simulation import simulate_events
from app.components.header import render_header
from app.components.sidebar_controls import render_sidebar
from app.components.kpis import render_kpis

from app.components.tabs import (
    overview as tab_overview,
    timeline as tab_timeline,
    flow_network as tab_flow_network,
    latency as tab_latency,
    status_table as tab_status_table,
    freshness as tab_freshness,
    data_elements as tab_data_elements,
    raw_data as tab_raw_data,
)

# ------------------------------------------------------------
# INITIALIZE APPLICATION INFRASTRUCTURE
# ------------------------------------------------------------
# Initialize logging, exception handling, and services
initialize_app()
logger = get_logger(__name__)

# Set correlation ID for this request/session
correlation_id = set_correlation_id()
logger.info("Streamlit session started", extra={"correlation_id": correlation_id})

# ------------------------------------------------------------
# STREAMLIT UI (Home / Shell)
# ------------------------------------------------------------
st.set_page_config(page_title="Engine Data Observability", layout="wide")

render_header()

# Sidebar controls (componentized)
sidebar = render_sidebar()

engine_serial = sidebar["engine_serial"]
tail_number = sidebar["tail_number"]
window_hours = sidebar["window_hours"]
auto_refresh = sidebar["auto_refresh"]
variation = sidebar["variation"]

now = datetime.utcnow()
if auto_refresh:
    # Auto refresh every 30 seconds
    st.experimental_set_query_params(auto="1")
    st.experimental_rerun()

# Simulate data (same as original)
df = simulate_events(engine_serial, tail_number, now, hours=window_hours, variation=variation)

# High-level KPIs (componentized)
render_kpis(df)

# Tabs (same labels/order as original)
tabs = st.tabs(["Overview", "Timeline", "Flow & Network", "Latency", "Status Table", "Freshness", "Data Elements", "Raw Data"])  # type: ignore

with tabs[0]:
    tab_overview.render(df, now, window_hours, engine_serial, tail_number)

with tabs[1]:
    tab_timeline.render(df, now, window_hours, engine_serial, tail_number)

with tabs[2]:
    tab_flow_network.render(df, now, window_hours, engine_serial, tail_number)

with tabs[3]:
    tab_latency.render(df, now, window_hours, engine_serial, tail_number)

with tabs[4]:
    tab_status_table.render(df, now, window_hours, engine_serial, tail_number)

with tabs[5]:
    tab_freshness.render(df, now, window_hours, engine_serial, tail_number)

with tabs[6]:
    tab_data_elements.render(df, now, window_hours, engine_serial, tail_number)

with tabs[7]:
    tab_raw_data.render(df, now, window_hours, engine_serial, tail_number)
