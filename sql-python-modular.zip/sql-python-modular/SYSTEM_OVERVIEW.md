# System Overview - Visual Architecture

## 🏗️ High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Home.py (Entry Point)                     │
│                    - Streamlit UI Application                    │
│                    - Initializes Infrastructure                  │
└────────────────────┬────────────────────────────────────────────┘
                     │
                     │ calls initialize_app()
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│              app/core/__init__.py (Initialization)               │
│  - Setup logging (console + file + CloudWatch)                  │
│  - Setup exception handling                                      │
│  - Generate correlation ID                                       │
│  - Register services in DI container                             │
└─────┬───────────────────────┬───────────────────┬───────────────┘
      │                       │                   │
      │                       │                   │
      ▼                       ▼                   ▼
┌──────────────┐    ┌──────────────────┐   ┌─────────────────┐
│  Logging     │    │   Exception      │   │  Dependency     │
│  System      │    │   Handling       │   │  Injection      │
│              │    │                  │   │  Container      │
│ - Console    │    │ - Correlation ID │   │                 │
│ - File       │    │ - Error codes    │   │ - Services      │
│ - CloudWatch │    │ - Auto logging   │   │ - Singletons    │
└──────────────┘    └──────────────────┘   └─────────────────┘
```

## 🔄 Request Flow with Logging

```
User Request
    │
    ├─► Generate Correlation ID (e.g., "01HQXXX...")
    │
    ├─► Log: "Request started" [correlation_id]
    │
    ▼
Data Service
    │
    ├─► Check Config: ENABLE_DUMMY_DATA?
    │
    ├─► Log: "Activity: get_events_data started" [correlation_id]
    │
    ▼
┌───────────────┐
│   If TRUE     │  Use JSON Data
│               │
│  Read JSON    │──► Log: "Loaded 15 records from JSON"
│  File         │
└───────────────┘
        │
        ▼
┌───────────────┐
│   If FALSE    │  Use PostgreSQL
│               │
│  Query        │──► Log: "Database query started" [correlation_id]
│  Database     │──► Log: "Query completed, 150 rows" [correlation_id]
└───────────────┘
        │
        ▼
Return DataFrame
    │
    ├─► Log: "Activity: get_events_data completed" [correlation_id]
    │
    ▼
Response to User

All logs include correlation_id for end-to-end tracing
```

## 📊 Data Flow Diagram

```
┌──────────────────┐
│ Configuration    │
│ (.env file)      │
└────────┬─────────┘
         │
         │ Controls behavior
         ▼
┌──────────────────────────────────────────────┐
│         Data Service (Abstraction)            │
│  - Checks ENABLE_DUMMY_DATA flag             │
│  - Routes to appropriate data source         │
│  - Logs all activities                       │
└────────┬────────────────────────┬────────────┘
         │                        │
         │ If TRUE                │ If FALSE
         ▼                        ▼
┌──────────────────┐    ┌──────────────────┐
│  JSON Provider   │    │ PostgreSQL       │
│                  │    │ Provider         │
│ - Reads file     │    │ - Queries DB     │
│ - Filters data   │    │ - Uses session   │
│ - Returns DF     │    │ - Returns DF     │
└──────────────────┘    └──────────────────┘
         │                        │
         └────────┬───────────────┘
                  │
                  ▼
         ┌────────────────┐
         │   DataFrame    │
         │  (Pandas)      │
         └────────────────┘
                  │
                  ▼
         ┌────────────────┐
         │   Streamlit    │
         │   UI Display   │
         └────────────────┘
```

## 🔧 Service Dependencies

```
┌─────────────────────────────────────────────────────┐
│          Dependency Injection Container              │
│                                                      │
│  ┌────────────────┐  ┌────────────────┐            │
│  │ Boto3Factory   │  │ SNSService     │            │
│  │                │  │                │            │
│  │ - S3 client    │  │ - Alerts       │            │
│  │ - SNS client   │  │ - Notifications│            │
│  │ - Logs client  │  │                │            │
│  └────────────────┘  └────────────────┘            │
│                                                      │
│  ┌────────────────┐  ┌────────────────┐            │
│  │ DatabaseService│  │ DataService    │            │
│  │                │  │                │            │
│  │ - SQLAlchemy   │  │ - JSON/PG      │            │
│  │ - Sessions     │  │ - Abstraction  │            │
│  │ - Health check │  │ - Routing      │            │
│  └────────────────┘  └────────────────┘            │
│                                                      │
│  All services can inject other services             │
└─────────────────────────────────────────────────────┘
```

## 📝 Logging Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Application Code                       │
│  logger.info("Event", extra={"key": "value"})            │
└───────────────────────┬──────────────────────────────────┘
                        │
                        │ Add correlation_id
                        ▼
┌──────────────────────────────────────────────────────────┐
│            Custom JSON Formatter                          │
│  {                                                        │
│    "timestamp": "2026-02-05T10:00:00",                   │
│    "level": "INFO",                                       │
│    "message": "Event",                                    │
│    "correlation_id": "01HQXXX...",                       │
│    "module": "data_service",                             │
│    "key": "value"                                         │
│  }                                                        │
└────┬──────────────────┬──────────────────┬───────────────┘
     │                  │                  │
     ▼                  ▼                  ▼
┌──────────┐   ┌─────────────┐   ┌──────────────────┐
│ Console  │   │ Local File  │   │  AWS CloudWatch  │
│ Handler  │   │ Handler     │   │  Handler         │
│          │   │             │   │                  │
│ Human    │   │ JSON        │   │ JSON             │
│ Readable │   │ Format      │   │ Format           │
└──────────┘   └─────────────┘   └──────────────────┘
     │               │                    │
     ▼               ▼                    ▼
  Terminal      logs/app.log      CloudWatch Logs
                                  (Searchable)
```

## 🚨 Exception Handling Flow

```
Application Code
    │
    │ Exception occurs
    ▼
try/except block
    │
    ├─► catch Exception
    │
    ├─► Generate correlation_id (if not exists)
    │
    ├─► Create AppException with:
    │   - error_code
    │   - message
    │   - details
    │   - correlation_id
    │
    ├─► Log exception with full context:
    │   {
    │     "level": "ERROR",
    │     "message": "Database query failed",
    │     "correlation_id": "01HQXXX...",
    │     "exception_type": "DatabaseException",
    │     "error_code": "DATABASE_ERROR",
    │     "stack_trace": "..."
    │   }
    │
    ├─► Send to all log handlers:
    │   - Console (visible immediately)
    │   - File (persisted locally)
    │   - CloudWatch (searchable)
    │
    └─► Optional: Send SNS alert for critical errors

User sees error with correlation_id
Developer searches logs using correlation_id
Full context available for debugging
```

## 🔀 Configuration-Based Behavior

```
┌─────────────────────────────────────────────────────┐
│              .env Configuration File                 │
│                                                      │
│  ENABLE_DUMMY_DATA = True/False                     │
│  ENABLE_AWS_LOGGING = True/False                    │
│  ENABLE_LOCAL_LOGGING = True/False                  │
│  DATABASE_URL = sqlite:// or postgresql://          │
│  AWS_SNS_TOPIC_ARN = arn:... or empty               │
└───────────────────┬─────────────────────────────────┘
                    │
                    │ Read at startup
                    ▼
┌──────────────────────────────────────────────────────┐
│          Settings Class (app/core/config.py)         │
│  - Parses environment variables                      │
│  - Provides defaults                                 │
│  - Validates configuration                           │
└────────┬─────────────────────────────────────────────┘
         │
         │ Used by all services
         ▼
┌───────────────────────────────────────────────────────┐
│           Behavior Changes Automatically              │
│                                                       │
│  Data Source: JSON ←→ PostgreSQL                     │
│  Logging: File only ←→ File + CloudWatch             │
│  Alerts: Disabled ←→ SNS enabled                     │
│  Database: SQLite ←→ PostgreSQL                      │
│                                                       │
│  NO CODE CHANGES REQUIRED                            │
└───────────────────────────────────────────────────────┘
```

## 🎯 Key Design Patterns

### 1. Dependency Injection

```
Service Registration (Startup)
    │
    ├─► register_singleton("service_name", factory)
    │
    └─► Services stored in container

Service Usage (Runtime)
    │
    ├─► service = inject("service_name")
    │
    └─► Factory called lazily on first access
```

### 2. Context Manager Pattern

```
with db_service.get_session() as session:
    # Session opened
    result = session.query(...)
    # Automatic commit on success
# Session closed automatically
# Rollback on exception
```

### 3. Factory Pattern

```
Boto3Factory
    │
    ├─► get_client("s3") → S3 client (cached)
    ├─► get_client("sns") → SNS client (cached)
    └─► get_resource("dynamodb") → DynamoDB resource (cached)

No manual client creation
Automatic caching
Consistent configuration
```

## 📈 Monitoring & Observability

```
┌─────────────────────────────────────────────────────┐
│                  Correlation ID                      │
│              "01HQXXX..." (ULID)                    │
│                                                      │
│  Generated: Start of request/session                │
│  Stored: Thread-local context variable              │
│  Propagated: All logs, exceptions, activities       │
│  Used for: End-to-end tracing                       │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Included in all logs
                     ▼
┌──────────────────────────────────────────────────────┐
│              Activity Logging                         │
│                                                       │
│  Each significant operation logs:                    │
│  - Activity name (e.g., "database_query")           │
│  - Status (started, completed, failed)              │
│  - Context (parameters, results, errors)            │
│  - Correlation ID                                    │
│  - Timestamp                                         │
│                                                       │
│  Example sequence:                                   │
│  1. "database_query started" [01HQXXX...]           │
│  2. "database_query completed" [01HQXXX...]         │
│     rows_returned=150, duration_ms=42                │
└──────────────────────────────────────────────────────┘
                     │
                     │ Searchable by correlation_id
                     ▼
┌──────────────────────────────────────────────────────┐
│        CloudWatch Logs (Production)                  │
│                                                       │
│  Search query:                                       │
│  { $.correlation_id = "01HQXXX..." }                │
│                                                       │
│  Result: All logs for that request                   │
│  - Request start                                     │
│  - Database queries                                  │
│  - SNS publishes                                     │
│  - Response completion                               │
│  - Any errors                                        │
└──────────────────────────────────────────────────────┘
```

## 🚀 Deployment Scenarios

### Local Development

```
Developer Machine
    │
    ├─► .env: ENABLE_DUMMY_DATA=True
    ├─► Data: data/dummy_events.json
    ├─► Logs: logs/app.log
    ├─► Database: SQLite (optional)
    └─► AWS: Not required

Fast iteration, no setup needed
```

### AWS Production

```
EC2/ECS/Lambda Instance
    │
    ├─► .env: ENABLE_DUMMY_DATA=False
    ├─► Data: PostgreSQL RDS
    ├─► Logs: CloudWatch Logs
    ├─► Alerts: SNS
    ├─► Auth: IAM Role
    └─► Monitoring: CloudWatch Metrics

Full production features enabled
```

## 🔍 Debugging Workflow

```
1. User reports issue
   │
   └─► Note correlation_id from error message

2. Developer searches logs
   │
   ├─► Local: grep "01HQXXX..." logs/app.log
   │
   └─► AWS: CloudWatch search by correlation_id

3. Find all related logs
   │
   ├─► Request start
   ├─► All activities
   ├─► Database queries
   ├─► AWS operations
   └─► Error details

4. Reproduce issue
   │
   └─► All context available in logs

5. Fix and verify
   │
   └─► New correlation_id for test
```

## 📦 Component Summary

| Component | Purpose | Key Files |
|-----------|---------|-----------|
| **Logging** | Structured logging with CloudWatch | [app/core/logging.py](app/core/logging.py) |
| **Exceptions** | Error handling with correlation IDs | [app/core/exceptions.py](app/core/exceptions.py) |
| **Context** | Correlation ID management | [app/core/context.py](app/core/context.py) |
| **DI Container** | Dependency injection | [app/core/di.py](app/core/di.py) |
| **AWS Services** | Boto3, SNS, CloudWatch | [app/core/aws.py](app/core/aws.py) |
| **Database** | SQLAlchemy abstraction | [app/core/database.py](app/core/database.py) |
| **Data Service** | JSON/PostgreSQL switching | [app/services/data_service.py](app/services/data_service.py) |
| **Config** | Environment variables | [app/core/config.py](app/core/config.py) |

## 🎓 Learning Path

### Beginner
1. Read [QUICKSTART.md](QUICKSTART.md)
2. Run locally with defaults
3. View logs in console
4. Try changing configuration

### Intermediate
1. Read [README.md](README.md)
2. Switch to PostgreSQL locally
3. Add custom logging
4. Create new service

### Advanced
1. Read [ARCHITECTURE.md](ARCHITECTURE.md)
2. Enable AWS CloudWatch
3. Configure SNS alerts
4. Deploy to production

## 💡 Key Takeaways

1. **Everything is Logged**
   - Every operation has start/complete/failed logs
   - Correlation ID in every log entry
   - Easy to trace requests end-to-end

2. **Easy Configuration**
   - Single .env file controls everything
   - No code changes to switch environments
   - Sensible defaults for local development

3. **Simple Patterns**
   - Dependency injection without complexity
   - Service layer abstractions
   - Consistent error handling

4. **Production Ready**
   - AWS integration included
   - Monitoring and alerting ready
   - Scalable architecture

5. **Maintainable**
   - Clear separation of concerns
   - Comprehensive documentation
   - No over-engineering

---

**This architecture supports your team from local development to AWS production with minimal configuration changes and maximum observability.**
