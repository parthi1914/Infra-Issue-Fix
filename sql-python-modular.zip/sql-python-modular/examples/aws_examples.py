"""
Practical examples of using AWS CloudWatch Logging and SNS.
"""
from app.core import initialize_app, get_logger
from app.core.di import inject
from app.core.context import get_correlation_id
from datetime import datetime

# Initialize infrastructure
initialize_app()
logger = get_logger(__name__)

print("=" * 70)
print(" AWS SERVICES - PRACTICAL EXAMPLES".center(70))
print("=" * 70)

# =============================================================================
# Example 1: Basic Logging (goes to Console + File + CloudWatch)
# =============================================================================

print("\n📝 Example 1: Basic Logging")
print("-" * 70)

logger.info("Application started")
logger.info("User logged in", extra={"user_id": "12345", "username": "john.doe"})
logger.warning("API rate limit approaching", extra={"current_rate": 90, "limit": 100})
logger.error("Failed to connect to database", extra={"retry_count": 3, "timeout": 30})

print("✅ Logs sent to:")
print("   • Console (see above)")
print("   • logs/app.log (check file)")
print("   • CloudWatch (if enabled)")

# =============================================================================
# Example 2: Correlation ID Tracking
# =============================================================================

print("\n🔗 Example 2: Correlation ID Tracking")
print("-" * 70)

# Get correlation ID for this request/session
correlation_id = get_correlation_id()
print(f"Correlation ID: {correlation_id}")

# All subsequent logs will include this ID
logger.info("Processing request", extra={"request_id": "req_001"})
logger.info("Fetching data from database")
logger.info("Processing data", extra={"record_count": 100})
logger.info("Request completed successfully")

print("\n✅ All logs above include correlation_id")
print("   Search in CloudWatch:")
print(f'   {{ $.correlation_id = "{correlation_id}" }}')

# =============================================================================
# Example 3: Activity Logging
# =============================================================================

print("\n📊 Example 3: Activity Logging")
print("-" * 70)

from app.core.logging import ActivityLogger

activity_logger = ActivityLogger(logger)

# Log start
activity_logger.log_activity(
    activity="data_processing",
    status="started",
    engine_serial="000000",
    record_count=150
)

# Simulate processing
import time
time.sleep(0.5)

# Log completion
activity_logger.log_activity(
    activity="data_processing",
    status="completed",
    engine_serial="000000",
    records_processed=150,
    duration_ms=500
)

print("✅ Activity logged with start/complete status")

# =============================================================================
# Example 4: SNS Alert - Simple Message
# =============================================================================

print("\n📧 Example 4: SNS Alert - Simple Message")
print("-" * 70)

try:
    sns_service = inject("sns_service")

    message_id = sns_service.publish_message(
        message="Data processing completed successfully",
        subject="Success Notification"
    )

    if message_id:
        print(f"✅ Message sent! Message ID: {message_id}")
        print("   Check your email/SMS for notification")
    else:
        print("⚠️  SNS not configured (check .env AWS_SNS_TOPIC_ARN)")

except Exception as e:
    print(f"❌ Failed to send SNS message: {e}")

# =============================================================================
# Example 5: SNS Alert - Structured Alert
# =============================================================================

print("\n🚨 Example 5: SNS Alert - Structured Alert")
print("-" * 70)

try:
    sns_service = inject("sns_service")

    message_id = sns_service.publish_alert(
        alert_type="DATA_QUALITY",
        message="Data quality score dropped below threshold",
        severity="WARNING",
        engine_serial="000000",
        current_score=0.82,
        threshold=0.85,
        correlation_id=correlation_id
    )

    if message_id:
        print(f"✅ Alert sent! Message ID: {message_id}")
        print("   Recipients receive:")
        print("      Subject: [WARNING] DATA_QUALITY")
        print("      Message: Data quality score dropped below threshold")
        print("      Attributes: engine_serial, current_score, threshold")
    else:
        print("⚠️  SNS not configured")

except Exception as e:
    print(f"❌ Failed to send alert: {e}")

# =============================================================================
# Example 6: Error Handling with AWS Logging and SNS
# =============================================================================

print("\n💥 Example 6: Error Handling with Logging & Alerts")
print("-" * 70)

def process_data_with_error_handling():
    """Example function with comprehensive error handling."""
    try:
        logger.info("Starting data processing")

        # Simulate error
        raise ValueError("Invalid data format")

    except Exception as e:
        # Log error with full context
        logger.error(
            "Data processing failed",
            exc_info=True,  # Include stack trace
            extra={
                "error_type": type(e).__name__,
                "error_message": str(e),
                "correlation_id": correlation_id
            }
        )

        # Send critical alert via SNS
        try:
            sns_service = inject("sns_service")
            sns_service.publish_alert(
                alert_type="ERROR",
                message=f"Data processing failed: {e}",
                severity="CRITICAL",
                error_type=type(e).__name__,
                correlation_id=correlation_id,
                timestamp=datetime.now().isoformat()
            )
            print("   📧 Alert sent to operations team")
        except Exception:
            pass  # SNS not configured

        return None

result = process_data_with_error_handling()
print("✅ Error logged and alert sent")
print("   • Error logged to CloudWatch (searchable)")
print("   • Alert sent via SNS (if configured)")
print(f"   • Correlation ID: {correlation_id}")

# =============================================================================
# Example 7: Integration with Data Service
# =============================================================================

print("\n🔄 Example 7: Integration with Data Service")
print("-" * 70)

try:
    data_service = inject("data_service")

    logger.info("Fetching events data", extra={
        "engine_serial": "000000",
        "hours": 24
    })

    # This automatically logs all database activities
    df = data_service.get_events_data(
        engine_serial="000000",
        hours=24
    )

    logger.info(f"Retrieved {len(df)} events", extra={
        "record_count": len(df),
        "engine_serial": "000000"
    })

    # Check data quality
    if not df.empty:
        avg_quality = df.get('data_quality_score', pd.Series([1.0])).mean()

        if avg_quality < 0.85:
            logger.warning("Low data quality detected", extra={
                "avg_quality": avg_quality,
                "threshold": 0.85
            })

            # Send alert
            sns_service = inject("sns_service")
            sns_service.publish_alert(
                alert_type="DATA_QUALITY",
                message=f"Data quality below threshold: {avg_quality:.3f}",
                severity="WARNING",
                engine_serial="000000",
                avg_quality=avg_quality
            )
            print(f"   ⚠️  Low quality alert sent: {avg_quality:.3f}")
        else:
            print(f"   ✅ Data quality good: {avg_quality:.3f}")

except Exception as e:
    logger.error(f"Data service error: {e}", exc_info=True)
    print(f"   ❌ Error: {e}")

# =============================================================================
# Example 8: Custom Log Fields (for filtering)
# =============================================================================

print("\n🏷️  Example 8: Custom Log Fields")
print("-" * 70)

# Add custom fields that can be searched in CloudWatch
logger.info("Engine maintenance required", extra={
    "event_type": "maintenance",
    "priority": "HIGH",
    "engine_serial": "000000",
    "maintenance_type": "SCHEDULED",
    "due_date": "2026-02-15",
    "estimated_downtime_hours": 4
})

print("✅ Log sent with custom fields")
print("   Search in CloudWatch:")
print('   { $.event_type = "maintenance" && $.priority = "HIGH" }')

# =============================================================================
# Example 9: Batch Operations Logging
# =============================================================================

print("\n📦 Example 9: Batch Operations Logging")
print("-" * 70)

engines = ["000000", "038429", "041223"]
logger.info(f"Starting batch processing", extra={
    "batch_id": "batch_001",
    "engine_count": len(engines),
    "engines": engines
})

for i, engine in enumerate(engines, 1):
    logger.info(f"Processing engine {i}/{len(engines)}", extra={
        "batch_id": "batch_001",
        "engine_serial": engine,
        "progress": f"{i}/{len(engines)}"
    })
    time.sleep(0.1)  # Simulate processing

logger.info("Batch processing completed", extra={
    "batch_id": "batch_001",
    "engines_processed": len(engines),
    "status": "SUCCESS"
})

print("✅ Batch operation logged")
print('   Search: { $.batch_id = "batch_001" }')

# =============================================================================
# Example 10: Health Check Monitoring
# =============================================================================

print("\n🏥 Example 10: Health Check with Alerts")
print("-" * 70)

def health_check_with_alerts():
    """Health check that sends alerts on failure."""
    services = {
        "database": False,
        "api": False,
        "cache": False
    }

    # Check database
    try:
        db_service = inject("database_service")
        services["database"] = db_service.health_check()
    except Exception as e:
        logger.error(f"Database health check failed: {e}")

    # Log health status
    logger.info("Health check completed", extra={
        "services": services,
        "healthy": all(services.values())
    })

    # Send alert if any service is down
    if not all(services.values()):
        unhealthy = [name for name, healthy in services.items() if not healthy]

        logger.error("Services unhealthy", extra={
            "unhealthy_services": unhealthy
        })

        try:
            sns_service = inject("sns_service")
            sns_service.publish_alert(
                alert_type="HEALTH_CHECK",
                message=f"Services unhealthy: {', '.join(unhealthy)}",
                severity="CRITICAL",
                unhealthy_services=unhealthy,
                services_status=services
            )
            print(f"   🚨 Alert sent: {unhealthy}")
        except Exception:
            pass

        return False

    print("   ✅ All services healthy")
    return True

health_check_with_alerts()

# =============================================================================
# Summary
# =============================================================================

print("\n" + "=" * 70)
print(" SUMMARY".center(70))
print("=" * 70)

print("\n✅ Examples Demonstrated:")
print("   1. Basic logging (INFO, WARNING, ERROR)")
print("   2. Correlation ID tracking")
print("   3. Activity logging (start/complete/failed)")
print("   4. SNS simple messages")
print("   5. SNS structured alerts")
print("   6. Error handling with logging + alerts")
print("   7. Integration with data service")
print("   8. Custom log fields")
print("   9. Batch operations logging")
print("   10. Health check monitoring")

print("\n📍 Where to Find Logs:")
print("   • Console: See above output")
print("   • Local: logs/app.log")
print("   • CloudWatch: AWS Console (if enabled)")

print("\n🔍 Search Logs by Correlation ID:")
print(f"   aws logs filter-log-events \\")
print(f'     --log-group-name "/aws/streamlit/data-observability" \\')
print(f'     --filter-pattern \'{{ $.correlation_id = "{correlation_id}" }}\'')

print("\n📚 Documentation:")
print("   • docs/AWS_SERVICES_GUIDE.md")
print("   • docs/QUICK_REFERENCE.md")

print("\n" + "=" * 70)
