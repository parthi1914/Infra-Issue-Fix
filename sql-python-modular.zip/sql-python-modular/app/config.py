from __future__ import annotations

# ------------------------------------------------------------
# CONFIG / CONSTANTS
# (Moved from original sql-python.py without logic changes)
# ------------------------------------------------------------

SYSTEM_FLOW = [
    "1FA",  # Product Development Configuration ingest
    "IFS",  # Enterprise asset reference
    "FDM",  # Flight Data Management staging
    "1FDI", # Final data integration / augmentation
    "PHM",  # Prognostic Health Management
    "SOAR", # Operational analytics / situational awareness
    "RDF",  # Reporting & decoding flow
    "FMX"   # Customer-facing experience endpoint
]
ASSET_SYSTEMS = {"1FA", "IFS", "FDM", "1FDI"}
FLIGHT_SYSTEMS = {"PHM", "SOAR", "RDF"}
ENDPOINT_SYSTEMS = {"FMX"}

# Sample identifiers (could be replaced with real query results)
SAMPLE_ENGINE_SERIALS = [
    "000000", "038429", "041223", "052781", "060009", "073145", "089771", "101556", "115902"
]
SAMPLE_TAIL_NUMBERS = [
    "N-DEMO", "B-1316", "LN-FGJ", "N872SK", "G-LOJO", "F-HXM", "D-ABCD", "N7-MXV", "N932SK"
]

# Aircraft-to-Engine mapping (each tail has 2 engines)
TAIL_TO_ENGINES = {
    "N-DEMO": ["000000", "038429"],
    "B-1316": ["041223", "052781"],
    "LN-FGJ": ["060009", "073145"],
    "N872SK": ["089771", "101556"],
    "G-LOJO": ["115902", "038429"],
    "F-HXM": ["041223", "060009"],
    "D-ABCD": ["073145", "089771"],
    "N7-MXV": ["101556", "115902"],
    "N932SK": ["000000", "052781"]
}

# Reverse mapping: Engine to Tails
ENGINE_TO_TAILS = {}
for tail, engines in TAIL_TO_ENGINES.items():
    for esn in engines:
        if esn not in ENGINE_TO_TAILS:
            ENGINE_TO_TAILS[esn] = []
        ENGINE_TO_TAILS[esn].append(tail)

STATUSES = ["Pending", "Processing", "Complete", "Delayed", "Error", "NotStarted"]
STATUS_COLOR_MAP = {
    "Complete": "#2ca02c",
    "Processing": "#1f77b4",
    "Pending": "#1f77b4",
    "Delayed": "#1f77b4",
    "Error": "#d62728",
    "NotStarted": "#d9d9d9"
}
