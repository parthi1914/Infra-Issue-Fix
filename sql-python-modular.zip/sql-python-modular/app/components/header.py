from __future__ import annotations
import streamlit as st

def render_header() -> None:
    st.markdown("""
<div style='text-align:center;padding:8px 0 4px;'>
    <h1 style='margin:0;font-size:38px;'> Asset & Diagnostic Data Observability</h1>
    <p style='margin:4px 0 0;color:#555;font-size:16px;'>End-to-end lineage: Asset ( ) → Flight ( ) → Customer ( )</p>
</div>
""", unsafe_allow_html=True)
