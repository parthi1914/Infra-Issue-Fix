from __future__ import annotations
import streamlit as st
import pandas as pd
from ..config import SYSTEM_FLOW

def render_kpis(df: pd.DataFrame) -> None:
    col_a, col_b, col_c, col_d = st.columns(4)
    col_a.metric("Total Systems", len(SYSTEM_FLOW))
    col_b.metric("Completed Systems", int((df.status == "Complete").sum()))
    col_c.metric("Avg Latency (s)", f"{df.latency_sec.mean():.2f}")
    col_d.metric("Total Records (current hop)", f"{int(df.records.iloc[-1]):,}")
