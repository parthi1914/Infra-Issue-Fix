from __future__ import annotations

import streamlit as st
import pandas as pd
from datetime import datetime

from ...data_simulation import DATA_ELEMENTS, simulate_data_elements_status, simulate_data_elements_with_values
from ...builders.data_elements_ui import build_data_elements_heatmap

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader(" Data Elements Tracking (19 per system)")
    st.caption("Matrix of expected elements across systems — Hover over cells to see actual values and failure reasons")

    # Summary KPIs
    mat = simulate_data_elements_status(df)
    total = mat.size
    passed = int((mat == "Pass").sum().sum())
    failed = total - passed
    pass_rate = (passed / total * 100) if total > 0 else 0

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Elements Tracked", len(DATA_ELEMENTS))
    col2.metric("Pass Count", passed, delta=f"{pass_rate:.1f}%")
    col3.metric("Fail Count", failed, delta=f"-{100-pass_rate:.1f}%", delta_color="inverse")
    col4.metric("Pass Rate", f"{pass_rate:.1f}%")

    # Heatmap with values and tooltips
    elements_html = build_data_elements_heatmap(df, engine_serial, tail_number)
    st.markdown(elements_html, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Failed Elements Details")

    # Show detailed failure table
    data = simulate_data_elements_with_values(df, engine_serial, tail_number)
    failures = []
    for system, elements in data.items():
        for element, details in elements.items():
            if details["status"] == "Fail":
                failures.append({
                    "System": system,
                    "Property": element,
                    "Expected": details["expected"],
                    "Actual": details["value"],
                    "Reason": details["reason"]
                })

    if failures:
        fail_df = pd.DataFrame(failures)
        st.dataframe(fail_df, use_container_width=True, hide_index=True)
    else:
        st.success(" All data elements passed validation!")
