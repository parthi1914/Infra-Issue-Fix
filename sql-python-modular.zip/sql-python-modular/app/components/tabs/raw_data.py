from __future__ import annotations

import streamlit as st
import pandas as pd
from datetime import datetime

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader(" Raw Simulated Data")
    st.write(df)
