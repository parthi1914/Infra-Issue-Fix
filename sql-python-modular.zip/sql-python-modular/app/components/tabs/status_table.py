from __future__ import annotations

import streamlit as st
import pandas as pd
from datetime import datetime

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader(" System Status Table")
    display_df = df[["system", "status", "start_time", "end_time", "latency_sec", "records", "data_size_mb"]].copy()
    display_df["start_time"] = display_df["start_time"].dt.strftime("%H:%M:%S")
    display_df["end_time"] = display_df["end_time"].dt.strftime("%H:%M:%S")
    display_df.rename(columns={"latency_sec": "latency_s", "data_size_mb": "size_MB"}, inplace=True)
    st.dataframe(display_df, use_container_width=True)
