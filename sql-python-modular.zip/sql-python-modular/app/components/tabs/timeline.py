from __future__ import annotations

import streamlit as st
import pandas as pd
from datetime import datetime

from ...builders.charts import build_timeline

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader(" Timeline")
    fig_timeline = build_timeline(df)
    st.plotly_chart(fig_timeline, use_container_width=True)
