from __future__ import annotations

import streamlit as st
import pandas as pd
from datetime import datetime

from ...builders.charts import build_sankey, build_network_graph

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader(" Flow & Network")
    col1, col2 = st.columns([2, 1])
    with col1:
        sankey = build_sankey(df)
        st.plotly_chart(sankey, use_container_width=True)
    with col2:
        network_fig = build_network_graph(df)
        st.plotly_chart(network_fig, use_container_width=True)
