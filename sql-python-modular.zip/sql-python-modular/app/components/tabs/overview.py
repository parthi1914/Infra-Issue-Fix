from __future__ import annotations

from datetime import datetime
import streamlit as st
import pandas as pd

from ...builders.helpers import build_status_summary, build_population_pies, build_last_updated_table, fake_root_cause_panel, build_error_notifications
from ...builders.sla import build_sla_dominos_html, build_dominos_style_tracker_html
# from ...core.di import inject  # Uncomment when enabling real data

def render(df: pd.DataFrame, now: datetime, window_hours: float, engine_serial: str, tail_number: str) -> None:
    st.subheader(" Overview Board")

    # ========================================================================
    # REAL DATABASE DATA INTEGRATION (Currently DISABLED)
    # ========================================================================
    # TODO: Uncomment the code below to switch from dummy data to real database
    # When uncommenting:
    # 1. Uncomment the 'from ...core.di import inject' import at the top
    # 2. Uncomment the data_service instantiation and overview_data call below
    # 3. Replace the dummy data assignments with the real data from overview_data
    # 4. Comment out or remove the dummy data builder calls
    # ========================================================================

    # # Get data service from DI container
    # data_service = inject("data_service")
    #
    # # Fetch all Overview metrics from real database using JOIN queries
    # # This includes: status summary (CASE), data population (LEFT JOIN),
    # # SLA timeline (time calculations), error notifications (INNER JOIN)
    # overview_data = data_service.get_overview_data(
    #     engine_serial=engine_serial,
    #     hours=int(window_hours)
    # )
    #
    # # Extract individual metrics from overview_data
    # status_summary = overview_data['status_summary']
    # # data_population_df = overview_data['data_population']
    # # sla_timeline_df = overview_data['sla_timeline']
    # # error_notifications_df = overview_data['error_notifications']
    # # last_updated_df = overview_data['last_updated']

    # ========================================================================
    # DUMMY DATA (Currently ACTIVE)
    # ========================================================================
    # This uses the current dummy data builders
    # Comment out these lines when switching to real database data
    # ========================================================================

    status_summary = build_status_summary(df)
    population_pies = build_population_pies(df)
    last_updated_table = build_last_updated_table(df)
    governance_df = fake_root_cause_panel()
    sla_html_tracker = build_sla_dominos_html(df, now, hours=window_hours)

    card_cols = st.columns(4)
    mapping_to_col = {"Fail": 0, "Pass": 1, "Pending": 2, "Processing": 3}
    for _, r in status_summary.iterrows():
        cat = r["category"]
        idx = mapping_to_col[cat]
        bg = {
            "Fail": "#ffe5e0",
            "Pass": "#e3f9e5",
            "Pending": "#e0efff",
            "Processing": "#e0efff"
        }[cat]
        card_cols[idx].markdown(
            f"<div style='padding:12px;border-radius:8px;background:{bg};'><h4 style='margin:0'>{cat}</h4><p style='font-size:28px;margin:0;font-weight:700'>{int(r['count'])}</p><small>System Status</small></div>",
            unsafe_allow_html=True
        )

    st.markdown("### Data Population by System")
    pie_row = st.columns(len(population_pies))
    for i, fig in enumerate(population_pies):
        pie_row[i].plotly_chart(fig, use_container_width=True)

    st.markdown("### SLA Timeline (Styled)")
    st.markdown(sla_html_tracker, unsafe_allow_html=True)

    # Domino's style progress bar
    st.markdown("### Domino Style Progress")
    dom_html = build_dominos_style_tracker_html(df, datetime.utcnow())
    st.markdown(dom_html, unsafe_allow_html=True)

    # Error notifications section (fixed display, no scrolling)
    error_notif_html = build_error_notifications(df, now)
    if error_notif_html:
        st.markdown("### Error Notifications & Response Team Alerts")
        st.components.v1.html(error_notif_html, height=380, scrolling=False)

    st.markdown("### Last Updated Times")
    st.dataframe(last_updated_table, use_container_width=True)

    st.markdown("### Root Cause & Governance")
    st.dataframe(governance_df, use_container_width=True)
