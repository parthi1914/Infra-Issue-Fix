from __future__ import annotations

import random
import numpy as np
import streamlit as st

from ..config import SAMPLE_ENGINE_SERIALS, SAMPLE_TAIL_NUMBERS, ENGINE_TO_TAILS, TAIL_TO_ENGINES
from ..data_simulation import simulate_events

def render_sidebar() -> dict:
    st.sidebar.header("Filters")
    st.sidebar.subheader("Identifiers")

    # Use session state to track which was changed
    if 'last_esn' not in st.session_state:
        st.session_state.last_esn = SAMPLE_ENGINE_SERIALS[0]
    if 'last_tail' not in st.session_state:
        st.session_state.last_tail = SAMPLE_TAIL_NUMBERS[0]

    # Selection method
    selection_method = st.sidebar.radio("Select by:", ["Engine Serial (ESN)", "Tail Number"], horizontal=True)

    if selection_method == "Engine Serial (ESN)":
        engine_choice = st.sidebar.selectbox("Sample Engine Serial", SAMPLE_ENGINE_SERIALS, index=0)
        # Get corresponding tail numbers for this engine
        available_tails = ENGINE_TO_TAILS.get(engine_choice, [SAMPLE_TAIL_NUMBERS[0]])
        tail_choice = st.sidebar.selectbox("Tail Number (for this ESN)", available_tails, index=0)
    else:  # Tail Number
        tail_choice = st.sidebar.selectbox("Sample Tail Number", SAMPLE_TAIL_NUMBERS, index=0)
        # Get corresponding engines for this tail
        available_esns = TAIL_TO_ENGINES.get(tail_choice, [SAMPLE_ENGINE_SERIALS[0]])
        engine_choice = st.sidebar.selectbox("Engine Serial (on this aircraft)", available_esns, index=0)

    # Scenario variation removed to keep UI simple; default to Normal
    variation = "Normal"
    custom_values = st.sidebar.checkbox("Use custom input instead")
    if custom_values:
        engine_serial = st.sidebar.text_input("Engine Serial", value=engine_choice)
        tail_number = st.sidebar.text_input("Tail Number", value=tail_choice)
    else:
        engine_serial = engine_choice
        tail_number = tail_choice

    window_hours = st.sidebar.slider("Time Window (hours)", 1.0, 6.0, 3.0, 0.5)
    auto_refresh = st.sidebar.checkbox("Auto-refresh (every 30s)")
    seed = st.sidebar.number_input("Simulation Seed", min_value=0, max_value=10_000, value=42, step=1, help="Change to vary synthetic data.")
    random.seed(seed)
    np.random.seed(seed)

    regen = st.sidebar.button(" Regenerate Simulation")
    if regen:
        # Clear cache for new simulation
        simulate_events.clear()

    return {
        "selection_method": selection_method,
        "engine_serial": engine_serial,
        "tail_number": tail_number,
        "window_hours": window_hours,
        "auto_refresh": auto_refresh,
        "seed": seed,
        "variation": variation,
        "regen": regen,
    }
