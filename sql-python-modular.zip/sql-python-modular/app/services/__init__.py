"""Services layer - business logic and external integrations."""
from __future__ import annotations

from app.services.data_service import DataService

__all__ = ["DataService"]
