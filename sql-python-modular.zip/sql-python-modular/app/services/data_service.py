"""
Data service layer - abstracts data source (JSON or PostgreSQL).
Easy to switch between dummy JSON data and AWS PostgreSQL.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from app.core.config import get_settings
from app.core.exceptions import DataNotFoundException, log_exception
from app.core.logging import ActivityLogger, get_logger


logger = get_logger(__name__)
activity_logger = ActivityLogger(logger)


class DataService:
    """
    Unified data service supporting both JSON and database sources.
    Switches automatically based on configuration.
    """

    def __init__(self):
        self.settings = get_settings()

    def get_events_data(
        self,
        engine_serial: Optional[str] = None,
        tail_number: Optional[str] = None,
        hours: int = 24
    ) -> pd.DataFrame:
        """
        Get events data from configured source.

        Args:
            engine_serial: Engine serial number filter
            tail_number: Tail number filter
            hours: Time window in hours

        Returns:
            DataFrame with events data
        """
        activity_logger.log_activity(
            activity="get_events_data",
            status="started",
            engine_serial=engine_serial,
            tail_number=tail_number,
            hours=hours,
            use_dummy_data=self.settings.ENABLE_DUMMY_DATA
        )

        try:
            if self.settings.ENABLE_DUMMY_DATA:
                # Use JSON dummy data
                data = self._get_json_data(engine_serial, tail_number, hours)
            else:
                # Use PostgreSQL data
                data = self._get_postgres_data(engine_serial, tail_number, hours)

            activity_logger.log_activity(
                activity="get_events_data",
                status="completed",
                rows_returned=len(data)
            )

            return data

        except Exception as e:
            activity_logger.log_activity(
                activity="get_events_data",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_events_data"})
            raise

    def _get_json_data(
        self,
        engine_serial: Optional[str] = None,
        tail_number: Optional[str] = None,
        hours: int = 24
    ) -> pd.DataFrame:
        """Load data from JSON file."""
        json_file = Path("data/dummy_events.json")

        if not json_file.exists():
            # Fallback to simulation if JSON doesn't exist
            logger.warning(f"JSON file not found: {json_file}, using simulation")
            from app.data_simulation import simulate_events
            from datetime import datetime
            return simulate_events(
                engine_serial or "000000",
                tail_number or "N-DEMO",
                datetime.utcnow(),
                hours=hours
            )

        try:
            with open(json_file, "r") as f:
                data = json.load(f)

            df = pd.DataFrame(data)

            # Apply filters
            if engine_serial:
                df = df[df["engine_serial"] == engine_serial]

            if tail_number:
                df = df[df["tail_number"] == tail_number]

            # Convert timestamps
            if "timestamp" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"])

            logger.info(f"Loaded {len(df)} records from JSON file")
            return df

        except Exception as e:
            raise DataNotFoundException(
                f"Failed to load JSON data: {e}",
                details={"file": str(json_file)}
            )

    def _get_postgres_data(
        self,
        engine_serial: Optional[str] = None,
        tail_number: Optional[str] = None,
        hours: int = 24
    ) -> pd.DataFrame:
        """Load data from PostgreSQL database."""
        from app.core.database import get_database_service

        db_service = get_database_service()

        activity_logger.log_activity(
            activity="query_postgres",
            status="started"
        )

        try:
            with db_service.get_session() as session:
                # Build query (example - adjust to your schema)
                query = """
                    SELECT *
                    FROM events
                    WHERE timestamp >= NOW() - INTERVAL '%s hours'
                """ % hours

                params = {}

                if engine_serial:
                    query += " AND engine_serial = :engine_serial"
                    params["engine_serial"] = engine_serial

                if tail_number:
                    query += " AND tail_number = :tail_number"
                    params["tail_number"] = tail_number

                query += " ORDER BY timestamp DESC"

                df = pd.read_sql(query, session.bind, params=params)

                activity_logger.log_activity(
                    activity="query_postgres",
                    status="completed",
                    rows_returned=len(df)
                )

                logger.info(f"Loaded {len(df)} records from PostgreSQL")
                return df

        except Exception as e:
            activity_logger.log_activity(
                activity="query_postgres",
                status="failed",
                error=str(e)
            )
            raise DataNotFoundException(
                f"Failed to query PostgreSQL: {e}",
                details={
                    "engine_serial": engine_serial,
                    "tail_number": tail_number
                }
            )

    def get_system_status(self) -> Dict[str, Any]:
        """
        Get system status summary.

        Returns:
            Dictionary with system status information
        """
        activity_logger.log_activity(
            activity="get_system_status",
            status="started"
        )

        try:
            status = {
                "data_source": "json" if self.settings.ENABLE_DUMMY_DATA else "postgres",
                "aws_logging": self.settings.ENABLE_AWS_LOGGING,
                "environment": self.settings.ENVIRONMENT
            }

            if not self.settings.ENABLE_DUMMY_DATA:
                from app.core.database import get_database_service
                db_service = get_database_service()
                status["database_healthy"] = db_service.health_check()

            activity_logger.log_activity(
                activity="get_system_status",
                status="completed"
            )

            return status

        except Exception as e:
            activity_logger.log_activity(
                activity="get_system_status",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_system_status"})
            return {"error": str(e)}

    # ========================================================================
    # OVERVIEW SCREEN DATA METHODS
    # ========================================================================
    # These methods fetch data for the Overview tab using real database queries
    # with JOINs, GROUP BY, CASE statements, and time calculations.
    # Currently COMMENTED OUT in overview.py - will be enabled when ready.
    # ========================================================================

    def get_status_summary(
        self,
        engine_serial: str,
        hours: int = 24
    ) -> pd.DataFrame:
        """
        Get status summary (Fail/Pass/Pending/Processing counts).

        Uses CASE statement to classify event statuses into 4 categories.

        Args:
            engine_serial: Engine serial number filter
            hours: Time window in hours (default 24)

        Returns:
            DataFrame with columns: category, count
            Categories: 'Fail', 'Pass', 'Pending', 'Processing'
        """
        activity_logger.log_activity(
            activity="get_status_summary",
            status="started",
            engine_serial=engine_serial,
            hours=hours
        )

        try:
            from app.core.database import get_database_service
            db_service = get_database_service()

            with db_service.get_session() as session:
                # Query with CASE statement to classify statuses
                query = """
                    SELECT
                        CASE
                            WHEN status = 'Complete' THEN 'Pass'
                            WHEN status = 'Error' THEN 'Fail'
                            WHEN status IN ('Pending', 'Delayed') THEN 'Pending'
                            ELSE 'Processing'
                        END as category,
                        COUNT(*) as count
                    FROM events
                    WHERE engine_serial = :engine_serial
                      AND start_time >= NOW() - INTERVAL ':hours hours'
                    GROUP BY category
                    ORDER BY
                        CASE category
                            WHEN 'Fail' THEN 1
                            WHEN 'Pass' THEN 2
                            WHEN 'Pending' THEN 3
                            WHEN 'Processing' THEN 4
                        END
                """

                df = pd.read_sql(
                    query,
                    session.bind,
                    params={"engine_serial": engine_serial, "hours": hours}
                )

                # Ensure all categories are present even if count is 0
                expected_categories = ["Fail", "Pass", "Pending", "Processing"]
                for cat in expected_categories:
                    if cat not in df['category'].values:
                        df = pd.concat([
                            df,
                            pd.DataFrame({'category': [cat], 'count': [0]})
                        ], ignore_index=True)

                activity_logger.log_activity(
                    activity="get_status_summary",
                    status="completed",
                    rows_returned=len(df)
                )

                logger.info(f"Status summary: {len(df)} categories for engine {engine_serial}")
                return df

        except Exception as e:
            activity_logger.log_activity(
                activity="get_status_summary",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_status_summary"})
            raise

    def get_data_population(
        self,
        engine_serial: str,
        hours: int = 24
    ) -> pd.DataFrame:
        """
        Get data population metrics by system.

        Uses LEFT JOIN to data_elements table to calculate completeness scores.

        Args:
            engine_serial: Engine serial number filter
            hours: Time window in hours (default 24)

        Returns:
            DataFrame with columns: system_name, completeness_pct, quality_pct
        """
        activity_logger.log_activity(
            activity="get_data_population",
            status="started",
            engine_serial=engine_serial,
            hours=hours
        )

        try:
            from app.core.database import get_database_service
            db_service = get_database_service()

            with db_service.get_session() as session:
                # Query with LEFT JOIN to get completeness scores
                query = """
                    SELECT
                        e.system_name,
                        AVG(de.completeness_score) * 100 as completeness_pct,
                        AVG(de.quality_score) * 100 as quality_pct,
                        COUNT(de.element_id) as total_elements
                    FROM events e
                    LEFT JOIN data_elements de ON e.event_id = de.event_id
                    WHERE e.engine_serial = :engine_serial
                      AND e.start_time >= NOW() - INTERVAL ':hours hours'
                    GROUP BY e.system_name
                    ORDER BY e.system_name
                """

                df = pd.read_sql(
                    query,
                    session.bind,
                    params={"engine_serial": engine_serial, "hours": hours}
                )

                activity_logger.log_activity(
                    activity="get_data_population",
                    status="completed",
                    rows_returned=len(df)
                )

                logger.info(f"Data population: {len(df)} systems for engine {engine_serial}")
                return df

        except Exception as e:
            activity_logger.log_activity(
                activity="get_data_population",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_data_population"})
            raise

    def get_sla_timeline(
        self,
        engine_serial: str,
        hours: int = 24
    ) -> pd.DataFrame:
        """
        Get SLA timeline with breach detection.

        Uses LEFT JOIN to sla_targets and time calculations (EXTRACT) to
        determine if events met their SLA targets.

        Args:
            engine_serial: Engine serial number filter
            hours: Time window in hours (default 24)

        Returns:
            DataFrame with columns: system_name, status, start_time, end_time,
                                   duration_minutes, expected_duration_minutes, sla_status
        """
        activity_logger.log_activity(
            activity="get_sla_timeline",
            status="started",
            engine_serial=engine_serial,
            hours=hours
        )

        try:
            from app.core.database import get_database_service
            db_service = get_database_service()

            with db_service.get_session() as session:
                # Query with time calculations and SLA comparison
                query = """
                    SELECT
                        e.event_id,
                        e.system_name,
                        e.status,
                        e.start_time,
                        e.end_time,
                        EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 as duration_minutes,
                        sla.expected_duration_minutes,
                        CASE
                            WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.expected_duration_minutes
                            THEN 'ON_TIME'
                            ELSE 'SLA_BREACH'
                        END as sla_status
                    FROM events e
                    LEFT JOIN sla_targets sla ON e.system_name = sla.system_name
                    WHERE e.engine_serial = :engine_serial
                      AND e.start_time >= NOW() - INTERVAL ':hours hours'
                    ORDER BY e.start_time
                """

                df = pd.read_sql(
                    query,
                    session.bind,
                    params={"engine_serial": engine_serial, "hours": hours}
                )

                activity_logger.log_activity(
                    activity="get_sla_timeline",
                    status="completed",
                    rows_returned=len(df)
                )

                logger.info(f"SLA timeline: {len(df)} events for engine {engine_serial}")
                return df

        except Exception as e:
            activity_logger.log_activity(
                activity="get_sla_timeline",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_sla_timeline"})
            raise

    def get_error_notifications(
        self,
        engine_serial: str,
        hours: int = 24
    ) -> pd.DataFrame:
        """
        Get error notifications with team alerts.

        Uses INNER JOIN to error_logs and engines tables (multiple JOINs)
        to get complete error information.

        Args:
            engine_serial: Engine serial number filter
            hours: Time window in hours (default 24)

        Returns:
            DataFrame with columns: system_name, error_message, error_severity,
                                   notified_team, notification_sent_at, engine_model
        """
        activity_logger.log_activity(
            activity="get_error_notifications",
            status="started",
            engine_serial=engine_serial,
            hours=hours
        )

        try:
            from app.core.database import get_database_service
            db_service = get_database_service()

            with db_service.get_session() as session:
                # Query with multiple INNER JOINs
                query = """
                    SELECT
                        e.event_id,
                        e.system_name,
                        e.error_message,
                        el.error_severity,
                        el.notified_team,
                        el.notification_sent_at,
                        eng.model as engine_model,
                        e.start_time,
                        e.records,
                        e.data_size_mb,
                        e.latency_sec
                    FROM events e
                    INNER JOIN error_logs el ON e.event_id = el.event_id
                    INNER JOIN engines eng ON e.engine_serial = eng.serial_number
                    WHERE e.status = 'Error'
                      AND e.engine_serial = :engine_serial
                      AND e.start_time >= NOW() - INTERVAL ':hours hours'
                    ORDER BY el.notification_sent_at DESC
                """

                df = pd.read_sql(
                    query,
                    session.bind,
                    params={"engine_serial": engine_serial, "hours": hours}
                )

                activity_logger.log_activity(
                    activity="get_error_notifications",
                    status="completed",
                    rows_returned=len(df)
                )

                logger.info(f"Error notifications: {len(df)} errors for engine {engine_serial}")
                return df

        except Exception as e:
            activity_logger.log_activity(
                activity="get_error_notifications",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_error_notifications"})
            raise

    def get_last_updated(
        self,
        engine_serial: str,
        hours: int = 24
    ) -> pd.DataFrame:
        """
        Get last updated times by system.

        Simple aggregation query to show when each system last updated.

        Args:
            engine_serial: Engine serial number filter
            hours: Time window in hours (default 24)

        Returns:
            DataFrame with columns: system_name, last_updated
        """
        activity_logger.log_activity(
            activity="get_last_updated",
            status="started",
            engine_serial=engine_serial,
            hours=hours
        )

        try:
            from app.core.database import get_database_service
            db_service = get_database_service()

            with db_service.get_session() as session:
                query = """
                    SELECT
                        system_name,
                        MAX(end_time) as last_updated
                    FROM events
                    WHERE engine_serial = :engine_serial
                      AND start_time >= NOW() - INTERVAL ':hours hours'
                    GROUP BY system_name
                    ORDER BY system_name
                """

                df = pd.read_sql(
                    query,
                    session.bind,
                    params={"engine_serial": engine_serial, "hours": hours}
                )

                activity_logger.log_activity(
                    activity="get_last_updated",
                    status="completed",
                    rows_returned=len(df)
                )

                logger.info(f"Last updated: {len(df)} systems for engine {engine_serial}")
                return df

        except Exception as e:
            activity_logger.log_activity(
                activity="get_last_updated",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_last_updated"})
            raise

    def get_overview_data(
        self,
        engine_serial: str,
        hours: int = 24
    ) -> Dict[str, pd.DataFrame]:
        """
        Get all Overview screen metrics in one call.

        This is a convenience method that calls all individual metric methods
        and returns them in a single dictionary.

        Args:
            engine_serial: Engine serial number filter
            hours: Time window in hours (default 24)

        Returns:
            Dictionary with keys:
                - 'status_summary': Status counts (Fail/Pass/Pending/Processing)
                - 'data_population': Completeness by system
                - 'sla_timeline': SLA timeline with breach detection
                - 'error_notifications': Error details with team alerts
                - 'last_updated': Last update times by system
        """
        activity_logger.log_activity(
            activity="get_overview_data",
            status="started",
            engine_serial=engine_serial,
            hours=hours
        )

        try:
            overview_data = {
                'status_summary': self.get_status_summary(engine_serial, hours),
                'data_population': self.get_data_population(engine_serial, hours),
                'sla_timeline': self.get_sla_timeline(engine_serial, hours),
                'error_notifications': self.get_error_notifications(engine_serial, hours),
                'last_updated': self.get_last_updated(engine_serial, hours)
            }

            activity_logger.log_activity(
                activity="get_overview_data",
                status="completed",
                metrics_fetched=len(overview_data)
            )

            logger.info(f"Overview data: {len(overview_data)} metrics for engine {engine_serial}")
            return overview_data

        except Exception as e:
            activity_logger.log_activity(
                activity="get_overview_data",
                status="failed",
                error=str(e)
            )
            log_exception(e, context={"activity": "get_overview_data"})
            raise
