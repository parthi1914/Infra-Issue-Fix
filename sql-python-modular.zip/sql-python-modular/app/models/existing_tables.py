"""
SQLAlchemy models for existing database tables.
These models map to your existing database schema.

IMPORTANT: Use __table_args__ = {'extend_existing': True} to prevent creating new tables!
"""
from sqlalchemy import Column, Integer, String, DateTime, Float, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.core.database import Base


# ============================================================================
# Table 1: EVENTS (Main pipeline events)
# ============================================================================

class Event(Base):
    """
    Events table - main pipeline events.
    Maps to existing 'events' table in database.
    """
    __tablename__ = "events"
    __table_args__ = {'extend_existing': True}  # Don't create new table!

    # Primary key
    id = Column(Integer, primary_key=True, autoincrement=True)

    # Core fields
    event_id = Column(String(100), unique=True, nullable=False, index=True)
    engine_serial = Column(String(50), nullable=False, index=True)
    tail_number = Column(String(50), nullable=True)
    system_name = Column(String(50), nullable=False, index=True)
    status = Column(String(50), nullable=False, index=True)

    # Timestamps
    start_time = Column(DateTime, nullable=False, index=True)
    end_time = Column(DateTime, nullable=False, index=True)

    # Metrics
    latency_ms = Column(Integer, nullable=True)
    records_processed = Column(Integer, nullable=True)
    data_size_mb = Column(Float, nullable=True)

    # Error info
    error_message = Column(Text, nullable=True)

    # Metadata
    created_at = Column(DateTime, nullable=True)

    # Relationships
    data_elements = relationship("DataElement", back_populates="event", lazy="select")
    error_logs = relationship("ErrorLog", back_populates="event", lazy="select")

    def __repr__(self):
        return f"<Event(event_id={self.event_id}, system={self.system_name}, status={self.status})>"


# ============================================================================
# Table 2: DATA_ELEMENTS (Data quality tracking)
# ============================================================================

class DataElement(Base):
    """
    Data elements table - tracks data completeness and quality.
    Maps to existing 'data_elements' table.
    """
    __tablename__ = "data_elements"
    __table_args__ = {'extend_existing': True}

    # Primary key
    element_id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign key
    event_id = Column(String(100), ForeignKey('events.event_id'), nullable=False, index=True)

    # Fields
    element_name = Column(String(100), nullable=False, index=True)
    is_present = Column(Boolean, default=False)
    completeness_score = Column(Float, nullable=True)  # 0.0 to 1.0
    quality_score = Column(Float, nullable=True)  # 0.0 to 1.0
    validation_errors = Column(Integer, default=0)

    # Metadata
    last_updated = Column(DateTime, nullable=True)

    # Relationships
    event = relationship("Event", back_populates="data_elements")

    def __repr__(self):
        return f"<DataElement(element_name={self.element_name}, present={self.is_present})>"


# ============================================================================
# Table 3: SLA_TARGETS (Expected completion times)
# ============================================================================

class SLATarget(Base):
    """
    SLA targets table - defines expected durations per system.
    Maps to existing 'sla_targets' table.
    """
    __tablename__ = "sla_targets"
    __table_args__ = {'extend_existing': True}

    # Primary key
    sla_id = Column(Integer, primary_key=True, autoincrement=True)

    # Fields
    system_name = Column(String(50), unique=True, nullable=False, index=True)
    expected_duration_minutes = Column(Integer, nullable=True)
    sla_threshold_minutes = Column(Integer, nullable=True)
    priority_level = Column(String(20), nullable=True)  # HIGH, MEDIUM, LOW

    def __repr__(self):
        return f"<SLATarget(system={self.system_name}, expected={self.expected_duration_minutes}min)>"


# ============================================================================
# Table 4: ERROR_LOGS (Detailed error tracking)
# ============================================================================

class ErrorLog(Base):
    """
    Error logs table - tracks detailed error information.
    Maps to existing 'error_logs' table.
    """
    __tablename__ = "error_logs"
    __table_args__ = {'extend_existing': True}

    # Primary key
    error_id = Column(Integer, primary_key=True, autoincrement=True)

    # Foreign key
    event_id = Column(String(100), ForeignKey('events.event_id'), nullable=False, index=True)

    # Error details
    error_code = Column(String(50), nullable=True)
    error_severity = Column(String(20), nullable=True, index=True)  # CRITICAL, HIGH, MEDIUM, LOW
    error_message = Column(Text, nullable=True)
    stack_trace = Column(Text, nullable=True)

    # Notification tracking
    notified_team = Column(String(100), nullable=True)
    notification_sent_at = Column(DateTime, nullable=True)

    # Resolution
    resolved_at = Column(DateTime, nullable=True)
    resolution_notes = Column(Text, nullable=True)

    # Metadata
    created_at = Column(DateTime, nullable=True)

    # Relationships
    event = relationship("Event", back_populates="error_logs")

    def __repr__(self):
        return f"<ErrorLog(error_id={self.error_id}, severity={self.error_severity})>"


# ============================================================================
# Table 5: ENGINES (Engine master data)
# ============================================================================

class Engine(Base):
    """
    Engines table - master data for engines.
    Maps to existing 'engines' table.
    """
    __tablename__ = "engines"
    __table_args__ = {'extend_existing': True}

    # Primary key
    engine_id = Column(Integer, primary_key=True, autoincrement=True)

    # Fields
    serial_number = Column(String(50), unique=True, nullable=False, index=True)
    model = Column(String(100), nullable=True)
    manufacture_date = Column(DateTime, nullable=True)
    status = Column(String(50), nullable=True)  # ACTIVE, MAINTENANCE, RETIRED
    current_tail_number = Column(String(50), nullable=True)

    def __repr__(self):
        return f"<Engine(serial={self.serial_number}, model={self.model})>"


# ============================================================================
# Table 6: FLIGHTS (Flight information)
# ============================================================================

class Flight(Base):
    """
    Flights table - flight information.
    Maps to existing 'flights' table.
    """
    __tablename__ = "flights"
    __table_args__ = {'extend_existing': True}

    # Primary key
    flight_id = Column(Integer, primary_key=True, autoincrement=True)

    # Fields
    flight_number = Column(String(20), nullable=True)
    tail_number = Column(String(50), nullable=True, index=True)
    departure_time = Column(DateTime, nullable=True, index=True)
    arrival_time = Column(DateTime, nullable=True)
    engine_serial_1 = Column(String(50), nullable=True, index=True)
    engine_serial_2 = Column(String(50), nullable=True, index=True)
    flight_status = Column(String(50), nullable=True)

    def __repr__(self):
        return f"<Flight(flight_number={self.flight_number}, tail={self.tail_number})>"


# ============================================================================
# Table 7: SYSTEM_HEALTH (System uptime and performance)
# ============================================================================

class SystemHealth(Base):
    """
    System health table - tracks system uptime and performance.
    Maps to existing 'system_health' table.
    """
    __tablename__ = "system_health"
    __table_args__ = {'extend_existing': True}

    # Primary key
    health_id = Column(Integer, primary_key=True, autoincrement=True)

    # Fields
    system_name = Column(String(50), nullable=False, index=True)
    check_time = Column(DateTime, nullable=True, index=True)
    is_healthy = Column(Boolean, default=True)
    response_time_ms = Column(Integer, nullable=True)
    error_rate = Column(Float, nullable=True)  # Percentage
    throughput_records_per_hour = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)

    def __repr__(self):
        return f"<SystemHealth(system={self.system_name}, healthy={self.is_healthy})>"


# ============================================================================
# Export all models
# ============================================================================

__all__ = [
    'Event',
    'DataElement',
    'SLATarget',
    'ErrorLog',
    'Engine',
    'Flight',
    'SystemHealth'
]
