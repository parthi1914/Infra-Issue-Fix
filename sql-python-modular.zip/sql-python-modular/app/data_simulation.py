from __future__ import annotations

import random
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import streamlit as st

from .config import SYSTEM_FLOW, STATUSES, TAIL_TO_ENGINES, ENGINE_TO_TAILS
from .config import STATUS_COLOR_MAP  # kept for compatibility

# ------------------------------------------------------------
# DATA SIMULATION (Moved as-is)
# ------------------------------------------------------------
@st.cache_data(show_spinner=False)
def simulate_events(engine_serial: str, tail_number: str, now: datetime, hours: float = 3.0, variation: str = "Normal") -> pd.DataFrame:
    """Simulate data travel events with deterministic variation by ESN+Tail hash and scenario label."""
    # Special case: Demo ESN/Tail always completes successfully
    is_demo = (engine_serial == "000000" and tail_number == "N-DEMO")

    # Deterministic seed based on identifiers + variation label
    base_seed = abs(hash(engine_serial + tail_number + variation)) % (2**32 - 1)
    rng = random.Random(base_seed)
    np_rng = np.random.default_rng(base_seed)

    start_window = now - timedelta(hours=hours)
    base_start = start_window + timedelta(minutes=rng.randint(0, 25))

    records = []
    cumulative_time = base_start
    total_records = rng.randint(55_000, 125_000)
    remaining = total_records

    # Variation profiles alter status weighting
    if variation == "High Delay":
        weight_profile = [0.03, 0.12, 0.45, 0.30, 0.10]
    elif variation == "Error Spike":
        weight_profile = [0.05, 0.10, 0.55, 0.15, 0.15]
    elif variation == "Fast Path":
        weight_profile = [0.02, 0.18, 0.70, 0.06, 0.04]
    else:  # Normal
        weight_profile = [0.04, 0.16, 0.60, 0.14, 0.06]

    pipeline_blocked = False
    for i, system in enumerate(SYSTEM_FLOW):
        proc_minutes = rng.randint(5, 22)
        # Fast Path compress durations toward lower bound
        if variation == "Fast Path":
            proc_minutes = int(proc_minutes * 0.7)
        start_time = cumulative_time
        end_time = start_time + timedelta(minutes=proc_minutes)
        gap = rng.randint(1, 8)
        if variation == "Fast Path":
            gap = max(1, int(gap * 0.5))
        cumulative_time = end_time + timedelta(minutes=gap) if i < len(SYSTEM_FLOW) - 1 else end_time

        # Demo always completes; others follow normal logic
        if is_demo:
            status = "Complete"
        elif pipeline_blocked:
            status = "NotStarted"
        else:
            # Weighted status selection + deterministic tweak based on hash of system
            sys_bias = (abs(hash(system + engine_serial)) % 100) / 100.0
            # Shift probabilities slightly per system to create variation
            adjusted_weights = [w * (0.9 + sys_bias * 0.2) for w in weight_profile]
            total_w = sum(adjusted_weights)
            adjusted_weights = [w / total_w for w in adjusted_weights]
            status = rng.choices(STATUSES[:5], weights=adjusted_weights, k=1)[0]  # exclude NotStarted from random selection

        if status == "NotStarted":
            # Collapse times for not started stage (placeholder minimal window)
            end_time = start_time + timedelta(minutes=1)
        elif status == "Delayed":
            end_time += timedelta(minutes=rng.randint(6, 16))
        elif status == "Error":
            end_time += timedelta(minutes=rng.randint(2, 6))

        latency = rng.uniform(0.5, 4.5) * (1.4 if status in {"Delayed", "Error"} else 1.0)

        hop_records = max(int(remaining * rng.uniform(0.91, 0.985)), 900)
        remaining = hop_records
        data_size_mb = hop_records * rng.uniform(0.00055, 0.0011)

        records.append({
            "engine_serial": engine_serial,
            "tail_number": tail_number,
            "system": system,
            "start_time": start_time,
            "end_time": end_time,
            "status": status,
            "latency_sec": latency,
            "records": hop_records,
            "data_size_mb": data_size_mb,
        })

        if not is_demo and status != "Complete" and status != "NotStarted":
            pipeline_blocked = True

    df = pd.DataFrame(records)
    return df

# ------------------------------------------------------------
# DATA ELEMENTS TRACKING (19 expected elements per system)
# ------------------------------------------------------------
DATA_ELEMENTS = [
    "Diagnostic Installation Date",
    "Diagnostic Tail",
    "Engine Position",
    "Installation Date",
    "Last Updated Date",
    "Monitor",
    "NI Modifier",
    "Operator",
    "Tail",
    "Flight Number",
    "Airport Code",
    "Route",
    "Phase of Flight",
    "Event Count",
    "Sensor Packet Size",
    "Data Quality Score",
    "Record Checksum",
    "Schema Version",
    "Ingestion Batch Id"
]

def simulate_data_elements_with_values(df: pd.DataFrame, engine_serial: str, tail_number: str) -> dict:
    """Simulate per-system data element values and validation status with failure reasons.
    Returns dict: {system: {element: {"value": X, "expected": Y, "status": "Pass"/"Fail", "reason": "..."}}}
    """
    systems = list(df["system"].values)
    rng = random.Random(abs(hash(engine_serial + tail_number + "elem")) % (2**32 - 1))

    # Base pass rate per system influenced by status
    status_to_pass = {
        "Complete": 0.97,
        "Processing": 0.92,
        "Pending": 0.90,
        "Delayed": 0.85,
        "Error": 0.70,
        "NotStarted": 0.0,
    }

    # Generate expected values (consistent across systems)
    expected_values = {
        "Diagnostic Installation Date": "2024-10-23",
        "Diagnostic Tail": tail_number,
        "Engine Position": "3",
        "Installation Date": "2024-10-23",
        "Last Updated Date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "Monitor": "SWR",
        "NI Modifier": "5",
        "Operator": "SWR",
        "Tail": tail_number,
        "Flight Number": rng.choice(["SWR123", "SWR456", "LX789", "LX234"]),
        "Airport Code": rng.choice(["ZRH", "GVA", "LHR", "CDG"]),
        "Route": rng.choice(["ZRH-JFK", "GVA-LHR", "ZRH-SIN"]),
        "Phase of Flight": rng.choice(["Cruise", "Takeoff", "Landing", "Climb"]),
        "Event Count": str(rng.randint(15000, 25000)),
        "Sensor Packet Size": f"{rng.uniform(1.2, 3.5):.2f} MB",
        "Data Quality Score": f"{rng.uniform(92, 99):.1f}",
        "Record Checksum": f"CHK-{rng.randint(10000, 99999)}",
        "Schema Version": "v2.4.1",
        "Ingestion Batch Id": f"BATCH-{rng.randint(1000, 9999)}"
    }

    result = {}
    for system in systems:
        system_status = df.loc[df.system == system, "status"].iloc[0]
        base_rate = status_to_pass.get(system_status, 0.9)
        jitter = (abs(hash(system)) % 7) / 100.0
        pass_rate = min(0.99, max(0.0, base_rate - (0.02 if system_status in {"Delayed", "Error"} else 0.0) + jitter))

        system_data = {}
        for element in DATA_ELEMENTS:
            expected = expected_values[element]
            is_pass = rng.random() < pass_rate

            if is_pass:
                actual = expected
                status = "Pass"
                reason = ""
            else:
                # Generate realistic failures
                failure_type = rng.choice(["missing", "mismatch", "format", "null", "invalid"])
                if failure_type == "missing":
                    actual = "NULL"
                    reason = "Field missing in source data"
                elif failure_type == "mismatch":
                    if element == "Diagnostic Tail":
                        actual = rng.choice(["HB-JME", "N-XXXX", "D-ABCD"])
                        reason = f"Value mismatch: expected '{expected}' but got '{actual}'"
                    elif element == "Engine Position":
                        actual = rng.choice(["1", "2", "4"])
                        reason = f"Value mismatch: expected '{expected}' but got '{actual}'"
                    elif element == "Monitor":
                        actual = rng.choice(["PHM", "FDM", "BLANK"])
                        reason = f"Value mismatch: expected '{expected}' but got '{actual}'"
                    elif element in ["Installation Date", "Last Updated Date", "Diagnostic Installation Date"]:
                        actual = rng.choice(["2024-11-19", "2025-11-19", "2024-10-01"])
                        reason = f"Date mismatch: expected '{expected}' but got '{actual}'"
                    else:
                        actual = f"{expected}-WRONG"
                        reason = f"Value mismatch: expected '{expected}'"
                elif failure_type == "format":
                    actual = str(expected).replace("-", "").replace(":", "")[:10]
                    reason = f"Format error: expected format not met"
                elif failure_type == "null":
                    actual = "NULL"
                    reason = "Null value found"
                else:
                    actual = "INVALID"
                    reason = "Data validation failed"
                status = "Fail"

            system_data[element] = {
                "value": actual,
                "expected": expected,
                "status": status,
                "reason": reason
            }

        result[system] = system_data

    return result

def simulate_data_elements_status(df: pd.DataFrame) -> pd.DataFrame:
    """Legacy function for simple Pass/Fail matrix - kept for compatibility."""
    systems = list(df["system"].values)
    rng = random.Random(abs(hash(tuple(systems))) % (2**32 - 1))
    status_to_pass = {
        "Complete": 0.97,
        "Processing": 0.92,
        "Pending": 0.90,
        "Delayed": 0.85,
        "Error": 0.70,
        "NotStarted": 0.0,
    }
    matrix = {}
    for system in systems:
        status = df.loc[df.system == system, "status"].iloc[0]
        base_rate = status_to_pass.get(status, 0.9)
        jitter = (abs(hash(system)) % 7) / 100.0
        pass_rate = min(0.99, max(0.0, base_rate - (0.02 if status in {"Delayed", "Error"} else 0.0) + jitter))
        vals = []
        for el in DATA_ELEMENTS:
            vals.append("Pass" if rng.random() < pass_rate else "Fail")
        matrix[system] = vals
    return pd.DataFrame(matrix, index=DATA_ELEMENTS)
