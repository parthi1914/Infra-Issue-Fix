"""
Core infrastructure initialization.
Sets up logging, exception handling, and dependency injection.
"""
from __future__ import annotations

from app.core.config import get_settings
from app.core.context import set_correlation_id
from app.core.di import get_container, register_singleton
from app.core.exceptions import setup_exception_handler
from app.core.logging import get_logger, setup_logging


logger = get_logger(__name__)


def initialize_app() -> None:
    """
    Initialize the application infrastructure.
    Call this at application startup.
    """
    # Generate correlation ID for this session
    correlation_id = set_correlation_id()

    # Setup logging
    setup_logging()

    # Setup global exception handler
    setup_exception_handler()

    logger.info(
        "Application initialized",
        extra={
            "correlation_id": correlation_id,
            "app_name": get_settings().APP_NAME,
            "app_version": get_settings().APP_VERSION,
            "environment": get_settings().ENVIRONMENT
        }
    )

    # Register services in DI container
    _register_services()


def _register_services() -> None:
    """Register services in dependency injection container."""
    from app.core.aws import Boto3Factory, SNSService
    from app.core.database import DatabaseService
    from app.services.data_service import DataService

    container = get_container()

    # Register core services as singletons
    register_singleton("boto3_factory", Boto3Factory)
    register_singleton("sns_service", SNSService)
    register_singleton("database_service", DatabaseService)
    register_singleton("data_service", DataService)

    logger.info("Services registered in DI container")


__all__ = [
    "initialize_app",
    "get_settings",
    "get_logger",
    "set_correlation_id",
    "get_container"
]
