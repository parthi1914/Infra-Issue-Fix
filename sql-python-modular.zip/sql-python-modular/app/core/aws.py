"""
AWS service integrations - boto3 factory, SNS, CloudWatch logging.
Provides reusable AWS service abstractions.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from app.core.config import get_settings
from app.core.exceptions import AWSServiceException, log_exception
from app.core.logging import ActivityLogger, get_logger


logger = get_logger(__name__)
activity_logger = ActivityLogger(logger)


class Boto3Factory:
    """
    Factory for creating boto3 clients and resources.
    Handles configuration and credentials.
    """

    def __init__(self):
        self.settings = get_settings()
        self._clients: Dict[str, Any] = {}
        self._resources: Dict[str, Any] = {}

    def get_client(self, service_name: str, **kwargs: Any) -> Any:
        """
        Get or create a boto3 client.

        Args:
            service_name: AWS service name (e.g., 'sns', 'logs', 's3')
            **kwargs: Additional client configuration

        Returns:
            Boto3 client instance
        """
        cache_key = f"{service_name}:{str(kwargs)}"

        if cache_key not in self._clients:
            activity_logger.log_activity(
                activity="create_boto3_client",
                status="started",
                service=service_name
            )

            try:
                client_config = {
                    "region_name": self.settings.AWS_REGION,
                    **kwargs
                }

                self._clients[cache_key] = boto3.client(service_name, **client_config)

                activity_logger.log_activity(
                    activity="create_boto3_client",
                    status="completed",
                    service=service_name,
                    region=self.settings.AWS_REGION
                )
            except (BotoCoreError, ClientError) as e:
                activity_logger.log_activity(
                    activity="create_boto3_client",
                    status="failed",
                    service=service_name,
                    error=str(e)
                )
                raise AWSServiceException(
                    f"Failed to create boto3 client for {service_name}",
                    service=service_name,
                    details={"error": str(e)}
                )

        return self._clients[cache_key]

    def get_resource(self, service_name: str, **kwargs: Any) -> Any:
        """
        Get or create a boto3 resource.

        Args:
            service_name: AWS service name (e.g., 's3', 'dynamodb')
            **kwargs: Additional resource configuration

        Returns:
            Boto3 resource instance
        """
        cache_key = f"{service_name}:{str(kwargs)}"

        if cache_key not in self._resources:
            activity_logger.log_activity(
                activity="create_boto3_resource",
                status="started",
                service=service_name
            )

            try:
                resource_config = {
                    "region_name": self.settings.AWS_REGION,
                    **kwargs
                }

                self._resources[cache_key] = boto3.resource(service_name, **resource_config)

                activity_logger.log_activity(
                    activity="create_boto3_resource",
                    status="completed",
                    service=service_name,
                    region=self.settings.AWS_REGION
                )
            except (BotoCoreError, ClientError) as e:
                activity_logger.log_activity(
                    activity="create_boto3_resource",
                    status="failed",
                    service=service_name,
                    error=str(e)
                )
                raise AWSServiceException(
                    f"Failed to create boto3 resource for {service_name}",
                    service=service_name,
                    details={"error": str(e)}
                )

        return self._resources[cache_key]


# Global boto3 factory instance
_boto3_factory: Optional[Boto3Factory] = None


def get_boto3_factory() -> Boto3Factory:
    """Get global boto3 factory instance."""
    global _boto3_factory
    if _boto3_factory is None:
        _boto3_factory = Boto3Factory()
    return _boto3_factory


def get_boto3_client(service_name: str, **kwargs: Any) -> Any:
    """
    Convenience function to get boto3 client.

    Args:
        service_name: AWS service name
        **kwargs: Additional configuration

    Returns:
        Boto3 client
    """
    return get_boto3_factory().get_client(service_name, **kwargs)


def get_boto3_resource(service_name: str, **kwargs: Any) -> Any:
    """
    Convenience function to get boto3 resource.

    Args:
        service_name: AWS service name
        **kwargs: Additional configuration

    Returns:
        Boto3 resource
    """
    return get_boto3_factory().get_resource(service_name, **kwargs)


class SNSService:
    """
    AWS SNS service wrapper.
    Handles publishing messages and notifications.
    """

    def __init__(self, boto3_factory: Optional[Boto3Factory] = None):
        self.boto3_factory = boto3_factory or get_boto3_factory()
        self.settings = get_settings()
        self._client = None

    @property
    def client(self) -> Any:
        """Get SNS client (lazy-loaded)."""
        if self._client is None:
            self._client = self.boto3_factory.get_client("sns")
        return self._client

    def publish_message(
        self,
        message: str,
        subject: Optional[str] = None,
        topic_arn: Optional[str] = None,
        attributes: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Publish a message to SNS topic.

        Args:
            message: Message content
            subject: Message subject (for email)
            topic_arn: SNS topic ARN (uses default if not provided)
            attributes: Message attributes

        Returns:
            Message ID if successful, None otherwise
        """
        topic_arn = topic_arn or self.settings.AWS_SNS_TOPIC_ARN

        if not topic_arn:
            logger.warning("SNS topic ARN not configured - message not sent")
            return None

        activity_logger.log_activity(
            activity="sns_publish",
            status="started",
            topic_arn=topic_arn,
            subject=subject
        )

        try:
            params = {
                "TopicArn": topic_arn,
                "Message": message
            }

            if subject:
                params["Subject"] = subject

            if attributes:
                params["MessageAttributes"] = {
                    key: {"DataType": "String", "StringValue": str(value)}
                    for key, value in attributes.items()
                }

            response = self.client.publish(**params)
            message_id = response.get("MessageId")

            activity_logger.log_activity(
                activity="sns_publish",
                status="completed",
                message_id=message_id,
                topic_arn=topic_arn
            )

            return message_id

        except (BotoCoreError, ClientError) as e:
            activity_logger.log_activity(
                activity="sns_publish",
                status="failed",
                topic_arn=topic_arn,
                error=str(e)
            )
            log_exception(
                e,
                context={
                    "activity": "sns_publish",
                    "topic_arn": topic_arn,
                    "subject": subject
                }
            )
            return None

    def publish_alert(
        self,
        alert_type: str,
        message: str,
        severity: str = "INFO",
        **extra_data: Any
    ) -> Optional[str]:
        """
        Publish an alert message with structured format.

        Args:
            alert_type: Type of alert (e.g., "ERROR", "WARNING", "DATA_QUALITY")
            message: Alert message
            severity: Alert severity (INFO, WARNING, ERROR, CRITICAL)
            **extra_data: Additional alert data

        Returns:
            Message ID if successful
        """
        attributes = {
            "alert_type": alert_type,
            "severity": severity,
            **extra_data
        }

        subject = f"[{severity}] {alert_type}"

        return self.publish_message(
            message=message,
            subject=subject,
            attributes=attributes
        )
