"""
Lightweight Dependency Injection container.
Simple, easy to use, minimal changes to existing code.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Optional, Type, TypeVar


T = TypeVar("T")


class Container:
    """
    Lightweight dependency injection container.

    Supports:
    - Singleton and factory registrations
    - Lazy initialization
    - Simple API with minimal boilerplate
    """

    def __init__(self):
        self._singletons: Dict[str, Any] = {}
        self._factories: Dict[str, Callable[[], Any]] = {}
        self._instances: Dict[str, Any] = {}

    def register_singleton(self, name: str, factory: Callable[[], T]) -> None:
        """
        Register a singleton service (lazy-initialized once).

        Args:
            name: Service name
            factory: Factory function to create the service
        """
        self._singletons[name] = factory

    def register_factory(self, name: str, factory: Callable[[], T]) -> None:
        """
        Register a factory service (created on each get).

        Args:
            name: Service name
            factory: Factory function to create the service
        """
        self._factories[name] = factory

    def register_instance(self, name: str, instance: T) -> None:
        """
        Register an existing instance.

        Args:
            name: Service name
            instance: Service instance
        """
        self._instances[name] = instance

    def get(self, name: str) -> Any:
        """
        Get a service by name.

        Args:
            name: Service name

        Returns:
            Service instance

        Raises:
            KeyError: If service not registered
        """
        # Check instances first
        if name in self._instances:
            return self._instances[name]

        # Check singletons (lazy-initialize if needed)
        if name in self._singletons:
            if name not in self._instances:
                self._instances[name] = self._singletons[name]()
            return self._instances[name]

        # Check factories (create new instance)
        if name in self._factories:
            return self._factories[name]()

        raise KeyError(f"Service '{name}' not registered in container")

    def has(self, name: str) -> bool:
        """
        Check if service is registered.

        Args:
            name: Service name

        Returns:
            True if registered
        """
        return name in self._singletons or name in self._factories or name in self._instances

    def clear(self) -> None:
        """Clear all registered services (useful for testing)."""
        self._singletons.clear()
        self._factories.clear()
        self._instances.clear()


# Global container instance
_container: Optional[Container] = None


def get_container() -> Container:
    """
    Get the global container instance.

    Returns:
        Global container
    """
    global _container
    if _container is None:
        _container = Container()
    return _container


def register_singleton(name: str, factory: Callable[[], T]) -> None:
    """
    Register a singleton service in global container.

    Args:
        name: Service name
        factory: Factory function
    """
    get_container().register_singleton(name, factory)


def register_factory(name: str, factory: Callable[[], T]) -> None:
    """
    Register a factory service in global container.

    Args:
        name: Service name
        factory: Factory function
    """
    get_container().register_factory(name, factory)


def register_instance(name: str, instance: T) -> None:
    """
    Register an instance in global container.

    Args:
        name: Service name
        instance: Service instance
    """
    get_container().register_instance(name, instance)


def inject(name: str) -> Any:
    """
    Inject a service from global container.

    Args:
        name: Service name

    Returns:
        Service instance
    """
    return get_container().get(name)


# Convenience decorator for dependency injection
def autowired(**dependencies: str):
    """
    Decorator to automatically inject dependencies.

    Example:
        @autowired(db="database_service", sns="sns_service")
        def my_function(db, sns):
            # db and sns are automatically injected
            pass
    """
    def decorator(func: Callable) -> Callable:
        def wrapper(*args, **kwargs):
            # Inject dependencies
            for param_name, service_name in dependencies.items():
                if param_name not in kwargs:
                    kwargs[param_name] = inject(service_name)
            return func(*args, **kwargs)
        return wrapper
    return decorator
