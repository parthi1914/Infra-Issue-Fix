"""
Database service layer with SQLAlchemy.
Supports SQLite (local) and PostgreSQL (AWS) with easy switching.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional, Type, TypeVar

from sqlalchemy import create_engine, event, pool
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.pool import StaticPool

from app.core.config import get_settings
from app.core.exceptions import DatabaseException, log_exception
from app.core.logging import ActivityLogger, get_logger


logger = get_logger(__name__)
activity_logger = ActivityLogger(logger)

# SQLAlchemy base for models
Base = declarative_base()

T = TypeVar("T", bound=Base)


class DatabaseService:
    """
    Database service providing connection management and session handling.
    Supports both SQLite and PostgreSQL.
    """

    def __init__(self):
        self.settings = get_settings()
        self._engine: Optional[Engine] = None
        self._session_factory: Optional[sessionmaker] = None

    @property
    def engine(self) -> Engine:
        """Get database engine (lazy-loaded)."""
        if self._engine is None:
            self._engine = self._create_engine()
        return self._engine

    @property
    def session_factory(self) -> sessionmaker:
        """Get session factory (lazy-loaded)."""
        if self._session_factory is None:
            self._session_factory = sessionmaker(
                bind=self.engine,
                autocommit=False,
                autoflush=False
            )
        return self._session_factory

    def _create_engine(self) -> Engine:
        """
        Create SQLAlchemy engine with appropriate configuration.

        Returns:
            SQLAlchemy engine
        """
        activity_logger.log_activity(
            activity="create_database_engine",
            status="started",
            database_url=self._mask_password(self.settings.DATABASE_URL)
        )

        try:
            engine_kwargs: Dict[str, Any] = {
                "echo": self.settings.DB_ECHO
            }

            # SQLite-specific configuration
            if self.settings.DATABASE_URL.startswith("sqlite"):
                engine_kwargs["connect_args"] = {"check_same_thread": False}
                engine_kwargs["poolclass"] = StaticPool
            else:
                # PostgreSQL configuration
                engine_kwargs["pool_size"] = self.settings.DB_POOL_SIZE
                engine_kwargs["max_overflow"] = self.settings.DB_MAX_OVERFLOW
                engine_kwargs["pool_pre_ping"] = True  # Verify connections
                engine_kwargs["pool_recycle"] = 3600  # Recycle connections after 1 hour

            engine = create_engine(self.settings.DATABASE_URL, **engine_kwargs)

            # Add logging for query execution
            @event.listens_for(engine, "before_cursor_execute")
            def receive_before_cursor_execute(conn, cursor, statement, params, context, executemany):
                activity_logger.log_activity(
                    activity="database_query",
                    status="started",
                    statement=statement[:200]  # Truncate long statements
                )

            activity_logger.log_activity(
                activity="create_database_engine",
                status="completed",
                database_url=self._mask_password(self.settings.DATABASE_URL)
            )

            logger.info(
                "Database engine created",
                extra={
                    "database_url": self._mask_password(self.settings.DATABASE_URL),
                    "pool_size": engine_kwargs.get("pool_size", "N/A"),
                    "echo": self.settings.DB_ECHO
                }
            )

            return engine

        except SQLAlchemyError as e:
            activity_logger.log_activity(
                activity="create_database_engine",
                status="failed",
                error=str(e)
            )
            raise DatabaseException(
                "Failed to create database engine",
                details={"error": str(e)}
            )

    @staticmethod
    def _mask_password(url: str) -> str:
        """Mask password in database URL for logging."""
        if "://" not in url:
            return url

        try:
            protocol, rest = url.split("://", 1)
            if "@" not in rest:
                return url

            credentials, host_part = rest.split("@", 1)
            if ":" in credentials:
                username, _ = credentials.split(":", 1)
                return f"{protocol}://{username}:****@{host_part}"

            return url
        except Exception:
            return url

    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """
        Context manager for database sessions.

        Yields:
            SQLAlchemy session

        Example:
            with db_service.get_session() as session:
                result = session.query(Model).all()
        """
        session = self.session_factory()
        activity_logger.log_activity(
            activity="database_session",
            status="started"
        )

        try:
            yield session
            session.commit()

            activity_logger.log_activity(
                activity="database_session",
                status="completed"
            )

        except SQLAlchemyError as e:
            session.rollback()

            activity_logger.log_activity(
                activity="database_session",
                status="failed",
                error=str(e)
            )

            log_exception(e, context={"activity": "database_session"})
            raise DatabaseException(
                "Database session error",
                details={"error": str(e)}
            )

        finally:
            session.close()

    def create_tables(self) -> None:
        """Create all database tables defined in models."""
        activity_logger.log_activity(
            activity="create_database_tables",
            status="started"
        )

        try:
            Base.metadata.create_all(bind=self.engine)

            activity_logger.log_activity(
                activity="create_database_tables",
                status="completed"
            )

            logger.info("Database tables created")

        except SQLAlchemyError as e:
            activity_logger.log_activity(
                activity="create_database_tables",
                status="failed",
                error=str(e)
            )
            raise DatabaseException(
                "Failed to create database tables",
                details={"error": str(e)}
            )

    def drop_tables(self) -> None:
        """Drop all database tables (use with caution!)."""
        activity_logger.log_activity(
            activity="drop_database_tables",
            status="started"
        )

        try:
            Base.metadata.drop_all(bind=self.engine)

            activity_logger.log_activity(
                activity="drop_database_tables",
                status="completed"
            )

            logger.warning("Database tables dropped")

        except SQLAlchemyError as e:
            activity_logger.log_activity(
                activity="drop_database_tables",
                status="failed",
                error=str(e)
            )
            raise DatabaseException(
                "Failed to drop database tables",
                details={"error": str(e)}
            )

    def health_check(self) -> bool:
        """
        Check database connectivity.

        Returns:
            True if database is accessible
        """
        activity_logger.log_activity(
            activity="database_health_check",
            status="started"
        )

        try:
            with self.get_session() as session:
                session.execute("SELECT 1")

            activity_logger.log_activity(
                activity="database_health_check",
                status="completed"
            )

            return True

        except Exception as e:
            activity_logger.log_activity(
                activity="database_health_check",
                status="failed",
                error=str(e)
            )
            return False


# Global database service instance
_database_service: Optional[DatabaseService] = None


def get_database_service() -> DatabaseService:
    """Get global database service instance."""
    global _database_service
    if _database_service is None:
        _database_service = DatabaseService()
    return _database_service
