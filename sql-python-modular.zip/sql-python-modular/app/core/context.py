"""
Request context management with correlation IDs for tracking.
Uses thread-local storage for safe concurrent access.
"""
from __future__ import annotations

import contextvars
from typing import Optional

from ulid import ULID


# Context variable for correlation ID (thread-safe)
_correlation_id_var: contextvars.ContextVar[str] = contextvars.ContextVar(
    "correlation_id",
    default=""
)


def generate_correlation_id() -> str:
    """
    Generate a new correlation ID using ULID.
    ULID provides sortable, unique identifiers.

    Returns:
        New correlation ID
    """
    return str(ULID())


def set_correlation_id(correlation_id: Optional[str] = None) -> str:
    """
    Set correlation ID for current context.

    Args:
        correlation_id: Correlation ID to set (generates new if None)

    Returns:
        The correlation ID that was set
    """
    if correlation_id is None:
        correlation_id = generate_correlation_id()

    _correlation_id_var.set(correlation_id)
    return correlation_id


def get_correlation_id() -> str:
    """
    Get correlation ID for current context.

    Returns:
        Current correlation ID (generates new if not set)
    """
    correlation_id = _correlation_id_var.get()
    if not correlation_id:
        correlation_id = set_correlation_id()
    return correlation_id


def clear_correlation_id() -> None:
    """Clear correlation ID from current context."""
    _correlation_id_var.set("")
