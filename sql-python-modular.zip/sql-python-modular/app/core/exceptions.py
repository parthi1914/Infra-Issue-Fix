"""
Global exception handling with correlation ID tracking.
Provides base exceptions and error handlers for the application.
"""
from __future__ import annotations

import sys
import traceback
from typing import Any, Optional, Type

from app.core.context import get_correlation_id
from app.core.logging import get_logger


logger = get_logger(__name__)


class AppException(Exception):
    """Base exception for application errors."""

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[dict[str, Any]] = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "APP_ERROR"
        self.details = details or {}
        self.correlation_id = get_correlation_id()

    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary."""
        return {
            "error": self.error_code,
            "message": self.message,
            "correlation_id": self.correlation_id,
            "details": self.details
        }


class DatabaseException(AppException):
    """Database operation errors."""

    def __init__(self, message: str, details: Optional[dict[str, Any]] = None):
        super().__init__(message, error_code="DATABASE_ERROR", details=details)


class AWSServiceException(AppException):
    """AWS service errors."""

    def __init__(self, message: str, service: str, details: Optional[dict[str, Any]] = None):
        details = details or {}
        details["service"] = service
        super().__init__(message, error_code="AWS_SERVICE_ERROR", details=details)


class DataNotFoundException(AppException):
    """Data not found errors."""

    def __init__(self, message: str, details: Optional[dict[str, Any]] = None):
        super().__init__(message, error_code="DATA_NOT_FOUND", details=details)


class ValidationException(AppException):
    """Data validation errors."""

    def __init__(self, message: str, details: Optional[dict[str, Any]] = None):
        super().__init__(message, error_code="VALIDATION_ERROR", details=details)


def setup_exception_handler() -> None:
    """Setup global exception handler for uncaught exceptions."""

    def handle_exception(exc_type: Type[BaseException], exc_value: BaseException, exc_traceback: Any) -> None:
        """Handle uncaught exceptions."""
        # Don't handle KeyboardInterrupt
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return

        correlation_id = get_correlation_id()

        # Log the exception with full traceback
        logger.critical(
            "Uncaught exception",
            exc_info=(exc_type, exc_value, exc_traceback),
            extra={
                "correlation_id": correlation_id,
                "exception_type": exc_type.__name__,
                "exception_message": str(exc_value)
            }
        )

    sys.excepthook = handle_exception
    logger.info("Global exception handler configured")


def log_exception(
    exception: Exception,
    context: Optional[dict[str, Any]] = None,
    reraise: bool = False
) -> None:
    """
    Log an exception with context.

    Args:
        exception: Exception to log
        context: Additional context information
        reraise: Whether to re-raise the exception after logging
    """
    correlation_id = get_correlation_id()

    log_data = {
        "correlation_id": correlation_id,
        "exception_type": type(exception).__name__,
        "exception_message": str(exception),
        **(context or {})
    }

    if isinstance(exception, AppException):
        log_data.update(exception.to_dict())

    logger.error(
        f"Exception occurred: {exception}",
        exc_info=True,
        extra=log_data
    )

    if reraise:
        raise
