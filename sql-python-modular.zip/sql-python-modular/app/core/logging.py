"""
Centralized logging configuration with local and AWS CloudWatch support.
Provides JSON-like format for easy parsing and debugging.
"""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

from pythonjsonlogger import jsonlogger

from app.core.config import get_settings
from app.core.context import get_correlation_id


class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """Custom JSON formatter that adds correlation ID and standard fields."""

    def add_fields(self, log_record: dict[str, Any], record: logging.LogRecord, message_dict: dict[str, Any]) -> None:
        """Add custom fields to log record."""
        super().add_fields(log_record, record, message_dict)

        # Add correlation ID
        log_record["correlation_id"] = get_correlation_id()

        # Add standard fields
        log_record["level"] = record.levelname
        log_record["logger"] = record.name
        log_record["module"] = record.module
        log_record["function"] = record.funcName
        log_record["line"] = record.lineno

        # Add environment info
        settings = get_settings()
        log_record["environment"] = settings.ENVIRONMENT
        log_record["app_name"] = settings.APP_NAME
        log_record["app_version"] = settings.APP_VERSION


def setup_logging() -> logging.Logger:
    """
    Configure logging with local file and AWS CloudWatch support.

    Returns:
        Configured root logger
    """
    settings = get_settings()

    # Create root logger
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, settings.LOG_LEVEL))
    logger.handlers.clear()  # Remove existing handlers

    # JSON formatter for structured logging
    json_formatter = CustomJsonFormatter(
        fmt="%(timestamp)s %(level)s %(message)s %(correlation_id)s",
        datefmt="%Y-%m-%dT%H:%M:%S"
    )

    # Simple formatter for console (more readable)
    console_formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | [%(correlation_id)s] | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # Console handler (always enabled)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO if not settings.DEBUG else logging.DEBUG)
    console_handler.setFormatter(console_formatter)
    console_handler.addFilter(CorrelationIdFilter())
    logger.addHandler(console_handler)

    # Local file handler
    if settings.ENABLE_LOCAL_LOGGING:
        log_file_path = Path(settings.LOG_FILE)
        log_file_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(json_formatter)
        file_handler.addFilter(CorrelationIdFilter())
        logger.addHandler(file_handler)

    # AWS CloudWatch handler
    if settings.ENABLE_AWS_LOGGING:
        try:
            import watchtower
            from app.core.aws import get_boto3_client

            cloudwatch_client = get_boto3_client("logs")

            cloudwatch_handler = watchtower.CloudWatchLogHandler(
                log_group=settings.AWS_LOG_GROUP,
                stream_name=settings.AWS_LOG_STREAM,
                boto3_client=cloudwatch_client,
                send_interval=5,  # Send logs every 5 seconds
                create_log_group=True
            )
            cloudwatch_handler.setLevel(logging.INFO)
            cloudwatch_handler.setFormatter(json_formatter)
            cloudwatch_handler.addFilter(CorrelationIdFilter())
            logger.addHandler(cloudwatch_handler)

            logger.info("AWS CloudWatch logging enabled", extra={
                "log_group": settings.AWS_LOG_GROUP,
                "log_stream": settings.AWS_LOG_STREAM
            })
        except ImportError:
            logger.warning("Watchtower not installed - AWS CloudWatch logging disabled")
        except Exception as e:
            logger.error(f"Failed to setup AWS CloudWatch logging: {e}")

    logger.info("Logging configured", extra={
        "log_level": settings.LOG_LEVEL,
        "local_logging": settings.ENABLE_LOCAL_LOGGING,
        "aws_logging": settings.ENABLE_AWS_LOGGING
    })

    return logger


class CorrelationIdFilter(logging.Filter):
    """Filter that adds correlation ID to log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Add correlation_id to record."""
        record.correlation_id = get_correlation_id()
        return True


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a specific module.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance
    """
    return logging.getLogger(name)


class ActivityLogger:
    """Helper class to log activities with consistent format."""

    def __init__(self, logger: logging.Logger):
        self.logger = logger

    def log_activity(
        self,
        activity: str,
        status: str = "started",
        **kwargs: Any
    ) -> None:
        """
        Log an activity with structured data.

        Args:
            activity: Activity description (e.g., "database_query", "sns_publish")
            status: Activity status (started, completed, failed)
            **kwargs: Additional context
        """
        log_data = {
            "activity": activity,
            "status": status,
            **kwargs
        }

        if status == "failed":
            self.logger.error(f"Activity {activity} failed", extra=log_data)
        elif status == "completed":
            self.logger.info(f"Activity {activity} completed", extra=log_data)
        else:
            self.logger.info(f"Activity {activity} {status}", extra=log_data)
