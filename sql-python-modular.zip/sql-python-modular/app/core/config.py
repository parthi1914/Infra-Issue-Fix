"""
Configuration management - environment-based settings.
Supports local (SQLite) and AWS (CloudWatch, SNS, Postgres) configurations.
"""
from __future__ import annotations

import os
from enum import Enum
from functools import lru_cache

from dotenv import load_dotenv


class Environment(str, Enum):
    """Application environment."""
    LOCAL = "local"
    AWS = "aws"
    TEST = "test"


class Settings:
    """Application configuration - loaded from environment variables."""

    # Environment
    ENVIRONMENT: str = os.getenv("APP_ENV", "local").lower()
    DEBUG: bool = os.getenv("DEBUG", "False").lower() in ("true", "1", "yes")

    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", "logs/app.log")
    ENABLE_LOCAL_LOGGING: bool = os.getenv("ENABLE_LOCAL_LOGGING", "True").lower() in ("true", "1", "yes")
    ENABLE_AWS_LOGGING: bool = os.getenv("ENABLE_AWS_LOGGING", "False").lower() in ("true", "1", "yes")

    # AWS Configuration
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    AWS_LOG_GROUP: str = os.getenv("AWS_LOG_GROUP", "/aws/streamlit/data-observability")
    AWS_LOG_STREAM: str = os.getenv("AWS_LOG_STREAM", "app-stream")
    AWS_SNS_TOPIC_ARN: str = os.getenv("AWS_SNS_TOPIC_ARN", "")

    # Database Configuration
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "sqlite:///./data_observability.db"
    )
    # SQLAlchemy engine settings
    DB_ECHO: bool = os.getenv("DB_ECHO", "False").lower() in ("true", "1", "yes")
    DB_POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", "10"))
    DB_MAX_OVERFLOW: int = int(os.getenv("DB_MAX_OVERFLOW", "20"))

    # Feature Flags
    ENABLE_AUTH: bool = os.getenv("ENABLE_AUTH", "False").lower() in ("true", "1", "yes")
    ENABLE_DUMMY_DATA: bool = os.getenv("ENABLE_DUMMY_DATA", "True").lower() in ("true", "1", "yes")

    # Application
    APP_NAME: str = "Engine Data Observability"
    APP_VERSION: str = "1.0.0"

    # Feature flags for database
    USE_AWS_POSTGRES: bool = os.getenv("USE_AWS_POSTGRES", "False").lower() in ("true", "1", "yes")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Get cached settings instance."""
    load_dotenv()
    return Settings()
