from __future__ import annotations

import pandas as pd

from ..data_simulation import DATA_ELEMENTS, simulate_data_elements_with_values

def build_data_elements_heatmap(df: pd.DataFrame, engine_serial: str, tail_number: str) -> str:
    """Return HTML table with values, status, and clickable cells showing failure reasons."""
    data = simulate_data_elements_with_values(df, engine_serial, tail_number)
    systems = list(data.keys())

    # Build HTML with tooltips
    style = """
    <style>
    .elem-table {font-family: Segoe UI, Arial, sans-serif; border-collapse: collapse; width: 100%; font-size: 11px;}
    .elem-table th, .elem-table td {border: 1px solid #ddd; padding: 8px 10px;}
    .elem-table thead th {background:#2c3e50; color:#fff; position: sticky; top:0; z-index:1; font-weight:600;}
    .elem-pass {background:#e3f9e5; color:#1a7f2b; text-align:center; cursor:pointer; position:relative;}
    .elem-fail {background:#ffe5e0; color:#a31d12; text-align:center; cursor:pointer; position:relative;}
    .elem-name {white-space: nowrap; font-weight:600; color:#333; background:#f8f9fa;}
    .elem-caption {font-size:13px; color:#666; margin:8px 0 12px; font-weight:600;}
    .elem-cell-value {display:block; font-weight:600; font-size:12px;}
    .elem-cell-status {display:block; font-size:10px; opacity:0.8;}
    .elem-table td:hover {filter: brightness(0.95);}
    </style>
    """

    # Header
    header = "<tr><th>Property</th>" + "".join([f"<th>{s}</th>" for s in systems]) + "<th>Expected</th></tr>"
    rows = []

    for element in DATA_ELEMENTS:
        cells = [f"<td class='elem-name'>{element}</td>"]
        expected_val = None
        for system in systems:
            elem_data = data[system][element]
            status = elem_data["status"]
            value = elem_data["value"]
            reason = elem_data["reason"]
            expected_val = elem_data["expected"]

            cls = 'elem-pass' if status == 'Pass' else 'elem-fail'
            tooltip = f"title=\"Value: {value}{'&#10;Reason: ' + reason if reason else ''}\""
            cells.append(f"<td class='{cls}' {tooltip}><span class='elem-cell-value'>{value}</span><span class='elem-cell-status'>{status}</span></td>")

        # Expected column
        cells.append(f"<td style='background:#f0f0f0; text-align:center; font-weight:600; color:#555;'>{expected_val}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")

    html = style + "<div class='elem-caption'> Data Elements Tracking — Hover over cells to see values and failure reasons</div>" + f"<table class='elem-table'><thead>{header}</thead><tbody>{''.join(rows)}</tbody></table>"
    return html
