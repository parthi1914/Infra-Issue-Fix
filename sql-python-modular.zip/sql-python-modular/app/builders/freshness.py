from __future__ import annotations

from datetime import datetime
import plotly.graph_objects as go
import pandas as pd

def freshness_gauge(df: pd.DataFrame, now: datetime) -> go.Figure:
    last_end = df["end_time"].max()
    minutes_old = (now - last_end).total_seconds() / 60.0
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=minutes_old,
        delta={"reference": 60},
        gauge={
            "axis": {"range": [0, 180], "tickwidth": 1, "tickcolor": "#444"},
            "bar": {"color": "#4c78a8"},
            "steps": [
                {"range": [0, 60], "color": "#2ca02c"},
                {"range": [60, 120], "color": "#ff7f0e"},
                {"range": [120, 180], "color": "#d62728"},
            ],
            "threshold": {"line": {"color": "#d62728", "width": 4}, "thickness": 0.75, "value": 150},
        },
        title={"text": "Data Freshness (Minutes Since Last Completion)"},
    ))
    return fig

def build_simple_freshness_card(df: pd.DataFrame, now: datetime) -> str:
    """Simple visual card showing data freshness status."""
    last_end = df["end_time"].max()
    minutes_old = (now - last_end).total_seconds() / 60.0

    if minutes_old < 60:
        status = "FRESH"
        emoji = " "
        color = "#2ca02c"
        bg_color = "#e8f5e9"
        message = "Data is current"
    elif minutes_old < 120:
        status = "AGING"
        emoji = " "
        color = "#ff7f0e"
        bg_color = "#fff8e1"
        message = "Check for delays"
    else:
        status = "STALE"
        emoji = " "
        color = "#d62728"
        bg_color = "#ffebee"
        message = "Needs attention"

    last_update_str = last_end.strftime("%H:%M:%S")

    html = f"""
    <style>
    .freshness-card {{
        background: linear-gradient(135deg, {bg_color} 0%, #ffffff 100%);
        border: 3px solid {color};
        border-radius: 16px;
        padding: 32px;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', Arial, sans-serif;
    }}
    .fresh-emoji {{font-size: 72px; margin: 16px 0;}}
    .fresh-status {{font-size: 42px; font-weight: 800; color: {color}; margin: 8px 0;}}
    .fresh-time {{font-size: 64px; font-weight: 700; color: #333; margin: 16px 0;}}
    .fresh-label {{font-size: 18px; color: #666; margin: 8px 0;}}
    .fresh-message {{font-size: 20px; color: {color}; font-weight: 600; margin-top: 16px;}}
    .fresh-detail {{font-size: 14px; color: #777; margin-top: 12px;}}
    </style>
    <div class='freshness-card'>
        <div class='fresh-emoji'>{emoji}</div>
        <div class='fresh-status'>{status}</div>
        <div class='fresh-time'>{int(minutes_old)} min</div>
        <div class='fresh-label'>Since Last Completion</div>
        <div class='fresh-message'>{message}</div>
        <div class='fresh-detail'>Last updated at {last_update_str}</div>
    </div>
    """
    return html

def build_freshness_timeline(df: pd.DataFrame, now: datetime) -> go.Figure:
    """Simple horizontal timeline showing freshness zones."""
    last_end = df["end_time"].max()
    minutes_old = (now - last_end).total_seconds() / 60.0

    fig = go.Figure()

    # Background zones
    fig.add_shape(type="rect", x0=0, x1=60, y0=0, y1=1, fillcolor="#2ca02c", opacity=0.3, line=dict(width=0))
    fig.add_shape(type="rect", x0=60, x1=120, y0=0, y1=1, fillcolor="#ff7f0e", opacity=0.3, line=dict(width=0))
    fig.add_shape(type="rect", x0=120, x1=180, y0=0, y1=1, fillcolor="#d62728", opacity=0.3, line=dict(width=0))

    # Zone labels
    fig.add_annotation(x=30, y=0.8, text="FRESH", showarrow=False, font=dict(size=16, color="#2ca02c", weight="bold"))
    fig.add_annotation(x=90, y=0.8, text="AGING", showarrow=False, font=dict(size=16, color="#ff7f0e", weight="bold"))
    fig.add_annotation(x=150, y=0.8, text="STALE", showarrow=False, font=dict(size=16, color="#d62728", weight="bold"))

    # Current position marker
    marker_x = min(minutes_old, 180)
    fig.add_shape(type="line", x0=marker_x, x1=marker_x, y0=0, y1=1, line=dict(color="#000", width=4))
    fig.add_annotation(x=marker_x, y=0.5, text=f"{int(minutes_old)} min", showarrow=True, arrowhead=2,
                       arrowsize=1, arrowwidth=2, arrowcolor="#000", font=dict(size=18, color="#000", weight="bold"),
                       bgcolor="#fff", bordercolor="#000", borderwidth=2, borderpad=8)

    fig.update_xaxes(title="Minutes Since Last Completion", range=[0, 180])
    fig.update_yaxes(visible=False, range=[0, 1])
    fig.update_layout(title="Data Freshness Timeline", height=250, margin=dict(l=20, r=20, t=50, b=60))

    return fig
