from __future__ import annotations

from datetime import datetime, timedelta
import pandas as pd
import plotly.graph_objects as go

from ..config import SYSTEM_FLOW, ASSET_SYSTEMS, FLIGHT_SYSTEMS, ENDPOINT_SYSTEMS
from .helpers import classify_status

def build_rich_sla_timeline_improved(df: pd.DataFrame, now: datetime, hours: float = 3.0) -> go.Figure:
    """Improved SLA timeline with hoverable stage markers and status badges."""
    start = now - timedelta(hours=hours)
    total_seconds = hours * 3600
    color_map = {"Pass": "#2ca02c", "Fail": "#d62728", "Pending": "#1f77b4", "Processing": "#1f77b4"}
    icon_map = {s: (" " if s in ASSET_SYSTEMS else " " if s in FLIGHT_SYSTEMS else " ") for s in SYSTEM_FLOW}

    fig = go.Figure()

    # Alternating background bands (30 min) for better readability
    bands = int(hours * 2)
    for i in range(bands):
        band_start = start + timedelta(minutes=30 * i)
        band_end = band_start + timedelta(minutes=30)
        x0 = (band_start - start).total_seconds() / total_seconds
        x1 = (band_end - start).total_seconds() / total_seconds
        shade = "#f5f7fa" if i % 2 == 0 else "#e9eef3"
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0, y1=0.5, fillcolor=shade, line=dict(width=0))
        if band_start.minute == 0:
            fig.add_annotation(x=x0 + 0.002, y=0.53, text=band_start.strftime('%H:%M'), showarrow=False, font=dict(size=10, color="#555"))

    # Stage blocks + invisible scatter for hover tooltips
    hover_x = []
    hover_y = []
    hover_texts = []
    for _, row in df.iterrows():
        mapped = classify_status(row.status)
        color = color_map[mapped]
        # Gradient effect: use two nested rectangles different opacity
        x0 = (row.start_time - start).total_seconds() / total_seconds
        x1 = (row.end_time - start).total_seconds() / total_seconds
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0.08, y1=0.42, fillcolor=color, opacity=0.92, line=dict(color="white", width=2))
        mid = (x0 + x1) / 2
        label = f"{icon_map[row.system]} {row.system}"
        fig.add_annotation(x=mid, y=0.25, text=label, showarrow=False, font=dict(color="white", size=13))
        # Status badge if problematic
        if row.status in {"Delayed", "Error"}:
            badge_color = "#ffbf00" if row.status == "Delayed" else "#d62728"
            fig.add_annotation(x=mid, y=0.07, text=row.status, showarrow=False,
                               font=dict(size=10, color="white"), bgcolor=badge_color)
        # Collect hover data
        dur_min = (row.end_time - row.start_time).total_seconds() / 60.0
        hover_x.append(mid)
        hover_y.append(0.3)
        hover_texts.append(
            f"<b>{row.system}</b><br>Status: {row.status}<br>Start: {row.start_time.strftime('%H:%M:%S')}<br>End: {row.end_time.strftime('%H:%M:%S')}<br>Duration: {dur_min:.1f} min<br>Latency: {row.latency_sec:.2f}s"
        )

    fig.add_trace(go.Scatter(x=hover_x, y=hover_y, mode="markers", marker=dict(size=8, color="rgba(0,0,0,0)"),
                             hovertemplate="%{text}", text=hover_texts, showlegend=False))

    # Current time marker
    now_x = (now - start).total_seconds() / total_seconds
    fig.add_shape(type="line", x0=now_x, x1=now_x, y0=0, y1=0.5, line=dict(color="#ff005e", width=3, dash="dot"))
    fig.add_annotation(x=now_x, y=0.57, text="Now", showarrow=True, arrowhead=2, arrowcolor="#ff005e")

    # ETA final system
    final_end = df.loc[df.system == SYSTEM_FLOW[-1], 'end_time'].iloc[0]
    eta_x = (final_end - start).total_seconds() / total_seconds
    fig.add_annotation(x=eta_x, y=-0.06, text="ETA " + final_end.strftime('%H:%M'), showarrow=False,
                       font=dict(size=12, color="#2ca02c"))

    fig.update_xaxes(visible=False, range=[0, 1])
    fig.update_yaxes(visible=False, range=[0, 0.6])
    fig.update_layout(title="SLA Timeline (Enhanced)", height=260, margin=dict(l=10, r=10, t=65, b=30), plot_bgcolor="#ffffff")
    return fig

def build_dominos_style_tracker_html(df: pd.DataFrame, now: datetime) -> str:
    """Return HTML for a Domino's style progress bar across SYSTEM_FLOW."""
    # Determine current stage index
    ordered = df.sort_values('start_time')
    current_idx = 0
    for i, row in ordered.iterrows():
        if row.status != 'Complete':
            current_idx = i
            break
        current_idx = i

    # Compute intra-stage percent for current segment and global progress fraction
    row = ordered.iloc[current_idx]
    span = (row.end_time - row.start_time).total_seconds()
    intra = 0.0
    if span > 0:
        intra = min(1.0, max(0.0, (now - row.start_time).total_seconds() / span))
    total = len(SYSTEM_FLOW)
    global_progress = ((current_idx) + intra) / total  # continuous fraction 0-1 across whole pipeline
    # Build step HTML
    step_html = []
    total = len(SYSTEM_FLOW)
    for i, r in ordered.iterrows():
        status = r.status
        base_class = 'step'
        if status == 'Complete':
            state_class = 'complete'
        elif status in {'Error'}:
            state_class = 'error'
        elif status in {'Delayed', 'Pending'}:
            state_class = 'pending'
        elif status == 'NotStarted':
            state_class = 'upcoming'
        elif i == current_idx:
            state_class = 'active'
        else:
            state_class = 'upcoming'
        fill_pct = 100 if state_class in {'complete'} else (intra*100 if i == current_idx else 0)
        step_html.append(f"<div class='step-wrap'><div class='{base_class} {state_class}'><div class='fill' style='width:{fill_pct}%;'></div><span class='code'>{r.system}</span></div><div class='label'>{r.system}</div></div>")
        if i < total - 1:
            connector_class = 'connector complete' if state_class == 'complete' else 'connector'
            step_html.append(f"<div class='{connector_class}'></div>")

    # Compute timestamps for display
    start_time = df['start_time'].min()
    end_time = df['end_time'].max()
    elapsed_min = (now - start_time).total_seconds() / 60.0
    remaining_min = max(0, (end_time - now).total_seconds() / 60.0)

    style = """
    <style>
    .tracker {display:flex;align-items:center;justify-content:center;margin:10px 0 30px;font-family:Segoe UI,Arial,sans-serif;}
    .step-wrap {display:flex;flex-direction:column;align-items:center;min-width:60px;}
    .step {position:relative;height:50px;width:60px;border-radius:30px;background:#e0e0e0;overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:600;color:#333;box-shadow:inset 0 0 4px rgba(0,0,0,0.15);}    
    .step.active {background:#1f77b4;color:#fff;}
    .step.complete {background:#2ca02c;color:#fff;}
    .step.pending {background:#1f77b4;color:#fff;}
    .step.error {background:#d62728;color:#fff;animation:pulse 1s infinite;}
    .step.upcoming {background:#d9d9d9;color:#666;}
    .step .fill {position:absolute;left:0;top:0;height:100%;background:rgba(255,255,255,0.25);transition:width 0.6s ease;}
    .connector {height:8px;width:40px;background:#d9d9d9;border-radius:4px;margin:0 4px;box-shadow:inset 0 0 3px rgba(0,0,0,0.2);}    
    .connector.complete {background:#2ca02c;}
    .label {margin-top:6px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:0.5px;}
    .smooth-track-wrapper {width:100%;display:flex;justify-content:center;position:relative;}
    .smooth-track {position:relative;width:92%;height:12px;background:#d9d9d9;border-radius:8px;overflow:hidden;margin:0 auto 18px auto;box-shadow:inset 0 0 4px rgba(0,0,0,0.25);}
    .smooth-track .bar {position:absolute;left:0;top:0;height:100%;background:linear-gradient(90deg,#1f77b4 0%, #2ca02c 85%);width:0%;transition:width 1.2s cubic-bezier(.25,.8,.25,1);box-shadow:0 0 4px rgba(0,0,0,0.2);}    
    .time-label {position:absolute;font-size:11px;color:#666;font-weight:600;top:-20px;}
    .time-label.start {left:4%;}
    .time-label.eta {right:4%;}
    .progress-meta {text-align:center;font-size:12px;color:#444;margin-top:4px;}
    @keyframes pulse {0%{filter:brightness(1);}50%{filter:brightness(1.3);}100%{filter:brightness(1);}}
    @media (max-width:1100px){.step{width:46px;height:46px}.connector{width:28px} .label{font-size:9px}}
    </style>
    """
    bar_width_pct = f"{global_progress*100:.3f}%"
    start_label = f"<div class='time-label start'>Start: {start_time.strftime('%H:%M')}</div>"
    eta_label = f"<div class='time-label eta'>ETA: {end_time.strftime('%H:%M')}</div>"
    progress_note = f"<div class='progress-meta'>Current Stage: <b>{row.system}</b> &nbsp;•&nbsp; Stage Progress {intra*100:.0f}% &nbsp;•&nbsp; Overall {global_progress*100:.1f}% &nbsp;•&nbsp; Elapsed {elapsed_min:.0f}m &nbsp;•&nbsp; Remaining ~{remaining_min:.0f}m</div>"
    smooth_track = f"<div class='smooth-track-wrapper'>{start_label}{eta_label}<div class='smooth-track'><div class='bar' style='width:{bar_width_pct};'></div></div></div>"
    html = style + smooth_track + "<div class='tracker'>" + ''.join(step_html) + "</div>" + progress_note
    return html

def build_sla_dominos_html(df: pd.DataFrame, now: datetime, hours: float = 3.0) -> str:
    """Styled SLA tracker similar to Domino's bar with time gradient and badges."""
    start = now - timedelta(hours=hours)
    total_seconds = hours * 3600
    # Determine pass/at-risk/fail based on final completion window
    last_end = df.end_time.max()
    freshness_min = (now - last_end).total_seconds() / 60.0
    freshness_state = "ok" if freshness_min < 60 else ("risk" if freshness_min < 120 else "fail")

    segments_html = []
    for i, row in df.iterrows():
        status = row.status
        if status == "Complete":
            cls = "pass"
        elif status == "Error":
            cls = "fail"
        elif status in {"Delayed", "Pending"}:
            cls = "pending"
        elif status == "NotStarted":
            cls = "upcoming"
        else:
            cls = "processing"
        icon = " " if row.system in ASSET_SYSTEMS else (" " if row.system in FLIGHT_SYSTEMS else " ")
        segments_html.append(f"<div class='sla-segment {cls}' style='flex:1'><div class='inner'><span>{icon} {row.system}</span><small>{row.status}</small></div></div>")
        if i < len(df) - 1:
            segments_html.append("<div class='sla-gap'></div>")

    style = """
    <style>
    .sla-bar {display:flex;align-items:stretch;gap:6px;margin:12px 0;font-family:Segoe UI,Arial,sans-serif;}
    .sla-segment {position:relative;background:#d9d9d9;border-radius:14px;min-height:70px;display:flex;align-items:center;justify-content:center;box-shadow:inset 0 0 4px rgba(0,0,0,0.15);}    
    .sla-segment.pass {background:linear-gradient(135deg,#2ca02c,#45c842);}    
    .sla-segment.processing {background:linear-gradient(135deg,#1f77b4,#3a92d0);}    
    .sla-segment.pending {background:linear-gradient(135deg,#1f77b4,#3a92d0);}    
    .sla-segment.fail {background:linear-gradient(135deg,#d62728,#f04141);}    
    .sla-segment.upcoming {background:#d9d9d9;color:#666;}    
    .sla-segment .inner {text-align:center;color:#fff;font-weight:600;font-size:15px;}
    .sla-segment .inner small {display:block;font-size:11px;font-weight:500;opacity:0.85;}
    .sla-gap {width:10px;height:8px;background:#e0e0e0;border-radius:4px;align-self:center;box-shadow:inset 0 0 3px rgba(0,0,0,0.2);}    
    .freshness-pill {display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;margin-top:4px;}    
    .freshness-pill.ok {background:#2ca02c;} .freshness-pill.risk {background:#ffbf00;color:#222;} .freshness-pill.fail {background:#d62728;}    
    </style>
    """
    freshness_label = f"Freshness {freshness_min:.0f}m" + (" (OK)" if freshness_state=='ok' else " (Risk)" if freshness_state=='risk' else " (Late)")
    pill = f"<div class='freshness-pill {freshness_state}'>{freshness_label}</div>"
    html = style + "<div class='sla-bar'>" + ''.join(segments_html) + "</div>" + pill
    return html
