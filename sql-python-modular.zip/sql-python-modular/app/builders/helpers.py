from __future__ import annotations

from datetime import datetime, timedelta
import random

import pandas as pd

from ..config import SYSTEM_FLOW

def classify_status(status: str) -> str:
    if status == "Complete":
        return "Pass"
    if status == "Error":
        return "Fail"
    if status in {"Pending", "Delayed"}:
        return "Pending"
    if status == "NotStarted":
        return "Pending"  # treat upcoming as pending for summary metrics
    return "Processing"

def build_status_summary(df: pd.DataFrame) -> pd.DataFrame:
    mapped = df.status.apply(classify_status)
    vc = mapped.value_counts()
    vc = vc.reindex(["Fail", "Pass", "Pending", "Processing"], fill_value=0)
    summary = vc.reset_index(name="count")
    summary.rename(columns={"index": "category"}, inplace=True)
    summary = summary.astype({"count": int})
    # Ensure expected columns even if rename fails for any reason
    if list(summary.columns) != ["category", "count"]:
        summary.columns = ["category", "count"]
    return summary

def build_population_pies(df: pd.DataFrame) -> list:
    import plotly.graph_objects as go
    pies = []
    for system in SYSTEM_FLOW:
        # Synthetic population proportion: assume some % of expected fields present
        completeness = random.uniform(0.8, 0.97)
        missing = 1 - completeness
        fig = go.Figure(data=[go.Pie(labels=["Present", "Missing"], values=[completeness, missing], hole=0.55)])
        fig.update_layout(title=f"{system}", margin=dict(l=0, r=0, t=35, b=0), showlegend=False)
        pies.append(fig)
    return pies

def build_last_updated_table(df: pd.DataFrame) -> pd.DataFrame:
    return df[["system", "end_time"]].rename(columns={"end_time": "last_updated"}).assign(
        last_updated=lambda d: d.last_updated.dt.strftime("%Y-%m-%d %H:%M:%S")
    )

def fake_root_cause_panel() -> pd.DataFrame:
    data = {
        "Root Cause (Auto Detected)": [
            "Invalid configuration mapping for several tails",
            "Diagnostic parsing queue backlog",
            "Field data contract mismatch"
        ],
        "Current Disruptions": [
            "Missed SLA for 5 flights today",
            "Delayed health diagnostics (Avg +28 min)",
            "Customer support tickets raised"
        ],
        "Action & Governance": [
            "Engage process owner + data team",
            "Re-queue parsing; scale workers",
            "Track MTTR & prevent repeats"
        ]
    }
    return pd.DataFrame(data)

def build_error_notifications(df: pd.DataFrame, now: datetime) -> str:
    """Generate error notification panel HTML when errors are detected."""
    error_systems = df[df.status == "Error"]
    if len(error_systems) == 0:
        return ""

    # System to team mapping
    team_map = {
        "1FA": "Product Configuration Team",
        "IFS": "Enterprise Asset Team",
        "FDM": "Flight Data Operations",
        "1FDI": "Data Integration Team",
        "PHM": "PHM Analytics Team",
        "SOAR": "SOAR Operations Team",
        "RDF": "Reporting & Decoding Team",
        "FMX": "Customer Experience Team"
    }

    notifications_html = []
    for _, row in error_systems.iterrows():
        system = row.system
        team = team_map.get(system, "Operations Team")
        # Notification sent shortly after error detected (simulate 2-5 min after error start)
        notification_time = row.start_time + timedelta(minutes=random.randint(2, 5))
        time_ago = (now - notification_time).total_seconds() / 60.0

        error_details = [
            f"System: {system}",
            f"Records Affected: {int(row.records):,}",
            f"Data Size: {row.data_size_mb:.2f} MB",
            f"Latency Spike: {row.latency_sec:.2f}s"
        ]

        details_list = ''.join([f'<li>{d}</li>' for d in error_details])
        notif_time_str = notification_time.strftime('%Y-%m-%d %H:%M:%S')

        notifications_html.append(f"""<div class='error-notification'>
<div class='notif-header'>
<span class='notif-icon'> </span>
<span class='notif-title'>Error Alert: {system}</span>
</div>
<div class='notif-body'>
<div class='notif-row'><strong>Notified Team:</strong> {team}</div>
<div class='notif-row'><strong>Notification Sent:</strong> {notif_time_str} ({time_ago:.0f} min ago)</div>
<div class='notif-row'><strong>Error Details:</strong></div>
<ul class='notif-details'>{details_list}</ul>
<div class='notif-status'>Status: <span class='status-badge investigating'>Team Investigating</span></div>
</div>
</div>""")

    style = """
    <style>
    .error-notification {border:2px solid #d62728;border-radius:12px;background:#fff5f5;padding:16px;margin:12px 0;font-family:Segoe UI,Arial,sans-serif;box-shadow:0 2px 8px rgba(214,39,40,0.15);}
    .notif-header {display:flex;align-items:center;gap:10px;margin-bottom:12px;border-bottom:1px solid #ffcccc;padding-bottom:8px;}
    .notif-icon {font-size:24px;}
    .notif-title {font-size:18px;font-weight:700;color:#d62728;}
    .notif-body {font-size:14px;color:#333;}
    .notif-row {margin:6px 0;}
    .notif-details {margin:8px 0;padding-left:20px;color:#555;}
    .notif-details li {margin:4px 0;}
    .notif-status {margin-top:12px;padding-top:8px;border-top:1px solid #ffcccc;font-weight:600;}
    .status-badge {display:inline-block;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:600;}
    .status-badge.investigating {background:#ff7f0e;color:#fff;}
    </style>
    """

    return style + ''.join(notifications_html)
