from __future__ import annotations

import plotly.express as px
import plotly.graph_objects as go
import networkx as nx
import pandas as pd

from ..config import SYSTEM_FLOW, ASSET_SYSTEMS, FLIGHT_SYSTEMS, ENDPOINT_SYSTEMS, STATUS_COLOR_MAP

def build_timeline(df: pd.DataFrame) -> go.Figure:
    df_sorted = df.sort_values("start_time")
    fig = px.timeline(
        df_sorted,
        x_start="start_time",
        x_end="end_time",
        y="system",
        color="status",
        hover_data=["latency_sec", "records", "data_size_mb"],
        title="Data Processing Timeline Across Systems",
        color_discrete_map=STATUS_COLOR_MAP
    )
    fig.update_yaxes(autorange="reversed")
    return fig

def build_sankey(df: pd.DataFrame) -> go.Figure:
    # Build Sankey based on SYSTEM_FLOW order
    sources = []
    targets = []
    values = []
    labels = SYSTEM_FLOW
    system_to_index = {s: i for i, s in enumerate(labels)}

    for i in range(len(SYSTEM_FLOW) - 1):
        s = SYSTEM_FLOW[i]
        t = SYSTEM_FLOW[i + 1]
        s_records = int(df.loc[df.system == s, "records"].iloc[0])
        sources.append(system_to_index[s])
        targets.append(system_to_index[t])
        values.append(s_records)

    colors = [
        "#4c78a8" if l in ASSET_SYSTEMS
        else "#f58518" if l in FLIGHT_SYSTEMS
        else "#2ca02c" if l in ENDPOINT_SYSTEMS
        else "#999999"
        for l in labels
    ]

    node = dict(pad=20, thickness=20, label=labels, color=colors)
    link = dict(source=sources, target=targets, value=values)
    fig = go.Figure(go.Sankey(node=node, link=link))
    fig.update_layout(title_text="Data Flow (Record Counts) Sankey", font_size=12)
    return fig

def build_network_graph(df: pd.DataFrame) -> go.Figure:
    G = nx.DiGraph()
    for system in SYSTEM_FLOW:
        status = df.loc[df.system == system, "status"].iloc[0]
        G.add_node(system, status=status)
    for i in range(len(SYSTEM_FLOW) - 1):
        G.add_edge(SYSTEM_FLOW[i], SYSTEM_FLOW[i + 1])

    pos = nx.spring_layout(G, seed=42)
    edge_x = []
    edge_y = []
    for edge in G.edges():
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_x += [x0, x1, None]
        edge_y += [y0, y1, None]

    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=2, color="#888"),
        hoverinfo="none",
        mode="lines"
    )

    node_x = []
    node_y = []
    texts = []
    colors = []
    for node, data in G.nodes(data=True):
        x, y = pos[node]
        node_x.append(x)
        node_y.append(y)
        status = data["status"]
        texts.append(f"{node}<br>Status: {status}")
        colors.append(STATUS_COLOR_MAP.get(status, "#1f77b4"))

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=[n for n in G.nodes()],
        textposition="bottom center",
        hovertext=texts,
        hoverinfo="text",
        marker=dict(
            showscale=False,
            color=colors,
            size=28,
            line=dict(width=2, color="white")
        )
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        title="System Path Network Graph",
        showlegend=False,
        margin=dict(l=20, r=20, t=50, b=20),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    return fig

def build_latency_chart(df: pd.DataFrame) -> go.Figure:
    fig = px.bar(
        df,
        x="system",
        y="latency_sec",
        color="status",
        title="Per-System Latency (seconds)",
        hover_data=["records", "data_size_mb"],
        color_discrete_map=STATUS_COLOR_MAP,
    )
    fig.update_layout(xaxis_title="System", yaxis_title="Latency (s)")
    return fig
