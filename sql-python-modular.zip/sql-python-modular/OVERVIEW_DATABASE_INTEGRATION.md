# Overview Screen - Database Integration Reference Guide

**Complete guide for connecting Overview screen to AWS PostgreSQL database**

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Database Requirements](#database-requirements)
4. [Configuration Steps](#configuration-steps)
5. [Code Changes](#code-changes)
6. [SQL Queries Reference](#sql-queries-reference)
7. [Testing & Verification](#testing--verification)
8. [Troubleshooting](#troubleshooting)
9. [Rollback Instructions](#rollback-instructions)

---

## Overview

### What This Document Covers

This guide explains how to connect the Overview screen from **dummy JSON data** to **real AWS PostgreSQL database** with complex SQL queries including JOINs, aggregations, and time calculations.

### Current Status

```
📊 Implementation Status: ✅ COMPLETE (Currently DISABLED)

✅ Models Created:      app/models/existing_tables.py (7 models)
✅ Queries Written:     app/services/data_service.py (6 methods)
✅ Integration Ready:   app/components/tabs/overview.py (commented out)
⚠️  Database Setup:     Required (your AWS RDS PostgreSQL)
⚠️  Enabled:            NO (using dummy data)
```

### What Will Change

| Component | Before (Dummy Data) | After (Real Database) |
|-----------|--------------------|-----------------------|
| **Data Source** | JSON file (`data/dummy_events.json`) | AWS PostgreSQL (RDS) |
| **Status Counts** | Random simulation | Real event counts with CASE statement |
| **Data Population** | Random percentages | Real AVG from LEFT JOIN |
| **SLA Timeline** | Simulated events | Real events with time calculations |
| **Error Notifications** | Fake errors | Real errors from INNER JOIN |
| **Last Updated** | Simulated times | Real MAX(end_time) from database |

---

## Architecture

### Data Flow: Overview → Database → Display

```
┌─────────────────────────────────────────────────────────────────┐
│  USER INTERACTION                                                │
│  User opens Overview tab → Streamlit loads overview.py          │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  OVERVIEW COMPONENT (app/components/tabs/overview.py)           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 1. Get DataService from DI container                      │  │
│  │    data_service = inject("data_service")                  │  │
│  │                                                            │  │
│  │ 2. Call get_overview_data()                               │  │
│  │    overview_data = data_service.get_overview_data(        │  │
│  │        engine_serial="000000", hours=24                   │  │
│  │    )                                                       │  │
│  │                                                            │  │
│  │ 3. Extract DataFrames                                     │  │
│  │    status_summary = overview_data['status_summary']       │  │
│  │    data_population_df = overview_data['data_population']  │  │
│  └──────────────────────────────────────────────────────────┘  │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  DATA SERVICE (app/services/data_service.py)                    │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ get_overview_data() orchestrates 5 query methods:        │  │
│  │                                                            │  │
│  │ 1. get_status_summary()        ← CASE, GROUP BY          │  │
│  │ 2. get_data_population()       ← LEFT JOIN, AVG          │  │
│  │ 3. get_sla_timeline()          ← LEFT JOIN, EXTRACT      │  │
│  │ 4. get_error_notifications()   ← INNER JOIN (multiple)   │  │
│  │ 5. get_last_updated()          ← MAX aggregation         │  │
│  │                                                            │  │
│  │ Each method:                                              │  │
│  │ • Builds SQL query string with JOINs                      │  │
│  │ • Gets database session                                   │  │
│  │ • Executes via pd.read_sql()                              │  │
│  │ • Returns pandas DataFrame                                │  │
│  │ • Logs activity with correlation ID                       │  │
│  └──────────────────────────────────────────────────────────┘  │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  DATABASE SERVICE (app/core/database.py)                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ • Creates SQLAlchemy engine                               │  │
│  │ • Manages connection pool (10 connections)                │  │
│  │ • Provides session context manager                        │  │
│  │ • Auto commit/rollback                                    │  │
│  │                                                            │  │
│  │ with db_service.get_session() as session:                 │  │
│  │     # Query executes here                                 │  │
│  │     # Auto-commits on success                             │  │
│  │     # Auto-rollback on error                              │  │
│  └──────────────────────────────────────────────────────────┘  │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  AWS RDS POSTGRESQL DATABASE                                    │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Tables Used:                                              │  │
│  │                                                            │  │
│  │ • events            (main table)                          │  │
│  │ • data_elements     (completeness scores)                 │  │
│  │ • sla_targets       (SLA expectations)                    │  │
│  │ • error_logs        (error details)                       │  │
│  │ • engines           (engine metadata)                     │  │
│  │                                                            │  │
│  │ PostgreSQL executes:                                      │  │
│  │ • JOINs (INNER, LEFT)                                     │  │
│  │ • Aggregations (COUNT, AVG, MAX)                          │  │
│  │ • GROUP BY                                                │  │
│  │ • CASE statements                                         │  │
│  │ • Time calculations (EXTRACT, INTERVAL)                   │  │
│  │                                                            │  │
│  │ Returns: Result rows                                      │  │
│  └──────────────────────────────────────────────────────────┘  │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  PANDAS DATAFRAMES                                               │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ pd.read_sql() converts SQL results to DataFrames:        │  │
│  │                                                            │  │
│  │ status_summary:        category | count                  │  │
│  │                        Fail      | 12                     │  │
│  │                        Pass      | 45                     │  │
│  │                                                            │  │
│  │ data_population:       system | completeness_pct         │  │
│  │                        1FA    | 98.2                      │  │
│  │                        IFS    | 95.7                      │  │
│  └──────────────────────────────────────────────────────────┘  │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  STREAMLIT VISUALIZATION                                         │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ • Status cards (st.metric)                                │  │
│  │ • Pie charts (st.plotly_chart)                            │  │
│  │ • SLA timeline (st.markdown with HTML)                    │  │
│  │ • Error notifications (st.components.v1.html)             │  │
│  │ • Last updated table (st.dataframe)                       │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### Key Components

| Component | File | Purpose |
|-----------|------|---------|
| **Models** | `app/models/existing_tables.py` | SQLAlchemy models (schema documentation) |
| **Data Service** | `app/services/data_service.py` | Query methods with SQL JOINs |
| **Database Service** | `app/core/database.py` | Connection pooling, session management |
| **Overview UI** | `app/components/tabs/overview.py` | Visualization and display |
| **Configuration** | `.env` | Database connection string |

---

## Database Requirements

### Required Tables

Your PostgreSQL database **must have** these tables:

#### 1. `events` Table (CRITICAL - Required)

```sql
CREATE TABLE events (
    id SERIAL PRIMARY KEY,
    event_id VARCHAR(100) UNIQUE NOT NULL,
    engine_serial VARCHAR(50) NOT NULL,
    system_name VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    error_message TEXT,
    records INTEGER,
    data_size_mb DECIMAL(10,2),
    latency_sec DECIMAL(10,3)
);

-- Required indexes for performance
CREATE INDEX idx_events_engine_serial ON events(engine_serial);
CREATE INDEX idx_events_start_time ON events(start_time);
CREATE INDEX idx_events_status ON events(status);
CREATE INDEX idx_events_system_name ON events(system_name);
```

**Used For:**
- Status summary (Fail/Pass/Pending/Processing counts)
- SLA timeline
- All queries filter by `engine_serial` and `start_time`

#### 2. `data_elements` Table (Recommended)

```sql
CREATE TABLE data_elements (
    element_id SERIAL PRIMARY KEY,
    event_id VARCHAR(100) REFERENCES events(event_id),
    element_name VARCHAR(100),
    is_present BOOLEAN,
    completeness_score DECIMAL(5,4),  -- 0.0000 to 1.0000
    quality_score DECIMAL(5,4)
);

-- Index for JOIN performance
CREATE INDEX idx_data_elements_event_id ON data_elements(event_id);
```

**Used For:**
- Data population pie charts (completeness %)
- LEFT JOIN with events table

#### 3. `sla_targets` Table (Optional)

```sql
CREATE TABLE sla_targets (
    id SERIAL PRIMARY KEY,
    system_name VARCHAR(50) UNIQUE NOT NULL,
    expected_duration_minutes INTEGER NOT NULL,
    sla_threshold INTEGER
);

-- Sample data
INSERT INTO sla_targets (system_name, expected_duration_minutes) VALUES
    ('1FA', 2),
    ('IFS', 3),
    ('FDM', 5),
    ('1FDI', 4);
```

**Used For:**
- SLA breach detection
- LEFT JOIN to compare actual duration vs expected

#### 4. `error_logs` Table (Optional)

```sql
CREATE TABLE error_logs (
    error_id SERIAL PRIMARY KEY,
    event_id VARCHAR(100) REFERENCES events(event_id),
    error_severity VARCHAR(20),
    notified_team VARCHAR(100),
    notification_sent_at TIMESTAMP
);

-- Index for JOIN
CREATE INDEX idx_error_logs_event_id ON error_logs(event_id);
```

**Used For:**
- Error notification panel
- INNER JOIN to get only events with errors

#### 5. `engines` Table (Optional)

```sql
CREATE TABLE engines (
    id SERIAL PRIMARY KEY,
    serial_number VARCHAR(50) UNIQUE NOT NULL,
    model VARCHAR(100),
    status VARCHAR(50)
);
```

**Used For:**
- Engine model details in error notifications
- INNER JOIN with error_logs

### Minimum Requirements

**To enable Overview with real data, you MUST have:**
- ✅ `events` table with columns: `event_id`, `engine_serial`, `system_name`, `status`, `start_time`, `end_time`

**Optional but recommended:**
- ⚠️ `data_elements` table (for data population pie charts)
- ⚠️ `sla_targets` table (for SLA timeline)
- ⚠️ `error_logs` table (for error notifications)

**If optional tables missing:**
- LEFT JOINs will return NULL for missing data
- Queries will still work, but some metrics won't display

---

## Configuration Steps

### Step 1: Get AWS RDS Connection Details

#### 1.1 Find Your RDS Endpoint

```bash
# AWS Console Path:
AWS Console → RDS → Databases → [Your Database] → Connectivity & Security

# You'll see:
Endpoint:  mydb.abc123def456.us-east-1.rds.amazonaws.com
Port:      5432
```

#### 1.2 Gather Connection Information

You need 5 pieces of information:

| Parameter | AWS Location | Example |
|-----------|-------------|---------|
| **Host** | RDS Endpoint (without :5432) | `mydb.abc123.us-east-1.rds.amazonaws.com` |
| **Port** | Usually 5432 | `5432` |
| **Database** | DB Configuration → DB Name | `aviation_db` |
| **Username** | Configuration → Master username | `admin` |
| **Password** | Set during RDS creation | `YourPassword123!` |

#### 1.3 Verify RDS Security Group

**Ensure your IP can connect:**

```bash
# AWS Console:
RDS → Your DB → Connectivity & Security → Security Group → Inbound Rules

# Add rule if needed:
Type:       PostgreSQL
Protocol:   TCP
Port:       5432
Source:     Your IP (e.g., 203.0.113.25/32) or 0.0.0.0/0 (all - less secure)
```

#### 1.4 Ensure Public Accessibility

```bash
# AWS Console:
RDS → Your DB → Connectivity & Security → Public Accessibility

# Should be: Yes
```

---

### Step 2: Create .env File

#### 2.1 Create File

**Location:** Project root directory

```bash
# Create .env file (if doesn't exist)
touch .env
```

#### 2.2 Add Configuration

**File:** `.env`

```bash
# =============================================================================
# DATABASE CONFIGURATION
# =============================================================================

# CRITICAL: Set to false to use real PostgreSQL
ENABLE_DUMMY_DATA=false

# PostgreSQL Connection String
# Format: postgresql://username:password@host:port/database
DATABASE_URL=postgresql://admin:YourPassword123@mydb.abc123.us-east-1.rds.amazonaws.com:5432/aviation_db

# REPLACE WITH YOUR ACTUAL VALUES:
# DATABASE_URL=postgresql://YOUR_USERNAME:YOUR_PASSWORD@YOUR_RDS_ENDPOINT:5432/YOUR_DATABASE

# =============================================================================
# AWS CONFIGURATION (Optional)
# =============================================================================

# Enable AWS CloudWatch logging (optional)
ENABLE_AWS_LOGGING=false

# AWS Region (must match your RDS region)
AWS_REGION=us-east-1

# CloudWatch settings (only if ENABLE_AWS_LOGGING=true)
AWS_LOG_GROUP=/aws/streamlit/aviation
AWS_LOG_STREAM=production

# =============================================================================
# APPLICATION SETTINGS
# =============================================================================

# Environment
ENVIRONMENT=production

# Application name
APP_NAME=Aviation-Dashboard
```

#### 2.3 Connection String Format

**General Format:**
```
postgresql://[username]:[password]@[host]:[port]/[database]
```

**Examples:**

```bash
# AWS RDS
DATABASE_URL=postgresql://admin:Pass123@mydb.abc123.us-east-1.rds.amazonaws.com:5432/aviation_db

# AWS RDS with SSL
DATABASE_URL=postgresql://admin:Pass123@mydb.abc123.us-east-1.rds.amazonaws.com:5432/aviation_db?sslmode=require

# Local PostgreSQL
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/mydb

# Special characters in password (URL encode)
# If password is: pass@word! → encode as: pass%40word%21
DATABASE_URL=postgresql://user:pass%40word%21@host:5432/db
```

#### 2.4 URL Encoding for Special Characters

If your password contains special characters, URL-encode them:

| Character | URL Encoded |
|-----------|-------------|
| `@` | `%40` |
| `:` | `%3A` |
| `/` | `%2F` |
| `?` | `%3F` |
| `#` | `%23` |
| `&` | `%26` |
| `=` | `%3D` |
| `+` | `%2B` |
| ` ` (space) | `%20` |

**Example:**
```bash
# Original password: MyPass@2024!
# Encoded password:  MyPass%402024%21

DATABASE_URL=postgresql://admin:MyPass%402024%21@host:5432/db
```

---

### Step 3: Test Database Connection

#### 3.1 Create Test Script

**File:** `test_connection.py` (project root)

```python
"""Test PostgreSQL database connection."""
import os
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get connection string
DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    print("❌ DATABASE_URL not found in .env file!")
    exit(1)

# Hide password in output
safe_url = DATABASE_URL.split('@')[1] if '@' in DATABASE_URL else DATABASE_URL
print(f"Testing connection to: {safe_url}\n")

try:
    # Create engine
    engine = create_engine(DATABASE_URL, echo=False)

    # Test connection
    with engine.connect() as conn:
        # Get PostgreSQL version
        result = conn.execute(text("SELECT version()"))
        version = result.fetchone()[0]
        print("✅ Connection successful!")
        print(f"   PostgreSQL version: {version[:50]}...\n")

        # List all tables
        result = conn.execute(text("""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            ORDER BY table_name
        """))
        tables = [row[0] for row in result.fetchall()]

        if tables:
            print(f"✅ Found {len(tables)} table(s):")
            for table in tables:
                print(f"   • {table}")
        else:
            print("⚠️  No tables found in database")

        print()

        # Check for required 'events' table
        if 'events' in tables:
            print("✅ Required 'events' table found!")

            # Count events
            result = conn.execute(text("SELECT COUNT(*) FROM events"))
            count = result.fetchone()[0]
            print(f"   Events count: {count:,} rows")

            # Check columns
            result = conn.execute(text("""
                SELECT column_name, data_type
                FROM information_schema.columns
                WHERE table_name = 'events'
                ORDER BY ordinal_position
            """))
            columns = result.fetchall()
            print(f"   Columns ({len(columns)}):")
            for col_name, col_type in columns[:10]:  # Show first 10
                print(f"      - {col_name}: {col_type}")

        else:
            print("❌ Required 'events' table NOT found!")
            print("   Create it or check table name in your database")

        print()

        # Check optional tables
        optional_tables = ['data_elements', 'sla_targets', 'error_logs', 'engines']
        print("Optional tables:")
        for table in optional_tables:
            if table in tables:
                result = conn.execute(text(f"SELECT COUNT(*) FROM {table}"))
                count = result.fetchone()[0]
                print(f"   ✅ {table}: {count:,} rows")
            else:
                print(f"   ⚠️  {table}: Not found (queries will still work with NULL)")

        print("\n" + "="*60)
        print("✅ DATABASE CONNECTION TEST PASSED!")
        print("="*60)

except Exception as e:
    print(f"❌ Connection failed!")
    print(f"   Error: {e}\n")
    print("Troubleshooting:")
    print("1. Check DATABASE_URL in .env file")
    print("2. Verify RDS security group allows your IP")
    print("3. Confirm RDS is publicly accessible")
    print("4. Check username and password are correct")
    print("5. Ensure database name matches")
    exit(1)
```

#### 3.2 Run Test

```bash
# Install required packages (if not already installed)
pip install sqlalchemy psycopg2-binary python-dotenv

# Run test
python test_connection.py
```

#### 3.3 Expected Output

```
Testing connection to: mydb.abc123.us-east-1.rds.amazonaws.com:5432/aviation_db

✅ Connection successful!
   PostgreSQL version: PostgreSQL 14.7 on x86_64-pc-linux-gnu, compiled...

✅ Found 5 table(s):
   • data_elements
   • engines
   • error_logs
   • events
   • sla_targets

✅ Required 'events' table found!
   Events count: 1,523 rows
   Columns (11):
      - id: integer
      - event_id: character varying
      - engine_serial: character varying
      - system_name: character varying
      - status: character varying
      - start_time: timestamp without time zone
      - end_time: timestamp without time zone
      - error_message: text
      - records: integer
      - data_size_mb: numeric
      - latency_sec: numeric

Optional tables:
   ✅ data_elements: 4,256 rows
   ✅ sla_targets: 8 rows
   ✅ error_logs: 47 rows
   ✅ engines: 12 rows

============================================================
✅ DATABASE CONNECTION TEST PASSED!
============================================================
```

---

## Code Changes

### File 1: app/components/tabs/overview.py

#### Change 1.1: Uncomment Import (Line 9)

**Before:**
```python
# from ...core.di import inject  # Uncomment when enabling real data
```

**After:**
```python
from ...core.di import inject  # Real data enabled
```

#### Change 1.2: Uncomment Real Data Section (Lines 25-41)

**Before:**
```python
# # Get data service from DI container
# data_service = inject("data_service")
#
# # Fetch all Overview metrics from real database using JOIN queries
# overview_data = data_service.get_overview_data(
#     engine_serial=engine_serial,
#     hours=int(window_hours)
# )
#
# # Extract individual metrics from overview_data
# status_summary = overview_data['status_summary']
# # data_population_df = overview_data['data_population']
```

**After:**
```python
# Get data service from DI container
data_service = inject("data_service")

# Fetch all Overview metrics from real database using JOIN queries
overview_data = data_service.get_overview_data(
    engine_serial=engine_serial,
    hours=int(window_hours)
)

# Extract individual metrics from overview_data
status_summary = overview_data['status_summary']
data_population_df = overview_data['data_population']
sla_timeline_df = overview_data['sla_timeline']
error_notifications_df = overview_data['error_notifications']
last_updated_df = overview_data['last_updated']
```

#### Change 1.3: Comment Out Dummy Data (Lines 50-54)

**Before:**
```python
status_summary = build_status_summary(df)
population_pies = build_population_pies(df)
last_updated_table = build_last_updated_table(df)
governance_df = fake_root_cause_panel()
sla_html_tracker = build_sla_dominos_html(df, now, hours=window_hours)
```

**After:**
```python
# status_summary = build_status_summary(df)  # Using real data now
# population_pies = build_population_pies(df)  # Will build from real data
# last_updated_table = build_last_updated_table(df)  # Using real data
governance_df = fake_root_cause_panel()  # Keep for now (not in database)
# sla_html_tracker = build_sla_dominos_html(df, now, hours=window_hours)  # Using real data
```

#### Change 1.4: Add Real Data Visualization Builders (After line 54)

**Add this code:**

```python
# ========================================================================
# BUILD VISUALIZATIONS FROM REAL DATABASE DATA
# ========================================================================

import plotly.graph_objects as go

# Build population pie charts from real data
population_pies = []
if not data_population_df.empty:
    for _, row in data_population_df.iterrows():
        completeness = row['completeness_pct'] / 100.0 if pd.notna(row['completeness_pct']) else 0
        missing = 1 - completeness

        fig = go.Figure(data=[go.Pie(
            labels=["Present", "Missing"],
            values=[completeness, missing],
            hole=0.55,
            marker=dict(colors=['#2ca02c', '#d62728'])
        )])
        fig.update_layout(
            title=f"{row['system_name']} ({completeness*100:.1f}%)",
            margin=dict(l=0, r=0, t=35, b=0),
            showlegend=False,
            height=200
        )
        population_pies.append(fig)
else:
    # Fallback if no data
    st.warning("No data population metrics available")

# Use real last updated data
last_updated_table = last_updated_df if not last_updated_df.empty else pd.DataFrame({'message': ['No data']})

# Build SLA tracker from real data (reuse existing builder if compatible)
if not sla_timeline_df.empty:
    sla_html_tracker = build_sla_dominos_html(sla_timeline_df, now, hours=window_hours)
else:
    sla_html_tracker = "<div>No SLA data available</div>"
```

---

### File 2: .env (Configuration)

**Create or update:**

```bash
# Database
ENABLE_DUMMY_DATA=false
DATABASE_URL=postgresql://YOUR_USERNAME:YOUR_PASSWORD@YOUR_RDS_ENDPOINT:5432/YOUR_DATABASE

# AWS (optional)
AWS_REGION=us-east-1
ENABLE_AWS_LOGGING=false

# App
ENVIRONMENT=production
APP_NAME=Aviation-Dashboard
```

---

### Files Already Complete (No Changes Needed)

These files are already implemented:

✅ `app/models/existing_tables.py` - SQLAlchemy models (7 tables)
✅ `app/services/data_service.py` - Query methods (6 methods)
✅ `app/core/database.py` - Database service
✅ `app/core/di.py` - Dependency injection

**No changes needed to these files!**

---

## SQL Queries Reference

### Query 1: Status Summary

**Method:** `get_status_summary()`

**SQL:**
```sql
SELECT
    CASE
        WHEN status = 'Complete' THEN 'Pass'
        WHEN status = 'Error' THEN 'Fail'
        WHEN status IN ('Pending', 'Delayed') THEN 'Pending'
        ELSE 'Processing'
    END as category,
    COUNT(*) as count
FROM events
WHERE engine_serial = :engine_serial
  AND start_time >= NOW() - INTERVAL ':hours hours'
GROUP BY category
ORDER BY
    CASE category
        WHEN 'Fail' THEN 1
        WHEN 'Pass' THEN 2
        WHEN 'Pending' THEN 3
        WHEN 'Processing' THEN 4
    END
```

**Returns:**
```
category   | count
-----------|------
Fail       |   12
Pass       |   45
Pending    |    3
Processing |    5
```

**SQL Features Used:**
- ✅ CASE statement (if/else logic)
- ✅ GROUP BY aggregation
- ✅ COUNT(*) function
- ✅ Parameterized query (:engine_serial)

---

### Query 2: Data Population

**Method:** `get_data_population()`

**SQL:**
```sql
SELECT
    e.system_name,
    AVG(de.completeness_score) * 100 as completeness_pct,
    AVG(de.quality_score) * 100 as quality_pct,
    COUNT(de.element_id) as total_elements
FROM events e
LEFT JOIN data_elements de ON e.event_id = de.event_id
WHERE e.engine_serial = :engine_serial
  AND e.start_time >= NOW() - INTERVAL ':hours hours'
GROUP BY e.system_name
ORDER BY e.system_name
```

**Returns:**
```
system_name | completeness_pct | quality_pct | total_elements
------------|------------------|-------------|---------------
1FA         |            98.2  |       97.5  |           142
IFS         |            95.7  |       96.2  |           128
FDM         |            92.3  |       88.1  |           156
```

**SQL Features Used:**
- ✅ LEFT JOIN (all events, even without data_elements)
- ✅ AVG() aggregation
- ✅ GROUP BY system_name
- ✅ JOIN ON condition (e.event_id = de.event_id)

**What LEFT JOIN Does:**
- Returns ALL events from `events` table
- Matches with `data_elements` where event_id matches
- If no match, returns NULL for data_elements columns
- AVG() ignores NULL values

---

### Query 3: SLA Timeline

**Method:** `get_sla_timeline()`

**SQL:**
```sql
SELECT
    e.event_id,
    e.system_name,
    e.status,
    e.start_time,
    e.end_time,
    EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 as duration_minutes,
    sla.expected_duration_minutes,
    CASE
        WHEN EXTRACT(EPOCH FROM (e.end_time - e.start_time)) / 60.0 <= sla.expected_duration_minutes
        THEN 'ON_TIME'
        ELSE 'SLA_BREACH'
    END as sla_status
FROM events e
LEFT JOIN sla_targets sla ON e.system_name = sla.system_name
WHERE e.engine_serial = :engine_serial
  AND e.start_time >= NOW() - INTERVAL ':hours hours'
ORDER BY e.start_time
```

**Returns:**
```
event_id | system | status   | duration_min | expected_min | sla_status
---------|--------|----------|--------------|--------------|------------
evt_001  | 1FA    | Complete |          2.1 |          2.0 | ON_TIME
evt_002  | IFS    | Complete |          3.2 |          3.0 | SLA_BREACH
evt_003  | FDM    | Processing|         5.0 |          5.0 | ON_TIME
```

**SQL Features Used:**
- ✅ LEFT JOIN to sla_targets
- ✅ EXTRACT(EPOCH FROM ...) - time difference in seconds
- ✅ Time calculation (end_time - start_time)
- ✅ CASE statement for SLA status
- ✅ Division / 60.0 to convert seconds to minutes

---

### Query 4: Error Notifications

**Method:** `get_error_notifications()`

**SQL:**
```sql
SELECT
    e.event_id,
    e.system_name,
    e.error_message,
    el.error_severity,
    el.notified_team,
    el.notification_sent_at,
    eng.model as engine_model,
    e.start_time,
    e.records,
    e.data_size_mb,
    e.latency_sec
FROM events e
INNER JOIN error_logs el ON e.event_id = el.event_id
INNER JOIN engines eng ON e.engine_serial = eng.serial_number
WHERE e.status = 'Error'
  AND e.engine_serial = :engine_serial
  AND e.start_time >= NOW() - INTERVAL ':hours hours'
ORDER BY el.notification_sent_at DESC
```

**Returns:**
```
system | error_message      | severity | notified_team       | engine_model
-------|--------------------|-----------|--------------------|-------------
PHM    | Database timeout   | CRITICAL  | PHM Analytics Team | GE90
FMX    | API rate limit     | HIGH      | Customer Exp Team  | GE90
```

**SQL Features Used:**
- ✅ Multiple INNER JOINs (events → error_logs → engines)
- ✅ Only returns rows that exist in ALL tables
- ✅ Filter WHERE status = 'Error'
- ✅ ORDER BY timestamp DESC (newest first)

**What INNER JOIN Does:**
- Only returns events that have errors (exist in error_logs)
- Only returns errors for engines that exist in engines table
- Excludes events without errors
- Combines columns from 3 tables

---

### Query 5: Last Updated

**Method:** `get_last_updated()`

**SQL:**
```sql
SELECT
    system_name,
    MAX(end_time) as last_updated
FROM events
WHERE engine_serial = :engine_serial
  AND start_time >= NOW() - INTERVAL ':hours hours'
GROUP BY system_name
ORDER BY system_name
```

**Returns:**
```
system_name | last_updated
------------|---------------------
1FA         | 2026-02-05 10:35:22
IFS         | 2026-02-05 10:38:15
FDM         | 2026-02-05 10:42:01
```

**SQL Features Used:**
- ✅ MAX() aggregation (finds latest time)
- ✅ GROUP BY system_name
- ✅ Simple query (no JOINs)

---

## Testing & Verification

### Test 1: Connection Test

```bash
python test_connection.py
```

**Expected:** ✅ Connection successful, tables found

---

### Test 2: Run Application

```bash
streamlit run Home.py
```

**Expected:** Application starts without errors

---

### Test 3: Navigate to Overview Tab

**Actions:**
1. Open application in browser
2. Click Overview tab
3. Wait for data to load

**Expected:**
- ✅ Status cards show correct counts from database
- ✅ Pie charts display (if data_elements exists)
- ✅ SLA timeline renders
- ✅ Last updated times are correct
- ✅ No error messages

---

### Test 4: Check Logs

```bash
# View logs
tail -f logs/app.log

# OR if no logs directory, check console output
```

**Look for:**
```
INFO - get_overview_data started (engine_serial=000000, hours=24)
INFO - get_status_summary started
INFO - get_status_summary completed (rows_returned=4)
INFO - get_data_population started
INFO - get_data_population completed (rows_returned=8)
INFO - get_sla_timeline started
INFO - get_sla_timeline completed (rows_returned=8)
INFO - get_error_notifications started
INFO - get_error_notifications completed (rows_returned=2)
INFO - get_last_updated started
INFO - get_last_updated completed (rows_returned=8)
INFO - get_overview_data completed (metrics_fetched=5)
```

---

### Test 5: Verify Database Queries

**Connect to PostgreSQL:**
```bash
psql "postgresql://user:pass@host:5432/db"
```

**Run queries manually:**
```sql
-- Check events count
SELECT COUNT(*) FROM events;

-- Check engine serials available
SELECT DISTINCT engine_serial FROM events LIMIT 10;

-- Test status summary query
SELECT
    CASE
        WHEN status = 'Complete' THEN 'Pass'
        WHEN status = 'Error' THEN 'Fail'
        ELSE 'Processing'
    END as category,
    COUNT(*) as count
FROM events
WHERE engine_serial = 'YOUR_ENGINE_SERIAL'
GROUP BY category;
```

---

## Troubleshooting

### Issue 1: "Could not connect to server"

**Error:**
```
OperationalError: could not connect to server: Connection timed out
```

**Causes:**
1. RDS security group blocks your IP
2. Database not publicly accessible
3. Wrong host/port

**Solutions:**

```bash
# 1. Check RDS security group
AWS Console → RDS → Your DB → Security Group → Inbound Rules
# Add rule: PostgreSQL, Port 5432, Your IP

# 2. Check public accessibility
AWS Console → RDS → Your DB → Connectivity → Public Accessibility = Yes

# 3. Test from command line
psql "postgresql://user:pass@host:5432/db"

# 4. Check host format (no :5432 in DATABASE_URL host part)
# Wrong:  DATABASE_URL=postgresql://user:pass@host:5432:5432/db
# Right:  DATABASE_URL=postgresql://user:pass@host:5432/db
```

---

### Issue 2: "password authentication failed"

**Error:**
```
OperationalError: FATAL: password authentication failed for user "admin"
```

**Causes:**
1. Wrong password
2. Special characters not URL-encoded
3. Wrong username

**Solutions:**

```bash
# 1. Verify username and password in AWS RDS console

# 2. URL-encode special characters
# If password is: pass@word!
# Use:           pass%40word%21

# 3. Test with psql directly
psql -h host -p 5432 -U username -d database
# Enter password when prompted
```

---

### Issue 3: "relation 'events' does not exist"

**Error:**
```
ProgrammingError: relation "events" does not exist
```

**Causes:**
1. Table not created
2. Wrong table name
3. Wrong schema/database

**Solutions:**

```bash
# 1. Check what tables exist
python scripts/inspect_database.py

# 2. If table has different name, update models
# File: app/models/existing_tables.py
class Event(Base):
    __tablename__ = "your_actual_table_name"  # Change this

# 3. Update queries in data_service.py
# Change: FROM events
# To:     FROM your_actual_table_name

# 4. Check you're connected to right database
psql "postgresql://user:pass@host:5432/db"
\dt  # List tables
```

---

### Issue 4: "column 'system_name' does not exist"

**Error:**
```
ProgrammingError: column "system_name" does not exist
```

**Causes:**
1. Column has different name
2. Case sensitivity (SystemName vs system_name)

**Solutions:**

```python
# 1. Check actual column names
python scripts/inspect_database.py

# 2. Update model to map column
# File: app/models/existing_tables.py
class Event(Base):
    system_name = Column('SystemName', String(50))  # Map to actual column name
    #                    ↑ Your actual column name

# 3. OR update queries in data_service.py
# Change: e.system_name
# To:     e."SystemName"  # Use quotes for case-sensitive names
```

---

### Issue 5: "No data displayed in Overview"

**Symptoms:**
- Application loads
- No errors
- But all metrics show 0 or empty

**Causes:**
1. Wrong engine_serial
2. Time window too small
3. No data in database

**Solutions:**

```bash
# 1. Check what engine serials exist in your database
psql "postgresql://user:pass@host:5432/db"

SELECT DISTINCT engine_serial FROM events LIMIT 20;

# 2. Use one of these engine serials in the app

# 3. Increase time window
# In Overview code, try hours=168 (7 days) or hours=720 (30 days)

# 4. Check data exists
SELECT COUNT(*) FROM events;
SELECT MIN(start_time), MAX(start_time) FROM events;
```

---

### Issue 6: "LEFT JOIN returns NULL"

**Symptoms:**
- Status summary works
- Data population shows NULL or 0%

**Cause:**
- `data_elements` table empty or doesn't exist

**Solution:**

```bash
# This is EXPECTED behavior for LEFT JOIN
# If data_elements doesn't exist, completeness will be NULL

# Either:
# 1. Populate data_elements table with data
# 2. Accept that pie charts won't show (queries still work)
# 3. Hide data population section if all NULL

# Check if data_elements has data:
SELECT COUNT(*) FROM data_elements;
```

---

### Issue 7: "Slow queries"

**Symptoms:**
- Overview takes >5 seconds to load
- Database connection timeouts

**Solutions:**

```sql
-- Add indexes for performance
CREATE INDEX idx_events_engine_serial ON events(engine_serial);
CREATE INDEX idx_events_start_time ON events(start_time);
CREATE INDEX idx_events_status ON events(status);
CREATE INDEX idx_data_elements_event_id ON data_elements(event_id);
CREATE INDEX idx_error_logs_event_id ON error_logs(event_id);

-- Check query execution time
EXPLAIN ANALYZE
SELECT COUNT(*) FROM events WHERE engine_serial = '000000';

-- Reduce time window
# In .env or code: Use hours=24 instead of hours=720
```

---

## Rollback Instructions

### To Switch Back to Dummy Data

If you need to revert to dummy JSON data:

#### Step 1: Update .env

```bash
# Change this:
ENABLE_DUMMY_DATA=false

# To this:
ENABLE_DUMMY_DATA=true
```

#### Step 2: Comment Out Real Data in overview.py

**File:** `app/components/tabs/overview.py`

**Re-comment lines 9, 25-41:**
```python
# from ...core.di import inject  # Uncomment when enabling real data

# # Get data service from DI container
# data_service = inject("data_service")
# ... (all real data code)
```

**Uncomment dummy data lines 50-54:**
```python
status_summary = build_status_summary(df)
population_pies = build_population_pies(df)
last_updated_table = build_last_updated_table(df)
governance_df = fake_root_cause_panel()
sla_html_tracker = build_sla_dominos_html(df, now, hours=window_hours)
```

#### Step 3: Restart Application

```bash
streamlit run Home.py
```

**Expected:** Dummy data displays again

---

## Summary Checklist

### Pre-Implementation
- [ ] AWS RDS PostgreSQL database exists
- [ ] Database has `events` table with required columns
- [ ] RDS security group allows your IP (port 5432)
- [ ] RDS is publicly accessible (or VPN configured)
- [ ] You have database credentials (username, password)

### Configuration
- [ ] Created `.env` file in project root
- [ ] Set `ENABLE_DUMMY_DATA=false`
- [ ] Set `DATABASE_URL` with correct connection string
- [ ] URL-encoded special characters in password (if any)
- [ ] Tested connection with `python test_connection.py`

### Code Changes
- [ ] Uncommented import in `overview.py` line 9
- [ ] Uncommented real data section in `overview.py` lines 25-41
- [ ] Commented out dummy data in `overview.py` lines 50-54
- [ ] Added visualization builders for real data

### Testing
- [ ] Connection test passes
- [ ] Application starts without errors
- [ ] Overview tab displays data from database
- [ ] Status cards show correct counts
- [ ] Pie charts render (if data_elements exists)
- [ ] No errors in console/logs
- [ ] Queries complete in reasonable time (<3 seconds)

### Verification
- [ ] Logs show successful query execution
- [ ] Correlation IDs appear in logs
- [ ] Data matches what's in database
- [ ] All 5 query methods execute successfully

---

## Additional Resources

### Documentation Files

| Document | Purpose |
|----------|---------|
| [OVERVIEW_IMPLEMENTATION_SUMMARY.md](OVERVIEW_IMPLEMENTATION_SUMMARY.md) | Quick summary of implementation |
| [OVERVIEW_QUICK_REFERENCE.md](OVERVIEW_QUICK_REFERENCE.md) | Visual reference for Overview screen |
| [docs/OVERVIEW_INTEGRATION_GUIDE.md](docs/OVERVIEW_INTEGRATION_GUIDE.md) | Complete integration guide with schema |
| [docs/OVERVIEW_REAL_DATA_IMPLEMENTATION.md](docs/OVERVIEW_REAL_DATA_IMPLEMENTATION.md) | SQL concepts and troubleshooting |
| [ENABLE_REAL_DATA_CHECKLIST.md](ENABLE_REAL_DATA_CHECKLIST.md) | Step-by-step enabling checklist |
| [docs/DATABASE_GUIDE.md](docs/DATABASE_GUIDE.md) | SQLAlchemy and PostgreSQL guide |
| [docs/EXISTING_DATABASE_GUIDE.md](docs/EXISTING_DATABASE_GUIDE.md) | Connect to existing database |

### Scripts

| Script | Purpose |
|--------|---------|
| `test_connection.py` | Test database connection |
| `scripts/inspect_database.py` | Inspect database schema |
| `scripts/test_postgres.py` | Test PostgreSQL queries |

---

## Contact & Support

For issues or questions:

1. Check [Troubleshooting](#troubleshooting) section above
2. Review log files in `logs/app.log`
3. Run `python test_connection.py` to diagnose connection issues
4. Check AWS RDS console for database status

---

**Last Updated:** 2026-02-05
**Version:** 1.0
**Status:** Production Ready
