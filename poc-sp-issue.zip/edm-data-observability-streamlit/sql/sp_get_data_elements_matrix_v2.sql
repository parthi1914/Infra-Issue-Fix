-- ============================================================================
-- Stored Procedure: sp_get_data_elements_matrix_v2
-- ============================================================================
-- Multi-ESN pivoted matrix for Data Elements tab.
-- Accepts comma-separated ESNs and optional tail filter.
-- Returns one row per ESN + tail + property with system columns pre-pivoted.
--
-- Usage:
--   -- Single ESN, specific tail:
--   SELECT * FROM sp_get_data_elements_matrix_v2('038294', 'SU-GEI');
--
--   -- Multiple ESNs, all tails:
--   SELECT * FROM sp_get_data_elements_matrix_v2('038294,041223,052781', NULL);
--
--   -- Multiple ESNs, specific tail:
--   SELECT * FROM sp_get_data_elements_matrix_v2('038294,041223', 'SU-GEI');
-- ============================================================================

DROP FUNCTION IF EXISTS sp_get_data_elements_matrix_v2(TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_data_elements_matrix_v2(
    p_esns TEXT,                -- comma-separated ESN list
    p_tail TEXT DEFAULT NULL    -- optional tail filter (NULL = all tails)
)
RETURNS TABLE (
    esn            TEXT,
    property_name  TEXT,
    prop_order     INT,
    expected       TEXT,
    fa_value       TEXT,
    fa_status      TEXT,
    fdi_value      TEXT,
    fdi_status     TEXT,
    phm_value      TEXT,
    phm_status     TEXT,
    fmx_value      TEXT,
    fmx_status     TEXT
)
AS $$
BEGIN
    RETURN QUERY
    WITH
    -- Parse comma-separated ESNs
    esn_list AS (
        SELECT TRIM(unnest(string_to_array(sp_get_data_elements_matrix_v2.p_esns, ','))) AS esn_val
    ),

    -- Step 1: Get latest row per ESN + system (tail removed)
    latest AS (
        SELECT
            a.esn::TEXT                         AS esn,
            a.data_source::TEXT                 AS sys,
            a.diagnostic_installation_date,
            a.engine_position,
            a.installation_date,
            a.last_update_date,
            a.n1_modifier,
            a.operator,
            a.monitor,
            a.operator_diagnostic_code,
            a.tail_number_aircraft_id,
            a.engine_model,
            a.engine_type,
            a.engine_family_model_series,
            a.aircraft_delivery_date,
            a.aircraft_family,
            a.aircraft_model,
            a.aircraft_series,
            a.installation_history,
            ROW_NUMBER() OVER (
                PARTITION BY a.esn, a.data_source
                ORDER BY a.last_update_date DESC NULLS LAST
            ) AS rn
        FROM edm_raw.asset_diagnostic_stg a
        INNER JOIN esn_list el ON a.esn::TEXT = el.esn_val
    ),

    -- Step 2: Latest per system
    systems AS (
        SELECT * FROM latest WHERE rn = 1
    ),

    -- Step 3: Unpivot 19 properties
    unpivoted AS (
        SELECT
            s.esn, s.sys,
            props.prop_name  AS prop,
            props.raw_val,
            props.prop_order
        FROM systems s
        CROSS JOIN LATERAL (
            VALUES
                ('ESN',                          s.esn::TEXT,                            1),
                ('Diagnostic Installation Date', s.diagnostic_installation_date::TEXT,   2),
                -- ('Diagnostic Tail',              s.tail::TEXT,                           3),
                ('Diagnostic Tail',              NULL,                                    3),
                ('Engine Position',              s.engine_position::TEXT,                4),
                ('Installation Date',            s.installation_date::TEXT,              5),
                ('Last Updated Date',            s.last_update_date::TEXT,               6),
                ('N1 Modifier',                  s.n1_modifier::TEXT,                    7),
                ('Operator',                     s.operator::TEXT,                       8),
                ('Monitor',                      s.monitor::TEXT,                        9),
                ('Operator Diagnostic Code',     s.operator_diagnostic_code::TEXT,      10),
                ('Tail Number Aircraft ID',      s.tail_number_aircraft_id::TEXT,       11),
                ('Engine Model',                 s.engine_model::TEXT,                  12),
                ('Engine Type',                  s.engine_type::TEXT,                   13),
                ('Engine Family Model Series',   s.engine_family_model_series::TEXT,    14),
                ('Aircraft Delivery Date',       s.aircraft_delivery_date::TEXT,        15),
                ('Aircraft Family',              s.aircraft_family::TEXT,               16),
                ('Aircraft Model',               s.aircraft_model::TEXT,                17),
                ('Aircraft Series',              s.aircraft_series::TEXT,               18),
                ('Installation History',         s.installation_history::TEXT,          19)
        ) AS props(prop_name, raw_val, prop_order)
    ),

    -- Step 4: Normalise (NULL / empty / NaN / None → 'NULL')
    normalised AS (
        SELECT
            unpivoted.esn, unpivoted.sys, unpivoted.prop, unpivoted.prop_order,
            CASE
                WHEN unpivoted.raw_val IS NULL                                    THEN 'NULL'
                WHEN TRIM(unpivoted.raw_val) = ''                                 THEN 'NULL'
                WHEN UPPER(TRIM(unpivoted.raw_val)) IN ('NONE', 'NAN', 'NAT')    THEN 'NULL'
                ELSE TRIM(unpivoted.raw_val)
            END AS val
        FROM unpivoted
    ),

    -- Step 5: Flag invalid placeholder dates
    with_flags AS (
        SELECT
            normalised.esn, normalised.sys, normalised.prop, normalised.prop_order, normalised.val,
            CASE
                WHEN normalised.val <> 'NULL'
                 AND (   normalised.val LIKE '%9999-01-01%'
                      OR normalised.val LIKE '%9999-12-31%'
                      OR normalised.val LIKE '%1900-01-01%'
                      OR normalised.val LIKE '%0001-01-01%' )
                THEN TRUE
                ELSE FALSE
            END AS is_invalid_date
        FROM normalised
    ),

    -- Step 6: Expected value per ESN + property
    expected_calc AS (
        SELECT
            with_flags.esn, with_flags.prop,
            COALESCE(
                MAX(CASE WHEN with_flags.sys = '1FA'  AND with_flags.val <> 'NULL' AND NOT with_flags.is_invalid_date AND UPPER(with_flags.val) NOT IN ('NA', 'TBD') THEN with_flags.val END),
                MAX(CASE WHEN with_flags.sys = '1FDI' AND with_flags.val <> 'NULL' AND NOT with_flags.is_invalid_date AND UPPER(with_flags.val) NOT IN ('NA', 'TBD') THEN with_flags.val END),
                MAX(CASE WHEN with_flags.sys = 'PHM'  AND with_flags.val <> 'NULL' AND NOT with_flags.is_invalid_date AND UPPER(with_flags.val) NOT IN ('NA', 'TBD') THEN with_flags.val END),
                MAX(CASE WHEN with_flags.sys = 'FMX'  AND with_flags.val <> 'NULL' AND NOT with_flags.is_invalid_date AND UPPER(with_flags.val) NOT IN ('NA', 'TBD') THEN with_flags.val END),
                '—'
            ) AS expected_val
        FROM with_flags
        GROUP BY with_flags.esn, with_flags.prop
    ),

    -- Step 7: Validate status + reason
    validated AS (
        SELECT
            with_flags.esn,
            with_flags.prop                          AS property_name,
            with_flags.prop_order,
            with_flags.sys                           AS system_name,
            with_flags.val                           AS actual_value,
            expected_calc.expected_val               AS expected,
            CASE
                WHEN with_flags.val = 'NULL'                         THEN 'Fail'
                WHEN with_flags.is_invalid_date                      THEN 'Fail'
                WHEN UPPER(with_flags.val) IN ('NA', 'TBD')          THEN 'Fail'
                WHEN expected_calc.expected_val = '—'                THEN 'Pass'
                WHEN with_flags.val = expected_calc.expected_val     THEN 'Pass'
                ELSE 'Fail'
            END                             AS status
        FROM with_flags
        JOIN expected_calc ON expected_calc.esn = with_flags.esn AND expected_calc.prop = with_flags.prop
    ),

    -- Step 8: Pivot — one row per ESN + property
    pivoted AS (
        SELECT
            validated.esn,
            validated.property_name,
            validated.prop_order,
            validated.expected,
            MAX(CASE WHEN validated.system_name = '1FA'  THEN validated.actual_value END) AS fa_value,
            MAX(CASE WHEN validated.system_name = '1FA'  THEN validated.status END)       AS fa_status,
            MAX(CASE WHEN validated.system_name = '1FDI' THEN validated.actual_value END) AS fdi_value,
            MAX(CASE WHEN validated.system_name = '1FDI' THEN validated.status END)       AS fdi_status,
            MAX(CASE WHEN validated.system_name = 'PHM'  THEN validated.actual_value END) AS phm_value,
            MAX(CASE WHEN validated.system_name = 'PHM'  THEN validated.status END)       AS phm_status,
            MAX(CASE WHEN validated.system_name = 'FMX'  THEN validated.actual_value END) AS fmx_value,
            MAX(CASE WHEN validated.system_name = 'FMX'  THEN validated.status END)       AS fmx_status
        FROM validated
        GROUP BY validated.esn, validated.property_name, validated.prop_order, validated.expected
    )

    SELECT
        pivoted.esn,
        pivoted.property_name,
        pivoted.prop_order,
        pivoted.expected,
        pivoted.fa_value,
        pivoted.fa_status,
        pivoted.fdi_value,
        pivoted.fdi_status,
        pivoted.phm_value,
        pivoted.phm_status,
        pivoted.fmx_value,
        pivoted.fmx_status
    FROM pivoted
    ORDER BY pivoted.esn, pivoted.prop_order;
END;
$$ LANGUAGE plpgsql STABLE;
