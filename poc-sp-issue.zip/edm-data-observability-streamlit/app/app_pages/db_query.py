import streamlit as st
import logging

from services.db import is_db_available, run_query
from config.settings import get_connection_info

log = logging.getLogger(__name__)


def render():
    st.subheader("Database Query")
    st.markdown("Query data directly from RDS Aurora PostgreSQL database")

    db_ready = is_db_available()

    if db_ready:
        conn_info = get_connection_info()
        if conn_info:
            st.success(f"Connected via {conn_info['source']}")
            with st.expander("Connection Details"):
                col1, col2, col3 = st.columns(3)
                col1.markdown(f"**Database:** `{conn_info['dbname']}`")
                col2.markdown(f"**Endpoint:** `{conn_info['host']}`")
                col3.markdown(f"**User:** `{conn_info['user']}`")
    else:
        st.warning(
            "No database credentials configured. "
            "Set up AWS Secrets Manager or add a [postgres] section to "
            "`.streamlit/secrets.toml` to connect."
        )

    if db_ready:
        st.markdown("### Available Schemas")
        try:
            schema_df = run_query(
                """
                SELECT schema_name
                  FROM information_schema.schemata
                 WHERE schema_name NOT IN ('pg_catalog', 'information_schema')
                 ORDER BY schema_name
                """
            )
            st.dataframe(schema_df, use_container_width=True, hide_index=True)
        except Exception as exc:
            st.warning(f"Could not list schemas: {exc}")

    st.markdown("### Execute Query")
    default_query = "SELECT * FROM edm_raw.asset_diagnostic_stg LIMIT 10"
    query = st.text_area("SQL Query:", value=default_query, height=100)

    if st.button("Run Query", type="primary"):
        if not query.strip():
            st.warning("Enter a SQL query first.")
            return

        if not db_ready:
            st.error("Cannot run query — no database connection. Configure credentials first.")
            return

        try:
            with st.spinner("Running query..."):
                df_result = run_query(query)

            st.success(f"Retrieved {len(df_result)} rows")
            st.dataframe(df_result, use_container_width=True, hide_index=True)

            col1, col2, col3 = st.columns(3)
            col1.markdown(
                f"<div style='padding:8px;background:#eff6ff;border-radius:6px;text-align:center;'>"
                f"<div style='font-size:11px;color:#6b7280;'>Total Rows</div>"
                f"<div style='font-size:20px;font-weight:700;'>{len(df_result)}</div></div>",
                unsafe_allow_html=True,
            )
            col2.markdown(
                f"<div style='padding:8px;background:#ecfdf5;border-radius:6px;text-align:center;'>"
                f"<div style='font-size:11px;color:#6b7280;'>Total Columns</div>"
                f"<div style='font-size:20px;font-weight:700;'>{len(df_result.columns)}</div></div>",
                unsafe_allow_html=True,
            )
            mem_kb = df_result.memory_usage(deep=True).sum() / 1024
            col3.markdown(
                f"<div style='padding:8px;background:#f5f3ff;border-radius:6px;text-align:center;'>"
                f"<div style='font-size:11px;color:#6b7280;'>Memory Usage</div>"
                f"<div style='font-size:20px;font-weight:700;'>{mem_kb:.2f} KB</div></div>",
                unsafe_allow_html=True,
            )

        except Exception as exc:
            st.error(f"Query Error: {exc}")
            st.markdown(
                """
**Troubleshooting:**
- Check if the schema exists in the 'Available Schemas' list above
- Verify you have SELECT permissions on the schema and table
- Try: `GRANT USAGE ON SCHEMA edm_raw TO your_user;`
- Try: `GRANT SELECT ON edm_raw.asset_diagnostic_stg TO your_user;`
                """
            )
