"""
Lookup Service
==============
Provides dropdown/select list data for the sidebar filters.
All queries now go through sp_get_filter_options stored procedure.

Caching: Enabled with 300s TTL (5 min) for dropdown data.
"""

import logging
import streamlit as st

# Conditional import to support both direct and package execution
import sys
import os
if __name__ == "__main__" or __package__ is None:
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from db import is_db_available, run_query_list
else:
    from .db import is_db_available, run_query_list
from utils.constants import (
    SAMPLE_ENGINE_SERIALS,
    SAMPLE_TAIL_NUMBERS,
    ENGINE_TO_TAILS,
    TAIL_TO_ENGINES,
)

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Caching Configuration
# ---------------------------------------------------------------------------
ENABLE_CACHE = False
CACHE_TTL_SECONDS = 300


def _apply_cache(func):
    """Apply Streamlit cache only if ENABLE_CACHE is True."""
    if ENABLE_CACHE:
        return st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)(func)
    return func


# ---------------------------------------------------------------------------
# Core SP Call
# ---------------------------------------------------------------------------
@_apply_cache
def _call_sp_filter(mode: str, value: str = None) -> list:
    """
    Call sp_get_filter_options and return list of option values.
    Cached for 5 minutes.
    """
    sql = "SELECT * FROM sp_get_filter_options(:mode, :value)"
    result = run_query_list(sql, {"mode": mode, "value": value})
    log.info("sp_get_filter_options('%s', '%s') returned %d items", mode, value, len(result) if result else 0)
    return result if result else []


# ---------------------------------------------------------------------------
# Public API (same signatures — no changes needed in callers)
# ---------------------------------------------------------------------------
def get_engine_serials() -> list:
    """Get distinct ESN values, ordered."""
    if not is_db_available():
        return SAMPLE_ENGINE_SERIALS
    try:
        # Use new sp_get_filter_options signature (TEXT) and filter for ESNs
        sql = "SELECT option_value FROM sp_get_filter_options(null,null) WHERE option_type = 'esn' ORDER BY option_value"
        result = run_query_list(sql)
        return result if result else SAMPLE_ENGINE_SERIALS
    except Exception as exc:
        log.warning("SP call failed for ESNs: %s", exc)
        return SAMPLE_ENGINE_SERIALS


def get_tail_numbers() -> list:
    """Get distinct diagnostic_tail values, ordered."""
    if not is_db_available():
        return SAMPLE_TAIL_NUMBERS
    try:
        result = _call_sp_filter("all_tails")
        return result if result else SAMPLE_TAIL_NUMBERS
    except Exception as exc:
        log.warning("SP call failed for tail numbers: %s", exc)
        return SAMPLE_TAIL_NUMBERS


def get_tails_for_engine(engine_serial: str) -> list:
    """Get tails for a given ESN."""
    if not engine_serial:
        return [""]
    if not is_db_available():
        return ENGINE_TO_TAILS.get(engine_serial, [SAMPLE_TAIL_NUMBERS[0] if SAMPLE_TAIL_NUMBERS else ""])
    try:
        result = _call_sp_filter("tails_for_esn", engine_serial)
        return result if result else [""]
    except Exception as exc:
        log.warning("SP call failed for tails by ESN: %s", exc)
        return ENGINE_TO_TAILS.get(engine_serial, [""])


def get_engines_for_tail(tail_number: str) -> list:
    """Get ESNs for a given tail."""
    if not tail_number:
        return [""]
    if not is_db_available():
        return TAIL_TO_ENGINES.get(tail_number, [SAMPLE_ENGINE_SERIALS[0] if SAMPLE_ENGINE_SERIALS else ""])
    try:
        result = _call_sp_filter("esns_for_tail", tail_number)
        return result if result else [""]
    except Exception as exc:
        log.warning("SP call failed for ESNs by tail: %s", exc)
        return TAIL_TO_ENGINES.get(tail_number, [""])


def get_operator_codes_for_esn(engine_serial: str) -> list:
    """Get operator codes for a given ESN."""
    if not engine_serial:
        return [""]
    if not is_db_available():
        return ["OP001", "OP002"]
    try:
        result = _call_sp_filter("operators_for_esn", engine_serial)
        return result if result else [""]
    except Exception as exc:
        log.warning("SP call failed for operator codes by ESN: %s", exc)
        return [""]


def get_operator_codes_for_tail(tail_number: str) -> list:
    """Get operator codes for a given tail."""
    if not tail_number:
        return [""]
    if not is_db_available():
        return ["OP001", "OP002"]
    try:
        result = _call_sp_filter("operators_for_tail", tail_number)
        return result if result else [""]
    except Exception as exc:
        log.warning("SP call failed for operator codes by tail: %s", exc)
        return [""]
