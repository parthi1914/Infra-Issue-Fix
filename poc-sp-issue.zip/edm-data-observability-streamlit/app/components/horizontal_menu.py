MENU_ITEMS = [
    "Overview",
    "Timeline",
    "Flow & Network",
    "Data Elements",
    "Raw Data",
    "Database Query",
]

MENU_TO_PAGE_FILE = {
    "Overview": "overview.py",
    "Timeline": "timeline.py",
    "Flow & Network": "flow_network.py",
    "Data Elements": "data_elements.py",
    "Raw Data": "raw_data.py",
    "Database Query": "db_query.py",
}
