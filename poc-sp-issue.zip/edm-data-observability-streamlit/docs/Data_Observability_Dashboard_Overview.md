# Data Observability Dashboard
## Executive Summary & Functional Overview

---

## 1. Purpose & Business Value

The **Data Observability Dashboard** provides real-time visibility into the health, freshness, and flow of diagnostic data across the enterprise data pipeline. It enables operations teams to:

- **Monitor Data Quality** – Track pass/fail status of data at each processing stage
- **Ensure SLA Compliance** – Validate data freshness within defined thresholds (≤30 minutes)
- **Accelerate Root Cause Analysis** – Quickly identify where data issues originate
- **Reduce Mean Time to Resolution (MTTR)** – Visual diagnostics enable faster troubleshooting

---

## 2. Data Pipeline Overview

The dashboard monitors a 4-stage data flow representing the journey of asset diagnostic data:

```
┌─────────┐      ┌─────────┐      ┌─────────┐      ┌─────────┐
│   1FA   │ ──▶  │  1FDI   │ ──▶  │   PHM   │ ──▶  │   FMX   │
│ (Source)│      │(Ingest) │      │(Process)│      │(Deliver)│
└─────────┘      └─────────┘      └─────────┘      └─────────┘
```

| Stage | System | Description |
|-------|--------|-------------|
| 1 | **1FA** | Source system - Initial data capture |
| 2 | **1FDI** | Data ingestion layer |
| 3 | **PHM** | Processing and health monitoring |
| 4 | **FMX** | Final delivery and downstream consumption |

---

## 3. Key Features & Tabs

### 3.1 Overview Tab
**Purpose:** Executive dashboard providing at-a-glance health status

| Component | Description |
|-----------|-------------|
| **KPI Header** | Total events, success rate, average latency, data freshness |
| **Pass/Fail/Pending Cards** | Count of records by validation status |
| **Pie Chart** | Visual breakdown of pass/fail/pending distribution |
| **SLA Timeline** | Hourly freshness status (OK/Failed) |
| **Domino Progress** | Visual representation of data flow through 4 systems |
| **Root Cause Panel** | System-specific issues and recommendations |

**Validation Logic:**
- ✅ **PASS**: Data arrives within 30 minutes of previous stage
- ❌ **FAIL**: Data exceeds 30-minute threshold or is missing
- ⏳ **PENDING**: Upstream system failed, blocking downstream validation

---

### 3.2 Timeline Tab
**Purpose:** Time-series visualization of system status over the selected period

- Displays each system's status across time intervals
- Color-coded markers: Green (Pass), Red (Fail), Yellow (Pending)
- Enables pattern recognition for recurring issues

---

### 3.3 Flow & Network Tab
**Purpose:** Visual representation of data movement and dependencies

| Visualization | Description |
|---------------|-------------|
| **Sankey Diagram** | Shows data volume flowing between systems |
| **Network Graph** | Displays system dependencies with status colors |

---

### 3.4 Data Elements Tab
**Purpose:** Detailed view of individual data elements and their status

- Heatmap visualization across 4 systems
- Drill-down capability for granular analysis
- Element-level pass/fail tracking

---

### 3.5 Raw Data Tab
**Purpose:** Direct database query access for technical investigation

- SQL query execution against staging tables
- Export capability for offline analysis

---

## 4. Filter Capabilities

The dashboard provides flexible filtering options:

| Filter | Description |
|--------|-------------|
| **Engine Serial (ESN)** | Filter by specific engine identifier |
| **Tail Number** | Filter by aircraft tail number |
| **Custom Input** | Manual entry for ad-hoc queries |
| **Clear All** | Reset all filters to default state |

**Smart Filter Behavior:**
- Changing filter mode automatically clears previous selections
- Cascading dropdowns (ESN → Tail, or Tail → ESN)
- "No Data Available" displayed when filters are cleared

---

## 5. SLA & Freshness Monitoring

### Freshness Definition
Data is considered **fresh** if it progresses through each system within **30 minutes**.

### SLA Status Display
| Status | Condition | Visual |
|--------|-----------|--------|
| **Freshness: OK** | 1FA (source) data is present and valid | Green indicator |
| **Freshness: Failed** | 1FA data is missing or stale | Red indicator |

### Latency Calculation
- Measured as time difference between consecutive systems
- Displayed in minutes with threshold comparison

---

## 6. Root Cause Analysis

Each system has a dedicated root cause configuration providing:

- **Common Issues** – Typical failure scenarios
- **Likely Causes** – Technical explanations
- **Recommended Actions** – Steps for resolution
- **Escalation Path** – Team contacts for support

Example root causes include:
- Network connectivity issues
- Upstream system delays
- Processing queue backlogs
- Authentication/authorization failures

---

## 7. Technical Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Streamlit Dashboard                       │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐        │
│  │Overview │  │Timeline │  │Flow &   │  │ Data    │        │
│  │   Tab   │  │   Tab   │  │Network  │  │Elements │        │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘        │
├─────────────────────────────────────────────────────────────┤
│                    Service Layer                             │
│  ┌───────────────────┐  ┌───────────────────┐              │
│  │ Diagnostic Service│  │  Lookup Service   │              │
│  └───────────────────┘  └───────────────────┘              │
├─────────────────────────────────────────────────────────────┤
│                    Data Layer                                │
│           ┌─────────────────────────────┐                   │
│           │  edm_raw.asset_diagnostic_stg│                  │
│           │      (PostgreSQL)            │                  │
│           └─────────────────────────────┘                   │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. Business Benefits

| Benefit | Impact |
|---------|--------|
| **Proactive Monitoring** | Identify issues before they impact downstream consumers |
| **Reduced Investigation Time** | Visual diagnostics accelerate root cause identification |
| **SLA Visibility** | Real-time tracking of data freshness commitments |
| **Operational Efficiency** | Self-service access reduces support ticket volume |
| **Data Trust** | Transparency builds confidence in data quality |

---

## 9. Future Enhancements (Roadmap)

- **Alerting Integration** – Push notifications for SLA breaches
- **Historical Trending** – Long-term pattern analysis
- **Expanded Systems** – Additional pipeline stages
- **Predictive Analytics** – ML-based anomaly detection
- **Mobile Access** – Responsive design for on-the-go monitoring

---

## 10. Access & Support

| Item | Details |
|------|---------|
| **URL** | (Deployed application URL) |
| **Supported Browsers** | Chrome, Edge, Firefox (latest versions) |
| **Data Refresh** | Real-time from PostgreSQL staging table |
| **Support Contact** | EDM Data Engineering Team |

---

*Document Version: 1.0*  
*Last Updated: February 2026*  
*Classification: Internal Use*
