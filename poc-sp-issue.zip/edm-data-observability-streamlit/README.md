## Streamlit Application Deployment & CI/CD Guide

Easily deploy your Streamlit app with a built-in CI/CD pipeline!

### Quick Start

1. **Create Your Repository**
   - Click "Use this template" on GitHub.
   - Enter a descriptive repository name and description.
   - Choose visibility "Internal" (looking to add private in future)
   - Click "Create repository".

2. **Deploy Your App**
   - Visit [Streamlit App Launcher 🚀](https://streamlit.dev.apps.geaerospace.net/).
   - Enter a unique app name.
   - Enter your repository name.
   - Enter your SSO.
   - Click **Build and Deploy**.

3. **Monitor Deployment**
   - Watch as AWS provisions your app and sets up a CI/CD pipeline.
   - Once complete, your repository will have a pipeline on the `main` branch, automatically deploying to your site.

### Notes

- You may remove the sample code in the `app/` directory. Ensure your entry point is `main.py`.
- Add any required Python packages to `requirements.txt`.
- You can further customize your AWS CodePipeline (e.g., add manual approvals, testing stages, or change triggers).
- Your pipeline will be named: `av-edm-<app-name>-pipeline`.
