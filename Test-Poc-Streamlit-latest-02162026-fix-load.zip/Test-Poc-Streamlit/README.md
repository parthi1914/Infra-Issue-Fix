# Asset & Diagnostic Data Observability Dashboard

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Directory Structure](#3-directory-structure)
4. [Application Startup Flow](#4-application-startup-flow)
5. [Sidebar & Filter Workflow](#5-sidebar--filter-workflow)
6. [Tab-by-Tab Code Flow](#6-tab-by-tab-code-flow)
   - [Overview Tab](#61-overview-tab)
   - [Timeline Tab](#62-timeline-tab)
   - [Flow & Network Tab](#63-flow--network-tab)
   - [Data Elements Tab](#64-data-elements-tab)
   - [Raw Data Tab](#65-raw-data-tab)
   - [Database Query Tab](#66-database-query-tab)
7. [Service Layer](#7-service-layer)
   - [db.py — Database Connection](#71-dbpy--database-connection)
   - [diagnostic_service.py — Overview Data](#72-diagnostic_servicepy--overview-data)
   - [data_element_service.py — Data Elements Matrix](#73-data_element_servicepy--data-elements-matrix)
   - [lookup_service.py — Filter Dropdowns](#74-lookup_servicepy--filter-dropdowns)
   - [raw_data_service.py — Raw Data Grid](#75-raw_data_servicepy--raw-data-grid)
   - [event_service.py — Pipeline Events](#76-event_servicepy--pipeline-events)
   - [sns_service.py — Alert Notifications](#77-sns_servicepy--alert-notifications)
8. [Stored Procedures (SQL)](#8-stored-procedures-sql)
   - [sp_get_overview_data](#81-sp_get_overview_data)
   - [sp_get_data_elements_matrix](#82-sp_get_data_elements_matrix)
   - [sp_get_filter_options](#83-sp_get_filter_options)
9. [Caching Architecture](#9-caching-architecture)
10. [Data Model & Database](#10-data-model--database)
11. [Validation Logic](#11-validation-logic)
12. [Configuration & Secrets](#12-configuration--secrets)
13. [How to Run](#13-how-to-run)
14. [How to Update / Extend](#14-how-to-update--extend)

---

## 1. Project Overview

This is a **Streamlit-based Engine Data Observability Dashboard** built for GE Aerospace's EDM (Engine Data Management) platform. It provides end-to-end visibility into diagnostic data flowing through 4 systems in a cascading pipeline:

```
1FA (Asset) → 1FDI (Asset) → PHM (Flight) → FMX (Endpoint)
```

**Key Capabilities:**
- Real-time system status monitoring (Pass / Fail / Pending)
- SLA timeline tracking with 30-minute gap enforcement
- Data element cross-system validation (19 properties × 4 systems)
- Domino-style progress visualization
- Error notifications with AWS SNS email alerts
- Root cause analysis panels
- Raw data inspection

**Tech Stack:**
- **Frontend:** Streamlit 1.45.1
- **Backend:** Python 3.10+, SQLAlchemy
- **Database:** PostgreSQL (AWS RDS)
- **Cloud:** AWS SNS (alerts), AWS Secrets Manager (credentials)
- **Visualization:** Plotly, NetworkX, Matplotlib

---

## 2. Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                      STREAMLIT UI LAYER                          │
│                                                                  │
│  main.py                                                         │
│    ├── components/header.py          (Page header banner)        │
│    ├── utils/sidebar.py              (Filter sidebar)            │
│    ├── components/kpis.py            (KPI cards row)             │
│    └── Tabs:                                                     │
│        ├── app_pages/overview.py     (Overview board)            │
│        ├── app_pages/timeline.py     (Timeline charts)           │
│        ├── app_pages/flow_network.py (Flow & network diagrams)   │
│        ├── app_pages/data_elements.py(Matrix heatmap)            │
│        ├── app_pages/raw_data.py     (Raw data grid)             │
│        └── app_pages/db_query.py     (Ad-hoc SQL query)          │
├──────────────────────────────────────────────────────────────────┤
│                      CHART / UTILITY LAYER                       │
│                                                                  │
│  utils/charts.py        (11 cached chart builder functions)      │
│  utils/utils.py         (show_filter_info, show_no_data_message) │
│  utils/constants.py     (SYSTEM_FLOW, DATA_ELEMENTS, samples)    │
│  utils/data_simulation.py (Simulation fallback when DB offline)  │
├──────────────────────────────────────────────────────────────────┤
│                      SERVICE LAYER (Cached)                      │
│                                                                  │
│  services/diagnostic_service.py  → sp_get_overview_data          │
│  services/data_element_service.py→ sp_get_data_elements_matrix   │
│  services/lookup_service.py      → sp_get_filter_options         │
│  services/raw_data_service.py    → Direct SQL (asset_diag_stg)   │
│  services/event_service.py       → Direct SQL (pipeline_events)  │
│  services/sns_service.py         → AWS SNS publish               │
├──────────────────────────────────────────────────────────────────┤
│                      DATABASE LAYER                              │
│                                                                  │
│  services/db.py                                                  │
│    ├── get_engine()       (@st.cache_resource — permanent pool)  │
│    ├── run_query()        → pd.DataFrame                         │
│    ├── run_query_single() → scalar                               │
│    └── run_query_list()   → list                                 │
├──────────────────────────────────────────────────────────────────┤
│                      POSTGRESQL DATABASE                         │
│                                                                  │
│  Table:  edm_raw.asset_diagnostic_stg                            │
│  Table:  pipeline_events (event_service only)                    │
│  SP:     sp_get_overview_data(esn, tail)                         │
│  SP:     sp_get_data_elements_matrix(esn, tail)                  │
│  SP:     sp_get_filter_options(mode, value)                      │
└──────────────────────────────────────────────────────────────────┘
```

---

## 3. Directory Structure

```
Test-Poc-Streamlit/
├── app/
│   ├── main.py                         # Entry point — run with: streamlit run app/main.py
│   │
│   ├── .streamlit/
│   │   ├── config.toml                 # Streamlit config (toolbar, theme)
│   │   ├── secrets.toml                # DB + AWS credentials (git-ignored)
│   │   └── secrets.toml.example        # Template for secrets
│   │
│   ├── app_pages/                      # One file per tab
│   │   ├── overview.py                 # Overview Board
│   │   ├── timeline.py                 # Timeline charts
│   │   ├── flow_network.py             # Flow & Network diagrams
│   │   ├── data_elements.py            # Data Elements matrix
│   │   ├── raw_data.py                 # Raw data grid
│   │   ├── db_query.py                 # Ad-hoc database query
│   │   ├── freshness.py                # (Demo) Freshness checks
│   │   ├── latency.py                  # (Demo) Latency monitoring
│   │   └── status_table.py             # (Demo) Status table
│   │
│   ├── components/                     # Reusable UI components
│   │   ├── header.py                   # "Asset & Diagnostic Data Observability" banner
│   │   ├── horizontal_menu.py          # Tab menu items list
│   │   └── kpis.py                     # Top KPI cards (Total, Pass, Fail, Pending)
│   │
│   ├── services/                       # Business logic + data access
│   │   ├── db.py                       # SQLAlchemy engine + query helpers
│   │   ├── diagnostic_service.py       # Overview page data (calls SP)
│   │   ├── data_element_service.py     # Data Elements matrix (calls SP)
│   │   ├── lookup_service.py           # Sidebar filter dropdowns (calls SP)
│   │   ├── raw_data_service.py         # Raw data grid (direct SQL)
│   │   ├── event_service.py            # Pipeline events (direct SQL)
│   │   └── sns_service.py              # AWS SNS alert publishing
│   │
│   ├── utils/                          # Helpers and shared utilities
│   │   ├── charts.py                   # 11 chart builder functions (cached)
│   │   ├── constants.py                # System flow, sample data, colors
│   │   ├── data_simulation.py          # Simulation fallback (no DB)
│   │   ├── sidebar.py                  # Filter sidebar logic
│   │   └── utils.py                    # show_filter_info, show_no_data_message
│   │
│   └── config/                         # Configuration
│       ├── settings.py                 # get_database_url() — multi-source
│       ├── secrets_manager.py          # AWS Secrets Manager integration
│       ├── 1FArootcause.json           # Root cause config for 1FA
│       ├── 1FDIrootcause.json          # Root cause config for 1FDI
│       ├── PHMrootcause.json           # Root cause config for PHM
│       └── FMXrootcause.json           # Root cause config for FMX
│
├── sql/                                # Stored procedures (deploy to PostgreSQL)
│   ├── sp_get_overview_data.sql        # Overview page system statuses
│   ├── sp_get_data_elements_matrix.sql # Data Elements 19×4 matrix
│   └── sp_get_filter_options.sql       # Sidebar filter dropdowns
│
└── requirements.txt                    # Python dependencies
```

---

## 4. Application Startup Flow

When `streamlit run app/main.py` is executed:

```
main.py
  │
  ├─ 1. st.set_page_config(layout="wide")
  │     Sets page title and wide layout
  │
  ├─ 2. Global CSS injection
  │     Styles for tabs, sidebar, KPI cards, header
  │
  ├─ 3. render_header()                          ← components/header.py
  │     Renders "Asset & Diagnostic Data Observability" banner
  │     Shows: ⚙ Asset → ✈ Flight lineage badges
  │
  ├─ 4. setup_sidebar()                          ← utils/sidebar.py
  │     Renders entire sidebar:
  │       - "Use custom input" checkbox
  │       - ESN / Tail Number / Operator Code dropdowns (or text inputs)
  │       - "Analyze" and "Clear" buttons
  │       - Loads filter data from DB via lookup_service.py
  │       - Stores selections in st.session_state
  │       - Fetches pipeline events if submitted
  │
  ├─ 5. render_kpis()                            ← components/kpis.py
  │     Shows 4 KPI cards across the top:
  │       Total Systems | Pass | Fail | Pending
  │     Data from: diagnostic_service.get_status_counts()
  │
  └─ 6. Tab rendering loop
        Creates 6 tabs and renders each page:
          tabs[0] → overview.render()
          tabs[1] → timeline.render()
          tabs[2] → flow_network.render()
          tabs[3] → data_elements.render()
          tabs[4] → raw_data.render()
          tabs[5] → db_query.render()
```

**Important:** Every tab's `render()` function:
1. Calls `show_filter_info()` to get `engine_serial`, `tail_number`, `operator_code` from `st.session_state`
2. If ESN or Tail is empty → shows "No Data Available" message and returns early
3. Otherwise → calls service functions to fetch data and render charts

---

## 5. Sidebar & Filter Workflow

### File: `utils/sidebar.py`

### Flow Diagram

```
┌─────────────────────────────────────────────┐
│  User opens the app                         │
│                                             │
│  ┌───────────────────────────────────────┐  │
│  │  [✓] Use custom input instead         │  │
│  │      ↓ (if checked)                   │  │
│  │  Text Input: Engine Serial *          │  │
│  │  Text Input: Tail Number *            │  │
│  │  Text Input: Operator Code *          │  │
│  │                                       │  │
│  │      ↓ (if unchecked)                 │  │
│  │  Radio: [ESN] or [Tail Number]        │  │
│  │      ↓                                │  │
│  │  If "ESN" selected:                   │  │
│  │    ESN dropdown ← get_engine_serials()│  │
│  │    Tail dropdown← get_tails_for_engine│  │
│  │    Operator     ← get_operator_codes  │  │
│  │                                       │  │
│  │  If "Tail" selected:                  │  │
│  │    Tail dropdown← get_tail_numbers()  │  │
│  │    ESN dropdown ← get_engines_for_tail│  │
│  │    Operator     ← get_operator_codes  │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  ┌──────────┐  ┌──────────┐                 │
│  │🚀 Analyze│  │🗑️ Clear  │                 │
│  └──────────┘  └──────────┘                 │
│                                             │
│  Analyze → validates all 3 fields           │
│         → sets st.session_state values      │
│         → sets _data_submitted = True       │
│                                             │
│  Clear   → sets _clear_requested = True     │
│         → st.rerun() to clear on next cycle │
└─────────────────────────────────────────────┘
```

### Session State Keys

| Key | Type | Purpose |
|-----|------|---------|
| `engine_serial` | str | Selected ESN (available to all tabs) |
| `tail_number` | str | Selected Tail Number (available to all tabs) |
| `operator_code` | str | Selected Operator Code (available to all tabs) |
| `_data_submitted` | bool | True after user clicks "Analyze" with valid inputs |
| `_clear_requested` | bool | Flag to clear all state on next render cycle |
| `use_custom_input` | bool | Checkbox state for custom input mode |
| `df` | DataFrame | Pipeline events data (from event_service) |
| `now` | datetime | Current UTC time at sidebar render |
| `window_hours` | float | Time window for events (default: 3.0) |

### Dropdown Data Source

All dropdown data comes from `lookup_service.py` which calls `sp_get_filter_options`:

| Function | SP Mode | Returns |
|----------|---------|---------|
| `get_engine_serials()` | `all_esns` | All distinct ESN values |
| `get_tail_numbers()` | `all_tails` | All distinct Tail Number values |
| `get_tails_for_engine(esn)` | `tails_for_esn` | Tails matching the given ESN |
| `get_engines_for_tail(tail)` | `esns_for_tail` | ESNs matching the given Tail |
| `get_operator_codes_for_esn(esn)` | `operators_for_esn` | Operator codes for the given ESN |
| `get_operator_codes_for_tail(tail)` | `operators_for_tail` | Operator codes for the given Tail |

### State Change Handling

When the user toggles "Use custom input" or switches the radio button:
- Previous state values are cleared immediately
- `_data_submitted` is set to `False`
- Streamlit auto-reruns (no explicit `st.rerun()` needed — this was a bug fix)

---

## 6. Tab-by-Tab Code Flow

### 6.1 Overview Tab

**File:** `app_pages/overview.py`

```
overview.render()
  │
  ├─ show_filter_info()          → Get ESN, Tail, Operator from session
  ├─ Early return if no ESN/Tail
  │
  ├─ now = datetime.utcnow().replace(second=0, microsecond=0)
  │   (Rounded to minute for cache key stability)
  │
  ├─ SECTION 1: Status Summary Cards (Pass / Fail / Pending)
  │   └─ build_diagnostic_pass_fail_summary(esn, tail)
  │       └─ get_status_counts(esn, tail)
  │           └─ _get_sp_statuses(esn, tail)
  │               └─ _call_sp_overview(esn, tail)        ← CACHED (60s)
  │                   └─ sp_get_overview_data(esn, tail)  ← PostgreSQL SP
  │
  ├─ SECTION 2: SLA Timeline
  │   └─ build_diagnostic_sla_timeline_html(esn, tail, now)  ← CACHED (60s)
  │       └─ get_sla_timeline_data(esn, tail, now)
  │
  ├─ SECTION 3: Domino Style Progress
  │   └─ build_diagnostic_dominos_style_tracker_html(esn, tail, now)  ← CACHED (60s)
  │       └─ calculate_system_statuses(esn, tail)
  │
  ├─ SECTION 4: Error Notifications
  │   └─ build_diagnostic_error_notifications(esn, tail, now)  ← CACHED (60s)
  │   └─ Send Alert button (if failures exist)
  │       └─ send_error_alert(esn, tail, operator, failed_systems)
  │           └─ AWS SNS publish
  │
  ├─ SECTION 5: Last Updated Times (table)
  │   └─ build_diagnostic_last_updated_table(esn, tail)  ← CACHED (60s)
  │       └─ get_last_updated_times(esn, tail)
  │
  └─ SECTION 6: Root Cause & Governance (table)
      └─ build_diagnostic_root_cause_panel(esn, tail)  ← CACHED (60s)
          └─ calculate_system_statuses(esn, tail)
          └─ Loads from config/*.json for failed systems
```

### 6.2 Timeline Tab

**File:** `app_pages/timeline.py`

```
timeline.render()
  │
  ├─ show_filter_info() → Get ESN, Tail
  ├─ Early return if no ESN/Tail
  │
  └─ build_diagnostic_timeline(esn, tail)  ← CACHED (60s)
      └─ get_timeline_chart_data(esn, tail)
          └─ _get_sp_statuses(esn, tail)
```

### 6.3 Flow & Network Tab

**File:** `app_pages/flow_network.py`

```
flow_network.render()
  │
  ├─ show_filter_info() → Get ESN, Tail
  ├─ Early return if no ESN/Tail
  │
  ├─ build_diagnostic_sankey(esn, tail)          ← CACHED (60s)
  │   └─ calculate_system_statuses(esn, tail)
  │
  └─ build_diagnostic_network_graph(esn, tail)   ← CACHED (60s)
      └─ calculate_system_statuses(esn, tail)
```

### 6.4 Data Elements Tab

**File:** `app_pages/data_elements.py`

```
data_elements.render()
  │
  ├─ show_filter_info() → Get ESN, Tail
  ├─ Early return if no ESN/Tail
  │
  ├─ get_data_elements_matrix(esn, tail)
  │   └─ _call_sp_matrix(esn, tail)                      ← CACHED (60s)
  │       └─ sp_get_data_elements_matrix(esn, tail)       ← PostgreSQL SP
  │   └─ _build_matrix_from_sp(rows)
  │       Returns: {properties, systems, matrix, summary, failures}
  │
  ├─ KPI Metrics: Properties Tracked, Pass Count, Fail Count, Pass Rate
  │
  ├─ Status Filter: Radio [All | Pass | Fail]
  │   └─ filter_matrix_by_status(matrix_data, filter)
  │
  ├─ Heatmap Grid
  │   └─ build_data_elements_heatmap(df, esn, tail, matrix_data)  ← CACHED (60s)
  │       Renders 19×4 HTML table with color-coded cells
  │
  └─ Failed Elements Details (paginated table)
      └─ 20 rows per page with numbered pagination
```

**Data Elements Matrix Structure:**

```python
{
    "properties": ["ESN", "Diagnostic Installation Date", ...],  # 19 items
    "systems": ["1FA", "1FDI", "PHM", "FMX"],                   # 4 items
    "matrix": {
        "ESN": {
            "1FA":  {"value": "729497", "status": "Pass", "reason": ""},
            "1FDI": {"value": "729497", "status": "Pass", "reason": ""},
            "PHM":  {"value": "NULL",   "status": "Fail", "reason": "Null value found"},
            "FMX":  {"value": "729497", "status": "Pass", "reason": ""},
            "expected": "729497"
        },
        "Diagnostic Tail": { ... },
        ...
    },
    "summary": {"total": 76, "passed": 60, "failed": 16, "pass_rate": 78.9},
    "failures": [
        {"system": "PHM", "property": "ESN", "expected": "729497", "actual": "NULL", "reason": "Null value found"},
        ...
    ]
}
```

### 6.5 Raw Data Tab

**File:** `app_pages/raw_data.py`

```
raw_data.render()
  │
  ├─ show_filter_info() → Get ESN, Tail
  ├─ Early return if no ESN/Tail
  │
  └─ get_raw_data(esn, tail)
      └─ _fetch_raw_cached(esn, tail)       ← CACHED (60s)
          └─ _fetch_raw_data_from_db(esn, tail)
              └─ Direct SQL: SELECT from edm_raw.asset_diagnostic_stg
                  Uses ROW_NUMBER() to get latest row per system
                  Returns: engine_serial, tail_number, system, start_time,
                           end_time, status, latency_sec, records, data_size_mb
```

### 6.6 Database Query Tab

**File:** `app_pages/db_query.py`

Provides a text area for ad-hoc SQL queries and displays results as a DataFrame.
Uses `run_query()` from `services/db.py` directly.

---

## 7. Service Layer

### 7.1 db.py — Database Connection

**File:** `services/db.py`

This is the foundation layer. All database access flows through here.

```python
# Connection pool — created ONCE, cached permanently
@st.cache_resource
def get_engine():
    url = get_database_url()        # From config/settings.py
    return create_engine(
        url,
        pool_pre_ping=True,         # Auto-reconnect stale connections
        pool_size=5,                # 5 persistent connections
        max_overflow=10,            # Up to 15 total under load
    )

# Query helpers (no caching — callers cache their own results)
def run_query(sql, params)       → pd.DataFrame   # For SELECT returning rows
def run_query_single(sql, params)→ scalar          # For single-value queries
def run_query_list(sql, params)  → list            # For single-column lists
```

**Parameter Binding:** Uses SQLAlchemy `text()` with `:param` named placeholders:
```python
run_query("SELECT * FROM sp_get_overview_data(:esn, :tail)", {"esn": "729497", "tail": "HZ-FAB"})
```

### 7.2 diagnostic_service.py — Overview Data

**File:** `services/diagnostic_service.py`

Central service for all Overview page data. Single SP call, multiple public functions.

```
┌──────────────────────────────────────────────────┐
│  sp_get_overview_data(esn, tail)                 │
│  Returns 4 rows: system_name, last_update_time,  │
│                   status, message, time_str       │
└──────────────────┬───────────────────────────────┘
                   │
          _call_sp_overview(esn, tail)  ← @st.cache_data(ttl=60s)
                   │
          _get_sp_statuses(esn, tail)   ← Maps rows to dict
                   │
    ┌──────────────┼──────────────────────────────────────┐
    │              │              │              │         │
    ▼              ▼              ▼              ▼         ▼
get_diagnostic   calculate_   get_status    get_total   get_last
_records()       system_      _counts()     _and_       _updated
                 statuses()                 completed() _times()
    │              │              │              │         │
    ▼              ▼              ▼              ▼         ▼
{sys: time}    {sys: full    {pass: N,     (total,     [{system,
               status dict}  fail: N,      completed)  last_updated}]
                             pending: N}
```

**Public API (8 functions, all same signatures):**

| Function | Returns | Used By |
|----------|---------|---------|
| `get_diagnostic_records(esn, tail)` | `{sys: datetime}` | charts.py |
| `calculate_system_statuses(esn, tail)` | `{sys: {status, time, message, time_str}}` | charts.py, overview.py |
| `get_status_counts(esn, tail)` | `{pass: N, fail: N, pending: N}` | kpis.py, charts.py |
| `get_total_and_completed(esn, tail)` | `(total, completed)` | kpis.py |
| `get_last_updated_times(esn, tail)` | `[{system, last_updated}]` | charts.py |
| `get_data_population(esn, tail)` | `{sys: {present, missing}}` | charts.py |
| `get_sla_timeline_data(esn, tail, now)` | `{systems, freshness_minutes, freshness_status}` | charts.py |
| `get_timeline_chart_data(esn, tail)` | `[{system, last_update, status, message}]` | charts.py |

### 7.3 data_element_service.py — Data Elements Matrix

**File:** `services/data_element_service.py`

```
get_data_elements_matrix(esn, tail)
  │
  ├─ DB available?
  │   ├─ YES → _call_sp_matrix(esn, tail)       ← @conditional_cache (60s)
  │   │         └─ "SELECT * FROM sp_get_data_elements_matrix(:esn, :tail)"
  │   │         └─ Returns flat DataFrame (76 rows = 19 props × 4 systems)
  │   │
  │   │     → _build_matrix_from_sp(rows)
  │   │         └─ Converts flat rows to nested dict:
  │   │            {properties, systems, matrix, summary, failures}
  │   │
  │   └─ NO / Error → _build_simulated_matrix(esn, tail)
  │                     └─ Deterministic random simulation using hash(esn+tail)
  │
  └─ Returns dict (same structure regardless of data source)
```

**Configuration:**
- `ENABLE_CACHE = True` — toggle caching on/off
- `CACHE_TTL_SECONDS = 60` — cache duration
- `SYSTEMS = ["1FA", "1FDI", "PHM", "FMX"]`
- `DISPLAY_PROPERTIES` — ordered list of 19 property names

### 7.4 lookup_service.py — Filter Dropdowns

**File:** `services/lookup_service.py`

Single SP with 6 modes, cached for 5 minutes (dropdowns change rarely).

```
_call_sp_filter(mode, value)           ← @st.cache_data(ttl=300s)
  └─ "SELECT * FROM sp_get_filter_options(:mode, :value)"
  └─ Returns list of option values

Public API:
  get_engine_serials()                 → mode="all_esns"
  get_tail_numbers()                   → mode="all_tails"
  get_tails_for_engine(esn)            → mode="tails_for_esn"
  get_engines_for_tail(tail)           → mode="esns_for_tail"
  get_operator_codes_for_esn(esn)      → mode="operators_for_esn"
  get_operator_codes_for_tail(tail)    → mode="operators_for_tail"
```

**Fallback:** If DB is unavailable, returns hardcoded sample data from `utils/constants.py`.

### 7.5 raw_data_service.py — Raw Data Grid

**File:** `services/raw_data_service.py`

```
get_raw_data(esn, tail)
  └─ _fetch_raw_cached(esn, tail)      ← @st.cache_data(ttl=60s)
      └─ _fetch_raw_data_from_db(esn, tail)
          └─ Direct SQL with ROW_NUMBER() to get latest per system
              FROM edm_raw.asset_diagnostic_stg
              WHERE esn = :esn AND diagnostic_tail = :tail
```

Displays columns: `engine_serial, tail_number, system, start_time, end_time, status, latency_sec, records, data_size_mb`

Systems shown: 1FA, IFS, FDM, 1FDI, PHM, SOAR, RDF, FMX (8 systems — more than the 4 validated systems)

### 7.6 event_service.py — Pipeline Events

**File:** `services/event_service.py`

```
get_events(engine_serial, tail_number, now, hours=3.0, variation="Normal")
  │
  ├─ DB available?
  │   ├─ YES → _query_events_cached(esn, tail, start_window_str)  ← @st.cache_data(60s)
  │   │         └─ SELECT from pipeline_events
  │   │             WHERE engine_serial = :esn AND tail_number = :tail
  │   │               AND start_time >= :start_window
  │   │
  │   └─ NO / Error / Empty → _simulate_events(esn, tail, now, hours, variation)
  │
  └─ Returns DataFrame with: engine_serial, tail_number, system,
     start_time, end_time, status, latency_sec, records, data_size_mb
```

**Note:** `start_window` is converted to ISO string for cache key stability.

### 7.7 sns_service.py — Alert Notifications

**File:** `services/sns_service.py`

Sends email alerts via AWS SNS when system failures are detected.

```
send_error_alert(engine_serial, tail_number, operator_code, failed_systems)
  │
  ├─ get_sns_client()
  │   Tries credentials in order:
  │     1. Hardcoded SAML credentials (if _USE_HARDCODED=True)
  │     2. Streamlit secrets [aws] section
  │     3. SAML profile
  │     4. Environment variables
  │     5. AWS SSO/default profile
  │     6. Default credentials chain
  │
  └─ client.publish(TopicArn, Message, Subject, MessageAttributes)
      └─ SNS topic: arn:aws:sns:us-east-1:395527390279:av-edm-streamlit-alert
      └─ Message: HTML email with failure details
      └─ Subject: "[SEVERITY] EDM Alert: Data Pipeline Failure - ESN X | Aircraft Y"
```

**Severity Levels:**
- CRITICAL: 3+ systems failed
- HIGH: 2 systems failed
- MEDIUM: 1 system failed

---

## 8. Stored Procedures (SQL)

All SPs are in the `sql/` directory. Deploy to PostgreSQL before running the app.

### 8.1 sp_get_overview_data

**File:** `sql/sp_get_overview_data.sql`

**Purpose:** Returns system statuses for the Overview page (4 rows).

**Input:** `(p_esn TEXT, p_tail TEXT)`

**Output:** `system_name, last_update_time, status, message, time_str`

**Logic:**
```
Step 1: Get LATEST row per system using ROW_NUMBER()
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn AND diagnostic_tail = p_tail
        PARTITION BY data_source
        ORDER BY last_update_date DESC NULLS LAST

Step 2: Cascading validation
        1FA:  PASS if last_update_date IS NOT NULL
        1FDI: PENDING if 1FA failed
              FAIL if no data / time before 1FA / gap > 30 min
              PASS if time after 1FA and gap <= 30 min
        PHM:  Same logic relative to 1FDI
        FMX:  Same logic relative to PHM

Step 3: Return 4 rows with status + human-readable message
```

**Bug Fixed:** Previous code used `SELECT DISTINCT data_source, last_update_date` which could return a non-latest timestamp. ROW_NUMBER() guarantees the latest.

### 8.2 sp_get_data_elements_matrix

**File:** `sql/sp_get_data_elements_matrix.sql`

**Purpose:** Returns the full validation matrix (76 rows = 19 properties × 4 systems).

**Input:** `(p_esn TEXT, p_tail TEXT)`

**Output:** `property_name, system_name, actual_value, expected, status, reason`

**Logic (7-step pipeline, single SQL query):**
```
Step 1: latest         – ROW_NUMBER() to get latest row per system
Step 2: systems        – Filter rn = 1
Step 3: unpivoted      – CROSS JOIN LATERAL (VALUES ...) to unpivot 19 columns into rows
Step 4: normalised     – NULL/empty/NaN/None → 'NULL', trim whitespace
Step 5: with_flags     – Flag invalid placeholder dates (9999-01-01, 1900-01-01, etc.)
Step 6: expected_calc  – Determine expected value: 1FA → 1FDI → PHM → FMX → '—'
Step 7: validated      – Compare actual vs expected:
                          NULL → Fail ("Null value found")
                          Invalid date → Fail ("Invalid placeholder date")
                          1FA with value → Pass (always)
                          No baseline → Pass
                          Match → Pass
                          Mismatch → Fail ("Value mismatch: expected X got Y")

Output: Ordered by property display order, then system order
```

**Performance:**
- Single table scan (ROW_NUMBER partition pruning)
- LATERAL VALUES unpivot (replaces 17 UNION ALLs from original)
- Scales to 100K+ records with recommended index:
```sql
CREATE INDEX IF NOT EXISTS idx_asset_diag_esn_tail_latest
    ON edm_raw.asset_diagnostic_stg (esn, diagnostic_tail, data_source, last_update_date DESC NULLS LAST);
```

### 8.3 sp_get_filter_options

**File:** `sql/sp_get_filter_options.sql`

**Purpose:** Returns filter dropdown values for the sidebar.

**Input:** `(p_mode TEXT, p_value TEXT DEFAULT NULL)`

**Output:** `option_value TEXT`

**Modes:**

| Mode | Query | Returns |
|------|-------|---------|
| `all_esns` | `SELECT DISTINCT esn` | All unique ESN values |
| `all_tails` | `SELECT DISTINCT diagnostic_tail` | All unique Tail values |
| `tails_for_esn` | `WHERE esn = p_value` | Tails for given ESN |
| `esns_for_tail` | `WHERE diagnostic_tail = p_value` | ESNs for given Tail |
| `operators_for_esn` | `WHERE esn = p_value` | Operator codes for ESN |
| `operators_for_tail` | `WHERE diagnostic_tail = p_value` | Operator codes for Tail |

All modes filter out NULL and empty values, and return results sorted alphabetically.

---

## 9. Caching Architecture

The application uses a **3-layer caching strategy** to minimize database calls:

```
┌─────────────────────────────────────────────────────────────┐
│ LAYER 1: Connection Pool                                     │
│ ─────────────────────────                                    │
│ Where:   services/db.py → get_engine()                       │
│ Cache:   @st.cache_resource (permanent, never expires)       │
│ What:    SQLAlchemy engine with pool_size=5, max_overflow=10 │
│ Why:     Creating DB connections is expensive (~100ms each)   │
│ Scope:   Shared across ALL users and sessions                │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 2: Service / SP Result Cache                           │
│ ──────────────────────────────────                           │
│ Where:   Each service file's internal cached function        │
│ Cache:   @st.cache_data(ttl=60s or 300s)                     │
│ What:    DataFrame / list results from stored procedures     │
│                                                              │
│ Service                     │ TTL   │ Cache Key              │
│ ────────────────────────────┼───────┼────────────────────    │
│ diagnostic_service          │  60s  │ (esn, tail)            │
│ data_element_service        │  60s  │ (esn, tail)            │
│ lookup_service              │ 300s  │ (mode, value)          │
│ raw_data_service            │  60s  │ (esn, tail)            │
│ event_service               │  60s  │ (esn, tail, start_str) │
│                                                              │
│ Why:  Same ESN+Tail combo → same SP result for 60 seconds.   │
│       Filter dropdowns cached 5 min (data changes rarely).   │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ LAYER 3: Chart Output Cache                                  │
│ ──────────────────────────                                   │
│ Where:   utils/charts.py → 11 builder functions              │
│ Cache:   @st.cache_data(ttl=60s)                             │
│ What:    HTML strings / DataFrames / Plotly figures           │
│                                                              │
│ Function                              │ Cache Key             │
│ ──────────────────────────────────────┼───────────────────    │
│ build_diagnostic_pass_fail_summary    │ (esn, tail)           │
│ build_diagnostic_population_pies      │ (esn, tail)           │
│ build_diagnostic_last_updated_table   │ (esn, tail)           │
│ build_diagnostic_sla_timeline_html    │ (esn, tail, now)      │
│ build_diagnostic_root_cause_panel     │ (esn, tail)           │
│ build_diagnostic_dominos_style_tracker│ (esn, tail, now)      │
│ build_diagnostic_error_notifications  │ (esn, tail, now)      │
│ build_diagnostic_timeline             │ (esn, tail)           │
│ build_diagnostic_sankey               │ (esn, tail)           │
│ build_diagnostic_network_graph        │ (esn, tail)           │
│ build_data_elements_heatmap           │ (df, esn, tail, data) │
│                                                              │
│ Why:  Chart rendering is expensive (HTML generation, Plotly   │
│       figure construction). Cache the final output so         │
│       re-renders within 60s return instantly.                 │
└─────────────────────────────────────────────────────────────┘
```

### Cache Key Stability

For functions that accept `now` (datetime), the caller in `overview.py` rounds to the minute:
```python
now = datetime.utcnow().replace(second=0, microsecond=0)
```
This ensures the cache key stays the same for ~60 seconds, aligning with the 60s TTL.

### Cache Invalidation

- **Automatic:** TTL expiry (60s or 300s depending on layer)
- **Manual:** User clicks "Clear" in sidebar → `st.session_state` is reset → next render uses new cache keys if ESN/Tail changed
- **Global:** `st.cache_data.clear()` can be called programmatically if needed

### When Cache Does NOT Help

- First load with a new ESN/Tail combo (cache miss)
- After TTL expires (60s or 300s)
- Different `now` minute boundary (for chart functions with `now` parameter)

---

## 10. Data Model & Database

### Primary Table: `edm_raw.asset_diagnostic_stg`

This is the single source of truth for all diagnostic data.

| Column | Type | Description |
|--------|------|-------------|
| `esn` | TEXT | Engine Serial Number |
| `diagnostic_tail` | TEXT | Aircraft Tail Number |
| `data_source` | TEXT | System name (1FA, 1FDI, PHM, FMX, IFS, FDM, SOAR, RDF) |
| `last_update_date` | TIMESTAMPTZ | When this system last received data |
| `diagnostic_installation_date` | TEXT | Installation date for diagnostics |
| `engine_position` | TEXT | Engine position (1 or 2) |
| `installation_date` | TEXT | Installation date |
| `n1_modifier` | TEXT | N1 modifier value |
| `operator` | TEXT | Operator identifier |
| `monitor` | TEXT | Monitor status |
| `operator_diagnostic_code` | TEXT | Operator diagnostic code |
| `tail_number_aircraft_id` | TEXT | Tail number aircraft identifier |
| `engine_model` | TEXT | Engine model (e.g., CFM56-7B26) |
| `engine_type` | TEXT | Engine type (e.g., TURBOFAN) |
| `engine_family_model_series` | TEXT | Engine family series |
| `aircraft_delivery_date` | TEXT | Aircraft delivery date |
| `aircraft_family` | TEXT | Aircraft family (e.g., A320) |
| `aircraft_model` | TEXT | Aircraft model (e.g., A320-214) |
| `aircraft_series` | TEXT | Aircraft series |
| `installation_history` | TEXT | Installation history |

### Secondary Table: `pipeline_events`

Used by `event_service.py` for pipeline event tracking.

| Column | Type | Description |
|--------|------|-------------|
| `engine_serial` | TEXT | ESN |
| `tail_number` | TEXT | Tail Number |
| `system` | TEXT | System name |
| `start_time` | TIMESTAMPTZ | Event start time |
| `end_time` | TIMESTAMPTZ | Event end time |
| `status` | TEXT | Event status |
| `latency_sec` | NUMERIC | Processing latency |
| `records` | INTEGER | Record count |
| `data_size_mb` | NUMERIC | Data size in MB |

### Recommended Index

```sql
CREATE INDEX IF NOT EXISTS idx_asset_diag_esn_tail_latest
    ON edm_raw.asset_diagnostic_stg (esn, diagnostic_tail, data_source, last_update_date DESC NULLS LAST);
```

This covering index ensures ROW_NUMBER() queries do an index-only scan, critical for 100K+ records.

---

## 11. Validation Logic

### Overview Validation (Cascading — sp_get_overview_data)

The 4 systems are validated in a dependency chain:

```
1FA  ──pass──→  1FDI  ──pass──→  PHM  ──pass──→  FMX
  │                │                │                │
  │ fail/pending   │ fail/pending   │ fail/pending   │
  ▼                ▼                ▼                ▼
1FDI=PENDING    PHM=PENDING     FMX=PENDING      (end)
```

**Rules:**
| System | Pass Condition | Fail Condition | Pending Condition |
|--------|---------------|----------------|-------------------|
| **1FA** | `last_update_date IS NOT NULL` | No data | Never |
| **1FDI** | Time > 1FA AND gap <= 30 min | No data, time < 1FA, or gap > 30 min | 1FA failed/pending |
| **PHM** | Time > 1FDI AND gap <= 30 min | No data, time < 1FDI, or gap > 30 min | 1FDI failed/pending |
| **FMX** | Time > PHM AND gap <= 30 min | No data, time < PHM, or gap > 30 min | PHM failed/pending |

### Data Elements Validation (Cross-System — sp_get_data_elements_matrix)

For each of the 19 properties across 4 systems:

1. **Normalize:** NULL, empty, "None", "NaN", "NaT" → `NULL`
2. **Flag invalid dates:** 9999-01-01, 9999-12-31, 1900-01-01, 0001-01-01
3. **Expected value:** Priority order: 1FA → 1FDI → PHM → FMX → "—"
4. **Validate:**

| Condition | Status | Reason |
|-----------|--------|--------|
| Value is NULL | Fail | "Null value found" |
| Invalid placeholder date | Fail | "Invalid placeholder date: {value}" |
| System is 1FA with valid value | Pass | (1FA defines truth) |
| No baseline exists ("—") | Pass | (nothing to compare against) |
| Value matches expected | Pass | |
| Value mismatches expected | Fail | "Value mismatch: expected '{X}' but got '{Y}'" |

---

## 12. Configuration & Secrets

### Database Credentials (config/settings.py)

The `get_database_url()` function tries these sources in order:

1. **Hardcoded** (if `_USE_HARDCODED = True`) — for development/testing
2. **Environment variable** `SECRET_NAME` → AWS Secrets Manager
3. **Streamlit secrets** `[aws]` section → AWS Secrets Manager
4. **Streamlit secrets** `[postgres]` section → direct connection string

### secrets.toml Structure

```toml
# Option A: Direct PostgreSQL connection
[postgres]
host = "your-rds-endpoint.amazonaws.com"
port = 5432
dbname = "postgres"
user = "edm_raw_web"
password = "your-password"

# Option B: AWS Secrets Manager
[aws]
secret_name = "av-edm-dev-rds-rpt-credentials"
region = "us-east-1"
profile = "saml"
access_key_id = "AKIA..."
secret_access_key = "..."
session_token = "..."
```

### Root Cause Configuration (config/*.json)

Each system has a JSON file with root cause templates:
- `config/1FArootcause.json`
- `config/1FDIrootcause.json`
- `config/PHMrootcause.json`
- `config/FMXrootcause.json`

These are loaded by `build_diagnostic_root_cause_panel()` in charts.py when a system fails.

---

## 13. How to Run

### Prerequisites

- Python 3.10+
- PostgreSQL database with `edm_raw.asset_diagnostic_stg` table
- (Optional) AWS credentials for SNS alerts

### Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Deploy stored procedures to PostgreSQL
psql -h your-host -U your-user -d postgres -f sql/sp_get_filter_options.sql
psql -h your-host -U your-user -d postgres -f sql/sp_get_overview_data.sql
psql -h your-host -U your-user -d postgres -f sql/sp_get_data_elements_matrix.sql

# 3. (Optional) Create performance index
psql -h your-host -U your-user -d postgres -c "
CREATE INDEX IF NOT EXISTS idx_asset_diag_esn_tail_latest
    ON edm_raw.asset_diagnostic_stg (esn, diagnostic_tail, data_source, last_update_date DESC NULLS LAST);
"

# 4. Configure secrets (copy and edit)
cp app/.streamlit/secrets.toml.example app/.streamlit/secrets.toml
# Edit secrets.toml with your database credentials

# 5. Run the app
cd app
streamlit run main.py
```

### Without Database

The app works without a database connection. All services have fallback behavior:
- `diagnostic_service.py` → Returns "pending" status for all systems
- `data_element_service.py` → Returns simulated matrix data
- `lookup_service.py` → Returns hardcoded sample ESN/Tail/Operator lists
- `event_service.py` → Returns simulated pipeline events
- `raw_data_service.py` → Returns empty DataFrame

---

## 14. How to Update / Extend

### Adding a New System (e.g., "IFS")

1. **constants.py:** Add `"IFS"` to `SYSTEM_FLOW` list
2. **sp_get_overview_data.sql:** Add `v_ifs_time`, `v_ifs_status`, `v_ifs_msg` variables and validation block
3. **sp_get_data_elements_matrix.sql:** Already handles any `data_source` value from the table (no change needed if IFS rows exist in DB)
4. **sp_get_filter_options.sql:** No change needed (queries are generic)
5. **config/:** Add `IFSrootcause.json` if root cause panel is needed

### Adding a New Property to Data Elements

1. **sp_get_data_elements_matrix.sql:** Add the new column to the `LATERAL VALUES` block:
   ```sql
   ('New Property Name', s.new_column_name::TEXT),
   ```
2. **sp_get_data_elements_matrix.sql:** Add to the ORDER BY CASE block with the next number
3. **data_element_service.py:** Add to `DISPLAY_PROPERTIES` and `COLUMN_TO_PROPERTY`
4. **constants.py:** Add to `DATA_ELEMENTS` list

### Adding a New Tab

1. Create `app/app_pages/new_tab.py` with a `render()` function
2. Add tab name to `components/horizontal_menu.py` → `MENU_ITEMS` list
3. Import and add renderer to `main.py` → `PAGE_RENDERERS` list
4. Create any needed service functions in the appropriate service file

### Adding a New Chart to Overview

1. Create the chart builder function in `utils/charts.py`:
   ```python
   @st.cache_data(ttl=CHART_CACHE_TTL, show_spinner=False)
   def build_new_chart(engine_serial: str, diagnostic_tail: str) -> str:
       # Build and return HTML or Plotly figure
   ```
2. Import it in `app_pages/overview.py`
3. Call it in the `render()` function with `st.markdown(html, unsafe_allow_html=True)`

### Adding a New Stored Procedure

1. Create `sql/sp_new_procedure.sql`
2. Create a service file or add to existing service:
   ```python
   @st.cache_data(ttl=60, show_spinner=False)
   def _call_new_sp(param1, param2):
       sql = "SELECT * FROM sp_new_procedure(:p1, :p2)"
       return run_query(sql, {"p1": param1, "p2": param2})
   ```
3. Deploy to PostgreSQL: `psql -f sql/sp_new_procedure.sql`

### Changing Cache TTL

| What to Change | Where |
|---------------|-------|
| SP result cache (diagnostic/data elements) | Service file → `CACHE_TTL_SECONDS = 60` |
| Filter dropdown cache | `lookup_service.py` → `CACHE_TTL_SECONDS = 300` |
| Chart output cache | `charts.py` → `CHART_CACHE_TTL = 60` |
| Connection pool | Cannot expire (permanent via `@st.cache_resource`) |

### Disabling Cache (for Debugging)

Set `ENABLE_CACHE = False` in the relevant service file:
- `data_element_service.py` line 26
- `diagnostic_service.py` line 33

Or clear all caches programmatically:
```python
st.cache_data.clear()
```

### Updating Database Credentials

1. If using hardcoded: Edit `config/settings.py` → `_HARDCODED_DB` dict
2. If using secrets.toml: Edit `app/.streamlit/secrets.toml`
3. If using Secrets Manager: Update the AWS secret value
4. Restart the Streamlit app (connection pool is permanent)

### Updating AWS SNS Credentials

1. Edit `services/sns_service.py` → `_HARDCODED_AWS` dict with fresh SAML credentials
2. Or update `app/.streamlit/secrets.toml` → `[aws]` section
3. No restart needed (SNS client is created per-request, not cached)
