import streamlit as st

from utils.charts import build_latency_chart
from utils.utils import show_no_data_message


def render():
    df = st.session_state.get("df", None)
    engine_serial = st.session_state.get("engine_serial", "")
    tail_number = st.session_state.get("tail_number", "")

    st.subheader(" Latency Analysis")
    
    # Check if filters are selected and data is available
    if not engine_serial or not tail_number or df is None or (hasattr(df, 'empty') and df.empty):
        show_no_data_message("Latency Analysis")
        return
    
    latency_fig = build_latency_chart(df)
    st.plotly_chart(latency_fig, use_container_width=True)
    st.caption("Latency includes processing + transfer overhead. Delays/Errors inflate values.")
