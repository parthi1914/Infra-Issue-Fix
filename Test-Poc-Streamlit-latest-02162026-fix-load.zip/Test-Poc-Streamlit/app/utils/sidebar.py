import streamlit as st
from datetime import datetime

from services.lookup_service import (
    get_engine_serials,
    get_tail_numbers,
    get_tails_for_engine,
    get_engines_for_tail,
    get_operator_codes_for_esn,
    get_operator_codes_for_tail,
)
from services.event_service import get_events


def setup_sidebar():
    """
    Setup sidebar filters with dynamic dropdown loading.
    
    Logic:
    ------
    1. If "Use custom input" is checked:
       - Select by is locked to "Engine Serial (ESN)"
       - Dropdowns are shown as empty and disabled
       - Only text inputs for Engine Serial and Tail Number are active
       - These custom values are passed to all tabs
    
    2. If "Engine Serial (ESN)" selected (and not custom):
       - Load ESN dropdown from edm_raw.asset_diagnostic_stg
       - On ESN selection, load corresponding Tail Numbers (diagnostic_tail)
    
    3. If "Tail Number" selected (and not custom):
       - Load Tail dropdown from edm_raw.asset_diagnostic_stg
       - On Tail selection, load corresponding ESNs
    """
    
    # -----------------------------------------------------------------
    # Handle Clear Request (must be BEFORE widgets are rendered)
    # -----------------------------------------------------------------
    if st.session_state.get("_clear_requested", False):
        # Clear the flag first
        st.session_state._clear_requested = False
        # Now clear all values (safe because widgets haven't been rendered yet)
        st.session_state.engine_serial = ""
        st.session_state.tail_number = ""
        st.session_state.operator_code = ""
        st.session_state.custom_esn_value = ""
        st.session_state.custom_tail_value = ""
        st.session_state.custom_operator_value = ""
        st.session_state.use_custom_input = False
        st.session_state._data_submitted = False
        st.session_state._prev_use_custom = None
        st.session_state._prev_selection_method = None
        # Clear dropdown keys
        for key in ["esn_dropdown", "tail_dropdown", "tail_for_esn_dropdown", 
                    "esn_for_tail_dropdown", "operator_for_esn_dropdown", "operator_for_tail_dropdown",
                    "selection_method"]:
            if key in st.session_state:
                del st.session_state[key]
    
    st.sidebar.header("Filters")
    
    # -----------------------------------------------------------------
    # Enterprise Button Styling
    # -----------------------------------------------------------------
    btn_css = """
    <style>
    /* Enterprise gradient styling for sidebar buttons */
    [data-testid="stSidebar"] .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white !important;
        border: none !important;
        border-radius: 8px;
        font-weight: 600;
        padding: 0.6rem 1rem;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        transition: all 0.3s ease;
        width: 100%;
    }
    [data-testid="stSidebar"] .stButton > button:hover {
        background: linear-gradient(135deg, #5a6fd6 0%, #6a4190 100%);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        transform: translateY(-2px);
    }
    [data-testid="stSidebar"] .stButton > button:active {
        transform: translateY(0);
    }
    /* Clear button - red gradient */
    [data-testid="stSidebar"] .clear-btn button {
        background: linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%) !important;
        box-shadow: 0 4px 15px rgba(238, 90, 90, 0.4);
    }
    [data-testid="stSidebar"] .clear-btn button:hover {
        background: linear-gradient(135deg, #ff5252 0%, #d94848 100%) !important;
        box-shadow: 0 6px 20px rgba(238, 90, 90, 0.6);
    }
    
    /* Enterprise Dropdown/Selectbox Styling */
    [data-testid="stSidebar"] .stSelectbox > div > div {
        background: linear-gradient(180deg, #ffffff 0%, #f8f9fa 100%);
        border: 1.5px solid #e0e5ec;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        transition: all 0.2s ease;
    }
    [data-testid="stSidebar"] .stSelectbox > div > div:hover {
        border-color: #667eea;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
    }
    [data-testid="stSidebar"] .stSelectbox > div > div:focus-within {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
    }
    /* Dropdown label styling */
    [data-testid="stSidebar"] .stSelectbox label {
        font-weight: 600;
        color: #374151;
        font-size: 0.9rem;
        margin-bottom: 4px;
    }
    /* Search hint styling */
    .search-hint {
        font-size: 11px;
        color: #667eea;
        font-style: italic;
        margin-top: -8px;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 4px;
    }
    .search-hint svg {
        width: 12px;
        height: 12px;
    }
    </style>
    """
    st.sidebar.markdown(btn_css, unsafe_allow_html=True)
    
    st.sidebar.subheader("Identifiers")

    # -----------------------------------------------------------------
    # Track state changes to clear data when filter mode changes
    # -----------------------------------------------------------------
    prev_custom = st.session_state.get("_prev_use_custom", None)
    prev_selection_method = st.session_state.get("_prev_selection_method", None)

    # -----------------------------------------------------------------
    # Custom Input Checkbox (at the top, before any inputs)
    # -----------------------------------------------------------------
    custom_values = st.sidebar.checkbox(
        "Use custom input instead",
        key="use_custom_input"
    )
    
    # Detect custom input toggle change — clear data but do NOT call st.rerun()
    # Streamlit already auto-reruns when the checkbox value changes.
    # An extra st.rerun() caused a double-render → duplicate buttons.
    if prev_custom is not None and prev_custom != custom_values:
        st.session_state.engine_serial = ""
        st.session_state.tail_number = ""
        st.session_state.operator_code = ""
        st.session_state.custom_esn_value = ""
        st.session_state.custom_tail_value = ""
        st.session_state.custom_operator_value = ""
        st.session_state._data_submitted = False

    st.session_state._prev_use_custom = custom_values

    # Initialize variables
    engine_choice = ""
    tail_choice = ""
    operator_choice = ""
    engine_serial = ""
    tail_number = ""
    operator_code = ""

    if custom_values:
        # -----------------------------------------------------------------
        # Custom Input Mode
        # -----------------------------------------------------------------
        # Text inputs for manual entry - these are the active inputs
        engine_serial = st.sidebar.text_input(
            "Engine Serial *",
            value=st.session_state.get("custom_esn_value", ""),
            key="custom_esn_input",
            help="Enter ESN manually (Required)"
        )
        
        tail_number = st.sidebar.text_input(
            "Tail Number *",
            value=st.session_state.get("custom_tail_value", ""),
            key="custom_tail_input",
            help="Enter Tail Number (diagnostic_tail) manually (Required)"
        )
        
        operator_code = st.sidebar.text_input(
            "Operator Code *",
            value=st.session_state.get("custom_operator_value", ""),
            key="custom_operator_input",
            help="Enter Operator Code manually (Required)"
        )
        
        # Store custom values for persistence
        st.session_state.custom_esn_value = engine_serial
        st.session_state.custom_tail_value = tail_number
        st.session_state.custom_operator_value = operator_code
        
    else:
        # -----------------------------------------------------------------
        # Dropdown Selection Mode
        # -----------------------------------------------------------------
        # Radio button to select filter mode
        selection_method = st.sidebar.radio(
            "Select by:", 
            ["Engine Serial (ESN)", "Tail Number"], 
            horizontal=True,
            key="selection_method"
        )
        
        # Detect radio button change — clear data, no explicit st.rerun()
        if prev_selection_method is not None and prev_selection_method != selection_method:
            st.session_state.engine_serial = ""
            st.session_state.tail_number = ""
            st.session_state.operator_code = ""
            st.session_state._data_submitted = False

        st.session_state._prev_selection_method = selection_method

        if selection_method == "Engine Serial (ESN)":
            # -----------------------------------------------------------------
            # Mode 1: Select by Engine Serial (ESN)
            # -----------------------------------------------------------------
            # Load all ESNs from database
            engine_serials = get_engine_serials()
            
            if not engine_serials:
                engine_serials = [""]
                st.sidebar.warning("No ESNs found in database")
            
            # ESN dropdown - show first record by default
            engine_choice = st.sidebar.selectbox(
                "Engine Serial",
                options=engine_serials,
                index=0,
                key="esn_dropdown",
                help="Type to search and filter options"
            )
            st.sidebar.markdown("<div class='search-hint'>🔍 Type to filter options</div>", unsafe_allow_html=True)
            
            # Load tails for the selected ESN
            if engine_choice:
                available_tails = get_tails_for_engine(engine_choice)
            else:
                available_tails = [""]
            
            if not available_tails:
                available_tails = [""]
            
            # Tail dropdown based on selected ESN
            tail_choice = st.sidebar.selectbox(
                "Tail Number (for this ESN)",
                options=available_tails,
                index=0,
                key="tail_for_esn_dropdown",
                help="Type to search and filter options"
            )
            st.sidebar.markdown("<div class='search-hint'>🔍 Type to filter options</div>", unsafe_allow_html=True)
            
            # Load operator codes for the selected ESN
            if engine_choice:
                available_operators = get_operator_codes_for_esn(engine_choice)
            else:
                available_operators = [""]
            
            if not available_operators:
                available_operators = [""]
            
            # Operator Code dropdown based on selected ESN
            operator_choice = st.sidebar.selectbox(
                "Operator Code",
                options=available_operators,
                index=0,
                key="operator_for_esn_dropdown",
                help="Type to search and filter options"
            )
            st.sidebar.markdown("<div class='search-hint'>🔍 Type to filter options</div>", unsafe_allow_html=True)
        
        else:
            # -----------------------------------------------------------------
            # Mode 2: Select by Tail Number
            # -----------------------------------------------------------------
            # Load all Tail Numbers from database
            tail_numbers = get_tail_numbers()
            
            if not tail_numbers:
                tail_numbers = [""]
                st.sidebar.warning("No Tail Numbers found in database")
            
            # Tail dropdown - show first record by default
            tail_choice = st.sidebar.selectbox(
                "Tail Number",
                options=tail_numbers,
                index=0,
                key="tail_dropdown",
                help="Type to search and filter options"
            )
            st.sidebar.markdown("<div class='search-hint'>🔍 Type to filter options</div>", unsafe_allow_html=True)
            
            # Load ESNs for the selected tail
            if tail_choice:
                available_esns = get_engines_for_tail(tail_choice)
            else:
                available_esns = [""]
            
            if not available_esns:
                available_esns = [""]
            
            # ESN dropdown based on selected Tail
            engine_choice = st.sidebar.selectbox(
                "Engine Serial (on this aircraft)",
                options=available_esns,
                index=0,
                key="esn_for_tail_dropdown",
                help="Type to search and filter options"
            )
            st.sidebar.markdown("<div class='search-hint'>🔍 Type to filter options</div>", unsafe_allow_html=True)
            
            # Load operator codes for the selected Tail
            if tail_choice:
                available_operators = get_operator_codes_for_tail(tail_choice)
            else:
                available_operators = [""]
            
            if not available_operators:
                available_operators = [""]
            
            # Operator Code dropdown based on selected Tail
            operator_choice = st.sidebar.selectbox(
                "Operator Code",
                options=available_operators,
                index=0,
                key="operator_for_tail_dropdown",
                help="Type to search and filter options"
            )
            st.sidebar.markdown("<div class='search-hint'>🔍 Type to filter options</div>", unsafe_allow_html=True)

        # Use dropdown selections
        engine_serial = engine_choice
        tail_number = tail_choice
        operator_code = operator_choice

    # -----------------------------------------------------------------
    # Mandatory Field Indicator + Action Buttons
    # -----------------------------------------------------------------
    # Render through a stable placeholder container to avoid duplicate
    # transient button blocks during reruns/loading.
    action_block = st.sidebar.empty()
    with action_block.container():
        st.markdown("<small style='color: #888;'>* All fields are mandatory</small>", unsafe_allow_html=True)
        st.markdown("---")
        
        # Custom CSS for equal button sizing
        st.markdown("""
        <style>
        [data-testid="stSidebar"] .row-widget.stButton {
            width: 100%;
        }
        </style>
        """, unsafe_allow_html=True)
        
        btn_col1, btn_col2 = st.columns([1, 1])
        
        # Track if submit was clicked
        submit_clicked = False
        clear_clicked = False
        
        with btn_col1:
            submit_clicked = st.button("🚀 Analyze", key="submit_filters_btn", use_container_width=True)
        
        with btn_col2:
            clear_clicked = st.button("🗑️ Clear", key="clear_filters_btn", use_container_width=True)
    
    # Handle Clear button - set flag and rerun (state will be cleared on next run)
    if clear_clicked:
        st.session_state._clear_requested = True
        st.rerun()
    
    # Handle Submit button with validation
    if submit_clicked:
        # Validate mandatory fields
        if not engine_serial or not engine_serial.strip():
            st.sidebar.error("⚠️ Engine Serial is required")
        elif not tail_number or not tail_number.strip():
            st.sidebar.error("⚠️ Tail Number is required")
        elif not operator_code or not operator_code.strip():
            st.sidebar.error("⚠️ Operator Code is required")
        else:
            # All validations passed - mark as submitted
            st.session_state._data_submitted = True
            st.session_state.engine_serial = engine_serial
            st.session_state.tail_number = tail_number
            st.session_state.operator_code = operator_code

    # -----------------------------------------------------------------
    # Current Time
    # -----------------------------------------------------------------
    now = datetime.utcnow()
    window_hours = 3.0  # Default time window

    # Get events data only if submitted
    variation = "Normal"
    if st.session_state.get("_data_submitted", False):
        df = get_events(engine_serial, tail_number, now, hours=window_hours, variation=variation)
    else:
        df = None

    # -----------------------------------------------------------------
    # Store values in session state for other tabs
    # -----------------------------------------------------------------
    st.session_state.df = df
    st.session_state.engine_serial = engine_serial if st.session_state.get("_data_submitted", False) else ""
    st.session_state.tail_number = tail_number if st.session_state.get("_data_submitted", False) else ""
    st.session_state.operator_code = operator_code if st.session_state.get("_data_submitted", False) else ""
    st.session_state.now = now
    st.session_state.window_hours = window_hours
