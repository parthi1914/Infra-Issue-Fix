-- ============================================================================
-- Stored Procedure: sp_get_overview_data
-- ============================================================================
-- Returns system statuses for the Overview page.
--
-- BUG FIX: Previous code used SELECT DISTINCT data_source, last_update_date
-- which could return multiple rows per system and pick a random one.
-- This SP uses ROW_NUMBER() to guarantee the LATEST row per system.
--
-- Validation Rules (cascading):
--   1FA:  PASS if last_update_date IS NOT NULL
--   1FDI: PENDING if 1FA failed; else PASS if time > 1FA AND gap <= 30 min
--   PHM:  PENDING if 1FDI failed/pending; else PASS if time > 1FDI AND gap <= 30 min
--   FMX:  PENDING if PHM failed/pending; else PASS if time > PHM AND gap <= 30 min
--
-- Returns one row per system (4 rows) with:
--   system_name, last_update_time, status, message, time_str
--
-- Usage:
--   SELECT * FROM sp_get_overview_data('729497', 'HZ-FAB');
-- ============================================================================

DROP FUNCTION IF EXISTS sp_get_overview_data(TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_overview_data(
    p_esn  TEXT,
    p_tail TEXT
)
RETURNS TABLE (
    system_name      TEXT,
    last_update_time TIMESTAMPTZ,
    status           TEXT,
    message          TEXT,
    time_str         TEXT
)
AS $$
DECLARE
    v_1fa_time   TIMESTAMPTZ;
    v_1fdi_time  TIMESTAMPTZ;
    v_phm_time   TIMESTAMPTZ;
    v_fmx_time   TIMESTAMPTZ;

    v_1fa_status   TEXT;
    v_1fdi_status  TEXT;
    v_phm_status   TEXT;
    v_fmx_status   TEXT;

    v_1fa_msg   TEXT;
    v_1fdi_msg  TEXT;
    v_phm_msg   TEXT;
    v_fmx_msg   TEXT;

    v_diff_min  DOUBLE PRECISION;
BEGIN
    -- =====================================================================
    -- Step 1: Get LATEST row per system using ROW_NUMBER
    -- This is the key fix — previous code used SELECT DISTINCT which
    -- could return a non-latest timestamp.
    -- =====================================================================
    SELECT sub.last_update_date INTO v_1fa_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn AND diagnostic_tail = p_tail AND data_source = '1FA'
    ) sub WHERE sub.rn = 1;

    SELECT sub.last_update_date INTO v_1fdi_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn AND diagnostic_tail = p_tail AND data_source = '1FDI'
    ) sub WHERE sub.rn = 1;

    SELECT sub.last_update_date INTO v_phm_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn AND diagnostic_tail = p_tail AND data_source = 'PHM'
    ) sub WHERE sub.rn = 1;

    SELECT sub.last_update_date INTO v_fmx_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn AND diagnostic_tail = p_tail AND data_source = 'FMX'
    ) sub WHERE sub.rn = 1;

    -- =====================================================================
    -- Step 2: Cascading validation
    -- =====================================================================

    -- 1FA: PASS if has data
    IF v_1fa_time IS NOT NULL THEN
        v_1fa_status := 'pass';
        v_1fa_msg    := 'Data received';
    ELSE
        v_1fa_status := 'fail';
        v_1fa_msg    := 'No data received';
    END IF;

    -- 1FDI: depends on 1FA
    IF v_1fa_status IN ('fail', 'pending') THEN
        v_1fdi_status := 'pending';
        v_1fdi_msg    := 'Waiting - previous system (1FA) not complete';
    ELSIF v_1fdi_time IS NULL THEN
        v_1fdi_status := 'fail';
        v_1fdi_msg    := 'No data received';
    ELSIF v_1fa_time IS NULL THEN
        v_1fdi_status := 'fail';
        v_1fdi_msg    := 'Cannot validate - no previous timestamp';
    ELSIF v_1fdi_time < v_1fa_time THEN
        v_diff_min := EXTRACT(EPOCH FROM (v_1fa_time - v_1fdi_time)) / 60.0;
        v_1fdi_status := 'fail';
        v_1fdi_msg    := 'Time is ' || ROUND(v_diff_min::NUMERIC) || ' min BEFORE previous system';
    ELSE
        v_diff_min := EXTRACT(EPOCH FROM (v_1fdi_time - v_1fa_time)) / 60.0;
        IF v_diff_min > 30 THEN
            v_1fdi_status := 'fail';
            v_1fdi_msg    := 'Time gap ' || ROUND(v_diff_min::NUMERIC) || ' min exceeds 30 min limit';
        ELSE
            v_1fdi_status := 'pass';
            v_1fdi_msg    := 'Received ' || ROUND(v_diff_min::NUMERIC) || ' min after previous';
        END IF;
    END IF;

    -- PHM: depends on 1FDI
    IF v_1fdi_status IN ('fail', 'pending') THEN
        v_phm_status := 'pending';
        v_phm_msg    := 'Waiting - previous system (1FDI) not complete';
    ELSIF v_phm_time IS NULL THEN
        v_phm_status := 'fail';
        v_phm_msg    := 'No data received';
    ELSIF v_1fdi_time IS NULL THEN
        v_phm_status := 'fail';
        v_phm_msg    := 'Cannot validate - no previous timestamp';
    ELSIF v_phm_time < v_1fdi_time THEN
        v_diff_min := EXTRACT(EPOCH FROM (v_1fdi_time - v_phm_time)) / 60.0;
        v_phm_status := 'fail';
        v_phm_msg    := 'Time is ' || ROUND(v_diff_min::NUMERIC) || ' min BEFORE previous system';
    ELSE
        v_diff_min := EXTRACT(EPOCH FROM (v_phm_time - v_1fdi_time)) / 60.0;
        IF v_diff_min > 30 THEN
            v_phm_status := 'fail';
            v_phm_msg    := 'Time gap ' || ROUND(v_diff_min::NUMERIC) || ' min exceeds 30 min limit';
        ELSE
            v_phm_status := 'pass';
            v_phm_msg    := 'Received ' || ROUND(v_diff_min::NUMERIC) || ' min after previous';
        END IF;
    END IF;

    -- FMX: depends on PHM
    IF v_phm_status IN ('fail', 'pending') THEN
        v_fmx_status := 'pending';
        v_fmx_msg    := 'Waiting - previous system (PHM) not complete';
    ELSIF v_fmx_time IS NULL THEN
        v_fmx_status := 'fail';
        v_fmx_msg    := 'No data received';
    ELSIF v_phm_time IS NULL THEN
        v_fmx_status := 'fail';
        v_fmx_msg    := 'Cannot validate - no previous timestamp';
    ELSIF v_fmx_time < v_phm_time THEN
        v_diff_min := EXTRACT(EPOCH FROM (v_phm_time - v_fmx_time)) / 60.0;
        v_fmx_status := 'fail';
        v_fmx_msg    := 'Time is ' || ROUND(v_diff_min::NUMERIC) || ' min BEFORE previous system';
    ELSE
        v_diff_min := EXTRACT(EPOCH FROM (v_fmx_time - v_phm_time)) / 60.0;
        IF v_diff_min > 30 THEN
            v_fmx_status := 'fail';
            v_fmx_msg    := 'Time gap ' || ROUND(v_diff_min::NUMERIC) || ' min exceeds 30 min limit';
        ELSE
            v_fmx_status := 'pass';
            v_fmx_msg    := 'Received ' || ROUND(v_diff_min::NUMERIC) || ' min after previous';
        END IF;
    END IF;

    -- =====================================================================
    -- Step 3: Return 4 rows in system order
    -- =====================================================================
    RETURN QUERY
    SELECT '1FA'::TEXT,  v_1fa_time,  v_1fa_status,  v_1fa_msg,
           COALESCE(TO_CHAR(v_1fa_time, 'YYYY-MM-DD HH24:MI:SS'), '—')
    UNION ALL
    SELECT '1FDI'::TEXT, v_1fdi_time, v_1fdi_status, v_1fdi_msg,
           COALESCE(TO_CHAR(v_1fdi_time, 'YYYY-MM-DD HH24:MI:SS'), '—')
    UNION ALL
    SELECT 'PHM'::TEXT,  v_phm_time,  v_phm_status,  v_phm_msg,
           COALESCE(TO_CHAR(v_phm_time, 'YYYY-MM-DD HH24:MI:SS'), '—')
    UNION ALL
    SELECT 'FMX'::TEXT,  v_fmx_time,  v_fmx_status,  v_fmx_msg,
           COALESCE(TO_CHAR(v_fmx_time, 'YYYY-MM-DD HH24:MI:SS'), '—');
END;
$$ LANGUAGE plpgsql STABLE;
