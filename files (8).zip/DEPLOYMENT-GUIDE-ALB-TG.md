# DEPLOYMENT GUIDE - ALB with Target Group

## 📦 Files to Deploy

### 1. `templates/alb/alb.yml`
**Replace with:** `alb-WITH-TARGET-GROUP.yml`

### 2. `templates/root.yml`
**Replace with:** `FINAL-root.yml`

### 3. `params/dev.json`
**Replace with:** `dev-MINIMAL.json`

### 4. Keep existing files:
- ✅ `templates/security/sg.yml` (use FINAL-sg.yml from earlier)
- ✅ `templates/secrets/secrets-params.yml` (use secrets-stack-fixed.yaml from earlier)
- ✅ `templates/s3/buckets.yml` (your existing file)

---

## 🏗️ What Will Be Created

### Stack 1: SecretsStack
- Secrets Manager secrets
- SSM parameters

### Stack 2: S3Stack
- S3 bucket for artifacts

### Stack 3: SecurityStack
- Security Group for ALB

### Stack 4: AlbStack (NEW - Updated)
- ✅ Application Load Balancer
- ✅ Target Group (with health checks configured)
- ❌ No Listener (will add later when you need it)

---

## 🎯 ALB + Target Group Details

### Application Load Balancer
```yaml
Name: hq-edm-customapps-dev-alb
Type: application
Scheme: internet-facing
Subnets: 
  - subnet-01710df4ae8c057c8 (hq-edm-dev-app-1a)
  - subnet-0a198c407107ac822 (hq-edm-qa-app-1b)
Security Group: Created by SecurityStack
Deletion Protection: Disabled (dev environment)
```

### Target Group
```yaml
Name: hq-edm-customapps-dev-tg
Protocol: HTTP
Port: 80
Target Type: ip (for ECS Fargate tasks)
Health Check:
  - Path: /
  - Interval: 30 seconds
  - Timeout: 5 seconds
  - Healthy threshold: 2
  - Unhealthy threshold: 3
  - Success codes: 200-399
Status: Will show "unhealthy" until you register ECS tasks
```

---

## 🚀 Deployment Steps

### Step 1: Update Files in GitHub
```bash
# Replace these 3 files:
templates/alb/alb.yml
templates/root.yml
params/dev.json
```

### Step 2: Commit and Push
```bash
git add .
git commit -m "Add ALB with Target Group - Phase 4"
git push origin main
```

### Step 3: Monitor CodePipeline
- CodePipeline will automatically trigger
- Watch the Deploy stage

### Step 4: Verify Deployment
After successful deployment, check CloudFormation outputs:
- `AlbDnsName` - Your ALB endpoint
- `TargetGroupArn` - For future ECS service attachment
- `ApplicationEndpoint` - URL (will return 503 until targets added)

---

## ✅ Expected Behavior

### What Works:
- ✅ ALB is created and accessible
- ✅ Target Group is created
- ✅ Security Group allows HTTP/HTTPS traffic
- ✅ ALB DNS name resolves

### What Doesn't Work Yet:
- ❌ Accessing the ALB URL will return **503 Service Unavailable**
  - This is NORMAL because:
    - No listener is attached yet
    - No targets are registered in the Target Group
    - Target Group health checks will fail

### How to Test:
```bash
# Get ALB DNS name from CloudFormation Outputs
curl http://hq-edm-customapps-dev-alb-XXXXXXXXX.us-east-1.elb.amazonaws.com

# Expected response:
# HTTP 503 Service Unavailable
# <html><body><h1>503 Service Temporarily Unavailable</h1></body></html>
```

This is **correct behavior** - the infrastructure is ready, just waiting for application targets!

---

## 📊 CloudFormation Stack Resources

After deployment, you'll have:

```
hq-edm-test2-stack2 (Root Stack)
├── SecretsStack
│   ├── ArtifactorySecret
│   ├── OIDCCredentialsSecret
│   └── 5x SSM Parameters
├── S3Stack
│   └── S3 Bucket
├── SecurityStack
│   └── ALB Security Group
└── AlbStack
    ├── Application Load Balancer ✅
    └── Target Group ✅
```

---

## 🔄 Next Steps (Future Phases)

### Phase 5: Add HTTP Listener
When you're ready, add:
```yaml
HttpListener:
  Type: AWS::ElasticLoadBalancingV2::Listener
  Properties:
    LoadBalancerArn: !Ref Alb
    Port: 80
    Protocol: HTTP
    DefaultActions:
      - Type: forward
        TargetGroupArn: !Ref TargetGroup
```

### Phase 6: Deploy ECS Service
Create ECS service that registers with Target Group:
```yaml
EcsService:
  Properties:
    LoadBalancers:
      - TargetGroupArn: !Ref TargetGroup
        ContainerName: my-app
        ContainerPort: 80
```

---

## 🆘 Troubleshooting

### If ALB creation fails again:
1. Check CloudFormation Events for specific error
2. Verify subnets exist: `subnet-01710df4ae8c057c8` and `subnet-0a198c407107ac822`
3. Verify subnets are in correct VPC: `vpc-07acc586ab2a9bab7`
4. Check if subnets have route to Internet Gateway

### If Target Group creation fails:
1. Verify VPC ID is correct
2. Check if port 80 is allowed in security groups

---

## 📝 Summary

**What you're deploying:**
- Infrastructure-ready ALB with Target Group
- No listener (will add when needed)
- No targets (will add when ECS is deployed)

**Why this approach:**
- Tests ALB creation in your subnets
- Creates Target Group ready for future use
- Simpler than full setup with listener
- Easy to troubleshoot

**Status after deployment:**
- Infrastructure: ✅ Complete
- Application: ❌ Not yet (expected)

---

Ready to deploy! 🚀
