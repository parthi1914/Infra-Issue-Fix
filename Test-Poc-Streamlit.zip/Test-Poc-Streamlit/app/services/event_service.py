import logging
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta

from services.db import is_db_available, run_query
from utils.data_simulation import simulate_events as _simulate_events

log = logging.getLogger(__name__)


def get_events(
    engine_serial: str,
    tail_number: str,
    now: datetime,
    hours: float = 3.0,
    variation: str = "Normal",
) -> pd.DataFrame:
    if not is_db_available():
        return _simulate_events(engine_serial, tail_number, now, hours, variation)

    try:
        start_window = now - timedelta(hours=hours)

        sql = """
            SELECT engine_serial,
                   tail_number,
                   system,
                   start_time,
                   end_time,
                   status,
                   latency_sec,
                   records,
                   data_size_mb
              FROM pipeline_events
             WHERE engine_serial = :esn
               AND tail_number   = :tail
               AND start_time   >= :start_window
             ORDER BY start_time
        """
        df = run_query(sql, {
            "esn": engine_serial,
            "tail": tail_number,
            "start_window": start_window,
        })

        if df.empty:
            return _simulate_events(engine_serial, tail_number, now, hours, variation)

        return df
    except Exception as exc:
        log.warning("DB query failed, falling back to simulation: %s", exc)
        return _simulate_events(engine_serial, tail_number, now, hours, variation)
