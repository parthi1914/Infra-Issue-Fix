"""
Data Element Service
====================
Fetches and validates data elements across systems (1FA, 1FDI, PHM, FMX).

Logic:
------
1. Filter `edm_raw.asset_diagnostic_stg` by ESN and diagnostic_tail
2. Get latest row per system (data_source)
3. Use 1FA value as the EXPECTED (golden/source of truth) for each property
4. Compare all other systems against the 1FA value
5. If value == 1FA value → Pass (green)
6. If value != 1FA value or NULL → Fail (red)
7. Expected column = 1FA value

Performance:
------------
- Single query with ROW_NUMBER() for latest per system
- Cache is configurable via ENABLE_CACHE flag
- Fallback to simulation if DB unavailable
"""

import logging
import pandas as pd
import streamlit as st
from datetime import datetime
from collections import Counter
from functools import wraps

from services.db import is_db_available, run_query
from utils.data_simulation import simulate_data_elements_with_values as _sim_values

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
# Cache toggle: Set to True to enable caching, False to disable
ENABLE_CACHE = False  # Disabled for development/debugging
CACHE_TTL_SECONDS = 60  # Cache duration when enabled

# Systems in display order (column headers) - 4 systems only
SYSTEMS = ["1FA", "1FDI", "PHM", "FMX"]

# Column-to-Property Mapping (DB column → UI property name)
# All 19 columns from edm_raw.asset_diagnostic_stg
COLUMN_TO_PROPERTY = {
    "esn": "ESN",
    "diagnostic_installation_date": "Diagnostic Installation Date",
    "diagnostic_tail": "Diagnostic Tail",
    "engine_position": "Engine Position",
    "installation_date": "Installation Date",
    "last_update_date": "Last Updated Date",
    "n1_modifier": "N1 Modifier",
    "operator": "Operator",
    "monitor": "Monitor",
    "operator_diagnostic_code": "Operator Diagnostic Code",
    "tail_number_aircraft_id": "Tail Number Aircraft ID",
    "engine_model": "Engine Model",
    "engine_type": "Engine Type",
    "engine_family_model_series": "Engine Family Model Series",
    "aircraft_delivery_date": "Aircraft Delivery Date",
    "aircraft_family": "Aircraft Family",
    "aircraft_model": "Aircraft Model",
    "aircraft_series": "Aircraft Series",
    "installation_history": "Installation History",
}

# Reverse mapping (property → column)
PROPERTY_TO_COLUMN = {v: k for k, v in COLUMN_TO_PROPERTY.items()}

# Properties to display (row headers) - all 19 properties
DISPLAY_PROPERTIES = [
    "ESN",
    "Diagnostic Installation Date",
    "Diagnostic Tail",
    "Engine Position",
    "Installation Date",
    "Last Updated Date",
    "N1 Modifier",
    "Operator",
    "Monitor",
    "Operator Diagnostic Code",
    "Tail Number Aircraft ID",
    "Engine Model",
    "Engine Type",
    "Engine Family Model Series",
    "Aircraft Delivery Date",
    "Aircraft Family",
    "Aircraft Model",
    "Aircraft Series",
    "Installation History",
]


# ---------------------------------------------------------------------------
# Configurable Cache Decorator
# ---------------------------------------------------------------------------
def conditional_cache(func):
    """Apply Streamlit cache only if ENABLE_CACHE is True."""
    if ENABLE_CACHE:
        return st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)(func)
    return func


# ---------------------------------------------------------------------------
# Helper Functions
# ---------------------------------------------------------------------------

# Invalid/placeholder date values that should be treated as NULL
INVALID_DATE_VALUES = {"9999-01-01", "9999-12-31", "1900-01-01", "0001-01-01"}


def _is_invalid_date(value: str) -> bool:
    """Check if value is an invalid placeholder date."""
    if not value or value == "NULL":
        return False
    # Check if any invalid date pattern is in the value
    for invalid in INVALID_DATE_VALUES:
        if invalid in value:
            return True
    return False


def _format_value(value) -> str:
    """Format a database value for display."""
    if value is None or pd.isna(value):
        return "NULL"
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    val_str = str(value).strip()
    if val_str.upper() in ("", "NONE", "NAN", "NAT"):
        return "NULL"
    return val_str


def _determine_expected_value(values_by_system: dict, property_name: str = "") -> str:
    """
    Determine the expected (golden) value.
    
    Logic: 
    1. 1FA is the source of truth, but skip invalid dates like 9999-01-01
    2. If 1FA is NULL or invalid, find the first valid value from other systems.
    """
    fa_value = values_by_system.get("1FA", "NULL")
    
    # Check if 1FA has a valid value (not NULL and not invalid date)
    if fa_value != "NULL" and not _is_invalid_date(fa_value):
        return fa_value
    
    # 1FA is NULL or has invalid date - find first valid value from other systems
    for sys in ["1FDI", "PHM", "FMX"]:
        val = values_by_system.get(sys, "NULL")
        if val != "NULL" and not _is_invalid_date(val):
            return val
    
    # All systems are NULL or have invalid dates
    return "—"


def _validate_value(actual: str, expected: str, is_1fa: bool = False) -> tuple:
    """
    Validate actual vs expected value.
    
    Args:
        actual: The actual value from the system
        expected: The expected value (from 1FA or first valid)
        is_1fa: If True, this is the 1FA system itself
    
    Returns: (status, reason) tuple
    """
    # Check for NULL
    if actual == "NULL":
        return "Fail", "Null value found"
    
    # Check for invalid placeholder dates
    if _is_invalid_date(actual):
        return "Fail", f"Invalid placeholder date: {actual}"
    
    # 1FA with valid value is always Pass
    if is_1fa:
        return "Pass", ""
    
    # No baseline to compare against
    if expected == "—":
        return "Pass", ""
    
    if actual == expected:
        return "Pass", ""
    
    return "Fail", f"Value mismatch: expected '{expected}' but got '{actual}'"
    
    return "Fail", f"Value mismatch: expected '{expected}' but got '{actual}'"


# ---------------------------------------------------------------------------
# Database Query (Configurable Cache)
# ---------------------------------------------------------------------------
@conditional_cache
def _query_asset_data(esn: str, tail: str) -> pd.DataFrame:
    """
    Query edm_raw.asset_diagnostic_stg for given ESN and diagnostic_tail.
    Returns latest row per system (data_source).
    
    Performance: Uses ROW_NUMBER() to get latest per system efficiently.
    Cache: Controlled by ENABLE_CACHE flag (currently disabled).
    """
    # Build column list dynamically based on available mappings
    db_columns = list(COLUMN_TO_PROPERTY.keys())
    columns_sql = ", ".join(db_columns)
    
    sql = f"""
        WITH filtered AS (
            SELECT 
                data_source AS system,
                {columns_sql},
                ROW_NUMBER() OVER (
                    PARTITION BY data_source 
                    ORDER BY last_update_date DESC NULLS LAST
                ) AS rn
            FROM edm_raw.asset_diagnostic_stg
            WHERE esn = :esn
              AND diagnostic_tail = :tail
        )
        SELECT 
            system,
            {columns_sql}
        FROM filtered
        WHERE rn = 1
        ORDER BY 
            CASE system 
                WHEN '1FA' THEN 1 WHEN '1FDI' THEN 2
                WHEN 'PHM' THEN 3 WHEN 'FMX' THEN 4 ELSE 5
            END
    """
    log.info("Executing query for ESN=%s, Tail=%s", esn, tail)
    log.debug("SQL: %s", sql)
    result = run_query(sql, {"esn": esn, "tail": tail})
    log.info("Query returned %d rows", len(result) if result is not None else 0)
    return result


# ---------------------------------------------------------------------------
# Main Function: Build Data Elements Matrix
# ---------------------------------------------------------------------------
def get_data_elements_matrix(esn: str, tail: str) -> dict:
    """
    Build the data elements matrix for display.
    
    Returns:
        {
            "properties": ["Diagnostic Installation Date", ...],
            "systems": ["1FA", "1FDI", "PHM", "FMX"],
            "matrix": {
                "Diagnostic Installation Date": {
                    "1FA": {"value": "2024-10-23", "status": "Pass", "reason": ""},
                    "1FDI": {"value": "2024-10-23", "status": "Pass", "reason": ""},
                    ...
                    "expected": "2024-10-23"
                },
                ...
            },
            "summary": {"total": 72, "passed": 45, "failed": 27, "pass_rate": 62.5},
            "failures": [{"system": "1FDI", "property": "...", "expected": "...", "actual": "...", "reason": "..."}]
        }
    """
    if not is_db_available():
        log.info("DB not available, using simulation")
        return _build_simulated_matrix(esn, tail)
    
    try:
        # Step 1: Query data from database
        rows = _query_asset_data(esn, tail)
        
        if rows is None or rows.empty:
            log.info("No data found for ESN=%s, Tail=%s, using simulation", esn, tail)
            return _build_simulated_matrix(esn, tail)
        
        # Step 2: Build system data lookup
        system_data = {}
        for _, row in rows.iterrows():
            sys = row["system"]
            system_data[sys] = row
        
        log.info("Found data for systems: %s (ESN=%s, Tail=%s)", 
                 list(system_data.keys()), esn, tail)
        
        # Step 3: Build matrix
        matrix = {}
        failures = []
        total_cells = 0
        passed_cells = 0
        
        for prop in DISPLAY_PROPERTIES:
            col = PROPERTY_TO_COLUMN.get(prop)
            if not col:
                continue
            
            # Collect values from all systems
            values_by_system = {}
            for sys in SYSTEMS:
                if sys in system_data and col in system_data[sys].index:
                    raw_val = system_data[sys][col]
                    values_by_system[sys] = _format_value(raw_val)
                else:
                    values_by_system[sys] = "NULL"
            
            # Determine expected value (1FA is the source of truth)
            expected = _determine_expected_value(values_by_system)
            
            # Validate each system's value against 1FA
            prop_data = {}
            for sys in SYSTEMS:
                actual = values_by_system[sys]
                is_1fa = (sys == "1FA")
                status, reason = _validate_value(actual, expected, is_1fa=is_1fa)
                
                prop_data[sys] = {
                    "value": actual,
                    "status": status,
                    "reason": reason
                }
                
                total_cells += 1
                if status == "Pass":
                    passed_cells += 1
                else:
                    failures.append({
                        "system": sys,
                        "property": prop,
                        "expected": expected,
                        "actual": actual,
                        "reason": reason
                    })
            
            prop_data["expected"] = expected
            matrix[prop] = prop_data
        
        # Step 4: Calculate summary
        failed_cells = total_cells - passed_cells
        pass_rate = (passed_cells / total_cells * 100) if total_cells > 0 else 0
        
        return {
            "properties": DISPLAY_PROPERTIES,
            "systems": SYSTEMS,
            "matrix": matrix,
            "summary": {
                "total": total_cells,
                "passed": passed_cells,
                "failed": failed_cells,
                "pass_rate": round(pass_rate, 1)
            },
            "failures": failures
        }
        
    except Exception as exc:
        log.warning("DB query failed: %s, using simulation", exc)
        return _build_simulated_matrix(esn, tail)


def _build_simulated_matrix(esn: str, tail: str) -> dict:
    """Build a simulated matrix when DB is unavailable."""
    import random
    
    rng = random.Random(hash(esn + tail) % (2**32 - 1))
    
    # All 19 properties from edm_raw.asset_diagnostic_stg table
    expected_values = {
        "ESN": esn if esn else "000000",
        "Diagnostic Installation Date": "2026-01-29",
        "Diagnostic Tail": tail if tail else "HZ-FAB",
        "Engine Position": "1",
        "Installation Date": "2026-01-29",
        "Last Updated Date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "N1 Modifier": "1000000045",
        "Operator": "15456",
        "Monitor": "TBD",
        "Operator Diagnostic Code": "ODC-001",
        "Tail Number Aircraft ID": tail if tail else "HZ-FAB",
        "Engine Model": "CFM56-7B26",
        "Engine Type": "TURBOFAN",
        "Engine Family Model Series": "CFM56-7B",
        "Aircraft Delivery Date": "2020-05-15",
        "Aircraft Family": "A320",
        "Aircraft Model": "A320-214",
        "Aircraft Series": "200",
        "Installation History": "2024-10-23",
    }
    
    matrix = {}
    failures = []
    total_cells = 0
    passed_cells = 0
    
    for prop in DISPLAY_PROPERTIES:
        # 1FA value is the expected/golden value
        fa_expected = expected_values.get(prop, "—")
        prop_data = {}
        
        for sys in SYSTEMS:
            is_1fa = (sys == "1FA")
            
            if is_1fa:
                # 1FA is the source of truth - always use expected value
                # Small chance of 1FA being NULL
                if rng.random() < 0.95:
                    actual = fa_expected
                    status = "Pass"
                    reason = ""
                else:
                    actual = "NULL"
                    status = "Fail"
                    reason = "Null value found"
                    failures.append({
                        "system": sys,
                        "property": prop,
                        "expected": fa_expected,
                        "actual": actual,
                        "reason": reason
                    })
            else:
                # Other systems - compare against 1FA value
                pass_rate = 0.85 if sys == "1FDI" else 0.70
                is_pass = rng.random() < pass_rate
                
                if is_pass:
                    actual = fa_expected
                    status = "Pass"
                    reason = ""
                else:
                    failure_type = rng.choice(["null", "mismatch", "invalid"])
                    if failure_type == "null":
                        actual = "NULL"
                        reason = "Null value found"
                    elif failure_type == "mismatch":
                        actual = f"{fa_expected}-WRONG" if fa_expected != "—" else "WRONG"
                        reason = f"Value mismatch: expected '{fa_expected}' but got '{actual}'"
                    else:
                        actual = "INVALID"
                        reason = f"Value mismatch: expected '{fa_expected}' but got 'INVALID'"
                    status = "Fail"
                    
                    failures.append({
                        "system": sys,
                        "property": prop,
                        "expected": fa_expected,
                        "actual": actual,
                        "reason": reason
                    })
            
            prop_data[sys] = {"value": actual, "status": status, "reason": reason}
            total_cells += 1
            if status == "Pass":
                passed_cells += 1
        
        prop_data["expected"] = fa_expected
        matrix[prop] = prop_data
    
    failed_cells = total_cells - passed_cells
    pass_rate = (passed_cells / total_cells * 100) if total_cells > 0 else 0
    
    return {
        "properties": DISPLAY_PROPERTIES,
        "systems": SYSTEMS,
        "matrix": matrix,
        "summary": {
            "total": total_cells,
            "passed": passed_cells,
            "failed": failed_cells,
            "pass_rate": round(pass_rate, 1)
        },
        "failures": failures
    }


# ---------------------------------------------------------------------------
# Legacy Functions (Backward Compatibility)
# ---------------------------------------------------------------------------
def get_data_elements_status(df: pd.DataFrame) -> pd.DataFrame:
    """Return Pass/Fail matrix. (Legacy)"""
    esn = df["engine_serial"].iloc[0] if "engine_serial" in df.columns else "000000"
    tail = df["tail_number"].iloc[0] if "tail_number" in df.columns else "N-DEMO"
    
    result = get_data_elements_matrix(esn, tail)
    
    matrix_df = {}
    for prop in result["properties"]:
        matrix_df[prop] = {}
        for sys in result["systems"]:
            matrix_df[prop][sys] = result["matrix"][prop][sys]["status"]
    
    return pd.DataFrame(matrix_df).T


def get_data_elements_with_values(
    df: pd.DataFrame, engine_serial: str, tail_number: str
) -> dict:
    """Fetch data elements with values. (Legacy)"""
    result = get_data_elements_matrix(engine_serial, tail_number)
    
    legacy = {}
    for sys in result["systems"]:
        legacy[sys] = {}
        for prop in result["properties"]:
            cell = result["matrix"][prop][sys]
            legacy[sys][prop] = {
                "value": cell["value"],
                "expected": result["matrix"][prop]["expected"],
                "status": cell["status"],
                "reason": cell["reason"]
            }
    
    return legacy
