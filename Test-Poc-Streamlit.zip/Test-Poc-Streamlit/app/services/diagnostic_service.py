"""
Diagnostic Service
==================
Provides diagnostic data from edm_raw.asset_diagnostic_stg table.

Query: SELECT DISTINCT data_source, last_update_date 
       FROM edm_raw.asset_diagnostic_stg
       WHERE esn = :esn AND diagnostic_tail = :tail

Validation Logic:
-----------------
1FA:  PASS if last_update_date IS NOT NULL, else FAIL
1FDI: PASS if (1FDI_time > 1FA_time) AND (1FDI_time - 1FA_time <= 30 min), else FAIL
PHM:  If 1FDI failed → PENDING, else apply same validation against 1FDI
FMX:  If PHM is pending/failed → PENDING, else apply same validation against PHM

Once a system FAILS, all subsequent systems are PENDING.
"""

import logging
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional

from services.db import is_db_available, run_query
from utils.constants import SYSTEM_FLOW

log = logging.getLogger(__name__)


def get_diagnostic_records(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, Optional[datetime]]:
    """
    Query DISTINCT diagnostic records from edm_raw.asset_diagnostic_stg.
    
    Returns dict mapping data_source to last_update_date:
        {"1FA": datetime, "1FDI": datetime, "PHM": datetime, "FMX": datetime}
    """
    result = {source: None for source in SYSTEM_FLOW}
    
    if not is_db_available() or not engine_serial or not diagnostic_tail:
        log.info("DB not available or missing params")
        return result
    
    try:
        sql = """
            SELECT DISTINCT data_source, last_update_date
            FROM edm_raw.asset_diagnostic_stg
            WHERE esn = :esn
              AND diagnostic_tail = :tail
              AND data_source IN ('1FA', '1FDI', 'PHM', 'FMX')
        """
        
        df = run_query(sql, {"esn": engine_serial, "tail": diagnostic_tail})
        
        if df.empty:
            log.info(f"No records found for ESN={engine_serial}, Tail={diagnostic_tail}")
            return result
        
        # Take first occurrence per data_source (DISTINCT ensures one per source typically)
        for _, row in df.iterrows():
            source = row["data_source"]
            if source in result and result[source] is None:
                ts = pd.to_datetime(row["last_update_date"], errors="coerce")
                result[source] = ts if pd.notna(ts) else None
        
        log.info(f"Diagnostic records: {result}")
        return result
        
    except Exception as exc:
        log.warning(f"Query failed: {exc}")
        return result


def calculate_system_statuses(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, Dict]:
    """
    Calculate Pass/Fail/Pending status for each system.
    
    Validation Rules:
    -----------------
    1FA:  PASS if last_update_date is NOT NULL
    1FDI: PASS if time > 1FA AND (time - 1FA) <= 30 min
          FAIL if time < 1FA OR (time - 1FA) > 30 min OR NULL
    PHM:  PENDING if 1FDI failed/pending, else apply validation vs 1FDI
    FMX:  PENDING if PHM failed/pending, else apply validation vs PHM
    
    Returns:
        {
            "1FA": {"status": "pass", "time": datetime, "message": "..."},
            "1FDI": {"status": "fail", "time": datetime, "message": "..."},
            ...
        }
    """
    records = get_diagnostic_records(engine_serial, diagnostic_tail)
    
    statuses = {}
    prev_status = None
    prev_time = None
    
    for source in SYSTEM_FLOW:
        curr_time = records.get(source)
        
        if source == "1FA":
            # First system: PASS if not null
            if curr_time is not None:
                status = "pass"
                message = "Data received"
            else:
                status = "fail"
                message = "No data received"
        else:
            # Subsequent systems
            if prev_status in ("fail", "pending"):
                # Previous failed or pending → Current is PENDING
                status = "pending"
                message = f"Waiting - previous system ({SYSTEM_FLOW[SYSTEM_FLOW.index(source)-1]}) not complete"
            elif curr_time is None:
                # No data
                status = "fail"
                message = "No data received"
            elif prev_time is None:
                # Previous had no time to compare
                status = "fail"
                message = "Cannot validate - no previous timestamp"
            else:
                # Apply validation: curr_time must be > prev_time AND within 30 min
                if curr_time < prev_time:
                    status = "fail"
                    diff_min = (prev_time - curr_time).total_seconds() / 60.0
                    message = f"Time is {diff_min:.0f} min BEFORE previous system"
                else:
                    diff_min = (curr_time - prev_time).total_seconds() / 60.0
                    if diff_min > 30:
                        status = "fail"
                        message = f"Time gap {diff_min:.0f} min exceeds 30 min limit"
                    else:
                        status = "pass"
                        message = f"Received {diff_min:.0f} min after previous"
        
        statuses[source] = {
            "status": status,
            "time": curr_time,
            "message": message,
            "time_str": curr_time.strftime("%Y-%m-%d %H:%M:%S") if curr_time else "—",
        }
        
        prev_status = status
        prev_time = curr_time
    
    return statuses


def get_status_counts(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, int]:
    """
    Get counts of Pass, Fail, Pending systems.
    
    Returns: {"pass": int, "fail": int, "pending": int}
    """
    statuses = calculate_system_statuses(engine_serial, diagnostic_tail)
    
    counts = {"pass": 0, "fail": 0, "pending": 0}
    for info in statuses.values():
        counts[info["status"]] += 1
    
    return counts


def get_total_and_completed(
    engine_serial: str,
    diagnostic_tail: str,
) -> Tuple[int, int]:
    """
    Get total systems count and completed (non-null) count.
    
    Returns: (total, completed)
    """
    records = get_diagnostic_records(engine_serial, diagnostic_tail)
    total = len(SYSTEM_FLOW)
    completed = sum(1 for v in records.values() if v is not None)
    return total, completed


def get_last_updated_times(
    engine_serial: str,
    diagnostic_tail: str,
) -> List[Dict]:
    """
    Get last updated times for display in table.
    
    Returns list of dicts: [{"system": "1FA", "last_updated": "2026-01-29 08:26:18"}, ...]
    """
    records = get_diagnostic_records(engine_serial, diagnostic_tail)
    
    result = []
    for source in SYSTEM_FLOW:
        ts = records.get(source)
        result.append({
            "system": source,
            "last_updated": ts.strftime("%Y-%m-%d %H:%M:%S") if ts else "—",
        })
    
    return result


def get_data_population(
    engine_serial: str,
    diagnostic_tail: str,
) -> Dict[str, Dict]:
    """
    Get data population metrics for each system (for pie charts).
    
    Since we only have last_update_date, we calculate:
    - Present: 1 if last_update_date is not null
    - Missing: 1 if last_update_date is null
    
    For more realistic percentages, query record counts.
    """
    if not is_db_available() or not engine_serial or not diagnostic_tail:
        # Return default values
        return {s: {"present": 0.85, "missing": 0.15} for s in SYSTEM_FLOW}
    
    try:
        sql = """
            SELECT 
                data_source,
                COUNT(*) as total,
                SUM(CASE WHEN last_update_date IS NOT NULL THEN 1 ELSE 0 END) as present
            FROM edm_raw.asset_diagnostic_stg
            WHERE esn = :esn
              AND diagnostic_tail = :tail
              AND data_source IN ('1FA', '1FDI', 'PHM', 'FMX')
            GROUP BY data_source
        """
        
        df = run_query(sql, {"esn": engine_serial, "tail": diagnostic_tail})
        
        result = {}
        for source in SYSTEM_FLOW:
            source_df = df[df["data_source"] == source]
            if not source_df.empty:
                total = int(source_df["total"].iloc[0])
                present = int(source_df["present"].iloc[0])
                if total > 0:
                    present_pct = present / total
                    missing_pct = 1.0 - present_pct
                else:
                    present_pct, missing_pct = 0.0, 1.0
            else:
                present_pct, missing_pct = 0.0, 1.0
            
            result[source] = {"present": present_pct, "missing": missing_pct}
        
        return result
        
    except Exception as exc:
        log.warning(f"Population query failed: {exc}")
        return {s: {"present": 0.85, "missing": 0.15} for s in SYSTEM_FLOW}


def get_sla_timeline_data(
    engine_serial: str,
    diagnostic_tail: str,
    now: datetime = None,
) -> Dict:
    """
    Get SLA timeline data for visualization.
    
    Returns:
        {
            "systems": {
                "1FA": {"status": "pass", "time": datetime, ...},
                ...
            },
            "freshness_minutes": float,
            "freshness_status": "ok" | "risk" | "fail",
        }
    """
    if now is None:
        now = datetime.utcnow()
    
    statuses = calculate_system_statuses(engine_serial, diagnostic_tail)
    records = get_diagnostic_records(engine_serial, diagnostic_tail)
    
    # Calculate freshness from last valid timestamp
    valid_times = [t for t in records.values() if t is not None]
    if valid_times:
        last_time = max(valid_times)
        freshness_min = (now - last_time).total_seconds() / 60.0
    else:
        freshness_min = 999
    
    if freshness_min < 60:
        freshness_status = "ok"
    elif freshness_min < 120:
        freshness_status = "risk"
    else:
        freshness_status = "fail"
    
    return {
        "systems": statuses,
        "freshness_minutes": freshness_min,
        "freshness_status": freshness_status,
    }


def get_timeline_chart_data(
    engine_serial: str,
    diagnostic_tail: str,
) -> List[Dict]:
    """
    Get timeline data for Gantt-style chart.
    
    Returns list of dicts with:
        [
            {"system": "1FA", "last_update": datetime, "status": "pass/fail/pending"},
            {"system": "1FDI", "last_update": datetime, "status": "pass/fail/pending"},
            ...
        ]
    
    Ordered by SYSTEM_FLOW: 1FA → 1FDI → PHM → FMX
    """
    statuses = calculate_system_statuses(engine_serial, diagnostic_tail)
    
    timeline_data = []
    for source in SYSTEM_FLOW:
        info = statuses.get(source, {"status": "pending", "time": None})
        timeline_data.append({
            "system": source,
            "last_update": info.get("time"),
            "status": info.get("status", "pending"),
            "message": info.get("message", ""),
        })
    
    return timeline_data
