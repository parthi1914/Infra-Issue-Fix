"""
Lookup Service
==============
Provides dropdown/select list data for the sidebar filters.

Table: edm_raw.asset_diagnostic_stg
- esn: Engine Serial Number
- diagnostic_tail: Tail Number

Logic:
------
1. If "Engine Serial (ESN)" selected:
   - Load distinct ESNs ordered by esn
   - For selected ESN, load corresponding diagnostic_tail values

2. If "Tail Number" selected:
   - Load distinct diagnostic_tail values ordered
   - For selected tail, load corresponding ESN values
"""

import logging
import streamlit as st

from services.db import is_db_available, run_query_list
from utils.constants import (
    SAMPLE_ENGINE_SERIALS,
    SAMPLE_TAIL_NUMBERS,
    ENGINE_TO_TAILS,
    TAIL_TO_ENGINES,
)

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
# Cache toggle: Set to True to enable caching, False to disable for debugging
ENABLE_CACHE = True
CACHE_TTL_SECONDS = 300


def _apply_cache(func):
    """Apply Streamlit cache only if ENABLE_CACHE is True."""
    if ENABLE_CACHE:
        return st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)(func)
    return func


# ---------------------------------------------------------------------------
# Get All Engine Serials (ESN)
# ---------------------------------------------------------------------------
@_apply_cache
def get_engine_serials() -> list:
    """
    Get distinct ESN values from edm_raw.asset_diagnostic_stg.
    Ordered by esn, used for "Sample Engine Serial" dropdown.
    """
    if not is_db_available():
        log.info("DB not available, using sample ESNs")
        return SAMPLE_ENGINE_SERIALS

    try:
        sql = """
            SELECT DISTINCT esn
            FROM edm_raw.asset_diagnostic_stg
            WHERE esn IS NOT NULL
              AND TRIM(esn) != ''
            ORDER BY esn
        """
        result = run_query_list(sql)
        if result:
            log.info("Loaded %d ESNs from database", len(result))
            return result
        log.warning("No ESNs found in DB, using sample data")
        return SAMPLE_ENGINE_SERIALS
    except Exception as exc:
        log.warning("DB query failed for ESNs: %s", exc)
        return SAMPLE_ENGINE_SERIALS


# ---------------------------------------------------------------------------
# Get All Tail Numbers (diagnostic_tail)
# ---------------------------------------------------------------------------
@_apply_cache
def get_tail_numbers() -> list:
    """
    Get distinct diagnostic_tail values from edm_raw.asset_diagnostic_stg.
    Ordered by diagnostic_tail, used for "Sample Tail Number" dropdown.
    """
    if not is_db_available():
        log.info("DB not available, using sample tail numbers")
        return SAMPLE_TAIL_NUMBERS

    try:
        sql = """
            SELECT DISTINCT diagnostic_tail
            FROM edm_raw.asset_diagnostic_stg
            WHERE diagnostic_tail IS NOT NULL
              AND TRIM(diagnostic_tail) != ''
            ORDER BY diagnostic_tail
        """
        result = run_query_list(sql)
        if result:
            log.info("Loaded %d tail numbers from database", len(result))
            return result
        log.warning("No tail numbers found in DB, using sample data")
        return SAMPLE_TAIL_NUMBERS
    except Exception as exc:
        log.warning("DB query failed for tail numbers: %s", exc)
        return SAMPLE_TAIL_NUMBERS


# ---------------------------------------------------------------------------
# Get Tail Numbers for a Specific ESN
# ---------------------------------------------------------------------------
@_apply_cache
def get_tails_for_engine(engine_serial: str) -> list:
    """
    Get distinct diagnostic_tail values for a given ESN.
    Used when "Engine Serial (ESN)" is selected - loads corresponding tails.
    
    Args:
        engine_serial: The selected ESN value
    
    Returns:
        List of diagnostic_tail values for this ESN, or empty list placeholder
    """
    if not engine_serial:
        return [""]
    
    if not is_db_available():
        return ENGINE_TO_TAILS.get(engine_serial, [SAMPLE_TAIL_NUMBERS[0] if SAMPLE_TAIL_NUMBERS else ""])

    try:
        sql = """
            SELECT DISTINCT diagnostic_tail
            FROM edm_raw.asset_diagnostic_stg
            WHERE esn = :esn
              AND diagnostic_tail IS NOT NULL
              AND TRIM(diagnostic_tail) != ''
            ORDER BY diagnostic_tail
        """
        result = run_query_list(sql, {"esn": engine_serial})
        if result:
            log.info("Found %d tails for ESN=%s", len(result), engine_serial)
            return result
        # No tails found for this ESN - return empty placeholder
        log.info("No tails found for ESN=%s", engine_serial)
        return [""]
    except Exception as exc:
        log.warning("DB query failed for tails by ESN: %s", exc)
        return ENGINE_TO_TAILS.get(engine_serial, [""])


# ---------------------------------------------------------------------------
# Get Engine Serials for a Specific Tail Number
# ---------------------------------------------------------------------------
@_apply_cache
def get_engines_for_tail(tail_number: str) -> list:
    """
    Get distinct ESN values for a given diagnostic_tail.
    Used when "Tail Number" is selected - loads corresponding ESNs.
    
    Args:
        tail_number: The selected diagnostic_tail value
    
    Returns:
        List of ESN values for this tail, or empty list placeholder
    """
    if not tail_number:
        return [""]
    
    if not is_db_available():
        return TAIL_TO_ENGINES.get(tail_number, [SAMPLE_ENGINE_SERIALS[0] if SAMPLE_ENGINE_SERIALS else ""])

    try:
        sql = """
            SELECT DISTINCT esn
            FROM edm_raw.asset_diagnostic_stg
            WHERE diagnostic_tail = :tail
              AND esn IS NOT NULL
              AND TRIM(esn) != ''
            ORDER BY esn
        """
        result = run_query_list(sql, {"tail": tail_number})
        if result:
            log.info("Found %d ESNs for tail=%s", len(result), tail_number)
            return result
        # No ESNs found for this tail - return empty placeholder
        log.info("No ESNs found for tail=%s", tail_number)
        return [""]
    except Exception as exc:
        log.warning("DB query failed for ESNs by tail: %s", exc)
        return TAIL_TO_ENGINES.get(tail_number, [""])


# ---------------------------------------------------------------------------
# Get Operator Codes for a Specific ESN
# ---------------------------------------------------------------------------
@_apply_cache
def get_operator_codes_for_esn(engine_serial: str) -> list:
    """
    Get distinct operator_diagnostic_code values for a given ESN.
    
    Args:
        engine_serial: The selected ESN value
    
    Returns:
        List of operator_diagnostic_code values for this ESN
    """
    if not engine_serial:
        return [""]
    
    if not is_db_available():
        return ["OP001", "OP002"]  # Sample fallback

    try:
        sql = """
            SELECT DISTINCT operator_diagnostic_code
            FROM edm_raw.asset_diagnostic_stg
            WHERE esn = :esn
              AND operator_diagnostic_code IS NOT NULL
              AND TRIM(operator_diagnostic_code) != ''
            ORDER BY operator_diagnostic_code
        """
        result = run_query_list(sql, {"esn": engine_serial})
        if result:
            log.info("Found %d operator codes for ESN=%s", len(result), engine_serial)
            return result
        log.info("No operator codes found for ESN=%s", engine_serial)
        return [""]
    except Exception as exc:
        log.warning("DB query failed for operator codes by ESN: %s", exc)
        return [""]


# ---------------------------------------------------------------------------
# Get Operator Codes for a Specific Tail Number
# ---------------------------------------------------------------------------
@_apply_cache
def get_operator_codes_for_tail(tail_number: str) -> list:
    """
    Get distinct operator_diagnostic_code values for a given diagnostic_tail.
    
    Args:
        tail_number: The selected diagnostic_tail value
    
    Returns:
        List of operator_diagnostic_code values for this tail
    """
    if not tail_number:
        return [""]
    
    if not is_db_available():
        return ["OP001", "OP002"]  # Sample fallback

    try:
        sql = """
            SELECT DISTINCT operator_diagnostic_code
            FROM edm_raw.asset_diagnostic_stg
            WHERE diagnostic_tail = :tail
              AND operator_diagnostic_code IS NOT NULL
              AND TRIM(operator_diagnostic_code) != ''
            ORDER BY operator_diagnostic_code
        """
        result = run_query_list(sql, {"tail": tail_number})
        if result:
            log.info("Found %d operator codes for tail=%s", len(result), tail_number)
            return result
        log.info("No operator codes found for tail=%s", tail_number)
        return [""]
    except Exception as exc:
        log.warning("DB query failed for operator codes by tail: %s", exc)
        return [""]
