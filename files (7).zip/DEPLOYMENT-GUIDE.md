# FINAL DEPLOYMENT GUIDE
## EDMCustomApps Infrastructure - Complete Stack

## 📦 FILES TO REPLACE IN YOUR GITHUB REPO

### 1. Root Template
**Location:** `templates/root.yml`
**Replace with:** `FINAL-root.yml`

### 2. Parameters File
**Location:** `params/dev.json`
**Replace with:** `FINAL-dev.json`

### 3. Security Groups Template
**Location:** `templates/security/sg.yml`
**Replace with:** `FINAL-sg.yml`

### 4. Secrets Template (Already Fixed)
**Location:** `templates/secrets/secrets-params.yml`
**Use:** `secrets-stack-fixed.yaml` (from Phase 3)

### 5. ALB Template (No Changes)
**Location:** `templates/alb/alb.yml`
**Keep:** Your existing ALB template (already perfect)

### 6. S3 Template (No Changes)
**Location:** `templates/s3/buckets.yml`
**Keep:** Your existing S3 template (already working)

---

## 📂 FINAL FILE STRUCTURE

```
your-repo/
├── templates/
│   ├── root.yml                    ← REPLACE with FINAL-root.yml
│   ├── secrets/
│   │   └── secrets-params.yml      ← Use secrets-stack-fixed.yaml
│   ├── s3/
│   │   └── buckets.yml             ← Keep existing (working)
│   ├── security/
│   │   └── sg.yml                  ← REPLACE with FINAL-sg.yml
│   └── alb/
│       └── alb.yml                 ← Keep existing (working)
└── params/
    └── dev.json                    ← REPLACE with FINAL-dev.json
```

---

## ✅ WHAT GETS DEPLOYED

### Stack 1: SecretsStack
- ✅ Secrets Manager: Artifactory credentials
- ✅ Secrets Manager: OIDC credentials
- ✅ SSM Parameters: DockerHub token, username, Artifactory URL, API key

### Stack 2: S3Stack
- ✅ S3 Bucket: `edm-customapps-dev-artifacts-086002003393-us-east-1`
- ✅ Versioning enabled
- ✅ Encryption enabled
- ✅ Public access blocked

### Stack 3: SecurityStack
- ✅ ALB Security Group: `hq-edm-customapps-dev-alb-sg`
- ✅ Allows HTTP (80) and HTTPS (443) from internet
- ✅ Allows all outbound traffic

### Stack 4: AlbStack
- ✅ Application Load Balancer: `hq-edm-customapps-dev-alb`
- ✅ Target Group: `hq-edm-customapps-dev-tg`
- ✅ HTTP Listener on port 80
- ✅ Internet-facing in public subnets

---

## 🔧 PARAMETERS IN dev.json

| Parameter | Value | Purpose |
|-----------|-------|---------|
| VpcId | `vpc-07acc586ab2a9bab7` | Existing VPC |
| PublicSubnetIds | `subnet-0a1d5e877b6b9ac8c,subnet-0a198c407197ac822` | Public subnets for ALB |
| ContainerPort | `80` | Target group port |
| ArtifactoryUsername | `223145047` | JFrog username |
| ArtifactoryPassword | `test123` | ⚠️ Change after deployment |
| ArtifactoryUrl | `streamlit-docker-local-dev` | JFrog URL |
| DockerHubUsername | `abdullahmamunge` | Docker Hub user |
| DockerHubToken | `test123` | ⚠️ Change after deployment |
| OIDCClientId | `av-edm-streamlit-app-launcher-dev-2` | OIDC client |
| OIDCClientSecret | `CHANGE_ME_AFTER_DEPLOYMENT` | ⚠️ Change after deployment |

---

## 🚀 DEPLOYMENT STEPS

1. **Backup Current Files** (optional but recommended)
   ```bash
   git checkout -b backup-before-phase4
   git push origin backup-before-phase4
   git checkout main
   ```

2. **Replace Files**
   - Replace `templates/root.yml` with `FINAL-root.yml`
   - Replace `params/dev.json` with `FINAL-dev.json`
   - Replace `templates/security/sg.yml` with `FINAL-sg.yml`
   - Update `templates/secrets/secrets-params.yml` with `secrets-stack-fixed.yaml` (if not done already)

3. **Commit and Push**
   ```bash
   git add .
   git commit -m "Phase 4: Add SecurityStack and ALB to infrastructure"
   git push origin main
   ```

4. **Monitor CodePipeline**
   - Go to AWS CodePipeline console
   - Watch execution progress
   - Check CloudFormation stacks

5. **Verify Deployment**
   - Check CloudFormation Outputs for `ApplicationEndpoint`
   - Test ALB DNS: `http://[alb-dns-name]`
   - Verify all 4 nested stacks created successfully

---

## 📊 EXPECTED OUTPUTS

After successful deployment, CloudFormation will output:

- **ApplicationEndpoint**: `http://hq-edm-customapps-dev-alb-1234567890.us-east-1.elb.amazonaws.com`
- **AlbDnsName**: Full ALB DNS name
- **ArtifactsBucketName**: S3 bucket name
- **AlbSecurityGroupId**: Security group ID
- **TargetGroupArn**: For future ECS integration
- **ArtifactorySecretArn**: Secret ARN
- **OIDCCredentialsSecretArn**: Secret ARN

---

## ⚠️ IMPORTANT NOTES

### 1. VPC and Subnets
**Verify these values in dev.json are correct:**
- `VpcId`: `vpc-07acc586ab2a9bab7`
- `PublicSubnetIds`: `subnet-0a1d5e877b6b9ac8c,subnet-0a198c407197ac822`

**If wrong, update them BEFORE deploying!**

### 2. Secrets
The passwords in `dev.json` are placeholders (`test123`). After deployment:
1. Go to AWS Secrets Manager console
2. Update actual credentials
3. Go to Systems Manager → Parameter Store
4. Update actual values

### 3. Stack Dependencies
CloudFormation will create in this order:
1. SecretsStack & S3Stack (parallel)
2. SecurityStack (after secrets/S3)
3. AlbStack (after SecurityStack)

---

## 🎯 SUCCESS CRITERIA

✅ CodePipeline execution succeeds
✅ 4 nested stacks show CREATE_COMPLETE
✅ ALB DNS resolves (even if returns 503 - no targets yet)
✅ Security group exists and has correct rules
✅ S3 bucket exists with proper encryption
✅ Secrets and parameters created in AWS

---

## 🆘 TROUBLESHOOTING

### If deployment fails:
1. Check CloudFormation Events tab for specific error
2. Click on failed nested stack to see detailed error
3. Common issues:
   - VPC ID doesn't exist → Update dev.json
   - Subnet IDs invalid → Update dev.json
   - Parameter name mismatch → Check template vs dev.json
   - Missing Output in nested stack → Check nested template

### To rollback:
```bash
git checkout backup-before-phase4
git push origin main --force
```

---

## 📞 NEXT STEPS AFTER SUCCESS

1. **Test ALB**: Visit the ApplicationEndpoint URL
2. **Update Secrets**: Replace placeholder passwords
3. **Add ECS**: Next phase will add ECS services
4. **Configure DNS**: Point custom domain to ALB (optional)

---

## 🎉 YOU'RE READY TO DEPLOY!

All files are consolidated and ready. Just replace the 3 files and push to GitHub!
