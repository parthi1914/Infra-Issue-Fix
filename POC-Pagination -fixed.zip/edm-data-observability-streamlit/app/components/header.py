import streamlit as st


def render_header():
    st.markdown(
        """
        <div style="
            display:flex; align-items:center; justify-content:space-between;
            padding:14px 8px 12px; border-bottom:2px solid #e2e6ec; margin-bottom:10px;
        ">
            <div style="font-size:24px;font-weight:700;color:#1a1a2e;letter-spacing:-0.3px;">
                Asset &amp; Diagnostic Data Observability
            </div>
            <div style="display:flex;align-items:center;gap:14px;font-size:16px;color:#6b7280;">
                <span style="font-weight:600;font-size:15px;">End-to-end lineage:</span>
                <span style="background:#eff6ff;color:#2563eb;padding:8px 18px;border-radius:8px;font-weight:700;font-size:16px;box-shadow:0 2px 4px rgba(37,99,235,0.15);">&#9881; Asset</span>
                <span style="color:#6b7280;font-size:22px;font-weight:bold;">&rarr;</span>
                <span style="background:#ecfdf5;color:#059669;padding:8px 18px;border-radius:8px;font-weight:700;font-size:16px;box-shadow:0 2px 4px rgba(5,150,105,0.15);">&#9992; Flight</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
