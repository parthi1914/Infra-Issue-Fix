# System Flow: 1FA -> 1FDI -> PHM -> FMX
SYSTEM_FLOW = [
    "1FA",
    "1FDI",
    "PHM",
    "FMX",
]

# Data Source Flow for diagnostic data (same as SYSTEM_FLOW)
DATA_SOURCE_FLOW = SYSTEM_FLOW

ASSET_SYSTEMS = {"1FA", "1FDI"}
FLIGHT_SYSTEMS = {"PHM"}
ENDPOINT_SYSTEMS = {"FMX"}

SAMPLE_ENGINE_SERIALS = [
    "000000", "038429", "041223", "052781", "060009",
    "073145", "089771", "101556", "115902",
]

SAMPLE_TAIL_NUMBERS = [
    "N-DEMO", "B-1316", "LN-FGJ", "N872SK", "G-LOJO",
    "F-HXM", "D-ABCD", "N7-MXV", "N932SK",
]

TAIL_TO_ENGINES = {
    "N-DEMO": ["000000", "038429"],
    "B-1316": ["041223", "052781"],
    "LN-FGJ": ["060009", "073145"],
    "N872SK": ["089771", "101556"],
    "G-LOJO": ["115902", "038429"],
    "F-HXM": ["041223", "060009"],
    "D-ABCD": ["073145", "089771"],
    "N7-MXV": ["101556", "115902"],
    "N932SK": ["000000", "052781"],
}

ENGINE_TO_TAILS = {}
for _tail, _engines in TAIL_TO_ENGINES.items():
    for _esn in _engines:
        if _esn not in ENGINE_TO_TAILS:
            ENGINE_TO_TAILS[_esn] = []
        ENGINE_TO_TAILS[_esn].append(_tail)

STATUSES = ["Pending", "Processing", "Complete", "Delayed", "Error", "NotStarted"]

STATUS_COLOR_MAP = {
    "Complete": "#2ca02c",
    "Processing": "#1f77b4",
    "Pending": "#1f77b4",
    "Delayed": "#1f77b4",
    "Error": "#d62728",
    "NotStarted": "#d9d9d9",
}

# All 19 properties from edm_raw.asset_diagnostic_stg table
DATA_ELEMENTS = [
    "ESN",
    "Diagnostic Installation Date",
    "Diagnostic Tail",
    "Engine Position",
    "Installation Date",
    "Last Updated Date",
    "N1 Modifier",
    "Operator",
    "Monitor",
    "Operator Diagnostic Code",
    "Tail Number Aircraft ID",
    "Engine Model",
    "Engine Type",
    "Engine Family Model Series",
    "Aircraft Delivery Date",
    "Aircraft Family",
    "Aircraft Model",
    "Aircraft Series",
    "Installation History",
]
