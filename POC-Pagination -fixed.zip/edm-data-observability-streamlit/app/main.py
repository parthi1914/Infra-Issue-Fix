import streamlit as st

from utils.sidebar import setup_sidebar
from components.header import render_header
from components.kpis import render_kpis
from components.horizontal_menu import MENU_ITEMS

from app_pages import overview, timeline, flow_network, data_elements, raw_data, db_query

st.set_page_config(page_title="Engine Data Observability", layout="wide")

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 0.5rem !important;
        padding-bottom: 0.5rem !important;
    }
    header[data-testid="stHeader"] {
        height: 0; min-height: 0; padding: 0;
    }
    h1 { font-size: 1.6rem !important; }
    h2 { font-size: 1.3rem !important; }
    h3 { font-size: 1.1rem !important; }
    .stTabs [data-baseweb="tab-list"] {
        gap: 0px; background: #f8f9fb; border-radius: 6px; padding: 2px 4px;
    }
    .stTabs [data-baseweb="tab"] {
        font-size: 0.82rem; padding: 6px 18px; font-weight: 500;
    }
    .stTabs [aria-selected="true"] {
        background: #ffffff; border-radius: 5px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }
    [data-testid="stMetric"] { display: none; }
    section[data-testid="stSidebar"] { background: #f5f6f8; }
    section[data-testid="stSidebar"] .stRadio > label,
    section[data-testid="stSidebar"] .stSelectbox > label,
    section[data-testid="stSidebar"] .stSlider > label {
        font-size: 0.82rem !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

render_header()
setup_sidebar()
render_kpis()

tabs = st.tabs(MENU_ITEMS)

PAGE_RENDERERS = [
    overview.render,
    timeline.render,
    flow_network.render,
    data_elements.render,
    raw_data.render,
    db_query.render,
]

for tab, renderer in zip(tabs, PAGE_RENDERERS):
    with tab:
        renderer()

# AWS Session Expiry Diagnostic
def show_aws_session_expiry():
    try:
        aws_cfg = dict(st.secrets.get("aws", {}))
        session_token = aws_cfg.get("session_token")
        if session_token:
            import base64
            import json
            import re
            import datetime
            # Try to decode the session token for expiry info (if JWT-like)
            m = re.search(r"\.([A-Za-z0-9_-]+)\.", session_token)
            if m:
                try:
                    payload = m.group(1)
                    padded = payload + '=' * (-len(payload) % 4)
                    decoded = base64.urlsafe_b64decode(padded)
                    data = json.loads(decoded)
                    exp = data.get('exp')
                    if exp:
                        expiry = datetime.datetime.utcfromtimestamp(exp)
                        st.info(f"AWS session token expires at: {expiry} UTC")
                        return
                except Exception:
                    pass
            st.info("AWS session token present (expiry not decoded, check your SSO/SAML tool for expiry time)")
    except Exception:
        pass

# show_aws_session_expiry()
