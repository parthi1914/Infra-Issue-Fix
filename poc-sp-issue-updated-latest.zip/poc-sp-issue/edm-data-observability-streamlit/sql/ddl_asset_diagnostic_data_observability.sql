-- ============================================================================
-- DDL: edm_rpt.asset_diagnostic_data_observability
-- ============================================================================
-- Target table for replicating data from edm_raw.asset_diagnostic_stg.
-- Mirrors the source table structure with an additional replicated_at column.
--
-- Also creates the ETL execution log table for tracking replication runs.
--
-- Prerequisites:
--   CREATE SCHEMA IF NOT EXISTS edm_rpt;
--
-- Usage:
--   Run this script once to create the tables and indexes.
-- ============================================================================

-- Ensure schema exists
CREATE SCHEMA IF NOT EXISTS edm_rpt;

-- ============================================================================
-- 1. Target Table
-- ============================================================================
CREATE TABLE IF NOT EXISTS edm_rpt.asset_diagnostic_data_observability (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    data_source varchar(10) NOT NULL,
	esn varchar(25) NOT NULL,
	diagnostic_installation_date date NULL,
	diagnostic_tail varchar(50) NULL,
	engine_position varchar(20) NULL,
	installation_date date NULL,
	last_update_date timestamp NULL,
	n1_modifier varchar(50) NULL,
	"operator" varchar(200) NULL,
	monitor varchar(50) NULL,
	operator_diagnostic_code varchar(50) NULL,
	tail_number_aircraft_id varchar(50) NULL,
	engine_model varchar(50) NULL,
	engine_type varchar(50) NULL,
	engine_family_model_series varchar(100) NULL,
	aircraft_delivery_date date NULL,
	aircraft_family varchar(50) NULL,
	aircraft_model varchar(250) NULL,
	aircraft_series varchar(50) NULL,
	installation_history date NULL,
    replicated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE edm_rpt.asset_diagnostic_data_observability
    IS 'Replicated copy of edm_raw.asset_diagnostic_stg for reporting and observability.';

COMMENT ON COLUMN edm_rpt.asset_diagnostic_data_observability.replicated_at
    IS 'Timestamp when this row was copied from the source table.';

-- Composite index for deduplication lookups during replication
CREATE INDEX IF NOT EXISTS idx_ado_dedup
    ON edm_rpt.asset_diagnostic_data_observability (esn, diagnostic_tail, data_source, last_update_date);

-- Index for common query patterns
CREATE INDEX IF NOT EXISTS idx_ado_esn
    ON edm_rpt.asset_diagnostic_data_observability (esn);

CREATE INDEX IF NOT EXISTS idx_ado_last_update
    ON edm_rpt.asset_diagnostic_data_observability (last_update_date DESC NULLS LAST);


-- ============================================================================
-- 2. ETL Replication Log Table
-- ============================================================================
CREATE TABLE IF NOT EXISTS edm_rpt.etl_replication_log (
    log_id              BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    execution_start     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    execution_end       TIMESTAMPTZ,
    status              VARCHAR(20) NOT NULL DEFAULT 'RUNNING',
    run_type            VARCHAR(20),
    source_table        TEXT NOT NULL,
    target_table        TEXT NOT NULL,
    records_processed   BIGINT DEFAULT 0,
    records_inserted    BIGINT DEFAULT 0,
    records_skipped     BIGINT DEFAULT 0,
    last_source_timestamp TIMESTAMPTZ,
    error_message       TEXT,
    executed_by         TEXT DEFAULT CURRENT_USER
);

COMMENT ON TABLE edm_rpt.etl_replication_log
    IS 'Execution log for sp_replicate_diagnostic_data. Tracks each ETL run with counts and status.';

-- Index for quick lookup of last successful run
CREATE INDEX IF NOT EXISTS idx_etl_log_status
    ON edm_rpt.etl_replication_log (status, execution_start DESC);
