-- ============================================================================
-- Stored Procedure: sp_get_overview_data
-- ============================================================================
-- Returns system statuses for the Overview page.
--
-- BUG FIX: Previous code used SELECT DISTINCT data_source, last_update_date
-- which could return multiple rows per system and pick a random one.
-- This SP uses ROW_NUMBER() to guarantee the LATEST row per system.
--
-- Mandatory / Optional Parameters:
--   p_esn           REQUIRED  — Engine Serial Number
--   p_tail          OPTIONAL  — Diagnostic tail filter (DEFAULT NULL = all tails for ESN)
--   p_operator_code OPTIONAL  — Operator diagnostic code filter (DEFAULT NULL = all operators)
--
-- Validation Rules (cascading):
--   1FA:  PASS if last_update_date IS NOT NULL
--   1FDI: PENDING if 1FA failed; else PASS if time > 1FA AND gap <= 30 min
--   PHM:  PENDING if 1FDI failed/pending; else PASS if time > 1FDI AND gap <= 30 min
--   FMX:  PENDING if PHM failed/pending; else PASS if time > PHM AND gap <= 30 min
--
-- Returns one row per system (4 rows) with:
--   system_name, last_update_time, status, message, time_str
--
-- Usage:
--   SELECT * FROM sp_get_overview_data('729497');                        -- ESN only
--   SELECT * FROM sp_get_overview_data('729497', 'HZ-FAB');              -- ESN + Tail
--   SELECT * FROM sp_get_overview_data('729497', 'HZ-FAB', 'ODC-001');   -- ESN + Tail + Operator
--   SELECT * FROM sp_get_overview_data('729497', NULL, 'ODC-001');        -- ESN + Operator (no tail filter)
--   SELECT * FROM sp_get_overview_data('729497', NULL, NULL);             -- ESN only (explicit NULLs)
-- ============================================================================

DROP FUNCTION IF EXISTS sp_get_overview_data(TEXT);
DROP FUNCTION IF EXISTS sp_get_overview_data(TEXT, TEXT);
DROP FUNCTION IF EXISTS sp_get_overview_data(TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_overview_data(
    p_esn            TEXT,
    p_tail           TEXT    DEFAULT NULL,  -- optional diagnostic_tail filter
    p_operator_code  TEXT    DEFAULT NULL   -- optional operator_diagnostic_code filter
)
RETURNS TABLE (
    system_name      TEXT,
    last_update_time TIMESTAMPTZ,
    status           TEXT,
    message          TEXT,
    time_str         TEXT
)
AS $$
DECLARE
    v_1fa_time   TIMESTAMPTZ;
    v_1fdi_time  TIMESTAMPTZ;
    v_phm_time   TIMESTAMPTZ;
    v_fmx_time   TIMESTAMPTZ;
    v_1fa_status   TEXT;
    v_1fdi_status  TEXT;
    v_phm_status   TEXT;
    v_fmx_status   TEXT;
    v_1fa_msg   TEXT;
    v_1fdi_msg  TEXT;
    v_phm_msg   TEXT;
    v_fmx_msg   TEXT;
    v_diff_min  DOUBLE PRECISION;
BEGIN
    -- Get latest timestamps for each system
    SELECT sub.last_update_date INTO v_1fa_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn
          AND (p_tail          IS NULL OR diagnostic_tail           = p_tail)
          AND (p_operator_code IS NULL OR operator_diagnostic_code  = p_operator_code)
          AND data_source = '1FA'
    ) sub WHERE sub.rn = 1;

    SELECT sub.last_update_date INTO v_1fdi_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn
          AND (p_tail          IS NULL OR diagnostic_tail           = p_tail)
          AND (p_operator_code IS NULL OR operator_diagnostic_code  = p_operator_code)
          AND data_source = '1FDI'
    ) sub WHERE sub.rn = 1;

    SELECT sub.last_update_date INTO v_phm_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn
          AND (p_tail          IS NULL OR diagnostic_tail           = p_tail)
          AND (p_operator_code IS NULL OR operator_diagnostic_code  = p_operator_code)
          AND data_source = 'PHM'
    ) sub WHERE sub.rn = 1;

    SELECT sub.last_update_date INTO v_fmx_time
    FROM (
        SELECT last_update_date,
               ROW_NUMBER() OVER (ORDER BY last_update_date DESC NULLS LAST) AS rn
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = p_esn
          AND (p_tail          IS NULL OR diagnostic_tail           = p_tail)
          AND (p_operator_code IS NULL OR operator_diagnostic_code  = p_operator_code)
          AND data_source = 'FMX'
    ) sub WHERE sub.rn = 1;

    -- 1FA logic
    IF v_1fa_time IS NOT NULL THEN
        v_1fa_status := 'pass';
        v_1fa_msg := 'Data received';
    ELSE
        v_1fa_status := 'fail';
        v_1fa_msg := 'No data received';
    END IF;

    -- 1FDI logic
    IF v_1fa_status = 'fail' THEN
        v_1fdi_status := 'pending';
        v_1fdi_msg := 'Waiting - previous system (1FA) not complete';
    ELSIF v_1fdi_time IS NULL THEN
        v_1fdi_status := 'fail';
        v_1fdi_msg := 'No data received';
    ELSE
        v_diff_min := EXTRACT(EPOCH FROM (v_1fdi_time - v_1fa_time)) / 60.0;
        IF v_diff_min < 0 OR v_diff_min > 30 THEN
            v_1fdi_status := 'fail';
            v_1fdi_msg := 'Time gap ' || COALESCE(ROUND(v_diff_min::NUMERIC),0) || ' min (invalid)';
        ELSE
            v_1fdi_status := 'pass';
            v_1fdi_msg := 'Received ' || COALESCE(ROUND(v_diff_min::NUMERIC),0) || ' min after previous';
        END IF;
    END IF;

    -- PHM logic
    IF v_1fa_status = 'fail' OR v_1fdi_status IN ('fail','pending') THEN
        v_phm_status := 'pending';
        v_phm_msg := 'Waiting - previous system (1FDI) not complete';
    ELSIF v_phm_time IS NULL THEN
        v_phm_status := 'fail';
        v_phm_msg := 'No data received';
    ELSE
        v_diff_min := EXTRACT(EPOCH FROM (v_phm_time - v_1fdi_time)) / 60.0;
        IF v_diff_min < 0 OR v_diff_min > 30 THEN
            v_phm_status := 'fail';
            v_phm_msg := 'Time gap ' || COALESCE(ROUND(v_diff_min::NUMERIC),0) || ' min (invalid)';
        ELSE
            v_phm_status := 'pass';
            v_phm_msg := 'Received ' || COALESCE(ROUND(v_diff_min::NUMERIC),0) || ' min after previous';
        END IF;
    END IF;

    -- FMX logic
    IF v_1fa_status = 'fail' OR v_1fdi_status IN ('fail','pending') OR v_phm_status IN ('fail','pending') THEN
        v_fmx_status := 'pending';
        v_fmx_msg := 'Waiting - previous system (PHM) not complete';
    ELSIF v_fmx_time IS NULL THEN
        v_fmx_status := 'fail';
        v_fmx_msg := 'No data received';
    ELSE
        v_diff_min := EXTRACT(EPOCH FROM (v_fmx_time - v_phm_time)) / 60.0;
        IF v_diff_min < 0 OR v_diff_min > 30 THEN
            v_fmx_status := 'fail';
            v_fmx_msg := 'Time gap ' || COALESCE(ROUND(v_diff_min::NUMERIC),0) || ' min (invalid)';
        ELSE
            v_fmx_status := 'pass';
            v_fmx_msg := 'Received ' || COALESCE(ROUND(v_diff_min::NUMERIC),0) || ' min after previous';
        END IF;
    END IF;

    -- Return rows in order: 1FA, 1FDI, PHM, FMX
    RETURN QUERY
    SELECT '1FA', v_1fa_time, v_1fa_status, v_1fa_msg, COALESCE(TO_CHAR(v_1fa_time, 'YYYY-MM-DD HH24:MI:SS'), '—')
    UNION ALL
    SELECT '1FDI', v_1fdi_time, v_1fdi_status, v_1fdi_msg, COALESCE(TO_CHAR(v_1fdi_time, 'YYYY-MM-DD HH24:MI:SS'), '—')
    UNION ALL
    SELECT 'PHM', v_phm_time, v_phm_status, v_phm_msg, COALESCE(TO_CHAR(v_phm_time, 'YYYY-MM-DD HH24:MI:SS'), '—')
    UNION ALL
    SELECT 'FMX', v_fmx_time, v_fmx_status, v_fmx_msg, COALESCE(TO_CHAR(v_fmx_time, 'YYYY-MM-DD HH24:MI:SS'), '—');
END;
$$ LANGUAGE plpgsql STABLE;

-- ============================================================================
-- Stored Procedure: sp_get_filter_options
-- ============================================================================
-- Returns options for ESN and Tail dropdown loading.
--
-- This function is called from the frontend to populate the dropdowns.
--
-- Usage:
--   SELECT * FROM sp_get_filter_options('729497');
-- ============================================================================

DROP FUNCTION IF EXISTS sp_get_filter_options(TEXT, TEXT);

CREATE OR REPLACE FUNCTION sp_get_filter_options(
    mode TEXT,
    value TEXT DEFAULT NULL
)
RETURNS TABLE (
    option_value TEXT,
    option_type TEXT
)
AS $$
BEGIN
    -- All ESNs
    IF mode IS NULL OR mode = 'all_esns' THEN
        RETURN QUERY
        SELECT DISTINCT esn::TEXT AS option_value, 'esn'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn IS NOT NULL
        ORDER BY esn;
    END IF;
    END IF;

    -- All Tail Numbers
    IF mode = 'all_tails' THEN
        RETURN QUERY
        SELECT DISTINCT diagnostic_tail::TEXT AS option_value, 'tail'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE diagnostic_tail IS NOT NULL
        ORDER BY diagnostic_tail;
    END IF;

    -- Tails for ESN
    IF mode = 'tails_for_esn' THEN
        RETURN QUERY
        SELECT DISTINCT diagnostic_tail::TEXT AS option_value, 'tail'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = value AND diagnostic_tail IS NOT NULL
        ORDER BY diagnostic_tail;
    END IF;

    -- ESNs for Tail
    IF mode = 'esns_for_tail' THEN
        RETURN QUERY
        SELECT DISTINCT esn::TEXT AS option_value, 'esn'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE diagnostic_tail = value AND esn IS NOT NULL
        ORDER BY esn;
    END IF;

    -- Operator Codes for ESN
    IF mode = 'operators_for_esn' THEN
        RETURN QUERY
        SELECT DISTINCT operator::TEXT AS option_value, 'operator'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE esn = value AND operator IS NOT NULL
        ORDER BY operator;
    END IF;

    -- Operator Codes for Tail
    IF mode = 'operators_for_tail' THEN
        RETURN QUERY
        SELECT DISTINCT operator_diagnostic_code::TEXT AS option_value, 'operator'::TEXT AS option_type
        FROM edm_raw.asset_diagnostic_stg
        WHERE diagnostic_tail = value AND operator_diagnostic_code IS NOT NULL
        ORDER BY operator_diagnostic_code;
    END IF;

END;
$$ LANGUAGE plpgsql STABLE;


