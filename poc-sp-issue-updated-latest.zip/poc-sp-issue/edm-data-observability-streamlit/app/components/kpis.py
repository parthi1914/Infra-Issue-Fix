import streamlit as st

from utils.constants import SYSTEM_FLOW
from services.diagnostic_service import (
    get_total_and_completed,
    get_status_counts,
)

_CARD_CSS = """
<style>
.kpi-row {
    display: flex;
    gap: 14px;
    margin: 8px 0 14px;
}
.kpi-card {
    flex: 1;
    background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%);
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 16px 18px;
    display: flex;
    align-items: center;
    gap: 14px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.kpi-icon {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    flex-shrink: 0;
    box-shadow: 0 2px 6px rgba(0,0,0,0.12);
}
.kpi-text .kpi-label {
    font-size: 11px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.6px;
    margin: 0;
}
.kpi-text .kpi-value {
    font-size: 26px;
    font-weight: 800;
    color: #1e293b;
    margin: 2px 0 0;
    line-height: 1.1;
}
</style>
"""

_CARD_TEMPLATE = """
<div class="kpi-card">
    <div class="kpi-icon" style="background:{bg};color:{fg};">{icon}</div>
    <div class="kpi-text">
        <p class="kpi-label">{label}</p>
        <p class="kpi-value">{value}</p>
    </div>
</div>
"""


def render_kpis():
    # Get engine serial and tail from session state
    engine_serial = st.session_state.get("engine_serial", "")
    tail_number = st.session_state.get("tail_number", "")
    
    # If no ESN selected, show dashes (Tail Number is optional)
    if not engine_serial:
        total_systems = "—"
        pass_count = "—"
        fail_count = "—"
        pending_count = "—"
    else:
        # Query diagnostic data for KPIs
        total_systems, _ = get_total_and_completed(engine_serial, tail_number)
        counts = get_status_counts(engine_serial, tail_number)
        pass_count = counts["pass"]
        fail_count = counts["fail"]
        pending_count = counts["pending"]

    cards = [
        {"label": "Total Systems",   "value": total_systems,   "icon": "&#9881;",  "bg": "linear-gradient(135deg,#3b82f6,#60a5fa)", "fg": "#fff"},
        {"label": "Pass",            "value": pass_count,      "icon": "&#10004;", "bg": "linear-gradient(135deg,#059669,#10b981)", "fg": "#fff"},
        {"label": "Fail",            "value": fail_count,      "icon": "&#10006;", "bg": "linear-gradient(135deg,#dc2626,#ef4444)", "fg": "#fff"},
        {"label": "Pending",         "value": pending_count,   "icon": "&#9202;",  "bg": "linear-gradient(135deg,#d97706,#f59e0b)", "fg": "#fff"},
    ]

    html = _CARD_CSS + '<div class="kpi-row">'
    for c in cards:
        html += _CARD_TEMPLATE.format(**c)
    html += "</div>"

    st.markdown(html, unsafe_allow_html=True)

