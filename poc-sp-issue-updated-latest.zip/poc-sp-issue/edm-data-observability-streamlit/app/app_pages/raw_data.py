import streamlit as st

from services.raw_data_service import get_raw_data
from utils.utils import show_filter_info, show_no_data_message


def render():
    """Render the Raw Data tab with actual data from asset_diagnostic_stg."""
    
    st.subheader("Raw Simulated Data")
    
    # Display filter info and get values
    engine_serial, tail_number, operator_code = show_filter_info()
    
    # Check if ESN is selected (Tail Number is optional)
    if not engine_serial:
        show_no_data_message("Raw Data")
        return
    
    # Fetch raw data from database
    df = get_raw_data(engine_serial, tail_number)
    
    if df.empty:
        st.warning(f"No data found for ESN: {engine_serial}, Tail: {tail_number}")
        return
    
    # Display the data grid
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "engine_serial": st.column_config.TextColumn("engine_serial", width="medium"),
            "tail_number": st.column_config.TextColumn("tail_number", width="medium"),
            "system": st.column_config.TextColumn("system", width="small"),
            "start_time": st.column_config.DatetimeColumn("start_time", width="medium"),
            "end_time": st.column_config.DatetimeColumn("end_time", width="medium"),
            "status": st.column_config.TextColumn("status", width="small"),
            "latency_sec": st.column_config.TextColumn("latency_sec", width="small"),
            "records": st.column_config.TextColumn("records", width="small"),
            "data_size_mb": st.column_config.TextColumn("data_size_mb", width="small"),
        }
    )
