import streamlit as st

from utils.charts import build_timeline, build_diagnostic_timeline
from utils.utils import show_filter_info, show_no_data_message


def render():
    """
    Render Timeline tab with diagnostic data.
    Shows "No Data" message until ESN is selected.
    """
    st.subheader("Timeline")

    # Display filter info and get values
    engine_serial, tail_number, operator_code = show_filter_info()

    # Check if ESN is selected (Tail Number is optional)
    if not engine_serial:
        show_no_data_message("Timeline")
        return
    
    # Render diagnostic timeline using DB data
    fig_timeline = build_diagnostic_timeline(engine_serial, tail_number)
    st.plotly_chart(fig_timeline, use_container_width=True)
