import streamlit as st

from utils.charts import build_sankey, build_network_graph, build_diagnostic_sankey, build_diagnostic_network_graph
from utils.utils import show_filter_info, show_no_data_message


def render():
    """
    Render Flow & Network tab with diagnostic data.
    Shows "No Data" message until ESN is selected.
    """
    st.subheader("Flow & Network")

    # Display filter info and get values
    engine_serial, tail_number, operator_code = show_filter_info()

    # Check if ESN is selected (Tail Number is optional)
    if not engine_serial:
        show_no_data_message("Flow & Network")
        return
    
    # Render diagnostic charts using DB data
    col1, col2 = st.columns([1, 1])
    with col1:
        sankey = build_diagnostic_sankey(engine_serial, tail_number)
        st.plotly_chart(sankey, use_container_width=True)
    with col2:
        network_fig = build_diagnostic_network_graph(engine_serial, tail_number)
        st.plotly_chart(network_fig, use_container_width=True)
