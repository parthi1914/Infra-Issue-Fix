import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import networkx as nx
import random
import json
import os
import streamlit as st
from datetime import datetime, timedelta

from utils.constants import (
    SYSTEM_FLOW, ASSET_SYSTEMS, FLIGHT_SYSTEMS, ENDPOINT_SYSTEMS,
    STATUS_COLOR_MAP, DATA_ELEMENTS, DATA_SOURCE_FLOW,
)
from services.diagnostic_service import (
    get_data_population,
    get_timeline_chart_data,
)

# ---------------------------------------------------------------------------
# Caching Configuration — caches chart output when filter inputs are unchanged
# ---------------------------------------------------------------------------
CHART_CACHE_TTL = 60


# ------------------------------------------------------------------
# Classification helper
# ------------------------------------------------------------------
def classify_status(status: str) -> str:
    if status == "Complete":
        return "Pass"
    if status == "Error":
        return "Fail"
    if status in {"Pending", "Delayed"}:
        return "Pending"
    if status == "NotStarted":
        return "Pending"
    return "Processing"


# ------------------------------------------------------------------
# Overview helpers
# ------------------------------------------------------------------
def build_status_summary(df: pd.DataFrame) -> pd.DataFrame:
    mapped = df.status.apply(classify_status)
    vc = mapped.value_counts()
    vc = vc.reindex(["Fail", "Pass", "Pending", "Processing"], fill_value=0)
    summary = vc.reset_index(name="count")
    summary.rename(columns={"index": "category"}, inplace=True)
    summary = summary.astype({"count": int})
    if list(summary.columns) != ["category", "count"]:
        summary.columns = ["category", "count"]
    return summary


def build_population_pies(df: pd.DataFrame) -> list:
    """Build pie charts for each system showing completeness (matching expected design)."""
    pies = []
    for system in SYSTEM_FLOW:
        completeness = random.uniform(0.80, 0.97)
        missing = 1.0 - completeness
        
        fig = go.Figure(data=[go.Pie(
            labels=["Present", "Missing"], 
            values=[completeness, missing], 
            hole=0.55,
            marker=dict(colors=["#1f77b4", "#aec7e8"]),  # Dark blue, Light blue
            textinfo="percent",
            textfont=dict(size=11),
            textposition="outside",
        )])
        fig.update_layout(
            title=dict(text=f"{system}", font=dict(size=14), x=0.5, xanchor="center"),
            margin=dict(l=10, r=10, t=40, b=10),
            showlegend=False,
            height=220,
        )
        pies.append(fig)
    return pies


# ------------------------------------------------------------------
# Diagnostic Data Functions (NEW)
# ------------------------------------------------------------------
def build_diagnostic_pass_fail_summary(
    engine_serial: str,
    diagnostic_tail: str,
    *,
    statuses: dict = None,
) -> pd.DataFrame:
    """
    Build Pass/Fail/Pending summary for diagnostic data.

    Returns: DataFrame with columns ['category', 'count']
    Loads from the statuses dict passed from the Overview tab (single SP call).
    """
    counts = {"pass": 0, "fail": 0, "pending": 0}
    if statuses:
        for info in statuses.values():
            counts[info["status"]] += 1

    data = {
        "category": ["Pass", "Fail", "Pending"],
        "count": [counts["pass"], counts["fail"], counts["pending"]],
    }
    return pd.DataFrame(data)


@st.cache_data(ttl=CHART_CACHE_TTL, show_spinner=False)
def build_diagnostic_population_pies(
    engine_serial: str,
    diagnostic_tail: str,
) -> list:
    """
    Build pie charts for each data source showing Present vs Missing fields.
    
    For each data source in DATA_SOURCE_FLOW (1FA, 1FDI, PHM, FMX):
    - Present: Records where last_update_date IS NOT NULL
    - Missing: Records where last_update_date IS NULL
    
    Returns: List of plotly figures
    """
    pies = []
    population = get_data_population(engine_serial, diagnostic_tail)
    
    for source in DATA_SOURCE_FLOW:
        source_data = population.get(source, {"present": 0.85, "missing": 0.15})
        present = source_data["present"]
        missing = source_data["missing"]
        
        fig = go.Figure(
            data=[go.Pie(
                labels=["Present", "Missing"],
                values=[present, missing],
                hole=0.55,
                marker=dict(colors=["#1f77b4", "#aec7e8"]),  # Dark blue, Light blue
                textinfo="percent",
                textfont=dict(size=11),
                textposition="outside",
            )]
        )
        fig.update_layout(
            title=dict(text=f"{source}", font=dict(size=14), x=0.5, xanchor="center"),
            margin=dict(l=10, r=10, t=40, b=30),
            showlegend=False,
            height=240,
        )
        pies.append(fig)
    
    return pies


def build_diagnostic_last_updated_table(
    engine_serial: str,
    diagnostic_tail: str,
    *,
    statuses: dict = None,
) -> pd.DataFrame:
    """
    Build table of last updated times for each data source.

    Returns: DataFrame with columns [Data Source, Last Updated, Duration]
    Ordered by DATA_SOURCE_FLOW (1FA -> 1FDI -> PHM -> FMX)
    Duration = (current system time - previous system time) in minutes with +/- sign
    Loads from the statuses dict passed from the Overview tab (single SP call).
    """
    records = {source: info["time"] for source, info in statuses.items()} if statuses else {}

    if not records:
        return pd.DataFrame(columns=["Data Source", "Last Updated", "Duration"])
    
    rows = []
    prev_ts = None
    
    for source in SYSTEM_FLOW:
        ts = records.get(source)
        last_updated_str = ts.strftime("%Y-%m-%d %H:%M:%S") if ts else "—"
        
        # Calculate duration (current - previous) in minutes
        if source == "1FA":
            # First system - no previous, set as NA
            duration_str = "NA"
        elif ts is None or prev_ts is None:
            # Current or previous is null
            duration_str = "NA"
        else:
            # Calculate difference in minutes: current - previous
            diff_seconds = (ts - prev_ts).total_seconds()
            diff_minutes = diff_seconds / 60.0
            
            # Format with +/- sign, always in minutes
            if diff_minutes >= 0:
                duration_str = f"+{diff_minutes:.0f} min"
            else:
                duration_str = f"{diff_minutes:.0f} min"
        
        rows.append({
            "Data Source": source,
            "Last Updated": last_updated_str,
            "Duration": duration_str,
        })
        
        prev_ts = ts
    
    return pd.DataFrame(rows)


def build_diagnostic_sla_timeline_html(
    engine_serial: str,
    diagnostic_tail: str,
    now: datetime = None,
    *,
    statuses: dict = None,
) -> str:
    """
    Build SLA Timeline with original design (horizontal bar segments with freshness pill).
    Uses DB data for status calculations.
    Freshness: OK (green) if 1FA passes, Failed (red) if 1FA fails.
    Loads from the statuses dict passed from the Overview tab (single SP call).
    """
    if now is None:
        now = datetime.utcnow()

    stages = statuses or {}
    
    # Freshness based on 1FA status: OK if pass, Failed if fail/pending
    fa_status = stages.get("1FA", {}).get("status", "pending")
    if fa_status == "pass":
        freshness_state = "ok"
        freshness_label = "Freshness: OK"
    else:
        freshness_state = "fail"
        freshness_label = "Freshness: Failed"
    
    # Build segments HTML
    segments_html = []
    for idx, source in enumerate(DATA_SOURCE_FLOW):
        stage = stages.get(source, {"status": "pending", "time": None})
        status = stage.get("status", "pending")
        
        # Map status to CSS class
        if status == "pass":
            cls = "pass"
            label = "Pass"
        elif status == "fail":
            cls = "fail"
            label = "Fail"
        else:
            cls = "pending"
            label = "Pending"
        
        # Icon based on system type
        icon = " " if source in ASSET_SYSTEMS else (" " if source in FLIGHT_SYSTEMS else " ")
        
        segments_html.append(
            f"<div class='sla-segment {cls}' style='flex:1'>"
            f"<div class='inner'><span>{icon} {source}</span><small>{label}</small></div></div>"
        )
        if idx < len(DATA_SOURCE_FLOW) - 1:
            segments_html.append("<div class='sla-gap'></div>")
    
    style = """
    <style>
    .sla-bar {display:flex;align-items:stretch;gap:6px;margin:12px 0;font-family:Segoe UI,Arial,sans-serif;}
    .sla-segment {position:relative;background:#d9d9d9;border-radius:14px;min-height:70px;display:flex;align-items:center;justify-content:center;box-shadow:inset 0 0 4px rgba(0,0,0,0.15);}
    .sla-segment.pass {background:linear-gradient(135deg,#2ca02c,#45c842);}
    .sla-segment.processing {background:linear-gradient(135deg,#1f77b4,#3a92d0);}
    .sla-segment.pending {background:linear-gradient(135deg,#1f77b4,#3a92d0);}
    .sla-segment.fail {background:linear-gradient(135deg,#d62728,#f04141);}
    .sla-segment.upcoming {background:#d9d9d9;color:#666;}
    .sla-segment .inner {text-align:center;color:#fff;font-weight:600;font-size:15px;}
    .sla-segment .inner small {display:block;font-size:11px;font-weight:500;opacity:0.85;}
    .sla-gap {width:10px;height:8px;background:#e0e0e0;border-radius:4px;align-self:center;box-shadow:inset 0 0 3px rgba(0,0,0,0.2);}
    .freshness-pill {display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;margin-top:4px;}
    .freshness-pill.ok {background:linear-gradient(135deg,#059669,#10b981);} .freshness-pill.fail {background:linear-gradient(135deg,#dc2626,#ef4444);}
    </style>
    """
    pill = f"<div class='freshness-pill {freshness_state}'>{freshness_label}</div>"
    html = style + "<div class='sla-bar'>" + "".join(segments_html) + "</div>" + pill
    return html


def _load_root_cause_json(system: str) -> dict:
    """
    Load root cause JSON file for a specific system.
    Returns dict with root_causes, disruptions, actions lists.
    """
    config_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config")
    json_file = os.path.join(config_dir, f"{system}rootcause.json")
    
    try:
        with open(json_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # Fallback if file not found
        return {
            "root_causes": [f"{system} configuration issue detected"],
            "disruptions": [f"{system} processing delayed"],
            "actions": [f"Contact {system} support team"]
        }


def build_diagnostic_root_cause_panel(
    engine_serial: str,
    diagnostic_tail: str,
    *,
    statuses: dict = None,
) -> pd.DataFrame:
    """
    Build Root Cause & Governance panel using DB data.
    Loads from system-specific JSON files when a system fails.
    Returns DataFrame with same structure as original fake_root_cause_panel.
    Loads from the statuses dict passed from the Overview tab (single SP call).
    """
    if statuses is None:
        statuses = {}

    # Find the first failed system and load its root cause JSON
    failed_system = None
    for source in DATA_SOURCE_FLOW:
        status_info = statuses.get(source, {"status": "pending", "message": "No data"})
        status = status_info.get("status", "pending")
        
        if status == "fail":
            failed_system = source
            break
    
    if failed_system:
        # Load root cause data from the corresponding JSON file
        rc_data = _load_root_cause_json(failed_system)
        root_causes = rc_data.get("root_causes", [])
        disruptions = rc_data.get("disruptions", [])
        actions = rc_data.get("actions", [])
    else:
        # No failures - show all-clear message
        root_causes = ["No issues detected"]
        disruptions = ["All systems operational"]
        actions = ["Continue monitoring"]
    
    # Ensure all lists have same length (pad if needed)
    max_len = max(len(root_causes), len(disruptions), len(actions))
    while len(root_causes) < max_len:
        root_causes.append("")
    while len(disruptions) < max_len:
        disruptions.append("")
    while len(actions) < max_len:
        actions.append("")
    
    data = {
        "Root Cause (Auto Detected)": root_causes,
        "Current Disruptions": disruptions,
        "Action & Governance": actions,
    }
    return pd.DataFrame(data)


def build_diagnostic_dominos_style_tracker_html(
    engine_serial: str,
    diagnostic_tail: str,
    now: datetime = None,
    *,
    statuses: dict = None,
) -> str:
    """
    Build Domino Style Progress tracker using DB data.
    Matches original design exactly.

    Logic:
    - Start: 1FA time
    - ETA: 1FA time + (Total Systems * 30 min)
    - Elapsed: Passed systems count * 30 min
    - Remaining: (Total systems - Passed systems) * 30 min
    Loads from the statuses dict passed from the Overview tab (single SP call).
    """
    if now is None:
        now = datetime.utcnow()

    if statuses is None:
        statuses = {}
    
    total = len(DATA_SOURCE_FLOW)
    
    # Count passed systems
    passed_count = 0
    current_idx = 0
    for i, source in enumerate(DATA_SOURCE_FLOW):
        status_info = statuses.get(source, {"status": "pending"})
        if status_info["status"] == "pass":
            passed_count += 1
            current_idx = i + 1
        else:
            current_idx = i
            break
    
    # Clamp to valid range
    current_idx = min(current_idx, len(DATA_SOURCE_FLOW) - 1)
    
    # Calculate intra-stage progress (100% for completed stages)
    current_source = DATA_SOURCE_FLOW[current_idx]
    current_status = statuses.get(current_source, {"status": "pending"})["status"]
    intra = 1.0 if current_status == "pass" else 0.0
    
    global_progress = (passed_count / total) if total > 0 else 0
    
    # Build step HTML
    step_html = []
    for i, source in enumerate(DATA_SOURCE_FLOW):
        status_info = statuses.get(source, {"status": "pending"})
        status = status_info["status"]
        
        # Map status to CSS class
        if status == "pass":
            state_class = "complete"
        elif status == "fail":
            state_class = "error"
        elif status == "pending":
            state_class = "pending"
        else:
            state_class = "upcoming"
        
        fill_pct = 100 if state_class == "complete" else (intra * 100 if i == current_idx else 0)
        
        step_html.append(
            f"<div class='step-wrap'><div class='step {state_class}'>"
            f"<div class='fill' style='width:{fill_pct}%;'></div>"
            f"<span class='code'>{source}</span></div>"
            f"<div class='label'>{source}</div></div>"
        )
        if i < total - 1:
            connector_class = "connector complete" if state_class == "complete" else "connector"
            step_html.append(f"<div class='{connector_class}'></div>")
    
    # Get 1FA time for Start
    fa_status = statuses.get("1FA", {"time": None})
    fa_time = fa_status.get("time")
    
    if fa_time is not None:
        start_time = fa_time
        # ETA = 1FA time + (Total Systems * 30 min)
        eta_time = fa_time + timedelta(minutes=total * 30)
    else:
        start_time = now
        eta_time = now + timedelta(minutes=total * 30)
    
    # Elapsed = Passed systems * 30 min
    elapsed_min = passed_count * 30
    
    # Remaining = (Total - Passed) * 30 min
    remaining_min = (total - passed_count) * 30
    
    style = """
    <style>
    .tracker {display:flex;align-items:center;justify-content:center;margin:10px 0 30px;font-family:Segoe UI,Arial,sans-serif;}
    .step-wrap {display:flex;flex-direction:column;align-items:center;min-width:60px;}
    .step {position:relative;height:50px;width:60px;border-radius:30px;background:#e0e0e0;overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:600;color:#333;box-shadow:inset 0 0 4px rgba(0,0,0,0.15);}
    .step.active {background:#1f77b4;color:#fff;}
    .step.complete {background:#2ca02c;color:#fff;}
    .step.pending {background:#1f77b4;color:#fff;}
    .step.error {background:#d62728;color:#fff;animation:pulse 1s infinite;}
    .step.upcoming {background:#d9d9d9;color:#666;}
    .step .fill {position:absolute;left:0;top:0;height:100%;background:rgba(255,255,255,0.25);transition:width 0.6s ease;}
    .connector {height:8px;width:40px;background:#d9d9d9;border-radius:4px;margin:0 4px;box-shadow:inset 0 0 3px rgba(0,0,0,0.2);}
    .connector.complete {background:#2ca02c;}
    .label {margin-top:6px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:0.5px;}
    .smooth-track-wrapper {width:100%;display:flex;justify-content:center;position:relative;}
    .smooth-track {position:relative;width:92%;height:12px;background:#d9d9d9;border-radius:8px;overflow:hidden;margin:0 auto 18px auto;box-shadow:inset 0 0 4px rgba(0,0,0,0.25);}
    .smooth-track .bar {position:absolute;left:0;top:0;height:100%;background:linear-gradient(90deg,#1f77b4 0%, #2ca02c 85%);width:0%;transition:width 1.2s cubic-bezier(.25,.8,.25,1);box-shadow:0 0 4px rgba(0,0,0,0.2);}
    .time-label {position:absolute;font-size:11px;color:#666;font-weight:600;top:-20px;}
    .time-label.start {left:4%;}
    .time-label.eta {right:4%;}
    .progress-meta {text-align:center;font-size:12px;color:#444;margin-top:4px;}
    @keyframes pulse {0%{filter:brightness(1);}50%{filter:brightness(1.3);}100%{filter:brightness(1);}}
    @media (max-width:1100px){.step{width:46px;height:46px}.connector{width:28px} .label{font-size:9px}}
    </style>
    """
    
    bar_width_pct = f"{global_progress * 100:.3f}%"
    start_label = f"<div class='time-label start'>Start: {start_time.strftime('%H:%M')}</div>"
    eta_label = f"<div class='time-label eta'>ETA: {eta_time.strftime('%H:%M')}</div>"
    
    progress_note = (
        f"<div class='progress-meta'>Current Stage: <b>{DATA_SOURCE_FLOW[current_idx]}</b> &nbsp;\u2022&nbsp; "
        f"Stage Progress {intra * 100:.0f}% &nbsp;\u2022&nbsp; Overall {global_progress * 100:.1f}% &nbsp;\u2022&nbsp; "
        f"Elapsed {elapsed_min:.0f}m &nbsp;\u2022&nbsp; Remaining ~{remaining_min:.0f}m</div>"
    )
    
    smooth_track = f"<div class='smooth-track-wrapper'>{start_label}{eta_label}<div class='smooth-track'><div class='bar' style='width:{bar_width_pct};'></div></div></div>"
    html = style + smooth_track + "<div class='tracker'>" + "".join(step_html) + "</div>" + progress_note
    return html


# ------------------------------------------------------------------
# Legacy functions (keep existing ones)
# ------------------------------------------------------------------

def build_last_updated_table(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df[["system", "end_time"]]
        .rename(columns={"end_time": "last_updated"})
        .assign(last_updated=lambda d: d.last_updated.dt.strftime("%Y-%m-%d %H:%M:%S"))
    )


def fake_root_cause_panel() -> pd.DataFrame:
    data = {
        "Root Cause (Auto Detected)": [
            "Invalid configuration mapping for several tails",
            "Diagnostic parsing queue backlog",
            "Field data contract mismatch",
        ],
        "Current Disruptions": [
            "Missed SLA for 5 flights today",
            "Delayed health diagnostics (Avg +28 min)",
            "Customer support tickets raised",
        ],
        "Action & Governance": [
            "Engage process owner + data team",
            "Re-queue parsing; scale workers",
            "Track MTTR & prevent repeats",
        ],
    }
    return pd.DataFrame(data)


def build_error_notifications(df: pd.DataFrame, now: datetime) -> str:
    error_systems = df[df.status == "Error"]
    if len(error_systems) == 0:
        return ""

    team_map = {
        "1FA": "Product Configuration Team",
        "1FDI": "Data Integration Team",
        "PHM": "PHM Analytics Team",
        "FMX": "Customer Experience Team",
    }

    notifications_html = []
    for _, row in error_systems.iterrows():
        system = row.system
        team = team_map.get(system, "Operations Team")
        notification_time = row.start_time + timedelta(minutes=random.randint(2, 5))
        time_ago = (now - notification_time).total_seconds() / 60.0

        error_details = [
            f"System: {system}",
            f"Records Affected: {int(row.records):,}",
            f"Data Size: {row.data_size_mb:.2f} MB",
            f"Latency Spike: {row.latency_sec:.2f}s",
        ]

        details_list = "".join([f"<li>{d}</li>" for d in error_details])
        notif_time_str = notification_time.strftime("%Y-%m-%d %H:%M:%S")

        notifications_html.append(
            f"""<div class='error-notification'>
<div class='notif-header'>
<span class='notif-icon'> </span>
<span class='notif-title'>Error Alert: {system}</span>
</div>
<div class='notif-body'>
<div class='notif-row'><strong>Notified Team:</strong> {team}</div>
<div class='notif-row'><strong>Notification Sent:</strong> {notif_time_str} ({time_ago:.0f} min ago)</div>
<div class='notif-row'><strong>Error Details:</strong></div>
<ul class='notif-details'>{details_list}</ul>
<div class='notif-status'>Status: <span class='status-badge investigating'>Team Investigating</span></div>
</div>
</div>"""
        )

    style = """
    <style>
    .error-notification {border:2px solid #d62728;border-radius:12px;background:#fff5f5;padding:16px;margin:12px 0;font-family:Segoe UI,Arial,sans-serif;box-shadow:0 2px 8px rgba(214,39,40,0.15);}
    .notif-header {display:flex;align-items:center;gap:10px;margin-bottom:12px;border-bottom:1px solid #ffcccc;padding-bottom:8px;}
    .notif-icon {font-size:24px;}
    .notif-title {font-size:18px;font-weight:700;color:#d62728;}
    .notif-body {font-size:14px;color:#333;}
    .notif-row {margin:6px 0;}
    .notif-details {margin:8px 0;padding-left:20px;color:#555;}
    .notif-details li {margin:4px 0;}
    .notif-status {margin-top:12px;padding-top:8px;border-top:1px solid #ffcccc;font-weight:600;}
    .status-badge {display:inline-block;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:600;}
    .status-badge.investigating {background:#ff7f0e;color:#fff;}
    </style>
    """

    return style + "".join(notifications_html)


def build_diagnostic_error_notifications(
    engine_serial: str,
    diagnostic_tail: str,
    now: datetime = None,
    *,
    statuses: dict = None,
) -> str:
    """
    Build Error Notifications & Response Team Alerts based on DB diagnostic data.
    Shows alerts for failed systems.
    Loads from the statuses dict passed from the Overview tab (single SP call).
    """
    if now is None:
        now = datetime.utcnow()

    if statuses is None:
        statuses = {}

    # Filter for failed systems
    failed_systems = {
        source: info for source, info in statuses.items() 
        if info.get("status") == "fail"
    }
    
    if not failed_systems:
        return ""
    
    team_map = {
        "1FA": "Product Configuration Team",
        "1FDI": "Data Integration Team",
        "PHM": "PHM Analytics Team",
        "FMX": "Customer Experience Team",
    }
    
    notifications_html = []
    for source, info in failed_systems.items():
        team = team_map.get(source, "Operations Team")
        error_time = info.get("time")
        
        if error_time:
            notification_time = error_time + timedelta(minutes=random.randint(2, 5))
            time_ago = (now - notification_time).total_seconds() / 60.0
            notif_time_str = notification_time.strftime("%Y-%m-%d %H:%M:%S")
        else:
            time_ago = 0
            notif_time_str = "—"
        
        reason = info.get("message", "Unknown error")
        last_update = info.get("time_str", "—")
        
        # Build error notification card with inline styles for reliable rendering
        notifications_html.append(f"""
<div style="border: 2px solid #d62728; border-radius: 12px; background: #fff5f5; padding: 20px; margin: 16px 0; font-family: 'Segoe UI', Arial, sans-serif; box-shadow: 0 2px 8px rgba(214,39,40,0.15);">
    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px; border-bottom: 1px solid #ffcccc; padding-bottom: 10px;">
        <span style="font-size: 24px;">🚨</span>
        <span style="font-size: 18px; font-weight: 700; color: #d62728;">Error Alert: {source}</span>
    </div>
    <div style="font-size: 14px; color: #333;">
        <div style="margin: 8px 0;"><strong>Notified Team:</strong> {team}</div>
        <div style="margin: 8px 0;"><strong>Notification Sent:</strong> {notif_time_str} ({time_ago:.0f} min ago)</div>
        <div style="margin: 8px 0;"><strong>Error Details:</strong></div>
        <ul style="margin: 8px 0 8px 20px; padding-left: 0; color: #555;">
            <li style="margin: 4px 0;">System: {source}</li>
            <li style="margin: 4px 0;">Status: Failed</li>
            <li style="margin: 4px 0;">Reason: {reason}</li>
            <li style="margin: 4px 0;">Last Update: {last_update}</li>
        </ul>
        <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid #ffcccc; font-weight: 600;">
            Status: <span style="display: inline-block; padding: 4px 14px; border-radius: 12px; font-size: 12px; font-weight: 600; background: #ff7f0e; color: #fff;">Team Investigating</span>
        </div>
    </div>
</div>
""")
    
    return "".join(notifications_html)


# ------------------------------------------------------------------
# Timeline
# ------------------------------------------------------------------
def build_timeline(df: pd.DataFrame) -> go.Figure:
    df_sorted = df.sort_values("start_time")
    fig = px.timeline(
        df_sorted,
        x_start="start_time",
        x_end="end_time",
        y="system",
        color="status",
        hover_data=["latency_sec", "records", "data_size_mb"],
        title="Data Processing Timeline Across Systems",
        color_discrete_map=STATUS_COLOR_MAP,
    )
    fig.update_yaxes(autorange="reversed")
    return fig


@st.cache_data(ttl=CHART_CACHE_TTL, show_spinner=False)
def build_diagnostic_timeline(
    engine_serial: str,
    diagnostic_tail: str,
) -> go.Figure:
    """
    Build Gantt-style timeline chart using diagnostic data.

    Y-axis: Systems (1FA → 1FDI → PHM → FMX) from top to bottom
    X-axis: last_update_date timestamps
    Colors: Pass (green gradient), Fail (red gradient), Pending (amber gradient)
    """
    timeline_data = get_timeline_chart_data(engine_serial, diagnostic_tail)
    
    # Enterprise gradient colors for status
    status_colors = {
        "pass": "rgba(16, 185, 129, 0.9)",      # Emerald green
        "fail": "rgba(239, 68, 68, 0.9)",       # Red
        "pending": "rgba(245, 158, 11, 0.9)",   # Amber
    }
    
    # Find time range for chart
    valid_times = [d["last_update"] for d in timeline_data if d["last_update"] is not None]
    
    if not valid_times:
        # No data - return empty chart
        fig = go.Figure()
        fig.update_layout(
            title="Data Processing Timeline",
            xaxis_title="Last Update Time",
            yaxis_title="System",
            height=300,
            annotations=[{
                "text": "No data available",
                "xref": "paper", "yref": "paper",
                "x": 0.5, "y": 0.5, "showarrow": False,
                "font": {"size": 16, "color": "#666"}
            }]
        )
        return fig
    
    min_time = min(valid_times)
    max_time = max(valid_times)
    
    # Create bar segments - each system is a horizontal bar
    fig = go.Figure()
    
    # Systems in order (reversed for top-to-bottom display)
    systems_reversed = DATA_SOURCE_FLOW[::-1]
    
    for item in timeline_data:
        system = item["system"]
        status = item["status"]
        last_update = item["last_update"]
        message = item["message"]
        
        color = status_colors.get(status, status_colors["pending"])
        
        # Y position based on system order
        y_pos = systems_reversed.index(system)
        
        if last_update is not None:
            # Draw bar from min_time to last_update
            time_str = last_update.strftime("%Y-%m-%d %H:%M:%S")
            
            fig.add_trace(go.Bar(
                x=[last_update],
                y=[system],
                orientation="h",
                marker=dict(
                    color=color,
                    line=dict(color="rgba(0,0,0,0.2)", width=1),
                ),
                text=f"{status.upper()} - {time_str}",
                textposition="inside",
                textfont=dict(color="white", size=12, family="Arial Black"),
                hovertemplate=f"<b>{system}</b><br>Status: {status.upper()}<br>Time: {time_str}<br>{message}<extra></extra>",
                name=system,
                showlegend=False,
            ))
        else:
            # No data - show placeholder
            fig.add_trace(go.Bar(
                x=[0.1],  # Small bar
                y=[system],
                orientation="h",
                marker=dict(
                    color=color,
                    line=dict(color="rgba(0,0,0,0.2)", width=1),
                ),
                text=f"{status.upper()} - No Data",
                textposition="inside",
                textfont=dict(color="white", size=12, family="Arial Black"),
                hovertemplate=f"<b>{system}</b><br>Status: {status.upper()}<br>{message}<extra></extra>",
                name=system,
                showlegend=False,
            ))
    
    # Add legend traces
    for status_name, color in [("Pass", status_colors["pass"]), 
                                ("Fail", status_colors["fail"]), 
                                ("Pending", status_colors["pending"])]:
        fig.add_trace(go.Bar(
            x=[None], y=[None],
            marker=dict(color=color),
            name=status_name,
            showlegend=True,
        ))
    
    fig.update_layout(
        title=dict(
            text="Data Processing Timeline Across Systems",
            font=dict(size=18, color="#1e293b"),
        ),
        xaxis=dict(
            title="Last Update Date/Time",
            type="date",
            tickformat="%Y-%m-%d %H:%M",
            gridcolor="rgba(0,0,0,0.1)",
        ),
        yaxis=dict(
            title="System",
            categoryorder="array",
            categoryarray=DATA_SOURCE_FLOW,  # 1FA at top, FMX at bottom
        ),
        height=350,
        bargap=0.3,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1,
        ),
        margin=dict(l=80, r=40, t=80, b=60),
        plot_bgcolor="rgba(248,250,252,1)",
    )
    
    return fig


# ------------------------------------------------------------------
# Sankey / Network
# ------------------------------------------------------------------
def build_sankey(df: pd.DataFrame) -> go.Figure:
    sources, targets, values = [], [], []
    labels = SYSTEM_FLOW
    system_to_index = {s: i for i, s in enumerate(labels)}

    for i in range(len(SYSTEM_FLOW) - 1):
        s = SYSTEM_FLOW[i]
        t = SYSTEM_FLOW[i + 1]
        s_records = int(df.loc[df.system == s, "records"].iloc[0])
        sources.append(system_to_index[s])
        targets.append(system_to_index[t])
        values.append(s_records)

    colors = [
        "#4c78a8" if l in ASSET_SYSTEMS
        else "#f58518" if l in FLIGHT_SYSTEMS
        else "#2ca02c" if l in ENDPOINT_SYSTEMS
        else "#999999"
        for l in labels
    ]

    node = dict(pad=20, thickness=20, label=labels, color=colors)
    link = dict(source=sources, target=targets, value=values)
    fig = go.Figure(go.Sankey(node=node, link=link))
    fig.update_layout(title_text="Data Flow (Record Counts) Sankey", font_size=12)
    return fig


def build_network_graph(df: pd.DataFrame) -> go.Figure:
    G = nx.DiGraph()
    for system in SYSTEM_FLOW:
        status = df.loc[df.system == system, "status"].iloc[0]
        G.add_node(system, status=status)
    for i in range(len(SYSTEM_FLOW) - 1):
        G.add_edge(SYSTEM_FLOW[i], SYSTEM_FLOW[i + 1])

    pos = nx.spring_layout(G, seed=42)
    edge_x, edge_y = [], []
    for edge in G.edges():
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_x += [x0, x1, None]
        edge_y += [y0, y1, None]

    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=2, color="#888"),
        hoverinfo="none",
        mode="lines",
    )

    node_x, node_y, texts, colors = [], [], [], []
    for node, data in G.nodes(data=True):
        x, y = pos[node]
        node_x.append(x)
        node_y.append(y)
        status = data["status"]
        texts.append(f"{node}<br>Status: {status}")
        colors.append(STATUS_COLOR_MAP.get(status, "#1f77b4"))

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=[n for n in G.nodes()],
        textposition="bottom center",
        hovertext=texts,
        hoverinfo="text",
        marker=dict(showscale=False, color=colors, size=28, line=dict(width=2, color="white")),
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        title="System Path Network Graph",
        showlegend=False,
        margin=dict(l=20, r=20, t=50, b=20),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
    )
    return fig


@st.cache_data(ttl=CHART_CACHE_TTL, show_spinner=False)
def build_diagnostic_sankey(
    engine_serial: str,
    diagnostic_tail: str,
) -> go.Figure:
    """
    Build Sankey diagram using diagnostic data.
    Shows data flow: 1FA → 1FDI → PHM → FMX
    Node colors based on Pass/Fail/Pending status.
    """
    timeline_data = get_timeline_chart_data(engine_serial, diagnostic_tail)
    
    # Build status map
    status_map = {item["system"]: item["status"] for item in timeline_data}
    
    labels = DATA_SOURCE_FLOW  # ["1FA", "1FDI", "PHM", "FMX"]
    system_to_index = {s: i for i, s in enumerate(labels)}
    
    sources, targets, values, link_colors = [], [], [], []
    
    # Status colors for nodes - enterprise gradient-like solid colors
    status_color_map = {
        "pass": "#10b981",      # Emerald green
        "fail": "#ef4444",      # Red
        "pending": "#f59e0b",   # Amber
    }
    
    node_colors = []
    for source in labels:
        status = status_map.get(source, "pending")
        node_colors.append(status_color_map.get(status, "#94a3b8"))
    
    # Create links between consecutive systems
    for i in range(len(labels) - 1):
        s = labels[i]
        t = labels[i + 1]
        sources.append(system_to_index[s])
        targets.append(system_to_index[t])
        
        # Value represents flow - use 100 for better visual
        values.append(100)
        
        # Link color based on target status (shows flow health)
        tgt_status = status_map.get(t, "pending")
        if tgt_status == "pass":
            link_colors.append("rgba(16, 185, 129, 0.5)")
        elif tgt_status == "fail":
            link_colors.append("rgba(239, 68, 68, 0.5)")
        else:
            link_colors.append("rgba(245, 158, 11, 0.5)")
    
    node = dict(
        pad=30, 
        thickness=30, 
        label=labels, 
        color=node_colors,
        line=dict(color="rgba(255,255,255,0.8)", width=2),
    )
    link = dict(
        source=sources, 
        target=targets, 
        value=values,
        color=link_colors,
    )
    
    fig = go.Figure(go.Sankey(
        node=node, 
        link=link,
        arrangement="snap",
    ))
    fig.update_layout(
        title=dict(
            text="Data Flow (1FA → 1FDI → PHM → FMX)",
            font=dict(size=18, color="#1e293b", family="Arial Black"),
            x=0.5,
            xanchor="center",
        ),
        font=dict(size=14, color="#374151", family="Arial"),
        height=450,
        margin=dict(l=20, r=20, t=60, b=20),
        paper_bgcolor="rgba(248,250,252,1)",
    )
    return fig


@st.cache_data(ttl=CHART_CACHE_TTL, show_spinner=False)
def build_diagnostic_network_graph(
    engine_serial: str,
    diagnostic_tail: str,
) -> go.Figure:
    """
    Build Network Graph using diagnostic data.
    Shows system path: 1FA → 1FDI → PHM → FMX
    Node colors based on Pass/Fail/Pending status.
    Zigzag layout flowing from top-right to bottom-left.
    """
    timeline_data = get_timeline_chart_data(engine_serial, diagnostic_tail)
    
    # Build status and time map
    status_map = {item["system"]: item["status"] for item in timeline_data}
    time_map = {item["system"]: item["last_update"] for item in timeline_data}
    
    # Status colors - enterprise style
    status_color_map = {
        "pass": "#10b981",      # Emerald green
        "fail": "#ef4444",      # Red
        "pending": "#f59e0b",   # Amber
    }
    
    # Zigzag layout - flowing from top-right to bottom-left
    pos = {
        "1FA": (0.75, 0.85),
        "1FDI": (0.55, 0.60),
        "PHM": (0.35, 0.40),
        "FMX": (0.15, 0.15),
    }
    
    # Build nodes data
    node_x, node_y, texts, colors, node_labels = [], [], [], [], []
    for system in DATA_SOURCE_FLOW:
        x, y = pos[system]
        node_x.append(x)
        node_y.append(y)
        status = status_map.get(system, "pending")
        last_time = time_map.get(system)
        time_str = last_time.strftime("%Y-%m-%d %H:%M:%S") if last_time else "No data"
        texts.append(f"<b>{system}</b><br>Status: {status.upper()}<br>Last Update: {time_str}")
        colors.append(status_color_map.get(status, "#94a3b8"))
        node_labels.append(system)
    
    # Draw connecting lines between consecutive nodes
    edge_x, edge_y = [], []
    for i in range(len(DATA_SOURCE_FLOW) - 1):
        x0, y0 = pos[DATA_SOURCE_FLOW[i]]
        x1, y1 = pos[DATA_SOURCE_FLOW[i + 1]]
        edge_x += [x0, x1, None]
        edge_y += [y0, y1, None]
    
    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=2, color="#888888"),
        hoverinfo="none",
        mode="lines",
    )
    
    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=node_labels,
        textposition="bottom center",
        textfont=dict(size=11, color="#374151"),
        hovertext=texts,
        hoverinfo="text",
        marker=dict(
            showscale=False, 
            color=colors, 
            size=28, 
            line=dict(width=2, color="white"),
            symbol="circle",
        ),
    )
    
    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        title=dict(
            text="System Path Network Graph",
            font=dict(size=16, color="#1e293b"),
            x=0.5,
            xanchor="center",
        ),
        showlegend=False,
        margin=dict(l=20, r=20, t=50, b=20),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[0, 1]),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[0, 1]),
        height=450,
        paper_bgcolor="white",
        plot_bgcolor="white",
    )
    return fig


# ------------------------------------------------------------------
# Latency
# ------------------------------------------------------------------
def build_latency_chart(df: pd.DataFrame) -> go.Figure:
    fig = px.bar(
        df,
        x="system",
        y="latency_sec",
        color="status",
        title="Per-System Latency (seconds)",
        hover_data=["records", "data_size_mb"],
        color_discrete_map=STATUS_COLOR_MAP,
    )
    fig.update_layout(xaxis_title="System", yaxis_title="Latency (s)")
    return fig


# ------------------------------------------------------------------
# Freshness
# ------------------------------------------------------------------
def freshness_gauge(df: pd.DataFrame, now: datetime) -> go.Figure:
    last_end = df["end_time"].max()
    minutes_old = (now - last_end).total_seconds() / 60.0
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=minutes_old,
        delta={"reference": 60},
        gauge={
            "axis": {"range": [0, 180], "tickwidth": 1, "tickcolor": "#444"},
            "bar": {"color": "#4c78a8"},
            "steps": [
                {"range": [0, 60], "color": "#2ca02c"},
                {"range": [60, 120], "color": "#ff7f0e"},
                {"range": [120, 180], "color": "#d62728"},
            ],
            "threshold": {"line": {"color": "#d62728", "width": 4}, "thickness": 0.75, "value": 150},
        },
        title={"text": "Data Freshness (Minutes Since Last Completion)"},
    ))
    return fig


def build_simple_freshness_card(df: pd.DataFrame, now: datetime) -> str:
    last_end = df["end_time"].max()
    minutes_old = (now - last_end).total_seconds() / 60.0

    if minutes_old < 60:
        status, emoji, color, bg_color, message = "FRESH", " ", "#2ca02c", "#e8f5e9", "Data is current"
    elif minutes_old < 120:
        status, emoji, color, bg_color, message = "AGING", " ", "#ff7f0e", "#fff8e1", "Check for delays"
    else:
        status, emoji, color, bg_color, message = "STALE", " ", "#d62728", "#ffebee", "Needs attention"

    last_update_str = last_end.strftime("%H:%M:%S")

    html = f"""
    <style>
    .freshness-card {{
        background: linear-gradient(135deg, {bg_color} 0%, #ffffff 100%);
        border: 3px solid {color};
        border-radius: 16px;
        padding: 32px;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        font-family: 'Segoe UI', Arial, sans-serif;
    }}
    .fresh-emoji {{font-size: 72px; margin: 16px 0;}}
    .fresh-status {{font-size: 42px; font-weight: 800; color: {color}; margin: 8px 0;}}
    .fresh-time {{font-size: 64px; font-weight: 700; color: #333; margin: 16px 0;}}
    .fresh-label {{font-size: 18px; color: #666; margin: 8px 0;}}
    .fresh-message {{font-size: 20px; color: {color}; font-weight: 600; margin-top: 16px;}}
    .fresh-detail {{font-size: 14px; color: #777; margin-top: 12px;}}
    </style>
    <div class='freshness-card'>
        <div class='fresh-emoji'>{emoji}</div>
        <div class='fresh-status'>{status}</div>
        <div class='fresh-time'>{int(minutes_old)} min</div>
        <div class='fresh-label'>Since Last Completion</div>
        <div class='fresh-message'>{message}</div>
        <div class='fresh-detail'>Last updated at {last_update_str}</div>
    </div>
    """
    return html


def build_freshness_timeline(df: pd.DataFrame, now: datetime) -> go.Figure:
    last_end = df["end_time"].max()
    minutes_old = (now - last_end).total_seconds() / 60.0

    fig = go.Figure()

    fig.add_shape(type="rect", x0=0, x1=60, y0=0, y1=1, fillcolor="#2ca02c", opacity=0.3, line=dict(width=0))
    fig.add_shape(type="rect", x0=60, x1=120, y0=0, y1=1, fillcolor="#ff7f0e", opacity=0.3, line=dict(width=0))
    fig.add_shape(type="rect", x0=120, x1=180, y0=0, y1=1, fillcolor="#d62728", opacity=0.3, line=dict(width=0))

    fig.add_annotation(x=30, y=0.8, text="FRESH", showarrow=False, font=dict(size=16, color="#2ca02c", weight="bold"))
    fig.add_annotation(x=90, y=0.8, text="AGING", showarrow=False, font=dict(size=16, color="#ff7f0e", weight="bold"))
    fig.add_annotation(x=150, y=0.8, text="STALE", showarrow=False, font=dict(size=16, color="#d62728", weight="bold"))

    marker_x = min(minutes_old, 180)
    fig.add_shape(type="line", x0=marker_x, x1=marker_x, y0=0, y1=1, line=dict(color="#000", width=4))
    fig.add_annotation(
        x=marker_x, y=0.5, text=f"{int(minutes_old)} min",
        showarrow=True, arrowhead=2, arrowsize=1, arrowwidth=2, arrowcolor="#000",
        font=dict(size=18, color="#000", weight="bold"),
        bgcolor="#fff", bordercolor="#000", borderwidth=2, borderpad=8,
    )

    fig.update_xaxes(title="Minutes Since Last Completion", range=[0, 180])
    fig.update_yaxes(visible=False, range=[0, 1])
    fig.update_layout(title="Data Freshness Timeline", height=250, margin=dict(l=20, r=20, t=50, b=60))
    return fig


# ------------------------------------------------------------------
# SLA / Tracker visualizations
# ------------------------------------------------------------------
def build_sla_bar(df: pd.DataFrame, now: datetime, hours: float = 3.0) -> go.Figure:
    start = now - timedelta(hours=hours)
    segments = []
    for _, row in df.iterrows():
        seg_start = row.start_time
        seg_end = row.end_time
        pct_start = (seg_start - start).total_seconds() / (hours * 3600)
        pct_end = (seg_end - start).total_seconds() / (hours * 3600)
        mapped = classify_status(row.status)
        color = {"Pass": "#2ca02c", "Fail": "#d62728", "Pending": "#1f77b4", "Processing": "#1f77b4"}[mapped]
        segments.append((pct_start, pct_end, mapped, color, row.system))

    fig = go.Figure()
    for s in segments:
        x0, x1 = s[0], s[1]
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0, y1=1, fillcolor=s[3], line=dict(width=0))
        fig.add_annotation(x=(x0 + x1) / 2, y=0.5, text=s[4], showarrow=False, font=dict(color="white", size=11))

    fig.update_xaxes(showticklabels=False, range=[0, 1])
    fig.update_yaxes(showticklabels=False, range=[0, 1])
    fig.update_layout(title="SLA 3-Hour Window (System Segments)", height=120, margin=dict(l=10, r=10, t=40, b=10))
    return fig


def build_rich_sla_timeline(df: pd.DataFrame, now: datetime, hours: float = 3.0) -> go.Figure:
    start = now - timedelta(hours=hours)
    total_seconds = hours * 3600

    fig = go.Figure()

    segments = int(hours * 4)
    for i in range(segments):
        seg_start = start + timedelta(minutes=15 * i)
        seg_end = seg_start + timedelta(minutes=15)
        x0 = (seg_start - start).total_seconds() / total_seconds
        x1 = (seg_end - start).total_seconds() / total_seconds
        shade = "#f8f9fa" if i % 2 == 0 else "#eef3f8"
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0, y1=0.4, fillcolor=shade, line=dict(width=0))
        if seg_start.minute == 0:
            fig.add_annotation(x=x0 + 0.002, y=0.42, text=seg_start.strftime("%H:%M"), showarrow=False, font=dict(size=11, color="#444"), align="left")

    color_map = {"Pass": "#2ca02c", "Fail": "#d62728", "Pending": "#1f77b4", "Processing": "#1f77b4"}
    icon_map = {}
    for s in SYSTEM_FLOW:
        if s in ASSET_SYSTEMS:
            icon_map[s] = " "
        elif s in FLIGHT_SYSTEMS:
            icon_map[s] = " "
        elif s in ENDPOINT_SYSTEMS:
            icon_map[s] = " "
        else:
            icon_map[s] = " "

    for _, row in df.iterrows():
        mapped = classify_status(row.status)
        color = color_map[mapped]
        x0 = (row.start_time - start).total_seconds() / total_seconds
        x1 = (row.end_time - start).total_seconds() / total_seconds
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0.05, y1=0.35, fillcolor=color, line=dict(color="white", width=2))
        mid = (x0 + x1) / 2
        fig.add_annotation(x=mid, y=0.20, text=f"{icon_map[row.system]} {row.system}", showarrow=False, font=dict(color="white", size=12))

    now_x = (now - start).total_seconds() / total_seconds
    fig.add_shape(type="line", x0=now_x, x1=now_x, y0=0, y1=0.4, line=dict(color="#ff005e", width=3, dash="dot"))
    fig.add_annotation(x=now_x, y=0.47, text="Now", showarrow=True, arrowhead=2, arrowcolor="#ff005e")

    final_end = df.loc[df.system == SYSTEM_FLOW[-1], "end_time"].iloc[0]
    eta_x = (final_end - start).total_seconds() / total_seconds
    fig.add_annotation(x=eta_x, y=-0.07, text="ETA " + final_end.strftime("%H:%M"), showarrow=False, font=dict(size=12, color="#2ca02c"))

    fig.update_xaxes(visible=False, range=[0, 1])
    fig.update_yaxes(visible=False, range=[0, 0.5])
    fig.update_layout(title="SLA Timeline (Rich View)", height=240, margin=dict(l=10, r=10, t=60, b=20), plot_bgcolor="#ffffff")
    return fig


def build_rich_sla_timeline_improved(df: pd.DataFrame, now: datetime, hours: float = 3.0) -> go.Figure:
    start = now - timedelta(hours=hours)
    total_seconds = hours * 3600
    color_map = {"Pass": "#2ca02c", "Fail": "#d62728", "Pending": "#1f77b4", "Processing": "#1f77b4"}
    icon_map = {s: (" " if s in ASSET_SYSTEMS else " " if s in FLIGHT_SYSTEMS else " ") for s in SYSTEM_FLOW}

    fig = go.Figure()

    bands = int(hours * 2)
    for i in range(bands):
        band_start = start + timedelta(minutes=30 * i)
        band_end = band_start + timedelta(minutes=30)
        x0 = (band_start - start).total_seconds() / total_seconds
        x1 = (band_end - start).total_seconds() / total_seconds
        shade = "#f5f7fa" if i % 2 == 0 else "#e9eef3"
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0, y1=0.5, fillcolor=shade, line=dict(width=0))
        if band_start.minute == 0:
            fig.add_annotation(x=x0 + 0.002, y=0.53, text=band_start.strftime("%H:%M"), showarrow=False, font=dict(size=10, color="#555"))

    hover_x, hover_y, hover_texts = [], [], []
    for _, row in df.iterrows():
        mapped = classify_status(row.status)
        color = color_map[mapped]
        x0 = (row.start_time - start).total_seconds() / total_seconds
        x1 = (row.end_time - start).total_seconds() / total_seconds
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0.08, y1=0.42, fillcolor=color, opacity=0.92, line=dict(color="white", width=2))
        mid = (x0 + x1) / 2
        label = f"{icon_map[row.system]} {row.system}"
        fig.add_annotation(x=mid, y=0.25, text=label, showarrow=False, font=dict(color="white", size=13))
        if row.status in {"Delayed", "Error"}:
            badge_color = "#ffbf00" if row.status == "Delayed" else "#d62728"
            fig.add_annotation(x=mid, y=0.07, text=row.status, showarrow=False, font=dict(size=10, color="white"), bgcolor=badge_color)
        dur_min = (row.end_time - row.start_time).total_seconds() / 60.0
        hover_x.append(mid)
        hover_y.append(0.3)
        hover_texts.append(
            f"<b>{row.system}</b><br>Status: {row.status}<br>Start: {row.start_time.strftime('%H:%M:%S')}<br>End: {row.end_time.strftime('%H:%M:%S')}<br>Duration: {dur_min:.1f} min<br>Latency: {row.latency_sec:.2f}s"
        )

    fig.add_trace(go.Scatter(
        x=hover_x, y=hover_y, mode="markers",
        marker=dict(size=8, color="rgba(0,0,0,0)"),
        hovertemplate="%{text}", text=hover_texts, showlegend=False,
    ))

    now_x = (now - start).total_seconds() / total_seconds
    fig.add_shape(type="line", x0=now_x, x1=now_x, y0=0, y1=0.5, line=dict(color="#ff005e", width=3, dash="dot"))
    fig.add_annotation(x=now_x, y=0.57, text="Now", showarrow=True, arrowhead=2, arrowcolor="#ff005e")

    final_end = df.loc[df.system == SYSTEM_FLOW[-1], "end_time"].iloc[0]
    eta_x = (final_end - start).total_seconds() / total_seconds
    fig.add_annotation(x=eta_x, y=-0.06, text="ETA " + final_end.strftime("%H:%M"), showarrow=False, font=dict(size=12, color="#2ca02c"))

    fig.update_xaxes(visible=False, range=[0, 1])
    fig.update_yaxes(visible=False, range=[0, 0.6])
    fig.update_layout(title="SLA Timeline (Enhanced)", height=260, margin=dict(l=10, r=10, t=65, b=30), plot_bgcolor="#ffffff")
    return fig


def build_dominos_style_tracker_html(df: pd.DataFrame, now: datetime) -> str:
    ordered = df.sort_values("start_time")
    current_idx = 0
    for i, row in ordered.iterrows():
        if row.status != "Complete":
            current_idx = i
            break
        current_idx = i

    row = ordered.iloc[current_idx]
    span = (row.end_time - row.start_time).total_seconds()
    intra = 0.0
    if span > 0:
        intra = min(1.0, max(0.0, (now - row.start_time).total_seconds() / span))
    total = len(SYSTEM_FLOW)
    global_progress = (current_idx + intra) / total

    step_html = []
    for i, r in ordered.iterrows():
        status = r.status
        if status == "Complete":
            state_class = "complete"
        elif status in {"Error"}:
            state_class = "error"
        elif status in {"Delayed", "Pending"}:
            state_class = "pending"
        elif status == "NotStarted":
            state_class = "upcoming"
        elif i == current_idx:
            state_class = "active"
        else:
            state_class = "upcoming"
        fill_pct = 100 if state_class in {"complete"} else (intra * 100 if i == current_idx else 0)
        step_html.append(
            f"<div class='step-wrap'><div class='step {state_class}'>"
            f"<div class='fill' style='width:{fill_pct}%;'></div>"
            f"<span class='code'>{r.system}</span></div>"
            f"<div class='label'>{r.system}</div></div>"
        )
        if i < total - 1:
            connector_class = "connector complete" if state_class == "complete" else "connector"
            step_html.append(f"<div class='{connector_class}'></div>")

    start_time = df["start_time"].min()
    end_time = df["end_time"].max()
    elapsed_min = (now - start_time).total_seconds() / 60.0
    remaining_min = max(0, (end_time - now).total_seconds() / 60.0)

    style = """
    <style>
    .tracker {display:flex;align-items:center;justify-content:center;margin:10px 0 30px;font-family:Segoe UI,Arial,sans-serif;}
    .step-wrap {display:flex;flex-direction:column;align-items:center;min-width:60px;}
    .step {position:relative;height:50px;width:60px;border-radius:30px;background:#e0e0e0;overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:600;color:#333;box-shadow:inset 0 0 4px rgba(0,0,0,0.15);}
    .step.active {background:#1f77b4;color:#fff;}
    .step.complete {background:#2ca02c;color:#fff;}
    .step.pending {background:#1f77b4;color:#fff;}
    .step.error {background:#d62728;color:#fff;animation:pulse 1s infinite;}
    .step.upcoming {background:#d9d9d9;color:#666;}
    .step .fill {position:absolute;left:0;top:0;height:100%;background:rgba(255,255,255,0.25);transition:width 0.6s ease;}
    .connector {height:8px;width:40px;background:#d9d9d9;border-radius:4px;margin:0 4px;box-shadow:inset 0 0 3px rgba(0,0,0,0.2);}
    .connector.complete {background:#2ca02c;}
    .label {margin-top:6px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:0.5px;}
    .smooth-track-wrapper {width:100%;display:flex;justify-content:center;position:relative;}
    .smooth-track {position:relative;width:92%;height:12px;background:#d9d9d9;border-radius:8px;overflow:hidden;margin:0 auto 18px auto;box-shadow:inset 0 0 4px rgba(0,0,0,0.25);}
    .smooth-track .bar {position:absolute;left:0;top:0;height:100%;background:linear-gradient(90deg,#1f77b4 0%, #2ca02c 85%);width:0%;transition:width 1.2s cubic-bezier(.25,.8,.25,1);box-shadow:0 0 4px rgba(0,0,0,0.2);}
    .time-label {position:absolute;font-size:11px;color:#666;font-weight:600;top:-20px;}
    .time-label.start {left:4%;}
    .time-label.eta {right:4%;}
    .progress-meta {text-align:center;font-size:12px;color:#444;margin-top:4px;}
    @keyframes pulse {0%{filter:brightness(1);}50%{filter:brightness(1.3);}100%{filter:brightness(1);}}
    @media (max-width:1100px){.step{width:46px;height:46px}.connector{width:28px} .label{font-size:9px}}
    </style>
    """
    bar_width_pct = f"{global_progress * 100:.3f}%"
    start_label = f"<div class='time-label start'>Start: {start_time.strftime('%H:%M')}</div>"
    eta_label = f"<div class='time-label eta'>ETA: {end_time.strftime('%H:%M')}</div>"
    progress_note = (
        f"<div class='progress-meta'>Current Stage: <b>{row.system}</b> &nbsp;\u2022&nbsp; "
        f"Stage Progress {intra * 100:.0f}% &nbsp;\u2022&nbsp; Overall {global_progress * 100:.1f}% &nbsp;\u2022&nbsp; "
        f"Elapsed {elapsed_min:.0f}m &nbsp;\u2022&nbsp; Remaining ~{remaining_min:.0f}m</div>"
    )
    smooth_track = f"<div class='smooth-track-wrapper'>{start_label}{eta_label}<div class='smooth-track'><div class='bar' style='width:{bar_width_pct};'></div></div></div>"
    html = style + smooth_track + "<div class='tracker'>" + "".join(step_html) + "</div>" + progress_note
    return html


def build_sla_dominos_html(df: pd.DataFrame, now: datetime, hours: float = 3.0) -> str:
    last_end = df.end_time.max()
    freshness_min = (now - last_end).total_seconds() / 60.0
    freshness_state = "ok" if freshness_min < 60 else ("risk" if freshness_min < 120 else "fail")

    segments_html = []
    for i, row in df.iterrows():
        status = row.status
        if status == "Complete":
            cls = "pass"
        elif status == "Error":
            cls = "fail"
        elif status in {"Delayed", "Pending"}:
            cls = "pending"
        elif status == "NotStarted":
            cls = "upcoming"
        else:
            cls = "processing"
        icon = " " if row.system in ASSET_SYSTEMS else (" " if row.system in FLIGHT_SYSTEMS else " ")
        segments_html.append(
            f"<div class='sla-segment {cls}' style='flex:1'>"
            f"<div class='inner'><span>{icon} {row.system}</span><small>{row.status}</small></div></div>"
        )
        if i < len(df) - 1:
            segments_html.append("<div class='sla-gap'></div>")

    style = """
    <style>
    .sla-bar {display:flex;align-items:stretch;gap:6px;margin:12px 0;font-family:Segoe UI,Arial,sans-serif;}
    .sla-segment {position:relative;background:#d9d9d9;border-radius:14px;min-height:70px;display:flex;align-items:center;justify-content:center;box-shadow:inset 0 0 4px rgba(0,0,0,0.15);}
    .sla-segment.pass {background:linear-gradient(135deg,#2ca02c,#45c842);}
    .sla-segment.processing {background:linear-gradient(135deg,#1f77b4,#3a92d0);}
    .sla-segment.pending {background:linear-gradient(135deg,#1f77b4,#3a92d0);}
    .sla-segment.fail {background:linear-gradient(135deg,#d62728,#f04141);}
    .sla-segment.upcoming {background:#d9d9d9;color:#666;}
    .sla-segment .inner {text-align:center;color:#fff;font-weight:600;font-size:15px;}
    .sla-segment .inner small {display:block;font-size:11px;font-weight:500;opacity:0.85;}
    .sla-gap {width:10px;height:8px;background:#e0e0e0;border-radius:4px;align-self:center;box-shadow:inset 0 0 3px rgba(0,0,0,0.2);}
    .freshness-pill {display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;color:#fff;margin-top:4px;}
    .freshness-pill.ok {background:#2ca02c;} .freshness-pill.risk {background:#ffbf00;color:#222;} .freshness-pill.fail {background:#d62728;}
    </style>
    """
    freshness_label = f"Freshness {freshness_min:.0f}m" + (" (OK)" if freshness_state == "ok" else " (Risk)" if freshness_state == "risk" else " (Late)")
    pill = f"<div class='freshness-pill {freshness_state}'>{freshness_label}</div>"
    html = style + "<div class='sla-bar'>" + "".join(segments_html) + "</div>" + pill
    return html


# ------------------------------------------------------------------
# Pizza tracker variants
# ------------------------------------------------------------------
def compute_truck_progress(df: pd.DataFrame, now: datetime) -> float:
    first_start = df.start_time.min()
    last_end = df.end_time.max()
    if now <= first_start:
        return 0.0
    if now >= last_end:
        return 1.0
    for i, row in df.sort_values("start_time").iterrows():
        if row.start_time <= now <= row.end_time:
            idx = SYSTEM_FLOW.index(row.system)
            span = (row.end_time - row.start_time).total_seconds()
            local = (now - row.start_time).total_seconds() / span if span > 0 else 0
            return (idx + local) / len(SYSTEM_FLOW)
    sorted_df = df.sort_values("start_time")
    for i in range(len(sorted_df) - 1):
        a = sorted_df.iloc[i]
        b = sorted_df.iloc[i + 1]
        if a.end_time < now < b.start_time:
            idx = SYSTEM_FLOW.index(b.system)
            return idx / len(SYSTEM_FLOW)
    return 0.0


def build_pizza_tracker_animated(df: pd.DataFrame, progress: float) -> go.Figure:
    total = len(SYSTEM_FLOW)
    fig = go.Figure()
    for i, system in enumerate(SYSTEM_FLOW):
        x0 = i / total
        x1 = (i + 1) / total
        status = df.loc[df.system == system, "status"].iloc[0]
        if status == "Complete":
            color = STATUS_COLOR_MAP["Complete"]
        elif status == "Error":
            color = STATUS_COLOR_MAP["Error"]
        elif status in {"Delayed", "Pending", "Processing"}:
            color = STATUS_COLOR_MAP["Processing"]
        else:
            color = STATUS_COLOR_MAP["NotStarted"]
        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0, y1=1, fillcolor=color, line=dict(color="white", width=2))
        font_color = "white" if color not in {"#d9d9d9"} else "black"
        fig.add_annotation(x=(x0 + x1) / 2, y=0.5, text=system, showarrow=False, font=dict(color=font_color, size=12))

    truck_x = progress
    fig.add_annotation(x=truck_x, y=1.15, text=" ", showarrow=False, font=dict(size=26))
    fig.add_annotation(x=0.5, y=1.28, text=("Delivered to FMX" if progress >= 0.999 else "In Transit to FMX"), showarrow=False, font=dict(size=12))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(title="Pizza Tracker: Data Journey Stages", height=170, margin=dict(l=10, r=10, t=55, b=10))
    return fig


def build_pizza_tracker(df: pd.DataFrame) -> go.Figure:
    completed = []
    current = None
    for _, row in df.iterrows():
        if row.status == "Complete":
            completed.append(row.system)
        elif current is None:
            current = row.system
    if current is None:
        current = "FMX"

    fig = go.Figure()
    total = len(SYSTEM_FLOW)
    for i, system in enumerate(SYSTEM_FLOW):
        x0 = i / total
        x1 = (i + 1) / total
        status = df.loc[df.system == system, "status"].iloc[0] if system in df.system.values else "Complete"
        if system in completed and system != current:
            color = "#2ca02c"
        elif system == current:
            if status in {"Delayed", "Pending"}:
                color = "#ffbf00"
            elif status == "Error":
                color = "#d62728"
            else:
                color = "#1f77b4"
        else:
            color = "#d9d9d9"

        fig.add_shape(type="rect", x0=x0, x1=x1, y0=0, y1=1, fillcolor=color, line=dict(color="white", width=2))
        fig.add_annotation(x=(x0 + x1) / 2, y=0.5, text=system, showarrow=False, font=dict(color="black", size=12))

    if set(completed) == set(SYSTEM_FLOW[:-1]) and df.loc[df.system == SYSTEM_FLOW[-1], "status"].iloc[0] == "Complete":
        fig.add_annotation(x=0.5, y=1.15, text=" Delivered to FMX", showarrow=False, font=dict(size=14))
    else:
        fig.add_annotation(x=0.5, y=1.15, text=" In Transit to FMX", showarrow=False, font=dict(size=14))

    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    fig.update_layout(title="Pizza Tracker: Data Journey Stages", height=160, margin=dict(l=10, r=10, t=50, b=10))
    return fig


# ------------------------------------------------------------------
# Data Elements heatmap
# ------------------------------------------------------------------
@st.cache_data(ttl=CHART_CACHE_TTL, show_spinner=False)
def build_data_elements_heatmap(
    df: pd.DataFrame,
    engine_serial: str,
    tail_number: str,
    matrix_data: dict = None
) -> str:
    """
    Build HTML table for Data Elements matrix.
    
    Args:
        df: DataFrame with system data (legacy, kept for compatibility)
        engine_serial: ESN for lookup
        tail_number: Diagnostic tail for lookup
        matrix_data: Optional pre-computed matrix from get_data_elements_matrix()
    
    Returns:
        HTML string with styled table
    """
    # Use provided matrix or fall back to simulation
    if matrix_data is None:
        # Legacy fallback
        from utils.data_simulation import simulate_data_elements_with_values
        data = simulate_data_elements_with_values(df, engine_serial, tail_number)
        systems = list(data.keys())
        properties = DATA_ELEMENTS
        use_legacy = True
    else:
        systems = matrix_data["systems"]
        properties = matrix_data["properties"]
        matrix = matrix_data["matrix"]
        use_legacy = False

    style = """
    <style>
    .elem-table {font-family: Segoe UI, Arial, sans-serif; border-collapse: collapse; width: 100%; font-size: 11px;}
    .elem-table th, .elem-table td {border: 1px solid #e2e8f0; padding: 8px 10px;}
    .elem-table thead th {background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%); color:#fff; position: sticky; top:0; z-index:1; font-weight:600; text-transform: uppercase; letter-spacing: 0.5px; font-size: 10px;}
    .elem-pass {background:#e3f9e5; color:#1a7f2b; text-align:center; cursor:pointer; position:relative;}
    .elem-fail {background:#ffe5e0; color:#a31d12; text-align:center; cursor:pointer; position:relative;}
    .elem-name {white-space: nowrap; font-weight:600; color:#333; background:#f8f9fa;}
    .elem-caption {font-size:13px; color:#666; margin:8px 0 12px; font-weight:600;}
    .elem-cell-value {display:block; font-weight:600; font-size:12px;}
    .elem-cell-status {display:block; font-size:10px; opacity:0.8;}
    .elem-table td:hover {filter: brightness(0.95);}
    </style>
    """

    header = "<tr><th>Property</th>" + "".join([f"<th>{s}</th>" for s in systems]) + "<th>Expected</th></tr>"
    rows = []

    for prop in properties:
        cells = [f"<td class='elem-name'>{prop}</td>"]
        
        if use_legacy:
            # Legacy format: data[system][element]
            expected_val = None
            for system in systems:
                elem_data = data[system].get(prop, {"status": "Fail", "value": "NULL", "reason": "Missing", "expected": "—"})
                status = elem_data["status"]
                value = elem_data["value"]
                reason = elem_data["reason"]
                expected_val = elem_data["expected"]
                
                cls = "elem-pass" if status == "Pass" else "elem-fail"
                tooltip = f'title="Value: {value}{"&#10;Reason: " + reason if reason else ""}"'
                cells.append(f"<td class='{cls}' {tooltip}><span class='elem-cell-value'>{value}</span><span class='elem-cell-status'>{status}</span></td>")
        else:
            # New format: matrix[property][system]
            prop_data = matrix.get(prop, {})
            expected_val = prop_data.get("expected", "—")
            
            for system in systems:
                cell = prop_data.get(system, {"value": "NULL", "status": "Fail", "reason": "Missing"})
                status = cell["status"]
                value = cell["value"]
                reason = cell.get("reason", "")
                
                cls = "elem-pass" if status == "Pass" else "elem-fail"
                tooltip = f'title="Value: {value}{"&#10;Reason: " + reason if reason else ""}"'
                cells.append(f"<td class='{cls}' {tooltip}><span class='elem-cell-value'>{value}</span><span class='elem-cell-status'>{status}</span></td>")

        cells.append(f"<td style='background:#f0f0f0; text-align:center; font-weight:600; color:#555;'>{expected_val}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")

    html = (
        style
        + "<div class='elem-caption'> Data Elements Tracking \u2014 Hover over cells to see values and failure reasons</div>"
        + f"<table class='elem-table'><thead>{header}</thead><tbody>{''.join(rows)}</tbody></table>"
    )
    return html


def build_data_elements_heatmap_v2(df: pd.DataFrame) -> str:
    """
    Build HTML heatmap table from the pivoted DataFrame returned by
    sp_get_data_elements_matrix_v2.

    Column order: ESN, Property, 1FA, 1FDI, PHM, FMX, Expected.
    Tail column is not shown.  ESN is always visible; the value is
    printed only on the first row of each ESN block (subsequent rows
    show an empty cell) to give a clean grouped-row appearance.
    """
    if df.empty:
        return "<p style='color:#888;'>No data available.</p>"

    system_pairs = [
        ("1FA",  "fa_value",  "fa_status"),
        ("1FDI", "fdi_value", "fdi_status"),
        ("PHM",  "phm_value", "phm_status"),
        ("FMX",  "fmx_value", "fmx_status"),
    ]

    style = """
    <style>
    .ev2-table {font-family: Segoe UI, Arial, sans-serif; border-collapse: collapse; width: 100%; font-size: 11px;}
    .ev2-table th, .ev2-table td {border: 1px solid #e2e8f0; padding: 7px 10px;}
    .ev2-table thead th {background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%); color:#fff; position: sticky; top:0; z-index:1; font-weight:600; text-transform: uppercase; letter-spacing: 0.5px; font-size: 10px;}
    .ev2-pass {background:#e3f9e5; color:#1a7f2b; text-align:center; cursor:pointer;}
    .ev2-fail {background:#ffe5e0; color:#a31d12; text-align:center; cursor:pointer;}
    .ev2-na   {background:#f5f5f5; color:#999; text-align:center;}
    .ev2-name {white-space: nowrap; font-weight:600; color:#333; background:#f8f9fa;}
    .ev2-esn  {font-weight:700; color:#1e3a5f; background:#eef3f8; white-space:nowrap; vertical-align:top;}
    .ev2-val  {display:block; font-weight:600; font-size:12px;}
    .ev2-sts  {display:block; font-size:10px; opacity:0.8;}
    .ev2-table td:hover {filter: brightness(0.95);}
    .ev2-caption {font-size:13px; color:#666; margin:8px 0 12px; font-weight:600;}
    </style>
    """

    # Header: ESN | Property | 1FA | 1FDI | PHM | FMX | Expected
    header_cells = "<th>ESN</th><th>Property</th>"
    for sys_name, _, _ in system_pairs:
        header_cells += f"<th>{sys_name}</th>"
    header_cells += "<th>Expected</th>"
    header = f"<tr>{header_cells}</tr>"

    # Body rows — ESN value shown only on the first row of each ESN group
    prev_esn = None
    rows_html = []
    for _, row in df.iterrows():
        cells = ""
        current_esn = str(row.get("esn", ""))
        if current_esn != prev_esn:
            cells += f"<td class='ev2-esn'>{current_esn}</td>"
            prev_esn = current_esn
        else:
            cells += "<td class='ev2-esn'></td>"

        cells += f"<td class='ev2-name'>{row.get('property_name', '')}</td>"

        for sys_name, val_col, sts_col in system_pairs:
            val = str(row.get(val_col, "--"))
            sts = str(row.get(sts_col, "--"))

            if sts == "Pass":
                cls = "ev2-pass"
            elif sts == "Fail":
                cls = "ev2-fail"
            else:
                cls = "ev2-na"
                val = "--"
                sts = ""

            tooltip = f'title="{sys_name}: {val}"' if val != "--" else ""
            sts_span = f"<span class='ev2-sts'>{sts}</span>" if sts else ""
            cells += f"<td class='{cls}' {tooltip}><span class='ev2-val'>{val}</span>{sts_span}</td>"

        expected = str(row.get("expected", "\u2014"))
        cells += f"<td style='background:#f0f0f0; text-align:center; font-weight:600; color:#555;'>{expected}</td>"

        rows_html.append(f"<tr>{cells}</tr>")

    esn_count = df["esn"].nunique() if "esn" in df.columns else 1
    caption = f"Data Elements Matrix \u2014 {esn_count} ESN(s)"
    html = (
        style
        + f"<div class='ev2-caption'>{caption} \u2014 Hover over cells to see values</div>"
        + f"<table class='ev2-table'><thead>{header}</thead><tbody>{''.join(rows_html)}</tbody></table>"
    )
    return html


# ------------------------------------------------------------------
# Architecture / Roadmap diagrams (unused in tabs but preserved)
# ------------------------------------------------------------------
def build_value_proposition_diagram():
    fig = go.Figure()

    metrics = [
        ("MTTD", 120, 8, "min"),
        ("MTTR", 180, 25, "min"),
        ("SLA Compliance", 82, 98, "%"),
        ("Monthly Incidents", 45, 9, ""),
    ]

    y_pos = 0.85
    for metric, before, after, unit in metrics:
        if "%" in unit:
            norm_before = before / 100
            norm_after = after / 100
        elif "min" in unit:
            norm_before = before / 200
            norm_after = after / 200
        else:
            norm_before = before / 50
            norm_after = after / 50

        fig.add_shape(type="rect", x0=0.20, x1=0.20 + norm_before, y0=y_pos - 0.025, y1=y_pos + 0.025, fillcolor="#ffcccc", line=dict(color="#d62728", width=2))
        fig.add_annotation(x=0.10, y=y_pos, text=f"<b>{metric}</b>", showarrow=False, font=dict(size=11), xanchor="right")
        fig.add_annotation(x=0.20 + norm_before + 0.03, y=y_pos, text=f"Before: {before}{unit}", showarrow=False, font=dict(size=9, color="#d62728"), xanchor="left")

        fig.add_shape(type="rect", x0=0.20, x1=0.20 + norm_after, y0=y_pos - 0.075, y1=y_pos - 0.025, fillcolor="#ccffcc", line=dict(color="#2ca02c", width=2))
        fig.add_annotation(x=0.20 + norm_after + 0.03, y=y_pos - 0.05, text=f"After: {after}{unit}", showarrow=False, font=dict(size=9, color="#2ca02c"), xanchor="left")

        y_pos -= 0.18

    fig.add_shape(type="rect", x0=0.70, x1=0.75, y0=0.90, y1=0.95, fillcolor="#ffcccc", line=dict(color="#d62728", width=1))
    fig.add_annotation(x=0.78, y=0.925, text=" Before", showarrow=False, font=dict(size=10), xanchor="left")
    fig.add_shape(type="rect", x0=0.70, x1=0.75, y0=0.83, y1=0.88, fillcolor="#ccffcc", line=dict(color="#2ca02c", width=1))
    fig.add_annotation(x=0.78, y=0.855, text=" After", showarrow=False, font=dict(size=10), xanchor="left")

    fig.update_xaxes(visible=False, range=[0, 1])
    fig.update_yaxes(visible=False, range=[0, 1])
    fig.update_layout(title="<b>Business Impact Metrics</b>", height=350, margin=dict(l=10, r=10, t=50, b=10), plot_bgcolor="white")
    return fig


def build_feature_roadmap_visual():
    fig = go.Figure()

    phases = [
        {"name": "Phase 0\nImmediate", "x": 0.15, "features": ["Dashboard", "Alerts", "Lookup"], "color": "#2ca02c"},
        {"name": "Phase 1\nFoundation", "x": 0.40, "features": ["Event Bus", "Auto Alerts", "Time-Series DB"], "color": "#1f77b4"},
        {"name": "Phase 2\nIntelligence", "x": 0.65, "features": ["ML Anomaly", "Predictive SLA", "Root Cause"], "color": "#ff7f0e"},
        {"name": "Phase 3\nScale", "x": 0.90, "features": ["NLP", "Mobile", "Auto-Fix"], "color": "#9467bd"},
    ]

    for phase in phases:
        fig.add_shape(type="rect", x0=phase["x"] - 0.10, x1=phase["x"] + 0.10, y0=0.65, y1=0.85, fillcolor=phase["color"], line=dict(color="white", width=2))
        fig.add_annotation(x=phase["x"], y=0.75, text=f"<b>{phase['name']}</b>", showarrow=False, font=dict(color="white", size=10))

        y_feat = 0.55
        for feat in phase["features"]:
            fig.add_annotation(x=phase["x"], y=y_feat, text=f"\u2022 {feat}", showarrow=False, font=dict(size=8, color="#333"))
            y_feat -= 0.08

    fig.add_shape(type="line", x0=0.05, x1=0.95, y0=0.40, y1=0.40, line=dict(color="#999", width=3))
    fig.add_annotation(x=0.95, y=0.40, ax=0.90, ay=0.40, axref="x", ayref="y", xref="x", yref="y", showarrow=True, arrowhead=2, arrowsize=2, arrowwidth=3, arrowcolor="#999")
    fig.add_annotation(x=0.50, y=0.32, text="<b>2026 Roadmap Timeline \u2192</b>", showarrow=False, font=dict(size=12, color="#666"))

    fig.update_xaxes(visible=False, range=[0, 1])
    fig.update_yaxes(visible=False, range=[0, 1])
    fig.update_layout(title="<b>Implementation Phases</b>", height=350, margin=dict(l=10, r=10, t=50, b=10), plot_bgcolor="white")
    return fig


def build_architecture_diagram() -> go.Figure:
    fig = go.Figure()

    fig.add_annotation(x=5, y=6.8, text="<b>GE Aerospace Data Observability Framework</b>", showarrow=False, font=dict(size=20, color="#003366"))
    fig.add_annotation(x=5, y=6.5, text="<i>Use Case: Asset + Flight Diagnostic Data Pipeline</i>", showarrow=False, font=dict(size=12, color="#666"))

    fig.add_annotation(x=1, y=6.2, text="<b>Data Pipeline Flow</b>", showarrow=False, font=dict(size=14, color="#1f77b4"))

    systems = [
        ("1FA", "Product Config", " "), ("IFS", "Asset Reference", " "),
        ("FDM", "Flight Data", " "), ("1FDI", "Data Integration", " "),
        ("PHM", "Health Analytics", " "), ("SOAR", "Ops Awareness", " "),
        ("RDF", "Reporting", " "), ("FMX", "Customer Portal", " "),
    ]

    for i, (code, name, icon) in enumerate(systems):
        y = 5.5 - (i * 0.65)
        fig.add_shape(type="rect", x0=0.3, x1=1.7, y0=y - 0.25, y1=y + 0.25, fillcolor="#1f77b4", opacity=0.7, line=dict(color="white", width=2))
        fig.add_annotation(x=1, y=y + 0.05, text=f"<b>{icon} {code}</b>", showarrow=False, font=dict(size=11, color="white"))
        fig.add_annotation(x=1, y=y - 0.1, text=name, showarrow=False, font=dict(size=8, color="white"))
        if i < len(systems) - 1:
            fig.add_annotation(x=1, y=y - 0.25, ax=1, ay=y - 0.4, showarrow=True, arrowhead=2, arrowsize=1, arrowwidth=2, arrowcolor="#1f77b4")

    fig.add_shape(type="rect", x0=2.5, x1=7.5, y0=0.8, y1=5.8, fillcolor="#f0f8ff", opacity=0.3, line=dict(color="#2ca02c", width=3, dash="dash"))
    fig.add_annotation(x=5, y=5.9, text="<b> Observability Platform (The Framework)</b>", showarrow=False, font=dict(size=14, color="#2ca02c"))

    fig.add_shape(type="rect", x0=2.7, x1=7.3, y0=4.8, y1=5.6, fillcolor="#ff7f0e", opacity=0.2, line=dict(color="#ff7f0e", width=2))
    fig.add_annotation(x=3.2, y=5.4, text="<b>Event Capture</b>", showarrow=False, font=dict(size=11, color="#ff7f0e"), xanchor="left")
    instruments = [" Emitters", " Metadata", " Tracing", " Timestamps"]
    for i, item in enumerate(instruments):
        fig.add_annotation(x=3 + i * 1.2, y=5, text=item, showarrow=False, font=dict(size=9, color="#333"))

    fig.add_shape(type="rect", x0=2.7, x1=7.3, y0=3.9, y1=4.6, fillcolor="#2ca02c", opacity=0.2, line=dict(color="#2ca02c", width=2))
    fig.add_annotation(x=5, y=4.4, text="<b>Event Bus</b>", showarrow=False, font=dict(size=12, color="#2ca02c"))
    fig.add_annotation(x=5, y=4.1, text="Kafka / Azure Event Hub", showarrow=False, font=dict(size=9, color="#666"))

    fig.add_shape(type="rect", x0=2.7, x1=7.3, y0=2.7, y1=3.7, fillcolor="#9467bd", opacity=0.2, line=dict(color="#9467bd", width=2))
    fig.add_annotation(x=3.2, y=3.5, text="<b>Data Processing</b>", showarrow=False, font=dict(size=11, color="#9467bd"), xanchor="left")
    processing = [("Time-Series DB", "3.5"), ("State Machine", "4.5"), ("Anomaly Detection", "5.5"), ("Data Quality", "6.5")]
    for item, x in processing:
        fig.add_shape(type="rect", x0=float(x) - 0.35, x1=float(x) + 0.35, y0=2.9, y1=3.25, fillcolor="#9467bd", opacity=0.6, line=dict(color="white", width=1))
        fig.add_annotation(x=float(x), y=3.07, text=item, showarrow=False, font=dict(size=8, color="white"))

    fig.add_shape(type="rect", x0=2.7, x1=7.3, y0=1.5, y1=2.5, fillcolor="#17becf", opacity=0.2, line=dict(color="#17becf", width=2))
    fig.add_annotation(x=3.2, y=2.3, text="<b>Applications</b>", showarrow=False, font=dict(size=11, color="#17becf"), xanchor="left")
    apps = [(" Dashboard", "3.3"), (" Alerts", "4.3"), (" APIs", "5.3"), (" Reports", "6.3")]
    for item, x in apps:
        fig.add_shape(type="rect", x0=float(x) - 0.4, x1=float(x) + 0.4, y0=1.7, y1=2.1, fillcolor="#17becf", opacity=0.7, line=dict(color="white", width=1))
        fig.add_annotation(x=float(x), y=1.9, text=item, showarrow=False, font=dict(size=9, color="white"))

    fig.add_annotation(x=9, y=6.2, text="<b>Stakeholders & Outputs</b>", showarrow=False, font=dict(size=14, color="#d62728"))
    stakeholders = [
        (" Business Analysts", "SLA Reports", 5.7), (" Data Engineers", "Pipeline Health", 5.0),
        (" System Owners", "Error Alerts", 4.3), (" Fleet Operations", "Data Freshness", 3.6),
        (" Customers (Airlines)", "Reliable Insights", 2.9),
    ]
    for role, output, y in stakeholders:
        fig.add_shape(type="rect", x0=8.2, x1=9.8, y0=y - 0.25, y1=y + 0.25, fillcolor="#d62728", opacity=0.15, line=dict(color="#d62728", width=1))
        fig.add_annotation(x=9, y=y + 0.08, text=f"<b>{role}</b>", showarrow=False, font=dict(size=9, color="#333"))
        fig.add_annotation(x=9, y=y - 0.1, text=output, showarrow=False, font=dict(size=8, color="#666"))

    for i in range(4):
        y_sys = 5.5 - (i * 1.3)
        fig.add_annotation(x=1.7, y=y_sys, ax=2.7, ay=5.2, showarrow=True, arrowhead=2, arrowsize=0.8, arrowwidth=1.5, arrowcolor="#999")
    fig.add_annotation(x=5, y=3.9, ax=5, ay=3.7, showarrow=True, arrowhead=2, arrowsize=1.5, arrowwidth=2.5, arrowcolor="#2ca02c")
    fig.add_annotation(x=5, y=2.7, ax=5, ay=2.5, showarrow=True, arrowhead=2, arrowsize=1.5, arrowwidth=2.5, arrowcolor="#9467bd")
    for i in range(3):
        fig.add_annotation(x=7.3, y=2 - i * 0.3, ax=8.2, ay=4.5 - i * 0.8, showarrow=True, arrowhead=2, arrowsize=0.8, arrowwidth=1.5, arrowcolor="#999")

    fig.add_shape(type="rect", x0=0.5, x1=9.5, y0=0.3, y1=1.2, fillcolor="#f9f9f9", opacity=0.9, line=dict(color="#999", width=1))
    fig.add_annotation(x=5, y=1.05, text="<b> Key Benefits:</b> Proactive Issue Detection \u2022 Real-Time SLA Monitoring \u2022 Automated Team Alerts \u2022 End-to-End Data Lineage \u2022 90% Faster MTTD", showarrow=False, font=dict(size=10, color="#003366"))
    fig.add_annotation(x=5, y=0.5, text="<b> Reusable Framework:</b> Designed for Asset + Flight use case \u2022 Extensible to Supply Chain, MRO, Quality, Finance pipelines", showarrow=False, font=dict(size=9, color="#666"))

    fig.update_xaxes(visible=False, range=[0, 10])
    fig.update_yaxes(visible=False, range=[0, 7])
    fig.update_layout(height=700, margin=dict(l=10, r=10, t=10, b=10), plot_bgcolor="white", paper_bgcolor="white")
    return fig


def build_data_flow_diagram() -> go.Figure:
    fig = go.Figure()

    systems = ["1FA", "IFS", "FDM", "1FDI", "PHM", "SOAR", "RDF", "FMX"]
    num_systems = len(systems)

    for i, system in enumerate(systems):
        x = i * 1.5
        fig.add_shape(type="rect", x0=x - 0.4, x1=x + 0.4, y0=2.7, y1=3.3, fillcolor="#1f77b4", opacity=0.8, line=dict(color="white", width=2))
        fig.add_annotation(x=x, y=3, text=f"<b>{system}</b>", showarrow=False, font=dict(size=11, color="white"))
        fig.add_shape(type="circle", x0=x - 0.15, x1=x + 0.15, y0=2.15, y1=2.45, fillcolor="#ff7f0e", opacity=0.9, line=dict(color="white", width=1))
        fig.add_annotation(x=x, y=2.3, text=" ", showarrow=False, font=dict(size=14))
        fig.add_annotation(x=x, y=2.15, ax=x, ay=1.5, xref="x", yref="y", axref="x", ayref="y", showarrow=True, arrowhead=2, arrowsize=1, arrowwidth=1.5, arrowcolor="#999")
        if i < num_systems - 1:
            fig.add_annotation(x=x + 0.4, y=3, ax=x + 1.1, ay=3, xref="x", yref="y", axref="x", ayref="y", showarrow=True, arrowhead=2, arrowsize=1.2, arrowwidth=2, arrowcolor="#1f77b4")

    fig.add_shape(type="rect", x0=-0.5, x1=10.5, y0=1.2, y1=1.8, fillcolor="#2ca02c", opacity=0.3, line=dict(color="#2ca02c", width=2))
    fig.add_annotation(x=5, y=1.5, text="<b>Event Bus (Kafka / Azure Event Hub)</b>", showarrow=False, font=dict(size=12, color="#2ca02c"))

    platform_components = ["Time-Series DB", "State Machine", "Alert Engine", "Dashboard API"]
    for i, comp in enumerate(platform_components):
        x = 1.5 + i * 2.5
        fig.add_shape(type="rect", x0=x - 0.6, x1=x + 0.6, y0=0.3, y1=0.7, fillcolor="#d62728", opacity=0.7, line=dict(color="white", width=2))
        fig.add_annotation(x=x, y=0.5, text=comp, showarrow=False, font=dict(size=9, color="white"))
        fig.add_annotation(x=x, y=1.2, ax=x, ay=0.7, xref="x", yref="y", axref="x", ayref="y", showarrow=True, arrowhead=2, arrowsize=1, arrowwidth=1.5, arrowcolor="#666")

    fig.add_annotation(x=5, y=3.8, text="<b>Data Pipeline Flow \u2192</b>", showarrow=False, font=dict(size=14, color="#333"))
    fig.add_annotation(x=5, y=0, text="<b>Observability Platform</b>", showarrow=False, font=dict(size=12, color="#d62728"))

    fig.update_xaxes(visible=False, range=[-1, 11])
    fig.update_yaxes(visible=False, range=[-0.2, 4])
    fig.update_layout(title="End-to-End Data Flow with Observability Instrumentation", height=450, margin=dict(l=20, r=20, t=60, b=20), plot_bgcolor="white")
    return fig


def build_roadmap_timeline() -> go.Figure:
    phases = [
        {"name": "Phase 1: Pilot", "start": "2026-01", "end": "2026-03", "color": "#4c78a8", "deliverables": "3 systems, Basic dashboard, Manual alerts"},
        {"name": "Phase 2: Production MVP", "start": "2026-04", "end": "2026-06", "color": "#f58518", "deliverables": "8 systems, Auto alerts, SLA monitoring, APIs"},
        {"name": "Phase 3: Scale & Enhance", "start": "2026-07", "end": "2026-12", "color": "#2ca02c", "deliverables": "ML anomaly detection, 3+ use cases, Data lineage"},
    ]

    fig = go.Figure()

    for i, phase in enumerate(phases):
        y = 3 - i
        fig.add_shape(type="rect", x0=0, x1=12, y0=y - 0.35, y1=y + 0.35, fillcolor=phase["color"], opacity=0.3, line=dict(color=phase["color"], width=2))
        fig.add_annotation(x=-0.5, y=y, text=f"<b>{phase['name']}</b>", showarrow=False, font=dict(size=12, color=phase["color"]), xanchor="right")
        fig.add_annotation(x=6, y=y, text=phase["deliverables"], showarrow=False, font=dict(size=10, color="#333"))
        start_month = int(phase["start"].split("-")[1])
        end_month = int(phase["end"].split("-")[1])
        fig.add_shape(type="rect", x0=start_month - 0.3, x1=end_month + 0.3, y0=y - 0.15, y1=y + 0.15, fillcolor=phase["color"], opacity=0.9, line=dict(color="white", width=2))

    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    for i, month in enumerate(months):
        fig.add_annotation(x=i + 1, y=3.8, text=month, showarrow=False, font=dict(size=10, color="#666"))

    fig.update_xaxes(visible=False, range=[-2, 13])
    fig.update_yaxes(visible=False, range=[1, 4.2])
    fig.update_layout(title="Implementation Roadmap - 2026", height=350, margin=dict(l=180, r=20, t=60, b=20), plot_bgcolor="white")
    return fig
