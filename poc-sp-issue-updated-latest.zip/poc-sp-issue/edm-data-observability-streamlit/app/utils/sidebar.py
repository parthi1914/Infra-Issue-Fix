import os
import sys
# Ensure project root is in sys.path for module resolution
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)
import streamlit as st
from datetime import datetime

from app.services.lookup_service import (
    get_engine_serials,
    get_tail_numbers,
    get_tails_for_engine,
    get_engines_for_tail,
    get_operator_codes_for_esn,
    get_operator_codes_for_tail,
)
from app.services.event_service import get_events


def setup_sidebar():
    """
    Setup sidebar filters with dynamic dropdown loading.

    Mandatory fields:
    -----------------
    Engine Serial (ESN) is the only required field.
    Tail Number and Operator Code are optional.

    Modes:
    ------
    1. "Use custom input instead" (checked):
       - Text inputs for ESN (required), Tail Number (optional), Operator Code (optional).

    2. "Engine Serial (ESN)" selected (default dropdown mode):
       - ESN dropdown loaded from DB (required).
       - Tail Number dropdown filtered by ESN (optional).
       - Operator Code dropdown filtered by ESN (optional).

    3. "Tail Number" selected:
       - Tail dropdown loaded from DB.
       - ESN dropdown filtered by tail (required).
       - Operator Code dropdown filtered by tail (optional).

    Rerun strategy (prevents duplicate widget renders):
    ---------------------------------------------------
    • Full Clear  → _clear_requested flag  → st.rerun() from button handler
                    processed at the very top of the NEXT run, before ANY
                    widget is created → clean single render.
    • Mode switch → _mode_switch_requested flag → st.rerun() called
                    immediately after ONLY the checkbox is rendered (no
                    buttons exist yet in that run) → no duplicate buttons.
    • Analyze     → state set inline; Streamlit's button-click auto-rerun
                    carries the new state → no explicit rerun needed.
    """

    # =================================================================
    # PHASE 1 — Pre-render state management
    # Handled BEFORE any interactive widget is created so Streamlit's
    # delta queue never has a stale partial render to reconcile.
    # =================================================================

    # ------------------------------------------------------------------
    # 1a. Full clear (triggered by Clear button in previous run)
    # ------------------------------------------------------------------
    if st.session_state.pop("_clear_requested", False):
        st.session_state.engine_serial = ""
        st.session_state.tail_number = ""
        st.session_state.operator_code = ""
        st.session_state.custom_esn_value = ""
        st.session_state.custom_tail_value = ""
        st.session_state.custom_operator_value = ""
        st.session_state.use_custom_input = False
        st.session_state._data_submitted = False
        st.session_state._prev_use_custom = None
        st.session_state._prev_selection_method = None
        for key in [
            "esn_dropdown", "tail_dropdown",
            "tail_for_esn_dropdown", "esn_for_tail_dropdown",
            "operator_for_esn_dropdown", "operator_for_tail_dropdown",
            "selection_method",
        ]:
            st.session_state.pop(key, None)

    # ------------------------------------------------------------------
    # 1b. Mode switch (checkbox toggled in previous run)
    #     Only clears data — preserves the new use_custom_input value.
    # ------------------------------------------------------------------
    if st.session_state.pop("_mode_switch_requested", False):
        st.session_state.engine_serial = ""
        st.session_state.tail_number = ""
        st.session_state.operator_code = ""
        st.session_state.custom_esn_value = ""
        st.session_state.custom_tail_value = ""
        st.session_state.custom_operator_value = ""
        st.session_state._data_submitted = False
        for key in [
            "esn_dropdown", "tail_dropdown",
            "tail_for_esn_dropdown", "esn_for_tail_dropdown",
            "operator_for_esn_dropdown", "operator_for_tail_dropdown",
        ]:
            st.session_state.pop(key, None)

    # =================================================================
    # PHASE 2 — Render the sidebar UI
    # =================================================================

    st.sidebar.header("Filters")

    # ------------------------------------------------------------------
    # Enterprise Button & Widget Styling
    # ------------------------------------------------------------------
    st.sidebar.markdown("""
    <style>
    [data-testid="stSidebar"] .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white !important;
        border: none !important;
        border-radius: 8px;
        font-weight: 600;
        padding: 0.6rem 1rem;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        transition: all 0.3s ease;
        width: 100%;
    }
    [data-testid="stSidebar"] .stButton > button:hover {
        background: linear-gradient(135deg, #5a6fd6 0%, #6a4190 100%);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        transform: translateY(-2px);
    }
    [data-testid="stSidebar"] .stButton > button:active { transform: translateY(0); }
    [data-testid="stSidebar"] .stSelectbox > div > div {
        background: linear-gradient(180deg, #ffffff 0%, #f8f9fa 100%);
        border: 1.5px solid #e0e5ec;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        transition: all 0.2s ease;
    }
    [data-testid="stSidebar"] .stSelectbox > div > div:hover {
        border-color: #667eea;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
    }
    [data-testid="stSidebar"] .stSelectbox label {
        font-weight: 600; color: #374151;
        font-size: 0.9rem; margin-bottom: 4px;
    }
    .search-hint {
        font-size: 11px; color: #667eea; font-style: italic;
        margin-top: -8px; margin-bottom: 12px;
        display: flex; align-items: center; gap: 4px;
    }
    </style>
    """, unsafe_allow_html=True)

    st.sidebar.subheader("Identifiers")

    # ------------------------------------------------------------------
    # Checkbox — rendered first so the mode-switch rerun fires BEFORE
    # any other interactive widgets are drawn.
    # ------------------------------------------------------------------
    prev_custom = st.session_state.get("_prev_use_custom", None)
    prev_selection_method = st.session_state.get("_prev_selection_method", None)

    custom_values = st.sidebar.checkbox(
        "Use custom input instead",
        key="use_custom_input",
    )

    # *** Mode-switch detection — MUST happen immediately after checkbox, ***
    # *** before any other widget is rendered.                              ***
    # Calling st.rerun() here is safe: only the checkbox has been rendered
    # so far, so the browser has no button deltas to double-render.
    if prev_custom is not None and prev_custom != custom_values:
        st.session_state._prev_use_custom = custom_values   # persist new value
        st.session_state._mode_switch_requested = True
        st.rerun()  # triggers Phase 1b on the next run → clean state + render

    st.session_state._prev_use_custom = custom_values

    # ------------------------------------------------------------------
    # Initialise local variables
    # ------------------------------------------------------------------
    engine_serial = ""
    tail_number = ""
    operator_code = ""

    # =================================================================
    # PHASE 2a — Mode-specific input widgets
    # =================================================================

    if custom_values:
        # --------------------------------------------------------------
        # Custom Input Mode
        # --------------------------------------------------------------
        engine_serial = st.sidebar.text_input(
            "Engine Serial *",
            value=st.session_state.get("custom_esn_value", ""),
            key="custom_esn_input",
            help="Enter ESN manually (Required)",
        )
        tail_number = st.sidebar.text_input(
            "Tail Number",
            value=st.session_state.get("custom_tail_value", ""),
            key="custom_tail_input",
            help="Enter Tail Number manually (Optional)",
            placeholder="Leave blank to search across all tails",
        )
        operator_code = st.sidebar.text_input(
            "Operator Code",
            value=st.session_state.get("custom_operator_value", ""),
            key="custom_operator_input",
            help="Enter Operator Code manually (Optional)",
            placeholder="Leave blank for no operator filter",
        )

        # Persist custom values for the next render
        st.session_state.custom_esn_value = engine_serial
        st.session_state.custom_tail_value = tail_number
        st.session_state.custom_operator_value = operator_code

    else:
        # --------------------------------------------------------------
        # Dropdown Selection Mode
        # --------------------------------------------------------------
        selection_method = st.sidebar.radio(
            "Select by:",
            ["Engine Serial (ESN)", "Tail Number"],
            horizontal=True,
            key="selection_method",
        )

        # Detect radio button change — clear data state without rerun
        if prev_selection_method is not None and prev_selection_method != selection_method:
            st.session_state.engine_serial = ""
            st.session_state.tail_number = ""
            st.session_state.operator_code = ""
            st.session_state._data_submitted = False

        st.session_state._prev_selection_method = selection_method

        if selection_method == "Engine Serial (ESN)":
            # ESN required; Tail & Operator optional
            engine_serials = get_engine_serials()
            if not engine_serials:
                engine_serials = []
                st.sidebar.warning("No ESNs found in database")

            engine_serial = st.sidebar.selectbox(
                "Engine Serial *",
                options=engine_serials,
                index=0,
                key="esn_dropdown",
                help="Required — type to search",
            )
            st.sidebar.markdown(
                "<div class='search-hint'>🔍 Type to filter options</div>",
                unsafe_allow_html=True,
            )

            available_tails = get_tails_for_engine(engine_serial) if engine_serial else []
            tail_number = st.sidebar.selectbox(
                "Tail Number (Optional)",
                options=[""] + (available_tails or []),
                index=0,
                key="tail_for_esn_dropdown",
                help="Leave blank to query all tails for this ESN",
            )
            st.sidebar.markdown(
                "<div class='search-hint'>🔍 Type to filter options</div>",
                unsafe_allow_html=True,
            )

            available_operators = get_operator_codes_for_esn(engine_serial) if engine_serial else []
            operator_code = st.sidebar.selectbox(
                "Operator Code (Optional)",
                options=[""] + (available_operators or []),
                index=0,
                key="operator_for_esn_dropdown",
                help="Leave blank for no operator filter",
            )
            st.sidebar.markdown(
                "<div class='search-hint'>🔍 Type to filter options</div>",
                unsafe_allow_html=True,
            )

        else:
            # Tail drives ESN list; ESN required; Operator optional
            tail_numbers = get_tail_numbers()
            if not tail_numbers:
                tail_numbers = []
                st.sidebar.warning("No Tail Numbers found in database")

            tail_number = st.sidebar.selectbox(
                "Tail Number *",
                options=tail_numbers,
                index=0,
                key="tail_dropdown",
                help="Required — type to search",
            )
            st.sidebar.markdown(
                "<div class='search-hint'>🔍 Type to filter options</div>",
                unsafe_allow_html=True,
            )

            available_esns = get_engines_for_tail(tail_number) if tail_number else []
            engine_serial = st.sidebar.selectbox(
                "Engine Serial * (on this aircraft)",
                options=available_esns or [],
                index=0,
                key="esn_for_tail_dropdown",
                help="Required — type to search",
            )
            st.sidebar.markdown(
                "<div class='search-hint'>🔍 Type to filter options</div>",
                unsafe_allow_html=True,
            )

            available_operators = get_operator_codes_for_tail(tail_number) if tail_number else []
            operator_code = st.sidebar.selectbox(
                "Operator Code (Optional)",
                options=[""] + (available_operators or []),
                index=0,
                key="operator_for_tail_dropdown",
                help="Leave blank for no operator filter",
            )
            st.sidebar.markdown(
                "<div class='search-hint'>🔍 Type to filter options</div>",
                unsafe_allow_html=True,
            )

    # ------------------------------------------------------------------
    # Mandatory field indicator
    # ------------------------------------------------------------------
    st.sidebar.markdown(
        "<small style='color:#888;'>* Engine Serial is required &nbsp;|&nbsp; "
        "Tail Number &amp; Operator Code are optional</small>",
        unsafe_allow_html=True,
    )

    # =================================================================
    # PHASE 3 — Action buttons
    # Rendered exactly once, outside all conditional branches.
    # =================================================================
    st.sidebar.markdown("---")
    st.sidebar.markdown("""
    <style>
    [data-testid="stSidebar"] .row-widget.stButton { width: 100%; }
    </style>
    """, unsafe_allow_html=True)

    btn_col1, btn_col2 = st.sidebar.columns([1, 1])

    with btn_col1:
        submit_clicked = st.button(
            "🚀 Analyze", key="submit_filters_btn", use_container_width=True
        )
    with btn_col2:
        clear_clicked = st.button(
            "🗑️ Clear", key="clear_filters_btn", use_container_width=True
        )

    # ------------------------------------------------------------------
    # Clear handler
    # Sets the flag, then calls st.rerun() so that Phase 1a processes
    # the flag at the very top of the NEXT run — before any widget is
    # created — giving a single, fully-clean render with no old data.
    # ------------------------------------------------------------------
    if clear_clicked:
        st.session_state._clear_requested = True
        st.rerun()

    # ------------------------------------------------------------------
    # Submit handler
    # Validates and sets session state inline. No explicit st.rerun()
    # needed: Streamlit's button-click auto-rerun carries the updated
    # state into every subsequent tab renderer in the same script pass.
    # ------------------------------------------------------------------
    if submit_clicked:
        if not engine_serial or not engine_serial.strip():
            st.sidebar.error("⚠️ Engine Serial is required")
        else:
            st.session_state._data_submitted = True
            st.session_state.engine_serial = engine_serial.strip()
            st.session_state.tail_number = (tail_number or "").strip()
            st.session_state.operator_code = (operator_code or "").strip()

    # =================================================================
    # PHASE 4 — Persist filter values for all tab renderers
    # =================================================================
    now = datetime.utcnow()
    window_hours = 3.0
    variation = "Normal"

    submitted = st.session_state.get("_data_submitted", False)

    if submitted:
        df = get_events(engine_serial, tail_number, now, hours=window_hours, variation=variation)
    else:
        df = None

    st.session_state.df = df
    st.session_state.engine_serial = engine_serial if submitted else ""
    st.session_state.tail_number = tail_number if submitted else ""
    st.session_state.operator_code = operator_code if submitted else ""
    st.session_state.now = now
    st.session_state.window_hours = window_hours
