"""
Data Element Service
====================
Fetches and validates data elements across systems (1FA, 1FDI, PHM, FMX).

Performance:
------------
- All matrix logic (unpivot, validation, expected-value) runs inside
  the PostgreSQL stored procedure `sp_get_data_elements_matrix`.
- Python only maps the flat result set into the dict structure the UI expects.
- Fallback to simulation if DB unavailable.
"""

import logging
import pandas as pd
import streamlit as st
from datetime import datetime

from services.db import is_db_available, run_query

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
ENABLE_CACHE = True
CACHE_TTL_SECONDS = 60

SYSTEMS = ["1FA", "1FDI", "PHM", "FMX"]

DISPLAY_PROPERTIES = [
    "ESN",
    "Diagnostic Installation Date",
    "Diagnostic Tail",
    "Engine Position",
    "Installation Date",
    "Last Updated Date",
    "N1 Modifier",
    "Operator",
    "Monitor",
    "Operator Diagnostic Code",
    "Tail Number Aircraft ID",
    "Engine Model",
    "Engine Type",
    "Engine Family Model Series",
    "Aircraft Delivery Date",
    "Aircraft Family",
    "Aircraft Model",
    "Aircraft Series",
    "Installation History",
]

# Keep for legacy callers
COLUMN_TO_PROPERTY = {
    "esn": "ESN",
    "diagnostic_installation_date": "Diagnostic Installation Date",
    "diagnostic_tail": "Diagnostic Tail",
    "engine_position": "Engine Position",
    "installation_date": "Installation Date",
    "last_update_date": "Last Updated Date",
    "n1_modifier": "N1 Modifier",
    "operator": "Operator",
    "monitor": "Monitor",
    "operator_diagnostic_code": "Operator Diagnostic Code",
    "tail_number_aircraft_id": "Tail Number Aircraft ID",
    "engine_model": "Engine Model",
    "engine_type": "Engine Type",
    "engine_family_model_series": "Engine Family Model Series",
    "aircraft_delivery_date": "Aircraft Delivery Date",
    "aircraft_family": "Aircraft Family",
    "aircraft_model": "Aircraft Model",
    "aircraft_series": "Aircraft Series",
    "installation_history": "Installation History",
}
PROPERTY_TO_COLUMN = {v: k for k, v in COLUMN_TO_PROPERTY.items()}


# ---------------------------------------------------------------------------
# Configurable Cache Decorator
# ---------------------------------------------------------------------------
def conditional_cache(func):
    """Apply Streamlit cache only if ENABLE_CACHE is True."""
    if ENABLE_CACHE:
        return st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)(func)
    return func


# ---------------------------------------------------------------------------
# Stored Procedure Query
# ---------------------------------------------------------------------------
@conditional_cache
def _call_sp_matrix(esn: str, tail: str) -> pd.DataFrame:
    """
    Call the stored procedure and return the flat result set.

    Columns returned: property_name, system_name, actual_value, expected,
                      status, reason
    """
    sql = "SELECT * FROM sp_get_data_elements_matrix(:esn, :tail)"
    log.info("Calling sp_get_data_elements_matrix(ESN=%s, Tail=%s)", esn, tail)
    result = run_query(sql, {"esn": esn, "tail": tail})
    log.info("SP returned %d rows", len(result) if result is not None else 0)
    return result


# ---------------------------------------------------------------------------
# Map SP rows → dict structure expected by the UI
# ---------------------------------------------------------------------------
def _build_matrix_from_sp(rows: pd.DataFrame) -> dict:
    """
    Convert the flat SP result into the nested dict the UI layer consumes.

    Returns the same structure as before:
        {
            "properties": [...],
            "systems": [...],
            "matrix": { prop: { sys: {value, status, reason}, ..., "expected": val } },
            "summary": { total, passed, failed, pass_rate },
            "failures": [ {system, property, expected, actual, reason} ]
        }
    """
    matrix = {}
    failures = []
    total_cells = 0
    passed_cells = 0

    for _, row in rows.iterrows():
        prop = row["property_name"]
        sys = row["system_name"]
        actual = row["actual_value"] if row["actual_value"] is not None else "NULL"
        expected = row["expected"] if row["expected"] is not None else "—"
        status = row["status"]
        reason = row["reason"] if row["reason"] else ""

        if prop not in matrix:
            matrix[prop] = {}

        matrix[prop][sys] = {
            "value": actual,
            "status": status,
            "reason": reason,
        }
        matrix[prop]["expected"] = expected

        total_cells += 1
        if status == "Pass":
            passed_cells += 1
        else:
            failures.append({
                "system": sys,
                "property": prop,
                "expected": expected,
                "actual": actual,
                "reason": reason,
            })

    # Preserve display order — only include properties that came back from SP
    ordered_props = [p for p in DISPLAY_PROPERTIES if p in matrix]

    failed_cells = total_cells - passed_cells
    pass_rate = (passed_cells / total_cells * 100) if total_cells > 0 else 0

    return {
        "properties": ordered_props,
        "systems": SYSTEMS,
        "matrix": matrix,
        "summary": {
            "total": total_cells,
            "passed": passed_cells,
            "failed": failed_cells,
            "pass_rate": round(pass_rate, 1),
        },
        "failures": failures,
    }


# ---------------------------------------------------------------------------
# Main Function: Build Data Elements Matrix
# ---------------------------------------------------------------------------
def get_data_elements_matrix(esn: str, tail: str) -> dict:
    """
    Build the data elements matrix for display.

    Calls the PostgreSQL stored procedure for all heavy lifting.
    Falls back to simulation when DB is unavailable.
    """
    if not is_db_available():
        log.info("DB not available, using simulation")
        return _build_simulated_matrix(esn, tail)

    try:
        rows = _call_sp_matrix(esn, tail)

        if rows is None or rows.empty:
            log.info("No data from SP for ESN=%s, Tail=%s, using simulation", esn, tail)
            return _build_simulated_matrix(esn, tail)

        return _build_matrix_from_sp(rows)

    except Exception as exc:
        log.warning("SP call failed: %s, using simulation", exc)
        return _build_simulated_matrix(esn, tail)


# ---------------------------------------------------------------------------
# Simulation Fallback (unchanged)
# ---------------------------------------------------------------------------
def _build_simulated_matrix(esn: str, tail: str) -> dict:
    """Build a simulated matrix when DB is unavailable."""
    import random

    rng = random.Random(hash(esn + tail) % (2**32 - 1))

    expected_values = {
        "ESN": esn if esn else "000000",
        "Diagnostic Installation Date": "2026-01-29",
        "Diagnostic Tail": tail if tail else "HZ-FAB",
        "Engine Position": "1",
        "Installation Date": "2026-01-29",
        "Last Updated Date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "N1 Modifier": "1000000045",
        "Operator": "15456",
        "Monitor": "TBD",
        "Operator Diagnostic Code": "ODC-001",
        "Tail Number Aircraft ID": tail if tail else "HZ-FAB",
        "Engine Model": "CFM56-7B26",
        "Engine Type": "TURBOFAN",
        "Engine Family Model Series": "CFM56-7B",
        "Aircraft Delivery Date": "2020-05-15",
        "Aircraft Family": "A320",
        "Aircraft Model": "A320-214",
        "Aircraft Series": "200",
        "Installation History": "2024-10-23",
    }

    matrix = {}
    failures = []
    total_cells = 0
    passed_cells = 0

    for prop in DISPLAY_PROPERTIES:
        fa_expected = expected_values.get(prop, "—")
        prop_data = {}

        for sys in SYSTEMS:
            is_1fa = (sys == "1FA")

            if is_1fa:
                if rng.random() < 0.95:
                    actual = fa_expected
                    status = "Pass"
                    reason = ""
                else:
                    actual = "NULL"
                    status = "Fail"
                    reason = "Null value found"
                    failures.append({
                        "system": sys,
                        "property": prop,
                        "expected": fa_expected,
                        "actual": actual,
                        "reason": reason,
                    })
            else:
                pass_rate = 0.85 if sys == "1FDI" else 0.70
                is_pass = rng.random() < pass_rate

                if is_pass:
                    actual = fa_expected
                    status = "Pass"
                    reason = ""
                else:
                    failure_type = rng.choice(["null", "mismatch", "invalid"])
                    if failure_type == "null":
                        actual = "NULL"
                        reason = "Null value found"
                    elif failure_type == "mismatch":
                        actual = f"{fa_expected}-WRONG" if fa_expected != "—" else "WRONG"
                        reason = f"Value mismatch: expected '{fa_expected}' but got '{actual}'"
                    else:
                        actual = "INVALID"
                        reason = f"Value mismatch: expected '{fa_expected}' but got 'INVALID'"
                    status = "Fail"

                    failures.append({
                        "system": sys,
                        "property": prop,
                        "expected": fa_expected,
                        "actual": actual,
                        "reason": reason,
                    })

            prop_data[sys] = {"value": actual, "status": status, "reason": reason}
            total_cells += 1
            if status == "Pass":
                passed_cells += 1

        prop_data["expected"] = fa_expected
        matrix[prop] = prop_data

    failed_cells = total_cells - passed_cells
    pass_rate = (passed_cells / total_cells * 100) if total_cells > 0 else 0

    return {
        "properties": DISPLAY_PROPERTIES,
        "systems": SYSTEMS,
        "matrix": matrix,
        "summary": {
            "total": total_cells,
            "passed": passed_cells,
            "failed": failed_cells,
            "pass_rate": round(pass_rate, 1),
        },
        "failures": failures,
    }


# ---------------------------------------------------------------------------
# V2: Multi-ESN SP calls (pivoted results, DataFrame-driven)
# ---------------------------------------------------------------------------
@conditional_cache
def _call_sp_matrix_v2(esns_csv: str) -> pd.DataFrame:
    """Call sp_get_data_elements_matrix_v2 and return pivoted DataFrame (ESN-only)."""
    sql = "SELECT * FROM sp_get_data_elements_matrix_v2(:esns, NULL)"
    log.info("Calling sp_get_data_elements_matrix_v2(ESNs=%s)", esns_csv)
    result = run_query(sql, {"esns": esns_csv})
    log.info("Matrix v2 SP returned %d rows", len(result) if result is not None else 0)
    return result


@conditional_cache
def _call_sp_failures_v2(esns_csv: str) -> pd.DataFrame:
    """Call sp_get_data_elements_failures_v2 and return failures DataFrame (ESN-only)."""
    sql = "SELECT * FROM sp_get_data_elements_failures_v2(:esns, NULL)"
    log.info("Calling sp_get_data_elements_failures_v2(ESNs=%s)", esns_csv)
    result = run_query(sql, {"esns": esns_csv})
    log.info("Failures v2 SP returned %d rows", len(result) if result is not None else 0)
    return result


def get_data_elements_multi(esns: list) -> dict:
    """
    Multi-ESN data elements — returns DataFrames directly from v2 SPs (ESN-only).

    Returns:
        {
            "matrix_df":   pd.DataFrame (pivoted: esn, property_name, ...),
            "failures_df": pd.DataFrame (flat failures),
            "summary":     { esn_count, properties, passed, failed, pass_rate },
            "esns":        list of ESNs queried,
        }
    """
    esns_csv = ",".join(esns)

    if not is_db_available():
        log.info("DB not available, using simulation for multi-ESN")
        return _build_simulated_multi(esns)

    try:
        matrix_df = _call_sp_matrix_v2(esns_csv)
        failures_df = _call_sp_failures_v2(esns_csv)

        if matrix_df is None or matrix_df.empty:
            log.info("No data from v2 SPs for ESNs=%s, using simulation", esns_csv)
            return _build_simulated_multi(esns)

        # Replace Python None / NaN with display-friendly '--'
        matrix_df = matrix_df.fillna("--")
        if failures_df is None:
            failures_df = pd.DataFrame()
        else:
            failures_df = failures_df.fillna("--")

        # Build summary from matrix_df status columns
        status_cols = ["fa_status", "fdi_status", "phm_status", "fmx_status"]
        total = 0
        passed = 0
        for col in status_cols:
            if col in matrix_df.columns:
                non_null = matrix_df[col][matrix_df[col] != "--"]
                total += len(non_null)
                passed += (non_null == "Pass").sum()
        failed = total - passed
        pass_rate = round((passed / total * 100), 1) if total > 0 else 0.0

        return {
            "matrix_df": matrix_df,
            "failures_df": failures_df,
            "summary": {
                "esn_count": matrix_df["esn"].nunique() if "esn" in matrix_df.columns else len(esns),
                "properties": matrix_df["property_name"].nunique() if "property_name" in matrix_df.columns else 0,
                "passed": int(passed),
                "failed": int(failed),
                "pass_rate": pass_rate,
            },
            "esns": esns,
        }

    except Exception as exc:
        log.warning("V2 SP call failed: %s, using simulation", exc)
        return _build_simulated_multi(esns)


def filter_matrix_df_by_status(df: pd.DataFrame, status_filter: str) -> pd.DataFrame:
    """Filter pivoted matrix DataFrame by All / Pass / Fail."""
    if status_filter == "All" or df.empty:
        return df

    status_cols = ["fa_status", "fdi_status", "phm_status", "fmx_status"]
    existing = [c for c in status_cols if c in df.columns]

    if status_filter == "Pass":
        # Keep rows where ALL present statuses are Pass or '--' (no data)
        mask = df[existing].apply(
            lambda row: all(v in ("Pass", "--") for v in row), axis=1
        )
    else:  # Fail
        # Keep rows where ANY status is Fail
        mask = df[existing].apply(
            lambda row: any(v == "Fail" for v in row), axis=1
        )
    return df[mask].reset_index(drop=True)


def _build_simulated_multi(esns: list) -> dict:
    """Simulation fallback returning the same DataFrame shape as v2 SPs (ESN-only)."""
    import random

    rows = []
    fail_rows = []

    for esn in esns:
        rng = random.Random(hash(esn) % (2**32 - 1))

        for idx, prop in enumerate(DISPLAY_PROPERTIES, start=1):
            expected = esn if prop == "ESN" else f"val_{prop[:8]}"
            row = {
                "esn": esn, "property_name": prop,
                "prop_order": idx, "expected": expected,
            }
            for sys_key, status_key in [
                ("fa_value", "fa_status"), ("fdi_value", "fdi_status"),
                ("phm_value", "phm_status"), ("fmx_value", "fmx_status"),
            ]:
                sys_name = sys_key.replace("_value", "").upper()
                if sys_name == "FA":
                    sys_name = "1FA"
                elif sys_name == "FDI":
                    sys_name = "1FDI"

                if rng.random() < 0.80:
                    row[sys_key] = expected
                    row[status_key] = "Pass"
                else:
                    val = rng.choice(["NULL", "WRONG", ""])
                    row[sys_key] = val if val else "--"
                    row[status_key] = "Fail"
                    fail_rows.append({
                        "esn": esn, "system_name": sys_name,
                        "property_name": prop, "prop_order": idx,
                        "expected": expected, "actual_value": val if val else "--",
                        "status": "Fail",
                        "reason": "Simulated failure",
                    })
            rows.append(row)

    matrix_df = pd.DataFrame(rows)
    failures_df = pd.DataFrame(fail_rows) if fail_rows else pd.DataFrame()

    status_cols = ["fa_status", "fdi_status", "phm_status", "fmx_status"]
    total = 0
    passed = 0
    for col in status_cols:
        if col in matrix_df.columns:
            total += len(matrix_df)
            passed += (matrix_df[col] == "Pass").sum()
    failed = total - passed
    pass_rate = round((passed / total * 100), 1) if total > 0 else 0.0

    return {
        "matrix_df": matrix_df,
        "failures_df": failures_df,
        "summary": {
            "esn_count": len(esns),
            "properties": len(DISPLAY_PROPERTIES),
            "passed": int(passed),
            "failed": int(failed),
            "pass_rate": pass_rate,
        },
        "esns": esns,
    }


# ---------------------------------------------------------------------------
# Legacy Functions (Backward Compatibility)
# ---------------------------------------------------------------------------
def get_data_elements_status(df: pd.DataFrame) -> pd.DataFrame:
    """Return Pass/Fail matrix. (Legacy)"""
    esn = df["engine_serial"].iloc[0] if "engine_serial" in df.columns else "000000"
    tail = df["tail_number"].iloc[0] if "tail_number" in df.columns else "N-DEMO"

    result = get_data_elements_matrix(esn, tail)

    matrix_df = {}
    for prop in result["properties"]:
        matrix_df[prop] = {}
        for sys in result["systems"]:
            matrix_df[prop][sys] = result["matrix"][prop][sys]["status"]

    return pd.DataFrame(matrix_df).T


def get_data_elements_with_values(
    df: pd.DataFrame, engine_serial: str, tail_number: str
) -> dict:
    """Fetch data elements with values. (Legacy)"""
    result = get_data_elements_matrix(engine_serial, tail_number)

    legacy = {}
    for sys in result["systems"]:
        legacy[sys] = {}
        for prop in result["properties"]:
            cell = result["matrix"][prop][sys]
            legacy[sys][prop] = {
                "value": cell["value"],
                "expected": result["matrix"][prop]["expected"],
                "status": cell["status"],
                "reason": cell["reason"],
            }

    return legacy
