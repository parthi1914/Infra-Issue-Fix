import streamlit as st
import pandas as pd

try:
    from sqlalchemy import create_engine, text
except ImportError:
    create_engine = None

from config.settings import get_database_url


def is_db_available() -> bool:
    return create_engine is not None and get_database_url() is not None


@st.cache_resource
def get_engine():
    url = get_database_url()
    return create_engine(
        url,
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=10,
    )


def run_query(sql: str, params: dict | None = None) -> pd.DataFrame:
    engine = get_engine()
    with engine.connect() as conn:
        return pd.read_sql(text(sql), conn, params=params or {})


def run_query_single(sql: str, params: dict | None = None):
    engine = get_engine()
    with engine.connect() as conn:
        row = conn.execute(text(sql), params or {}).fetchone()
    return row[0] if row else None


def run_query_list(sql: str, params: dict | None = None) -> list:
    engine = get_engine()
    with engine.connect() as conn:
        rows = conn.execute(text(sql), params or {}).fetchall()
    return [r[0] for r in rows]
