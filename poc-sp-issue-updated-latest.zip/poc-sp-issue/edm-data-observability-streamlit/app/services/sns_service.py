"""
SNS Service for sending alert notifications via AWS SNS.
"""
import boto3
import json
import logging
import os
import warnings
from datetime import datetime
from typing import Dict, List, Optional

# Suppress SSL warnings for corporate proxy environments
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    import streamlit as st
    HAS_STREAMLIT = True
except ImportError:
    HAS_STREAMLIT = False

log = logging.getLogger(__name__)

# ===========================================================================
# SNS Configuration
# ===========================================================================
# SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:395527390279:av-edm-streamlit-alert"
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:395527390279:av-edm-streamlit-alert"

AWS_REGION = "us-east-1"

# ===========================================================================
# Hardcoded AWS Credentials (for deployment/development)
# Fresh SAML credentials - expires 2026-02-12T04:43:32+00:00
# ===========================================================================
_HARDCODED_AWS = {
    "access_key_id": "ASIAVYF2FARDTHRZNSNI",
    "secret_access_key": "FU+cz8q3AzbBzsPihTeK21N36bJxlxE6czEP/1ee",
    "session_token": "IQoJb3JpZ2luX2VjEA4aCXVzLWVhc3QtMSJHMEUCIQDS9F3uz0VNvkIzj95dO1a4fbDJm9wWXsr5JmsW1TzDJQIgLViKhUYt5A7c3bQVS/8btRC1bPsSQkeAapT4/mtiCiQqigMI1///////////ARADGgwzOTU1MjczOTAyNzkiDBzQnBz2y3NIxH5YFCreApkU7vfkOFvY8w13aOTxz1TSVwYSFvKitec+Gu6KwfocOzmA0C7iM1rbbI8weCFk5Z3kRy2Y6KoGYzhM8k8BrAo6YVOI1UTMbl/YfZ8PVMwJaPTylVqRH3KpF6T4bXTl9ImgoWx6PL6W3aASSOM0uiyHD8dq8ezYbHA92k/vn40oTDjOjfW1+WZmeC6/n+6cHG8vLnoC9GNwvTinUilzUslNo0blPuoxjMIaPsVHsx2W56beyB1tp0JhqDs+m0EZFqBmYa/HKkSuxgngToUVbzkNIkgK9FR5Qrf/dehSDRfSlCaK+vSCwymPLjlJhrsqPw4c3Y18Lv8Xm5KCO2KW4MZdhcK0HmmCAmrsBDaZVIU7I94FKW2Cy9Z7GzLSxmek6/rrBI/Ey5ALAB4Vp14+TY7zDrDDFVTuXs5s2uNuFjrVs4rU0s535EouoR2GIzdft8NXlEc6aDJW0jtyzDNlMMa0t8wGOpgBFIOd7aHMiJb7NGQkYqcQYIulYSmeHpKkVyPqueE24g+JjGE1Z3nS2X2xQrgYnUWKhBL2JG/0BWmr8NHQS30BYVbeAkWNZRP/zEFxZprtBj4FojziWwoCNoUCTz9rLiQSLTF2K2u52YKlSxfLnpEvlFOxj953nHK6vf7KU2Aa7fD2HjhsVHO0MoUY8PJrk0/Mih/FaFRnktc=",
    "region": "us-east-1",
}

# Set to True to use hardcoded credentials above
_USE_HARDCODED = True  # Using hardcoded SAML credentials


def get_sns_client():
    """
    Get boto3 SNS client with credentials from multiple sources.
    
    Tries in order:
    1. Hardcoded credentials (if _USE_HARDCODED = True)
    2. Streamlit secrets (aws section)
    3. Environment variables
    4. AWS SSO/default profile
    5. Default credentials chain (IAM role, ~/.aws/credentials)
    """
    # Import botocore config to disable SSL verification (corporate proxy workaround)
    from botocore.config import Config
    
    # Config to handle corporate proxy SSL issues
    boto_config = Config(
        signature_version='v4',
        retries={'max_attempts': 3, 'mode': 'standard'}
    )
    
    try:
        # Method 0: Use hardcoded credentials (highest priority when enabled)
        if _USE_HARDCODED and _HARDCODED_AWS.get("access_key_id") and _HARDCODED_AWS["access_key_id"] != "YOUR_ACCESS_KEY_ID":
            client_kwargs = {
                "region_name": _HARDCODED_AWS.get("region", AWS_REGION),
                "aws_access_key_id": _HARDCODED_AWS["access_key_id"],
                "aws_secret_access_key": _HARDCODED_AWS["secret_access_key"],
                "verify": False,  # Disable SSL verification for corporate proxy
                "config": boto_config,
            }
            if _HARDCODED_AWS.get("session_token"):
                client_kwargs["aws_session_token"] = _HARDCODED_AWS["session_token"]
            
            log.info("Using hardcoded AWS credentials for SNS")
            return boto3.client("sns", **client_kwargs)
        
        # Method 1: Try streamlit secrets (supports temporary credentials with session_token)
        if HAS_STREAMLIT:
            try:
                aws_cfg = dict(st.secrets.get("aws", {}))
                if aws_cfg.get("access_key_id") and aws_cfg.get("secret_access_key"):
                    # Build client kwargs
                    client_kwargs = {
                        "region_name": aws_cfg.get("region", AWS_REGION),
                        "aws_access_key_id": aws_cfg["access_key_id"],
                        "aws_secret_access_key": aws_cfg["secret_access_key"],
                        "verify": False,  # Disable SSL verification for corporate proxy
                        "config": boto_config,
                    }
                    # Add session token if present (for temporary credentials)
                    if aws_cfg.get("session_token"):
                        client_kwargs["aws_session_token"] = aws_cfg["session_token"]
                    
                    return boto3.client("sns", **client_kwargs)
            except Exception:
                pass
        
        # Method 2: Try SAML profile (corporate federated login) - PRIORITY!
        try:
            session = boto3.Session(profile_name='saml', region_name=AWS_REGION)
            client = session.client("sns", verify=False, config=boto_config)
            log.info("Using SAML profile for SNS")
            return client
        except Exception as e:
            log.debug(f"SAML profile failed: {e}")
        
        # Method 3: Try environment variables
        access_key = os.environ.get("AWS_ACCESS_KEY_ID")
        secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
        if access_key and secret_key:
            return boto3.client(
                "sns",
                region_name=os.environ.get("AWS_REGION", AWS_REGION),
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                verify=False,  # Disable SSL verification for corporate proxy
                config=boto_config,
            )
        
        # Method 4: Try default AWS profile (works with SSO after `aws sso login`)
        try:
            session = boto3.Session(region_name=AWS_REGION)
            client = session.client("sns", verify=False, config=boto_config)
            # Test the client by getting topic attributes
            client.get_topic_attributes(TopicArn=SNS_TOPIC_ARN)
            return client
        except Exception as e:
            log.debug(f"Default session failed: {e}")
        
        # Method 5: Try specific profile names commonly used
        for profile in [None, "default", "sso"]:
            try:
                session = boto3.Session(profile_name=profile, region_name=AWS_REGION)
                client = session.client("sns", verify=False, config=boto_config)
                return client
            except Exception:
                continue
        
        # Final fallback
        return boto3.client("sns", region_name=AWS_REGION, verify=False, config=boto_config)
        
    except Exception as e:
        log.error(f"Failed to create SNS client: {e}")
        return None


def send_error_alert(
    engine_serial: str,
    tail_number: str,
    operator_code: str,
    failed_systems: List[Dict],
) -> Dict:
    """
    Send error alert notification to SNS topic.
    
    Args:
        engine_serial: ESN identifier
        tail_number: Tail number (diagnostic_tail)
        operator_code: Operator code
        failed_systems: List of failed system details
    
    Returns:
        Dict with status and message
    """
    try:
        client = get_sns_client()
        if not client:
            return {"success": False, "message": "Failed to connect to AWS SNS"}
        
        # Build alert message
        now = datetime.utcnow()
        
        # Format failed systems details with clean styling
        failed_details = []
        for idx, sys_info in enumerate(failed_systems, 1):
            system_name = sys_info.get('system', 'Unknown')
            reason = sys_info.get('reason', 'Data flow interruption detected')
            last_update = sys_info.get('last_update', 'N/A')
            failed_details.append(
                f"    [{idx}] {system_name}\n"
                f"        Status: CRITICAL - FAILURE DETECTED\n"
                f"        Issue: {reason}\n"
                f"        Last Successful Update: {last_update}"
            )
        
        failed_systems_text = "\n\n".join(failed_details) if failed_details else "    No specific failure details available"
        
        # Count of failed systems for severity
        failure_count = len(failed_systems)
        severity = "CRITICAL" if failure_count >= 3 else "HIGH" if failure_count >= 2 else "MEDIUM"
        
        # Build HTML table rows for failed systems
        failed_rows = "".join([
            f"<tr><td>{idx+1}</td><td>{sys_info.get('system','Unknown')}</td><td>CRITICAL - FAILURE DETECTED</td><td>{sys_info.get('reason','Data flow interruption detected')}</td><td>{sys_info.get('last_update','N/A')}</td></tr>"
            for idx, sys_info in enumerate(failed_systems)
        ])

        # Build the message body with enterprise HTML formatting
        message_body = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <style>
    body {{ font-family: 'Segoe UI', Arial, sans-serif; color: #222; background: #f7f7fa; }}
    .header {{ background: #003366; color: #fff; padding: 24px 0; text-align: center; font-size: 22px; font-weight: 700; letter-spacing: 1px; }}
    .subheader {{ background: #e5eaf5; color: #003366; padding: 8px 0; text-align: center; font-size: 16px; font-weight: 600; border-bottom: 2px solid #003366; }}
    .section {{ margin: 24px 0 0 0; }}
    .section-title {{ background: #f0f4f8; color: #003366; font-size: 15px; font-weight: 700; padding: 8px 16px; border-left: 4px solid #003366; margin-bottom: 8px; }}
    .info-table {{ width: 100%; border-collapse: collapse; margin-bottom: 16px; }}
    .info-table td {{ padding: 8px 12px; border-bottom: 1px solid #e5eaf5; font-size: 14px; }}
    .info-table th {{ background: #e5eaf5; color: #003366; font-weight: 600; padding: 8px 12px; font-size: 14px; }}
    .fail-table th {{ background: #ffe5e5; color: #b30000; }}
    .fail-table td {{ background: #fff6f6; color: #b30000; }}
    .footer {{ background: #e5eaf5; color: #003366; text-align: center; padding: 16px 0; font-size: 13px; margin-top: 32px; border-top: 2px solid #003366; }}
  </style>
</head>
<body>
  <div class='header'>GE Aerospace - EDM Data Observability Platform</div>
  <div class='subheader'>Automated Alert Notification</div>

  <div class='section'>
    <div class='section-title'>Alert Summary</div>
    <table class='info-table'>
      <tr><th>Alert Type</th><td>Data Pipeline Failure</td></tr>
      <tr><th>Severity Level</th><td>{severity}</td></tr>
      <tr><th>Alert Time</th><td>{now.strftime('%B %d, %Y at %H:%M:%S')} UTC</td></tr>
      <tr><th>Reference ID</th><td>EDM-{now.strftime('%Y%m%d%H%M%S')}</td></tr>
    </table>
  </div>

  <div class='section'>
    <div class='section-title'>Asset Information</div>
    <table class='info-table'>
      <tr><th>Engine Serial Number (ESN)</th><td>{engine_serial}</td></tr>
      <tr><th>Aircraft Tail Number</th><td>{tail_number}</td></tr>
      <tr><th>Operator Code</th><td>{operator_code or 'Not Specified'}</td></tr>
    </table>
  </div>

  <div class='section'>
    <div class='section-title'>System Failure Details ({failure_count} System{'s' if failure_count != 1 else ''})</div>
    <table class='info-table fail-table'>
      <tr><th>#</th><th>System</th><th>Status</th><th>Issue</th><th>Last Successful Update</th></tr>
      {failed_rows}
    </table>
  </div>

  <div class='section'>
    <div class='section-title'>Recommended Actions</div>
    <ul style='font-size:14px;color:#003366;'>
      <li>Review the affected system(s) data pipeline status</li>
      <li>Check upstream data source connectivity</li>
      <li>Verify data transformation processes are running</li>
      <li>Escalate to Data Engineering team if issue persists</li>
    </ul>
  </div>

  <div class='section'>
    <div class='section-title'>Contact & Support</div>
    <table class='info-table'>
      <tr><th>Data Engineering Team</th><td>edm-support@geaerospace.com</td></tr>
      <tr><th>Dashboard URL</th><td>EDM Data Observability Portal</td></tr>
    </table>
  </div>

  <div class='footer'>
    This is an automated notification from the EDM Data Observability Platform.<br>
    Please do not reply directly to this message.<br><br>
    &copy; {now.year} GE Aerospace. All rights reserved.
  </div>
</body>
</html>
"""
        # Build professional subject line
        subject = f"[{severity}] EDM Alert: Data Pipeline Failure Detected - ESN {engine_serial} | Aircraft {tail_number}"

        # Build professional plain text message
        plain_text = f"""
GE Aerospace - EDM Data Observability Platform
Automated Alert Notification

Alert Summary:
  Alert Type: Data Pipeline Failure
  Severity Level: {severity}
  Alert Time: {now.strftime('%B %d, %Y at %H:%M:%S')} UTC
  Reference ID: EDM-{now.strftime('%Y%m%d%H%M%S')}

Asset Information:
  Engine Serial Number (ESN): {engine_serial}
  Aircraft Tail Number: {tail_number}
  Operator Code: {operator_code or 'Not Specified'}

System Failure Details ({failure_count} System{'s' if failure_count != 1 else ''}):
"""
        for idx, sys_info in enumerate(failed_systems, 1):
            plain_text += f"  {idx}. System: {sys_info.get('system','Unknown')}, Status: CRITICAL - FAILURE DETECTED, Issue: {sys_info.get('reason','Data flow interruption detected')}, Last Successful Update: {sys_info.get('last_update','N/A')}\n"
        if not failed_systems:
            plain_text += "  No specific failure details available\n"
        plain_text += """

Recommended Actions:
  - Review the affected system(s) data pipeline status
  - Check upstream data source connectivity
  - Verify data transformation processes are running
  - Escalate to Data Engineering team if issue persists

Contact & Support:
  Data Engineering Team: edm-support@geaerospace.com
  Dashboard URL: EDM Data Observability Portal

This is an automated notification from the EDM Data Observability Platform.
Please do not reply directly to this message.
© {now.year} GE Aerospace. All rights reserved.
"""

        response = client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=plain_text,
            Subject=subject,
            MessageAttributes={
                "AlertType": {
                    "DataType": "String",
                    "StringValue": "DataPipelineFailure"
                },
                "ESN": {
                    "DataType": "String",
                    "StringValue": engine_serial
                },
                "TailNumber": {
                    "DataType": "String",
                    "StringValue": tail_number
                },
                "Severity": {
                    "DataType": "String",
                    "StringValue": severity
                },
                "FailedSystems": {
                    "DataType": "Number",
                    "StringValue": str(failure_count)
                }
            }
        )

        message_id = response.get("MessageId", "")
        log.info(f"Alert sent successfully. MessageId: {message_id}")

        return {
            "success": True,
            "message": f"Alert sent successfully! Message ID: {message_id}",
            "message_id": message_id
        }
        
    except Exception as e:
        log.error(f"Failed to send SNS alert: {e}")
        return {
            "success": False,
            "message": f"Failed to send alert: {str(e)}"
        }


def test_sns_connection() -> bool:
    """Test if SNS connection is working."""
    try:
        client = get_sns_client()
        if client:
            # Try to get topic attributes to verify connection
            client.get_topic_attributes(TopicArn=SNS_TOPIC_ARN)
            return True
    except Exception as e:
        log.error(f"SNS connection test failed: {e}")
    return False
